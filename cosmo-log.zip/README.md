# cosmo-log — Spring Boot 構造化ログ サンプル実装

`ログ設計書.md`（顧客設計書 **SSD-010 処理方式設計書** 反映済み）の設計を Spring Boot (Gradle) で実装したサンプル。
ログ種類ごとの**固定ロガー名 (`logger_name`)** で **32項目を構造化(JSON)** 出力し、
**stdout / stderr に振り分けて** CloudWatch Logs に収集させる。

- 出力先は **stdout / stderr**（ファイル出力ではない）。ERROR→stderr、それ以外→stdout（`LevelFilter`）。
- ログ種類の区別は `logger_name` のJSONフィールドで行う（appenderは stdout/stderr の2本）。
- 設計の根拠・項目定義・出力対象ログマトリクスは [`ログ設計書.md`](./ログ設計書.md) を参照。

## ドキュメント / 設計書（EPUB）

3レベル（要件・項目定義 / 設計書 / 実装ガイド）のMarkdownを `book/` に置き、出先で読めるEPUBにまとめている。未確定は **(TODO)** で明示。

| 成果物 | 内容 |
|---|---|
| `book/01_要件・項目定義（Excel資料レベル）.md` | ログ種類・項目定義・取得方法・出力対象マトリクス |
| `book/02_設計書（Markdownレベル）.md` | スコープ・MDC・出力基盤・部品設計 |
| `book/03_実装ガイド（実装レベル）.md` | logback/appender・MDCスコープ・ECS取得(Java+sh)・各部品コード |
| `Springbootログ設計書.epub` | 上記3部を1冊にしたEPUB（Apple Books等で閲覧） |
| `ログ設計.xlsx` | 上流共有用のExcel（`make xlsx` で生成） |

ワークフロー：**`book/` のMarkdownを編集 → `make book` → `open "Springbootログ設計書.epub"`（Apple Booksで確認）**。

```bash
make book    # EPUB を再生成（要 pandoc）
make xlsx    # Excel を生成（要 python3 + openpyxl）
make docs    # 両方
make clean   # 生成物を削除
```

---

## 1. 全体像

```
                         ┌─────────────────────────── HTTPリクエスト ───────────────────────────┐
                         │                                                                      │
   traceparent / X-User-Id / X-Forwarded-For                                                     │
                         ▼                                                                      │
            ┌───────────────────────────┐                                                       │
            │   HttpLoggingFilter        │  ① MDC設定: trace_id/user/source_ip/function/action  │
            │  (OncePerRequestFilter)    │  ② req/resp を ContentCaching でラップ                │
            └───────────────────────────┘                                                       │
                         │ chain.doFilter                                                        │
                         ▼                                                                      │
            ┌───────────────────────────┐                                                       │
            │  SampleController          │                                                       │
            └───────────────────────────┘                                                       │
                         ▼                                                                      │
            ┌───────────────────────────┐   ServiceJournalAspect (@Around @Service)             │
            │  SampleService (@Service)  │── 開始/終了/エラー のジャーナルを出力 ───────────────┐ │
            └───────────────────────────┘                                                     │ │
                         │  appLogger.info(...)                                                │ │
                         ▼                                                                     │ │
            ┌───────────────────────────┐                                                     │ │
            │  ApplicationLogger         │── 業務ログ / 業務エラーログ ────────────────────────┤ │
            └───────────────────────────┘                                                     │ │
                         │                                                                     │ │
   ① 戻りで HttpLoggingFilter が                                                               │ │
      アクセスジャーナル(要求/応答)を出力 ──────────────────────────────────────────────────┘ │
      finally で MDC クリア ──────────────────────────────────────────────────────────────────┘

   すべてのログ → StructuredLog(Marker) + 固定ロガー名 → logback → stdout(ERROR以外)/stderr(ERROR) → CloudWatch Logs
```

---

## 2. 32項目はどこから来るか（供給元の4系統）

設計の「スコープ」をそのまま実装の供給経路に対応させている。

| 供給元 | 項目 | 実装箇所 |
|---|---|---|
| **logback 組み込み provider** | timestamp, level, level_value, logger_name, thread, message, stack_trace | `logback/appender-*.xml` の `<providers>` |
| **独自 provider**（アプリスコープ） | id, name | `ContainerInfoJsonProvider` ← `ContainerInfoProvider`（起動時1回取得） |
| **MDC**（実行単位スコープ） | function, user, action, trace_id, source_ip | `HttpLoggingFilter` が set → finally で clear |
| **Marker**（ログイベント/メソッド/AWS呼び出しスコープ） | type, subtype, url, status, headers, body, class_name, method_name, args, result, bucket_name, path, latency, aws_* | `StructuredLog` ビルダー |

> ポイント：MDC に載せるのは「複数ログで使い回す実行単位スコープの値」だけ。
> その場で確定する値・logback が持つ値・固定値・AWS呼び出し結果は Marker で出力時に付与する。

---

## 3. クラス構成

```
src/main/java/com/example/cosmolog/
├── CosmoLogApplication.java                  … エントリポイント
├── logging/
│   ├── LoggerNames.java                       … 固定ロガー名(12種)の定数
│   ├── LogType.java / LogSubtype.java         … type / subtype の定数
│   ├── MdcKeys.java                           … MDCキー(function/user/action/trace_id/source_ip)
│   ├── LogFields.java                         … Markerで付与する項目の物理名
│   ├── StructuredLog.java                     … 項目を組み立てて Marker 化するビルダー
│   ├── LoggingProperties.java                 … @ConfigurationProperties(logging.custom.*)
│   ├── ApplicationLogger.java                 … 業務ログ / 業務エラーログ出力部品
│   ├── container/
│   │   ├── ContainerInfo.java                 … id/name の静的保持(全スレッド共通)
│   │   └── ContainerInfoProvider.java         … 起動時に ECS Task ID / Service名 を取得
│   ├── logback/
│   │   └── ContainerInfoJsonProvider.java     … 全ログに id/name を付与する provider
│   ├── mask/
│   │   └── LogMaskingService.java             … headers/body/args/result/message/url のマスク・切詰め
│   ├── async/
│   │   ├── MdcTaskDecorator.java              … MDC を子スレッド/非同期へ伝播
│   │   └── AsyncConfig.java                   … @EnableAsync + Decorator付Executor
│   ├── aws/
│   │   ├── AwsResponseMetadataExtractor.java  … aws_request_id / 拡張ID 抽出の共通部品
│   │   ├── S3AccessService.java               … S3アクセス → ストレージジャーナル
│   │   ├── SqsAccessService.java              … SQS送受信 → メッセージジャーナル
│   │   ├── KmsAccessService.java              … KMS暗号/復号 → KMSジャーナル
│   │   └── DynamoDbAccessService.java         … DynamoDB Get/Put → DynamoDBジャーナル
│   ├── mybatis/
│   │   └── SqlJournalInterceptor.java         … SQL実行 → DBCALLジャーナル(参照実装)
│   ├── scope/                                 … 実行区分別の実行単位スコープ起点（MDC）
│   │   ├── ExecutionScopeMdc.java             …   共通：MDC set/clear(try-with-resources)
│   │   ├── online/                            …   【API】
│   │   │   ├── HttpLoggingFilter.java         …     HTTPリクエスト起点 + アクセスログ/ジャーナル
│   │   │   └── FunctionActionResolver.java    …     function / action 解決
│   │   ├── batch/BatchLogScope.java           …   【バッチ】ジョブ起点
│   │   └── resident/MessageLogScope.java      …   【常駐バッチ】メッセージ処理起点
│   ├── web/                                   … 外部HTTPジャーナル（全区分共通）
│   │   ├── HttpClientJournalInterceptor.java  …   外部HTTP → 外部アクセスジャーナル
│   │   └── RestClientConfig.java              …   上記Interceptor付き RestTemplate
│   └── aspect/
│       ├── ServiceJournalAspect.java          … @Service の開始/終了/エラー ジャーナル
│       └── CacheJournalAspect.java            … @Cacheable → キャッシュジャーナル
└── demo/                                      … 動作確認用(API/バッチ/常駐の起点デモ含む)

src/main/resources/
├── application.yml                            … LoggingProperties へバインド
├── logback-spring.xml                         … include + logger_name→appender 振り分け
└── logback/
    ├── appender-stdout.xml                     … STDOUT(ERROR以外) ConsoleAppender + JSON encoder
    └── appender-stderr.xml                     … STDERR(ERRORのみ) ConsoleAppender + JSON encoder
```

---

## 4. ログ種類 → ロガー名 → 出力（stdout / stderr）

`logback-spring.xml` が stdout / stderr の2本の appender を `<include>` し、各 `logger_name` の `<logger>` で振り分ける。

出力先は全て **stdout（ERROR以外）/ stderr（ERROR）**。ログ種類は `logger_name` で区別する。レベルは SSD-010 準拠。

| ログ種類 | logger_name | レベル | 出力する部品 |
|---|---|---|---|
| アクセスログ | SPRINGBOOT_API_ACCESS_LOG | INFO | `HttpLoggingFilter`（サマリ1件） |
| アクセスジャーナル | SPRINGBOOT_API_ACCESS_JNL_LOG | INFO | `HttpLoggingFilter`（要求/応答） |
| サービスジャーナル | SPRINGBOOT_SERVICE_JNL_LOG | INFO | `ServiceJournalAspect` |
| SQLジャーナル | SPRINGBOOT_SQL_JNL_LOG | INFO | `SqlJournalInterceptor`（MyBatis・参照実装） |
| ストレージアクセスジャーナル | SPRINGBOOT_STORAGE_JNL_LOG | INFO | `S3AccessService` |
| 外部アクセスジャーナル | SPRINGBOOT_HTTP_CLIENT_JNL_LOG | INFO | `HttpClientJournalInterceptor` |
| キャッシュジャーナル | SPRINGBOOT_CACHE_JNL_LOG | INFO | `CacheJournalAspect` |
| メッセージジャーナル(SQS) | SPRINGBOOT_SQS_JNL_LOG | DEBUG/INFO/WARN | `SqsAccessService` |
| KMSアクセスジャーナル | SPRINGBOOT_KMS_JNL_LOG | INFO | `KmsAccessService` |
| DynamoDBアクセスジャーナル | SPRINGBOOT_DYNAMODB_JNL_LOG | INFO | `DynamoDbAccessService` |
| 業務ログ | SPRINGBOOT_API_LOG | DEBUG/INFO/WARN | `ApplicationLogger#info` |
| 業務エラーログ | SPRINGBOOT_ERROR_LOG | ERROR | `ApplicationLogger#error` |
| システムログ | （固定名なし・root） | INFO〜ERROR | 明示出力なし（Spring/Tomcat等のFW） |

> appender は `logback/appender-stdout.xml`（ERROR以外）と `logback/appender-stderr.xml`（ERRORのみ）を
> `logback-spring.xml` が include し、各 `logger_name` は両方を参照する（レベルで自動振り分け）。
> type/subtype は `TypeSubtypeJsonProvider` が付与（type=レベル判定、subtype=logger_name導出）。
> **システムログ**=固定ロガーに該当しない root のログ（明示出力していないFW等）。

> appender は stdout / stderr の2本のみ（`logback/appender-stdout.xml` / `appender-stderr.xml` を include）。
> ログ種類は `logger_name` のJSONフィールドで区別する。新ログ種類の追加は「logger_name 定数追加 → `<logger>` 1行」。

---

## 5. ビルドと実行

> 必要環境: **JDK 17**。Gradle ラッパー(`gradlew`)は未同梱のため、初回のみ生成する。

```bash
# 1) Gradle ラッパー生成（gradle 本体 or IDE のGradle連携が必要。一度だけ）
gradle wrapper --gradle-version 8.7

# 2) 起動
./gradlew bootRun
```

ログは **stdout / stderr に 1行JSON** で出る（ERRORは stderr）。`bootRun` のコンソールに表示される。
本番(ECS)では CloudWatch Logs が stdout/stderr を収集する。logger_name でログ種類を抽出する。

### 動作確認

```bash
# 業務ログ + サービスジャーナル(開始/終了) + アクセスログ + アクセスジャーナル(要求/応答)
curl -s "http://localhost:8080/api/orders/1" \
  -H "traceparent: trace-abc" -H "X-User-Id: user-001"

# リクエストボディの password がマスクされることを確認
curl -s -X POST "http://localhost:8080/api/orders" \
  -H "Content-Type: application/json" \
  -d '{"id":"9","customer":"山田太郎","amount":500,"password":"p@ss"}'

# 業務エラーログ(stack_trace付き / SPRINGBOOT_ERROR_LOG) + サービスジャーナル(エラー)
curl -s "http://localhost:8080/api/orders/error"

# キャッシュジャーナル(CACHE_JNL)。1回目はメソッド実行、2回目はキャッシュヒット
curl -s "http://localhost:8080/api/price/SKU-1"
curl -s "http://localhost:8080/api/price/SKU-1"

# 外部アクセスジャーナル(HTTP_CLIENT_JNL)。外部疎通が必要
curl -s "http://localhost:8080/api/external?url=https://example.com"
```

> S3(`S3AccessService`) / SQS(`SqsAccessService`) は AWS 実環境(認証・リージョン)が必要なため
> デモのHTTP経路からは呼び出していない。`StructuredLog` + 固定ロガー名のパターンは他部品と同一。
> SQL(`SqlJournalInterceptor`) は MyBatis 依存を `compileOnly` にした参照実装で、実DB接続時に登録する。

---

## 6. 出力イメージ

`GET /api/orders/1`（`traceparent: trace-abc`, `X-User-Id: user-001`）で **stdout** に出る1行JSON（抜粋）。

サービスジャーナル（`logger_name=SPRINGBOOT_SERVICE_JNL_LOG`）:
```json
{"timestamp":"2026-06-05 16:20:00.123","level":"INFO","level_value":20000,
 "logger_name":"SPRINGBOOT_SERVICE_JNL_LOG","thread":"http-nio-8080-exec-1",
 "message":"service journal (start)","id":"<task-id>","name":"cosmo-log",
 "trace_id":"trace-abc","user":"user-001","source_ip":"127.0.0.1",
 "function":"orders","action":"GET /api/orders/1",
 "type":"app","subtype":"APL",
 "class_name":"com.example.cosmolog.demo.SampleService","method_name":"getOrder","args":["1"]}
```

業務ログ（`logger_name=SPRINGBOOT_API_LOG`。発生元 class_name/method_name は StackWalker で自動取得）:
```json
{"timestamp":"...","level":"INFO","level_value":20000,"logger_name":"SPRINGBOOT_API_LOG",
 "thread":"http-nio-8080-exec-1","message":"注文を取得しました id=1","id":"...","name":"cosmo-log",
 "trace_id":"trace-abc","user":"user-001","source_ip":"127.0.0.1","function":"orders","action":"GET /api/orders/1",
 "type":"app","subtype":"APL",
 "class_name":"com.example.cosmolog.demo.SampleService","method_name":"getOrder"}
```

アクセスジャーナル 応答（`logger_name=SPRINGBOOT_API_ACCESS_JNL_LOG`）:
```json
{"timestamp":"...","logger_name":"SPRINGBOOT_API_ACCESS_JNL_LOG","message":"access journal (response)",
 "trace_id":"trace-abc","function":"orders","action":"GET /api/orders/1","source_ip":"127.0.0.1",
 "type":"app","subtype":"APL","url":"GET /api/orders/1","status":200,
 "headers":{"Content-Type":"application/json"},"body":"{\"id\":\"1\",...}","latency":12}
```

---

## 7. 設定（application.yml）

`LoggingProperties` にバインドされ、マスク・切詰めに使われる。

```yaml
logging:
  custom:
    body-max-length: 2048          # body/args/result の最大長
    message-max-length: 4096       # message の最大長
    mask-header-names:             # 値を *** にするヘッダー
      - authorization
      - cookie
      - set-cookie
      - x-api-key
    mask-body-keys:                # "key":"value" / key=value を *** にするキー
      - password
      - secret
      - token
      - accessKey
      - secretKey
```

---

## 8. 部品追加の共通パターン

全ジャーナル部品は**「`StructuredLog` で固有項目を組み立て、固定ロガー名の `Logger` に出力する」**だけ。
function/user/action/trace_id/source_ip は MDC から、id/name は provider から自動付与されるため、
各部品は**そのログ固有の項目だけ**を組み立てればよい（例: `S3AccessService`）。

```java
private static final Logger log = LoggerFactory.getLogger(LoggerNames.STORAGE_JNL);

log.info(StructuredLog.of(LogType.APP, LogSubtype.AWSCALL)
        .put(LogFields.BUCKET_NAME, bucket)
        .put(LogFields.PATH, key)
        .put(LogFields.AWS_REQUEST_ID, meta.requestId())
        .put(LogFields.AWS_S3_EXTENDED_REQUEST_ID, meta.extendedRequestId())
        .put(LogFields.LATENCY, latencyMs)
        .marker(), "storage journal");
```

### 残りの未実装（設計の論点が先）

| 部品 | 状況 |
|---|---|
| KmsAccessService / DynamoDbAccessService | AWSメタデータ抽出は `AwsResponseMetadataExtractor` を流用可能だが、**出力先ログ種類(logger_name)が設計未定義**。決定後に実装する。 |
| AuroraDBアクセス | SQLジャーナルは `SqlJournalInterceptor` でカバー（実DB接続時に登録）。 |

---

## 9. 注意・未確定事項

- **本環境ではコンパイル/起動は未検証**（JDK/Gradle未導入）。コードはレビュー済みだが、初回ビルド時に依存解決を要確認。
- `type` / `subtype` のログ種類ごとの割当は設計書で未確定の箇所があり、本サンプルは `app`/`APL`・`monitor`/`APL` 等で仮置き（各 `StructuredLog.of(...)` 呼び出しで指定）。確定値が決まれば呼び出し箇所を直すだけ。
- `function` は実装上「実行単位スコープ＝リクエスト中のみ」MDCに存在するため、起動時やリクエスト外のシステムログには付与されない（バッチ/常駐バッチでは各起点でMDC設定する想定）。
- `latency` と `aws_response_time` の重複は設計書セクション9の論点のまま（未確定）。`aws_request_timestamp` / `aws_response_time` は設計マトリクスで△(案)。
- **SQLジャーナルの固定ロガー名 `SPRINGBOOT_SQL_JNL_LOG` は顧客設計書(SSD-010)で定義済み**。**KMS / DynamoDB** も `SPRINGBOOT_KMS_JNL_LOG` / `SPRINGBOOT_DYNAMODB_JNL_LOG`（AWSCALL）として追加定義・実装済み（マトリクスL〜Z外の追加ログ種類）。
- 元資料(SSD-010)に **`pid`（プロセスID）** 項目があるが合意済み32項目に含まれない（採否要確認）。
- AWS SDK(S3/SQS) はクライアントを遅延生成し、デモ経路からは呼ばないため起動時にAWS認証は不要。実呼び出し時のみ認証/リージョン解決が走る。
