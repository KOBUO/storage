#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ログ設計.xlsx を生成する（Excelシート構成計画.md の5シート構成）。
要確認は専用シートを作らず、各シートの「備考/要確認」欄に記載する。"""
from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

ITAL = Font(italic=True, color="555555", size=10)


def note(cell, text):
    """セルにコメント（説明）を付ける。"""
    c = Comment(text, "設計")
    c.width = 360
    c.height = 170
    cell.comment = c

HEAD_FILL = PatternFill("solid", fgColor="4472C4")
HEAD_FONT = Font(color="FFFFFF", bold=True)
SUB_FILL = PatternFill("solid", fgColor="D9E1F2")
YEL = PatternFill("solid", fgColor="FFF2CC")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(vertical="top", wrap_text=True)
CENTER = Alignment(horizontal="center", vertical="center")

COLS = ["L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
ALL = set(COLS)

# 物理名 -> (論理名, 概要, 必須, デフォルト, サンプル, 取得方法, MDC, MDCキー, スコープ, 備考/要確認, present, tri)
ITEMS = [
    ("timestamp", "タイムスタンプ", "ログ出力時のサーバ時刻(JST)", "必須", "(必ず設定)", "2026-02-20 12:34:34.123",
     "logback encoder。@timestamp→timestamp、yyyy-MM-dd HH:mm:ss.SSS/Asia/Tokyo", "不要", "", "ログイベント", "", ALL, set()),
    ("id", "コンテナID", "ECS Task ID", "必須", "(必ず設定)", "1b2c3d4e…",
     "ECSメタデータ(ECS_CONTAINER_METADATA_URI_V4 +/task)を起動時1回取得しキャッシュ/entrypoint.sh", "不要", "", "アプリケーション", "", ALL, set()),
    ("name", "コンテナ名", "ECS Service名", "必須", "(必ず設定)", "my-service",
     "ECSメタデータ または 環境変数。起動時1回取得", "不要", "", "アプリケーション", "", ALL, set()),
    ("level", "ログレベル", "DEBUG/INFO/WARN/ERROR", "必須", "(必ず設定)", "INFO",
     "LoggingEvent#getLevel()", "不要", "", "ログイベント", "", ALL, set()),
    ("level_value", "ログレベル値", "レベルの数値表現", "必須", "(必ず設定)", "20000",
     "getLevel().toInt() (DEBUG10000/INFO20000/WARN30000/ERROR40000)", "不要", "", "ログイベント", "", ALL, set()),
    ("logger_name", "ロガー名", "ログ種類ごとの固定ロガー名", "必須", "(必ず設定)", "SPRINGBOOT_API_LOG",
     "LoggerFactory.getLogger(\"SPRINGBOOT_xxx\")", "不要", "", "ログイベント", "", ALL - {"L"}, set()),
    ("type", "ログ種類", "大分類 app/monitor/trail", "必須", "(必ず設定)", "app",
     "ログ種類定義の固定値", "不要", "", "ログイベント", "", ALL, set()),
    ("thread", "スレッド番号", "Javaスレッド名", "必須", "(必ず設定)", "http-nio-8080-exec-1",
     "getThreadName()。nginxは擬似ID $pid-$connection-$connection_requests", "不要", "", "ログイベント", "", ALL - {"L"}, set()),
    ("function", "機能ID", "API/ジョブ/処理機能の単位", "任意", "null", "配信計画API",
     "オンライン:API名/バッチ:JOB ID/常駐:JOB ID。MDC設定(X-Function-Id等)", "要", "function", "実行単位", "", ALL, set()),
    ("user", "ユーザーID", "利用者識別子", "任意", "null", "U0001",
     "オンライン:X-User-Id/バッチ・常駐:JOB ID/機能ID。MDC設定", "要", "user", "実行単位",
     "★バッチ/常駐の値の取り方 要確認", {"L", "M"}, set()),
    ("action", "操作", "実行された操作内容", "任意", "null", "download",
     "アプリ定義。MDC設定(X-Action等)", "要", "action", "実行単位", "", {"L", "M"}, set()),
    ("subtype", "ログ種類詳細", "SHELL/SYSTEM/NGINX/AWSCALL/DBCALL/APL", "必須", "(必ず設定)", "DBCALL",
     "処理種別に応じた固定値", "不要", "", "ログイベント", "", ALL, set()),
    ("trace_id", "トレースID", "リクエスト/処理を一意識別", "任意", "null", "00-abc…-01",
     "オンライン:traceparent(無ければ生成)/バッチ:ジョブ実行ID/常駐:MessageId。MDC設定", "要", "trace_id", "実行単位", "", ALL - {"L", "M"}, set()),
    ("message", "ログメッセージ", "ログ本文", "任意", "null", "sample log",
     "logger.info(\"…\")", "不要", "", "ログイベント", "★未指定時のデフォルト/4KB制限 要確認。改行エスケープ・PIIマスク", ALL, set()),
    ("stack_trace", "スタックトレース", "例外のスタックトレース", "任意", "null", "java.lang.RuntimeException…",
     "logger.error(\"…\", throwable)", "不要", "", "ログイベント", "例外時のみ。マスク要否", {"Y", "Z"}, set()),
    ("source_ip", "クライアントIPアドレス", "リクエスト元IP", "任意", "null", "203.0.113.10",
     "X-Forwarded-For先頭、無ければgetRemoteAddr()。MDC設定", "要", "source_ip", "実行単位", "", {"L", "M"}, set()),
    ("url", "URL", "アクセスURL", "任意", "null", "GET /v1/xxx?id=123 HTTP/1.1",
     "request.getMethod()/getRequestURI()/getQueryString()", "不要", "", "ログイベント", "", {"L", "M", "N", "O", "T", "U"}, set()),
    ("status", "HTTPステータス", "レスポンスステータスコード", "任意", "null", "200",
     "response.getStatus()", "不要", "", "ログイベント", "", {"L", "M", "N", "O", "T", "U"}, set()),
    ("headers", "ヘッダ情報", "リクエスト/レスポンスヘッダ", "任意", "null", '{"host":[…]}',
     "getHeaderNames()/getHeaders()をMap化", "不要", "", "ログイベント",
     "★全量 or 許可リスト 要確認。Authorization/Cookie等マスク", {"N", "O", "T", "U"}, set()),
    ("body", "ボディ情報", "リクエスト/レスポンスボディ", "任意", "null", '{"id":"123"}',
     "ContentCaching(Request|Response)Wrapper", "不要", "", "ログイベント", "マスク/最大長/copyBodyToResponse注意", {"N", "O", "T", "U"}, set()),
    ("class_name", "クラス名", "ログ出力元クラス名", "必須", "(必ず設定)", "com.example.Sample",
     "AOP:JoinPoint署名", "不要", "", "メソッド実行", "★サービスジャーナル(P,Q)のみ。他種別へ拡大するか要確認", {"P", "Q"}, set()),
    ("method_name", "メソッド名", "ログ出力元メソッド名", "必須", "(必ず設定)", "getOrder",
     "AOP:JoinPoint署名", "不要", "", "メソッド実行", "★P,Qのみ", {"P", "Q"}, set()),
    ("args", "引数", "メソッド引数", "任意", "null", '["123","456"]',
     "AOP:getArgs()", "不要", "", "メソッド実行", "★P,Qのみ。マスク要", {"P", "Q"}, set()),
    ("result", "実行結果", "メソッド実行結果", "任意", "null", "123 hello 456",
     "AOP:戻り値", "不要", "", "メソッド実行", "★P,Qのみ。マスク/最大長", {"P", "Q"}, set()),
    ("bucket_name", "バケット名", "S3対象バケット名", "必須", "(必ず設定)", "my-bucket",
     "S3 SDKリクエスト情報", "不要", "", "AWS呼び出し", "", {"S"}, set()),
    ("path", "パス", "S3対象キー", "必須", "(必ず設定)", "input/customer.csv",
     "S3 SDKリクエスト情報", "不要", "", "AWS呼び出し", "", {"S"}, set()),
    ("latency", "処理時間", "処理にかかった時間(ms)", "任意", "null", "123",
     "開始〜終了の差分", "不要", "", "ログイベント", "★aws_response_timeと重複整理 要確認", {"L", "M", "O", "Q", "R", "S", "U", "V", "W"}, set()),
    ("aws_request_id", "AWS Request ID", "AWS APIのリクエストID", "任意", "null", "TA1B2C3D4E5F6789",
     "SDK responseMetadata().requestId()", "不要", "", "AWS呼び出し", "", {"S", "U", "W"}, set()),
    ("aws_request_timestamp", "AWS Request Timestamp", "AWS API実行日時", "任意", "null", "2026-02-20T04:12:34Z",
     "呼び出し直前の時刻を自前記録", "不要", "", "AWS呼び出し", "★△未確定。AWSCALLでは出力方針。確定可否", set(), {"S", "U", "W"}),
    ("aws_response_time", "AWS Response Time", "AWS API経過時間(ms)", "任意", "null", "45",
     "呼び出し開始〜受信の差分", "不要", "", "AWS呼び出し", "★△未確定。latencyと重複", set(), {"S", "U", "W"}),
    ("aws_s3_extended_request_id", "S3 Extended Request ID", "S3拡張リクエストID", "任意", "null", "h9nBAbC6EFG12345",
     "S3 S3ResponseMetadata#extendedRequestId()(x-amz-id-2)", "不要", "", "AWS呼び出し", "S3専用", {"S"}, set()),
    ("aws_sqs_message_id", "SQS Message ID", "SQSメッセージID", "任意", "null", "2f3c4a5b-…",
     "送信:SendMessageResponse#messageId()/受信:Message#messageId()", "不要", "", "AWS呼び出し", "SQS専用", {"W"}, set()),
]
# pid 候補行（32項目外）
PID = ("pid", "プロセスID", "プロセスID", "-", "-", "12345", "-", "不要", "", "-",
       "★候補：SSD-010元資料にあるが合意済み32項目外。採否要確認", set(), set())

JNAME = {p: t[0] for p, *t in [(i[0], i[1]) for i in ITEMS]}
JNAME = {i[0]: i[1] for i in ITEMS}


def style_header(ws, row, ncols, fill=HEAD_FILL, font=HEAD_FONT):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        cell.border = BORDER


def put_row(ws, r, values, wrap=True):
    for j, v in enumerate(values, 1):
        cell = ws.cell(row=r, column=j, value=v)
        cell.alignment = WRAP if wrap else CENTER
        cell.border = BORDER


wb = Workbook()

# =========================================================================
# Sheet1: 定義一覧（4ブロック）
# =========================================================================
ws = wb.active
ws.title = "1.定義一覧"
r = 1


def block(title, headers, rows, widths, desc=None):
    global r
    ws.cell(row=r, column=1, value=title).font = Font(bold=True, size=12)
    r += 1
    if desc:
        cell = ws.cell(row=r, column=1, value="【説明】" + desc)
        cell.font = ITAL
        cell.alignment = WRAP
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=max(len(headers), 4))
        ws.row_dimensions[r].height = 42
        r += 1
    for j, h in enumerate(headers, 1):
        ws.cell(row=r, column=j, value=h)
    style_header(ws, r, len(headers))
    hr = r
    r += 1
    for row in rows:
        put_row(ws, r, row)
        r += 1
    for j, w in enumerate(widths, 1):
        cur = ws.column_dimensions[get_column_letter(j)].width or 0
        if w > cur:
            ws.column_dimensions[get_column_letter(j)].width = w
    r += 1  # 空行


block("■ 処理分類（実行区分）",
      ["処理分類", "概要", "備考"],
      [["オンライン(API)", "APIおよび画面など。HTTPリクエスト単位", ""],
       ["バッチ(コンテナ内)", "AWSバッチ等。ジョブ実行単位", ""],
       ["常駐バッチ", "メッセージ処理単位（≒バッチ。MDC起点が違うだけ）", "バッチと統合可：要確認"]],
      [18, 50, 24],
      desc="アプリの実行形態の分類。ログの『実行単位スコープ』（機能ID・ユーザーID・操作・トレースID・クライアントIPアドレス を いつ設定し・いつクリアするか）の単位が分類ごとに変わる。"
           "トレースIDの源泉（オンライン=ヘッダ／バッチ=ジョブ実行ID／常駐=メッセージID）・取得できる項目（クライアントIPアドレスやURLはオンラインのみ）・出るログ種類が分類で異なる。")

block("■ ログレベル",
      ["レベル", "level_value", "説明"],
      [["DEBUG", 10000, "開発者向け詳細"], ["INFO", 20000, "通常の動作情報"],
       ["WARN", 30000, "警告"], ["ERROR", 40000, "エラー（監視対象）"]],
      [10, 12, 40],
      desc="ログの重大度。『ログレベル値』は数値表現。"
           "レベルで出力先と『ログ種類』が決まる：ERROR→標準エラー(stderr) かつ ログ種類=monitor、それ以外→標準出力(stdout) かつ ログ種類=app。")

block("■ ログ種類",
      ["ログ種類名", "物理名", "ログ種類(type)", "ロガー名(logger_name)", "ログレベル", "出力先"],
      [["Nginxログ", "nginx", "app/monitor", "（既存・固定名なし）", "INFO", "stdout/stderr"],
       ["アクセスログ", "access", "app", "SPRINGBOOT_API_ACCESS_LOG", "INFO", "stdout"],
       ["アクセスジャーナルログ", "access_jnl", "app", "SPRINGBOOT_API_ACCESS_JNL_LOG", "INFO", "stdout"],
       ["サービスジャーナルログ", "service_jnl", "app", "SPRINGBOOT_SERVICE_JNL_LOG", "INFO", "stdout"],
       ["SQLジャーナルログ", "sql_jnl", "app", "SPRINGBOOT_SQL_JNL_LOG", "INFO", "stdout"],
       ["ストレージアクセスジャーナルログ", "storage_jnl", "app", "SPRINGBOOT_STORAGE_JNL_LOG", "INFO", "stdout"],
       ["外部アクセスジャーナルログ", "external_jnl", "app", "SPRINGBOOT_HTTP_CLIENT_JNL_LOG", "INFO", "stdout"],
       ["キャッシュジャーナルログ", "cache_jnl", "app", "SPRINGBOOT_CACHE_JNL_LOG", "INFO", "stdout"],
       ["メッセージジャーナルログ", "msg_jnl", "app", "SPRINGBOOT_SQS_JNL_LOG", "DEBUG/INFO/WARN", "stdout"],
       ["KMSアクセスジャーナルログ", "kms_jnl", "app", "SPRINGBOOT_KMS_JNL_LOG", "INFO", "stdout"],
       ["DynamoDBアクセスジャーナルログ", "dynamodb_jnl", "app", "SPRINGBOOT_DYNAMODB_JNL_LOG", "INFO", "stdout"],
       ["業務ログ", "app", "app", "SPRINGBOOT_API_LOG", "DEBUG/INFO/WARN", "stdout"],
       ["業務エラーログ", "app_err", "monitor", "SPRINGBOOT_ERROR_LOG", "ERROR", "stderr"],
       ["システムログ", "(root)", "app/monitor", "（固定名なし・root）", "INFO/WARN/ERROR", "stdout(ERROR→stderr)"]],
      [26, 14, 12, 30, 18, 20],
      desc="出力するログの種類。列の意味→ 物理名:内部識別名 / ログ種類(type):大分類（app/monitor/trail。ログレベルで自動的に決まる）/ "
           "ロガー名(logger_name):ログ種類ごとに決めた固定の名前（これでログ種類を振り分ける。システムログは固定名なし）/ "
           "ログレベル:既定の出力レベル / 出力先:標準出力 または 標準エラー。")

block("■ ログ詳細種別（subtype） × 実行区分の適用",
      ["subtype", "オンライン", "バッチ", "常駐", "概要"],
      [["SHELL", "", "○", "", "コンテナ内Shellに出力するJOBログ"],
       ["SYSTEM", "○", "○", "○", "Tomcat/Spring等が出力"],
       ["NGINX", "○", "", "", "nginxのログ"],
       ["AWSCALL", "○", "○", "○", "AWS-API呼び出し時"],
       ["DBCALL", "○", "○", "○", "SQL実行ログ（バッチは件数制限）"],
       ["APL", "○", "○", "○", "アプリ開発者用の任意ログ"]],
      [10, 10, 8, 8, 40],
      desc="ログの発生箇所/種別。ロガー名(logger_name)から自動的に決まる（固定ロガー以外＝システムログ＝SYSTEM）。○=その実行区分で発生しうる。")

block("■ 利用スコープ（各ログ出力項目が『いつ決まる値か』の分類）",
      ["スコープ", "説明", "該当項目（論理名・例）"],
      [["アプリケーション", "アプリ起動中ずっと共通。起動時に1回取得して保持", "コンテナID, コンテナ名"],
       ["実行単位", "1リクエスト/1ジョブ/1メッセージの単位。MDCで保持し、終了時にクリア", "機能ID, ユーザーID, 操作, トレースID, クライアントIPアドレス"],
       ["ログイベント", "ログ出力の1回ごとに決まる/その場で取得する値", "タイムスタンプ, ログレベル, ロガー名, スレッド番号, ログ種類, ログ種類詳細, ログメッセージ, スタックトレース, URL, HTTPステータス, ヘッダ情報, ボディ情報, 処理時間"],
       ["メソッド実行", "メソッド呼び出し単位で取得", "クラス名, メソッド名, 引数, 実行結果"],
       ["AWS呼び出し", "AWS API 呼び出し単位で取得", "バケット名, パス, AWS Request ID ほか"]],
      [16, 52, 50],
      desc="各ログ出力項目が『いつ決まり・どれだけ保持されるか』の分類。"
           "MDCに載せるのは実行単位スコープの項目だけ（同一処理の複数ログで共有するため）。")

block("■ 用語・設計の基本",
      ["用語", "説明"],
      [["MDC", "実行単位スコープの値（機能ID・トレースID等）を、同一処理で出力する複数ログへ自動的に付与する仕組み。処理の開始時に設定し、終了時に必ずクリアする。子スレッド/非同期処理へも引き継ぐ"],
       ["ロガー名", "ログ種類ごとに決めた固定の名前（Javaのクラス名ではない）。これでログ種類を判別・振り分ける。発生元のクラス名・メソッド名は別項目で出力する"],
       ["ログ種類・ログ種類詳細の自動付与", "個々のログ出力では指定しない。ログ種類はログレベルから（ERROR→monitor/他→app）、ログ種類詳細はロガー名から、自動的に決めて付与する"],
       ["システムログ", "固定ロガーに該当しない＝実装で明示的に出力していない、基盤やフレームワーク（Spring/Tomcat等）のログの総称"],
       ["ジャーナルログ", "処理の『送信/受信（要求/応答）』や開始/終了を記録する詳細ログ。アクセス/サービス/SQL/ストレージ/外部/キャッシュ/メッセージ/KMS/DynamoDB がある"],
       ["出力先（標準出力/標準エラー）", "ファイルではなく標準出力／標準エラーへ1行のJSONで出す。ERRORは標準エラー、それ以外は標準出力。基盤側のログ収集（CloudWatch Logs 等）が拾う"]],
      [28, 100],
      desc="ログ設計で使う主要用語。")

block("■ 出力対象ログの記号（L〜Z）",
      ["記号", "ログ種類", "記号", "ログ種類"],
      [["L", "Nginxログ", "S", "ストレージアクセスジャーナルログ"],
       ["M", "アクセスログ", "T", "外部アクセスジャーナルログ（要求）"],
       ["N", "アクセスジャーナルログ（要求）", "U", "外部アクセスジャーナルログ（応答）"],
       ["O", "アクセスジャーナルログ（応答）", "V", "キャッシュジャーナルログ"],
       ["P", "サービスジャーナルログ（開始）", "W", "メッセージジャーナルログ"],
       ["Q", "サービスジャーナルログ（終了）", "X", "業務ログ"],
       ["R", "SQLジャーナルログ", "Y", "業務エラーログ"],
       ["", "", "Z", "システムログ"]],
      [6, 30, 6, 30],
      desc="シート2の『出力対象ログ』列（L〜Z）の記号と、対応するログ種類（論理名）。○=出力対象 / △=未確定。")

# =========================================================================
# Sheet2: ログ出力項目（32項目＋pid候補）
# =========================================================================
ws2 = wb.create_sheet("2.ログ出力項目")
head = ["No", "論理名", "物理名", "概要", "階層", "必須", "デフォルト値", "サンプル",
        "取得方法", "MDC要否", "MDCキー", "利用スコープ"] + COLS + ["備考/要確認"]
for j, h in enumerate(head, 1):
    ws2.cell(row=1, column=j, value=h)
style_header(ws2, 1, len(head))
rownum = 2
for idx, it in enumerate(ITEMS + [PID], 1):
    (p, ja, gai, must, deflt, sample, how, mdc, mkey, scope, biko, present, tri) = it
    no = idx if p != "pid" else "候補"
    base = [no, ja, p, gai, 1, must, deflt, sample, how, mdc, mkey, scope]
    for j, v in enumerate(base, 1):
        ws2.cell(row=rownum, column=j, value=v).alignment = WRAP
        ws2.cell(row=rownum, column=j).border = BORDER
    for k, c in enumerate(COLS):
        col = 13 + k
        cell = ws2.cell(row=rownum, column=col)
        if c in present:
            cell.value = "○"
        elif c in tri:
            cell.value = "△"
            cell.fill = YEL
        cell.alignment = CENTER
        cell.border = BORDER
    bcell = ws2.cell(row=rownum, column=13 + len(COLS), value=biko)
    bcell.alignment = WRAP
    bcell.border = BORDER
    if p == "pid":
        for j in range(1, len(head) + 1):
            ws2.cell(row=rownum, column=j).fill = YEL
    rownum += 1
widths2 = [5, 18, 22, 26, 5, 6, 12, 22, 40, 8, 10, 14] + [4] * 15 + [34]
for j, w in enumerate(widths2, 1):
    ws2.column_dimensions[get_column_letter(j)].width = w
ws2.freeze_panes = "D2"
ws2.row_dimensions[1].height = 28

# =========================================================================
# Sheet3: ログ種類別定義（11行）
# =========================================================================
ws3 = wb.create_sheet("3.ログ種類別定義")
# logtype -> 代表列(出力項目導出用), MDC項目導出
present_by_col = {c: set() for c in COLS}
tri_by_col = {c: set() for c in COLS}
for it in ITEMS:
    p = it[0]
    for c in it[11]:
        present_by_col[c].add(p)
    for c in it[12]:
        tri_by_col[c].add(p)


def items_label(colset):
    seen = []
    for it in ITEMS:
        p = it[0]
        if any(p in present_by_col[c] for c in colset):
            seen.append(it[1])
        elif any(p in tri_by_col[c] for c in colset):
            seen.append(it[1] + "(△)")
    return ", ".join(seen)


def mdc_label(colset):
    keys = []
    for it in ITEMS:
        if it[7] == "要" and any(it[0] in present_by_col[c] for c in colset):
            keys.append(it[1])
    return ", ".join(keys)


h3 = ["ログ種類", "物理名", "ロガー名(logger_name)", "ログ種類(type)", "ログ種類詳細(subtype)", "ログレベル", "出力先", "出力部品",
      "出力項目", "MDC項目", "appender", "備考/要確認"]
lt = [
    ("Nginxログ", "nginx", "（既存・固定名なし）", "app/monitor", "NGINX", "INFO", "stdout/stderr", "nginx", {"L"}, "nginx側(logback対象外)。1行JSONを/dev/stdout"),
    ("アクセスログ", "access", "SPRINGBOOT_API_ACCESS_LOG", "app", "APL", "INFO", "stdout", "HttpLoggingFilter", {"M"}, "アプリ側のサマリ(nginxではない)。HttpLoggingFilterが別ログで1件出力"),
    ("アクセスジャーナルログ", "access_jnl", "SPRINGBOOT_API_ACCESS_JNL_LOG", "app", "APL", "INFO", "stdout", "HttpLoggingFilter", {"N", "O"}, "要求/応答(送信/受信)。latencyは応答のみ"),
    ("サービスジャーナルログ", "service_jnl", "SPRINGBOOT_SERVICE_JNL_LOG", "app", "APL", "INFO", "stdout", "ServiceJournalAspect", {"P", "Q"}, "開始/終了。result/latencyは終了のみ"),
    ("SQLジャーナルログ", "sql_jnl", "SPRINGBOOT_SQL_JNL_LOG", "app", "DBCALL", "INFO", "stdout", "SqlJournalInterceptor", {"R"}, "★class_name/method_name/argsは出さない。バッチ件数制限・SQL詳細の扱い要確認"),
    ("ストレージアクセスジャーナルログ", "storage_jnl", "SPRINGBOOT_STORAGE_JNL_LOG", "app", "AWSCALL", "INFO", "stdout", "S3AccessService", {"S"}, "aws_request_timestamp/response_timeは△"),
    ("外部アクセスジャーナルログ", "external_jnl", "SPRINGBOOT_HTTP_CLIENT_JNL_LOG", "app", "APL", "INFO", "stdout", "HttpClientJournalInterceptor", {"T", "U"}, "要求/応答の2回。AWS宛時のみaws_request_id"),
    ("キャッシュジャーナルログ", "cache_jnl", "SPRINGBOOT_CACHE_JNL_LOG", "app", "APL", "INFO", "stdout", "CacheJournalAspect", {"V"}, "★args/result等は出さない(latencyのみ)"),
    ("メッセージジャーナルログ", "msg_jnl", "SPRINGBOOT_SQS_JNL_LOG", "app", "AWSCALL", "DEBUG/INFO/WARN", "stdout", "SqsAccessService", {"W"}, "常駐スコープ。trace_id=MessageId。△項目あり"),
    ("業務ログ", "app", "SPRINGBOOT_API_LOG", "app", "APL", "DEBUG/INFO/WARN", "stdout", "ApplicationLogger#info", {"X"}, "★class_name/method_nameは出さない"),
    ("業務エラーログ", "app_err", "SPRINGBOOT_ERROR_LOG", "monitor", "APL", "ERROR", "stderr", "ApplicationLogger#error", {"Y"}, "明示的な業務エラー(logger.error)"),
    ("システムログ", "(root)", "（固定名なし・root/実クラス名）", "app/monitor", "SYSTEM", "INFO/WARN/ERROR", "stdout(ERROR→stderr)", "—(明示出力なし。FW等)", {"Z"}, "★固定ロガーに該当しないログの総称。type=レベル判定/subtype=SYSTEM"),
    # KMS/DynamoDB はマトリクス(L〜Z)に列が無いため出力項目を直接指定（共通項目＋下記）
    ("KMSアクセスジャーナルログ", "kms_jnl", "SPRINGBOOT_KMS_JNL_LOG", "app", "AWSCALL", "INFO", "stdout", "KmsAccessService",
     ("共通＋ ロガー名, スレッド番号, トレースID, 処理時間, AWS Request ID（△AWS Request Timestamp, △AWS Response Time）", "機能ID, トレースID"),
     "マトリクスL〜Z外の追加ログ種類。KMS暗号/復号"),
    ("DynamoDBアクセスジャーナルログ", "dynamodb_jnl", "SPRINGBOOT_DYNAMODB_JNL_LOG", "app", "AWSCALL", "INFO", "stdout", "DynamoDbAccessService",
     ("共通＋ ロガー名, スレッド番号, トレースID, 処理時間, AWS Request ID（△AWS Request Timestamp, △AWS Response Time）", "機能ID, トレースID"),
     "マトリクスL〜Z外の追加ログ種類。DynamoDB Get/Put等"),
]
for j, h in enumerate(h3, 1):
    ws3.cell(row=1, column=j, value=h)
style_header(ws3, 1, len(h3))
for i, (name, phys, logger, tp, st, lv, out, part, cset, biko) in enumerate(lt, 2):
    app = "—(nginx側)" if logger.startswith("（既存") else "STDOUT/STDERR（共有・JSON）"
    if isinstance(cset, tuple) and cset and isinstance(cset[0], str):
        items_str, mdc_str = cset
    else:
        items_str, mdc_str = items_label(cset), mdc_label(cset)
    put_row(ws3, i, [name, phys, logger, tp, st, lv, out, part, items_str, mdc_str, app, biko])
for j, w in enumerate([24, 12, 30, 8, 12, 18, 18, 26, 50, 24, 26, 40], 1):
    ws3.column_dimensions[get_column_letter(j)].width = w
ws3.freeze_panes = "A2"

# =========================================================================
# Sheet4: 実装部品一覧
# =========================================================================
ws4 = wb.create_sheet("4.実装部品一覧")
h4 = ["#", "論理名", "物理名(クラス)", "実行区分", "スコープ", "実行タイミング", "実装方法", "取得/設定項目", "出力ロガー", "備考/要確認"]
parts = [
    [1, "コンテナ情報取得", "ContainerInfoProvider(+entrypoint.sh)", "共通", "アプリ", "起動時", "@PostConstruct/sh", "id, name", "—", ""],
    [2, "実行スコープMDC", "ExecutionScopeMdc", "共通", "実行単位", "処理開始〜終了", "try-with-resources", "function,user,action,trace_id,source_ip", "—", ""],
    [3, "HTTPログ制御", "HttpLoggingFilter", "API", "実行単位/イベント", "HTTPリクエスト", "OncePerRequestFilter", "url,status,headers,body,latency", "API_ACCESS(アクセスログ) / API_ACCESS_JNL(ジャーナル)", "アクセスログ＋ジャーナル要求/応答の3本"],
    [4, "機能・アクション解決", "FunctionActionResolver", "API", "実行単位", "処理開始時", "Filterから呼出", "function,action", "—", ""],
    [5, "バッチ起点", "BatchLogScope", "バッチ", "実行単位", "ジョブ開始〜終了", "ExecutionScopeMdc利用", "function=JOB, trace_id=ジョブ実行ID", "—", "★userの値/常駐との統合 要確認"],
    [6, "常駐起点", "MessageLogScope", "常駐", "実行単位", "メッセージ処理", "ExecutionScopeMdc利用", "function, trace_id=MessageId", "—", "★バッチと統合可"],
    [7, "サービスジャーナル", "ServiceJournalAspect", "共通", "メソッド実行", "@Service前後", "@Aspect+@Around", "class_name,method_name,args,result,latency", "SERVICE_JNL", ""],
    [8, "SQLジャーナル", "SqlJournalInterceptor", "共通", "メソッド実行", "SQL実行", "MyBatis Interceptor", "latency", "SQL_JNL", "★class_name/method_name/argsは出さない。SQL詳細はmessage。バッチ件数制限"],
    [9, "ストレージ(S3)", "S3AccessService", "共通", "AWS呼び出し", "S3 API", "S3 Clientラップ", "bucket_name,path,aws_request_id,aws_s3_extended_request_id,latency", "STORAGE_JNL", "aws_request_timestamp/response_timeは△"],
    [10, "メッセージ(SQS)", "SqsAccessService", "共通", "AWS呼び出し", "SQS送受信", "SQS Clientラップ", "aws_sqs_message_id,aws_request_id,latency", "SQS_JNL", "△項目あり"],
    [11, "外部HTTP", "HttpClientJournalInterceptor", "共通", "外部呼び出し", "外部HTTP前後", "ClientHttpRequestInterceptor", "url,status,headers,body,latency", "HTTP_CLIENT_JNL", ""],
    [12, "キャッシュ", "CacheJournalAspect", "共通", "メソッド実行", "@Cacheable前後", "@Aspect", "latency", "CACHE_JNL", "★args/result等は出さない"],
    [13, "AWSメタデータ抽出", "AwsResponseMetadataExtractor", "共通", "AWS呼び出し", "AWS応答取得", "共通部品", "aws_request_id,aws_s3_extended_request_id", "—", ""],
    [14, "業務ログ", "ApplicationLogger", "共通", "イベント", "業務処理内", "Spring Bean", "message,stack_trace", "API_LOG / ERROR_LOG", "★class_name/method_nameは出さない"],
    [15, "マスキング", "LogMaskingService", "共通", "イベント", "出力直前", "各部品から呼出", "headers,body,message,args,result,stack_trace,url(クエリ)", "—", "URLクエリのPIIもマスク"],
    [16, "ログ設定保持", "LoggingProperties", "共通", "アプリ", "起動時", "@ConfigurationProperties", "body/message最大長,マスク対象", "—", ""],
    [19, "MDC伝播", "MdcTaskDecorator + AsyncConfig", "共通", "実行単位", "非同期/子スレッド", "TaskDecorator", "MDC(function/trace_id等)を子スレッドへ複製", "—", "@Async/プールでtrace_id欠落を防ぐ"],
    [20, "トレース伝播(SQS)", "SqsTraceSupport", "共通/常駐", "AWS呼び出し", "SQS送受信", "メッセージ属性traceparent", "trace_id", "—", "送信で付与/受信で抽出。下流へtrace連携"],
    [17, "KMSアクセス", "KmsAccessService", "共通", "AWS呼び出し", "暗号/復号", "KMS Clientラップ", "aws_request_id,aws_request_timestamp,aws_response_time,latency", "KMS_JNL", "マトリクスL〜Z外の追加ログ種類"],
    [18, "DynamoDBアクセス", "DynamoDbAccessService", "共通", "AWS呼び出し", "Get/Put/Query", "DynamoDB Clientラップ", "aws_request_id,aws_request_timestamp,aws_response_time,latency", "DYNAMODB_JNL", "マトリクスL〜Z外の追加ログ種類"],
]
for j, h in enumerate(h4, 1):
    ws4.cell(row=1, column=j, value=h)
style_header(ws4, 1, len(h4))
for i, row in enumerate(parts, 2):
    put_row(ws4, i, row)
    if row[8] == "未定":
        ws4.cell(row=i, column=9).fill = YEL
for j, w in enumerate([4, 20, 32, 10, 16, 16, 26, 44, 22, 40], 1):
    ws4.column_dimensions[get_column_letter(j)].width = w
ws4.freeze_panes = "A2"

# =========================================================================
# Sheet5: 出力方針(logback)
# =========================================================================
ws5 = wb.create_sheet("5.出力方針(logback)")
h5 = ["項目", "内容"]
pol = [
    ["出力先", "stdout / stderr。ERROR→stderr / それ以外→stdout（LevelFilter で振り分け）。CloudWatch Logs が収集"],
    ["appender", "STDOUT / STDERR の2本のみ。各ログ種類は logger_name の <logger> でレベルと振り分けを指定"],
    ["ログ種類の区別", "logger_name（JSONフィールド）で区別"],
    ["encoder", "LoggingEventCompositeJsonEncoder（JSON1行）"],
    ["timestamp", "@timestamp→timestamp にリネーム。yyyy-MM-dd HH:mm:ss.SSS / Asia/Tokyo"],
    ["@version", "出力しない（抑止）"],
    ["type / subtype", "独自provider TypeSubtypeJsonProvider が付与。type=レベル判定(ERROR→monitor/他→app)、subtype=logger_nameから導出(固定ロガー以外=SYSTEM)。Markerには持たせない"],
    ["システムログ(root)", "固定ロガーに該当しない＝明示出力していないFW等のログ。logger_name=実クラス名、type=レベル判定、subtype=SYSTEM が自動付与"],
    ["MDC", "<mdc> + includeMdcKeyName で function/user/action/trace_id/source_ip を明示"],
    ["id / name", "独自provider（ContainerInfoJsonProvider）。ECSメタデータを起動時1回取得"],
    ["その他項目", "type/subtype/url/status/headers/body/class_name/method_name/args/result/bucket_name/path/latency/aws_* は Marker で付与"],
    ["マスク", "headers/body/message/args/result/stack_trace/url(クエリ)。body/message は最大長制限"],
    ["トレース伝播", "外部HTTPは traceparent ヘッダ、SQSは メッセージ属性 traceparent で下流へ trace_id を連携"],
    ["MDC伝播", "非同期/子スレッドは MdcTaskDecorator で MDC を複製（@Async・独自プール）"],
    ["フィルタ順序", "HttpLoggingFilter は @Order(HIGHEST_PRECEDENCE) で最外周 wrap"],
]
for j, h in enumerate(h5, 1):
    ws5.cell(row=1, column=j, value=h)
style_header(ws5, 1, len(h5))
for i, row in enumerate(pol, 2):
    put_row(ws5, i, row)
ws5.column_dimensions["A"].width = 18
ws5.column_dimensions["B"].width = 90

# =========================================================================
# Sheet0: 前提（先頭・読む順の最初）
# =========================================================================
ws0 = wb.create_sheet("0.前提", 0)
ws0.column_dimensions["A"].width = 22
ws0.column_dimensions["B"].width = 110
_r0 = [1]


def s0title(text):
    c = ws0.cell(row=_r0[0], column=1, value=text)
    c.font = Font(bold=True, size=12, color="FFFFFF")
    c.fill = HEAD_FILL
    ws0.merge_cells(start_row=_r0[0], start_column=1, end_row=_r0[0], end_column=2)
    _r0[0] += 1


def s0row(label, content):
    a = ws0.cell(row=_r0[0], column=1, value=label)
    a.font = Font(bold=True)
    a.alignment = WRAP
    a.border = BORDER
    b = ws0.cell(row=_r0[0], column=2, value=content)
    b.alignment = WRAP
    b.border = BORDER
    _r0[0] += 1


ws0.cell(row=_r0[0], column=1, value="前提・このシートについて").font = Font(bold=True, size=14)
_r0[0] += 2

s0title("■ この資料は何か")
s0row("目的", "Spring Bootアプリケーションの『ログ設計書（上位設計）』。出力するログ項目・ログ種類・出力方式・取得方法・利用スコープを定義する。")
s0row("設計の流れ", "本Excel（上位設計）→ Markdown設計書（下位設計）→ 実装。Excelで設計→Markdownへ反映→Markdownから実装、の順。"
                   "本Excelは外部資料を参照せず自己完結させる（下位の設計書/実装を参照しない）。")

s0title("■ どういう仕組み上で設計するか（前提とする基盤）")
s0row("ログ出力", "Spring Boot 上で logback を使ってログを出力する。ログは JSON 形式（1行）で出す。")
s0row("出力先", "標準出力(stdout)／標準エラー(stderr) に出す（ファイル出力しない）。ERRORは標準エラー、それ以外は標準出力。")
s0row("ログ収集", "標準出力/標準エラーを AWS の CloudWatch Logs が収集する（Logs Insights で検索・集約）。")
s0row("実行基盤", "ECS（コンテナ）上で動作。フロントに nginx。")
s0row("利用AWS", "S3 / SQS / KMS / DynamoDB を利用し、アクセス時にジャーナルログを出す。")
s0row("実行区分", "オンライン(API) / バッチ / 常駐バッチ（詳細は『1.定義一覧』の処理分類）。")

s0title("■ シート構成（読む順）")
s0row("1.定義一覧", "用語・処理分類・ログレベル・ログ種類・詳細種別・利用スコープ・出力対象ログの記号 などの定義。")
s0row("2.ログ出力項目", "各ログ出力項目（論理名/物理名/取得方法/スコープ/出力対象ログ L〜Z）。")
s0row("3.ログ種類別定義", "ログ種類ごとの出力項目・出力先・出力部品。")
s0row("4.実装部品一覧", "実装する部品（クラス）一覧と取得項目・出力ロガー。")
s0row("5.出力方針(logback)", "logback を作る際の確定方針（encoder/MDC/マスク/トレース伝播 等）。")

s0title("■ 読み方・凡例")
s0row("名称", "論理名で記載し、物理名（JSONキー名）は補足として併記する。")
s0row("記号", "○=出力対象 ／ △=未確定（要確認）／ ★=要確認事項。")
s0row("用語", "不明な用語は『1.定義一覧』の用語ブロックを参照。")

# =========================================================================
# ヘッダのコメント説明（セルにマウスを乗せると表示）
# =========================================================================
note(ws2.cell(row=1, column=1), "シート2：32のログ出力項目の定義＋出力対象ログ(L〜Z)。スコープ/MDC等の用語定義は『1.定義一覧』参照。")
note(ws2.cell(row=1, column=5), "階層：JSONの階層。基本は1(フラット)。headers/body は入れ子のオブジェクト。")
note(ws2.cell(row=1, column=6), "必須：必ず出力される=必須 / 値が無ければ出力されない=任意(null扱い)。")
note(ws2.cell(row=1, column=7), "デフォルト値：取得できなかった場合の出力。(必ず設定)=常に値あり / null=その項目は出力されない。")
note(ws2.cell(row=1, column=9), "取得方法：その値をどう取得するか（logback/MDC/AOP/SDK等）。")
note(ws2.cell(row=1, column=10), "MDC要否：要=実行単位スコープでMDCに載せ複数ログで共有 / 不要=その場で取得。")
note(ws2.cell(row=1, column=11), "MDCキー：MDCに載せる際のキー名（物理名と一致）。")
note(ws2.cell(row=1, column=12), "利用スコープ：値がいつ決まり・どれだけ保持されるか。定義は『1.定義一覧』の利用スコープ参照。")
note(ws2.cell(row=1, column=13), "L〜Z：出力対象ログ。○=出力対象 / △=未確定。各記号(L〜Z)の対応ログ種類は『1.定義一覧』の『出力対象ログの記号』を参照。")
note(ws2.cell(row=1, column=28), "備考/要確認：★は要確認事項。")
note(ws3.cell(row=1, column=1), "シート3：ログ種類ごとの『出力項目・出力部品・appender・MDC項目』を1行で確認する表。")
note(ws3.cell(row=1, column=11), "appender：出力先の定義。全ログ種類が STDOUT/STDERR(JSON) を共有し、logger_name で振り分ける。")
note(ws4.cell(row=1, column=1), "シート4：Java側で作る部品(クラス)の一覧。実行区分・スコープ・取得項目・出力ロガーを定義。")
note(ws5.cell(row=1, column=1), "シート5：logback を作る際の確定方針（出力先/encoder/MDC/マスク/トレース伝播 等）。")

wb.save("/Users/kobuo/workspace/cosmo-log/ログ設計.xlsx")
print("written: ログ設計.xlsx  sheets =", wb.sheetnames)
