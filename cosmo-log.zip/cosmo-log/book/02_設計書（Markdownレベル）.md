# 第2部　設計書（Markdownレベル）

> この部は「実装ができるレベル」の設計。第1部の項目定義を、スコープ・MDC・出力部品の設計に落とし込む。
> **(TODO)** は未確定・要確認事項。

---

## 2.1 スコープ設計

ログ項目は5つのスコープで管理する。

| スコープ | 説明 | 該当項目 | 実装上の保持先 |
|---|---|---|---|
| アプリケーション | 起動中common | id, name | 静的保持（起動時1回） |
| 実行単位 | オンライン=HTTPリクエスト／バッチ=ジョブ／常駐=メッセージ | function, user, action, trace_id, source_ip | **MDC** |
| ログイベント | `logger.xxx()` 1回ごと | timestamp, level, level_value, thread, logger_name, type, subtype, message, stack_trace | その場 |
| メソッド実行 | メソッド呼び出し単位 | class_name, method_name, args, result | AOP引数 |
| AWS呼び出し | AWS API 呼び出し単位 | bucket_name, path, latency, aws_* | SDK応答 |

### 実行単位スコープと MDC ライフサイクル

実行単位スコープの値だけを MDC に載せ、複数ログで共有する。**開始時に設定、終了時に必ずクリア**する。

| 実行単位 | MDC設定タイミング | MDCクリアタイミング | trace_id の源泉 |
|---|---|---|---|
| オンライン | HTTPリクエスト開始 | レスポンス返却後（finally） | ヘッダ `traceparent`、無ければ生成 |
| バッチ | ジョブ開始 | ジョブ終了 | ジョブ実行ID |
| 常駐 | メッセージ受信・処理開始 | メッセージ処理終了 | MessageId |

MDCキー：`function` / `user` / `action` / `trace_id` / `source_ip`（物理名と一致）。

---

## 2.2 出力基盤の設計

### 出力先（確定）

CloudWatch Logs 収集のため stdout/stderr を明示する。

- **ERROR → stderr**（`System.err`）
- **ERROR以外 → stdout**（`System.out`）
- `ch.qos.logback.classic.filter.LevelFilter` で振り分け。
- ログ種類の区別は **`logger_name`（JSONフィールド）** で行う。appender は stdout/stderr の2本。

### JSONエンコード（確定）

`logstash-logback-encoder` を使用し、項目の供給元を4系統に分ける。

| 供給元 | 項目 |
|---|---|
| logback組み込み provider | timestamp, level, level_value, logger_name, thread, message, stack_trace |
| 独自 provider | id, name |
| `<mdc>`（`includeMdcKeyName` で出力キーを明示） | function, user, action, trace_id, source_ip |
| `<logstashMarkers/>` | type, subtype, url, status, headers, body, class_name, method_name, args, result, bucket_name, path, latency, aws_* |

`@timestamp`→`timestamp`（`yyyy-MM-dd HH:mm:ss.SSS`/JST）、`@version` は抑止。

---

## 2.3 出力部品の設計

| 部品 | スコープ | トリガ | 出力ログ(logger_name) | 主な取得項目 |
|---|---|---|---|---|
| ContainerInfoProvider | アプリ | 起動時 | - | id, name |
| ExecutionScopeMdc | 実行単位 | 処理開始〜終了 | - | function, user, action, trace_id, source_ip |
| scope.online.HttpLoggingFilter（API） | 実行単位/イベント | HTTPリクエスト | SPRINGBOOT_API_ACCESS_LOG | url, status, headers, body, latency |
| scope.batch.BatchLogScope（バッチ） | 実行単位 | ジョブ開始〜終了 | - | function=JOB, trace_id=ジョブ実行ID |
| scope.resident.MessageLogScope（常駐） | 実行単位 | メッセージ処理 | SPRINGBOOT_SQS_JNL_LOG | trace_id=MessageId |
| ServiceJournalAspect | メソッド実行 | @Service前後 | SPRINGBOOT_SERVICE_JNL_LOG | class_name, method_name, args, result, latency |
| SqlJournalInterceptor | メソッド実行 | SQL実行 | SPRINGBOOT_SQL_JNL_LOG | latency（★class_name/method_name/args は出さない・マトリクス準拠） |
| S3AccessService | AWS呼び出し | S3 API | SPRINGBOOT_STORAGE_JNL_LOG | bucket_name, path, aws_request_id, aws_s3_extended_request_id, latency |
| SqsAccessService | AWS呼び出し | SQS送受信 | SPRINGBOOT_SQS_JNL_LOG | aws_sqs_message_id, aws_request_id, latency |
| HttpClientJournalInterceptor | 外部呼び出し | 外部HTTP | SPRINGBOOT_HTTP_CLIENT_JNL_LOG | url, status, headers, body, latency |
| CacheJournalAspect | メソッド実行 | @Cacheable前後 | SPRINGBOOT_CACHE_JNL_LOG | latency（★class_name/method_name/args/result は出さない・マトリクス準拠） |
| ApplicationLogger | イベント | 業務処理内 | SPRINGBOOT_API_LOG(app/APL) / _ERROR_LOG(monitor/SYSTEM) | message, stack_trace（★class_name/method_name は出さない・マトリクス準拠） |
| LogMaskingService | イベント | 出力直前 | - | headers, body, message, args, result |
| AwsResponseMetadataExtractor | AWS呼び出し | AWS応答取得 | - | aws_request_id, aws_s3_extended_request_id |
| KmsAccessService | AWS呼び出し | 暗号/復号 | **(TODO: logger未定義)** | aws_request_id ほか |
| DynamoDbAccessService | AWS呼び出し | Get/Put/Query | **(TODO: logger未定義)** | aws_request_id ほか |

---

## 2.4 実行区分別の取得方針（SSD-010）

### subtype × 実行区分

| subtype | オンライン | バッチ(コンテナ内) | 常駐 | 概要 |
|---|:-:|:-:|:-:|---|
| SHELL | - | ○ | - | コンテナ内Shellに出力するJOBログ |
| SYSTEM | ○ | ○ | ○ | Tomcat/Spring 等が出力 |
| NGINX | ○ | - | - | nginx のログ |
| AWSCALL | ○ | ○ | ○ | AWS-API呼び出し時 |
| DBCALL | ○ | ○ | ○ | SQL実行ログ |
| APL | ○ | ○ | ○ | アプリ開発者用の任意ログ |

### AWSCALL の出力ルール

AWS-API呼び出し時に次を含める：`aws_request_id` / `aws_request_timestamp` / `aws_response_time` / `aws_s3_extended_request_id`（S3のみ）/ `aws_sqs_message_id`（SQSのみ）。
→ 28/29 はマトリクスでは黄色＝未確定だが、AWSCALL詳細では「出力する」方針 **(TODO: △→○の確定)**。

### DBCALL（バッチ/常駐）の出力ルール

大量件数のため全DBアクセスは出力しない。**IN/OUT件数**、ループ時は「ループ処理開始/終了」「1000件完了」等の進捗、**SQLException等のエラー時は詳細SQL** を出力する。

---

## 2.5 マスキング設計

| 設定 | 内容 |
|---|---|
| マスク対象ヘッダ | Authorization, Cookie, Set-Cookie, X-Api-Key（値を `***`） |
| マスク対象ボディ/引数キー | password, secret, token, accessKey, secretKey |
| body/args/result 最大長 | 既定 2048 文字 **(TODO: 値確定)** |
| message 最大長 | 既定 4096 文字 **(TODO: 4KB制約のしきい値確定)** |

対象項目：headers, body, message, args, result, stack_trace。

---

## 2.6 コンテナ情報（id / name）の取得設計

- id/name はアプリから直接参照不可。**ECSコンテナメタデータ**を参照する。
- ECS起動時に環境変数 `ECS_CONTAINER_METADATA_URI_V4` が注入される。
- `${ECS_CONTAINER_METADATA_URI_V4}/task` を GET し、`TaskARN`（→Task ID）・`ServiceName`/`Family`（→name）を取得。
- ローカル通信だがオーバーヘッドがあるため、**起動時1回取得しキャッシュ**（または entrypoint.sh で環境変数化）。
- 実装は第3部参照。
