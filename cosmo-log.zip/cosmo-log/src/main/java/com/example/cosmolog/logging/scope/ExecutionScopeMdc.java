package com.example.cosmolog.logging.scope;

import org.slf4j.MDC;

import com.example.cosmolog.logging.MdcKeys;

/**
 * 実行単位スコープの MDC を設定し、close() で必ずクリアする共通部品。
 * オンライン(API) / バッチ / 常駐バッチ のいずれの起点からも利用する。
 *
 * <pre>{@code
 * try (var scope = ExecutionScopeMdc.open(function, action, user, traceId, sourceIp)) {
 *     // ... この間のログに function/user/action/trace_id/source_ip が付与される ...
 * } // ← ここで MDC を自動クリア
 * }</pre>
 */
public final class ExecutionScopeMdc implements AutoCloseable {

    private ExecutionScopeMdc() {
    }

    /** function/user/action/trace_id/source_ip を MDC へ設定する。null/空は設定しない。 */
    public static ExecutionScopeMdc open(String function, String action, String user,
                                         String traceId, String sourceIp) {
        put(MdcKeys.FUNCTION, function);
        put(MdcKeys.ACTION, action);
        put(MdcKeys.USER, user);
        put(MdcKeys.TRACE_ID, traceId);
        put(MdcKeys.SOURCE_IP, sourceIp);
        return new ExecutionScopeMdc();
    }

    private static void put(String key, String value) {
        if (value != null && !value.isBlank()) {
            MDC.put(key, value);
        }
    }

    @Override
    public void close() {
        for (String key : MdcKeys.ALL) {
            MDC.remove(key);
        }
    }
}
