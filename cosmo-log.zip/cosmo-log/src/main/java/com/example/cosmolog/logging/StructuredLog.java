package com.example.cosmolog.logging;

import java.util.LinkedHashMap;
import java.util.Map;

import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;

/**
 * ログ出力1回ぶんの「その場で設定する項目」を組み立てるビルダー。
 *
 * <pre>{@code
 * logger.info(StructuredLog.of(LogType.APP, LogSubtype.APL)
 *         .put(LogFields.URL, url)
 *         .put(LogFields.STATUS, status)
 *         .marker(), "message");
 * }</pre>
 *
 * null値は出力しない（その項目を持たないログ種類では自然に欠落する）。
 */
public final class StructuredLog {

    private final Map<String, Object> fields = new LinkedHashMap<>();

    private StructuredLog(String type, String subtype) {
        fields.put(LogFields.TYPE, type);
        fields.put(LogFields.SUBTYPE, subtype);
    }

    public static StructuredLog of(String type, String subtype) {
        return new StructuredLog(type, subtype);
    }

    public StructuredLog put(String key, Object value) {
        if (value != null) {
            fields.put(key, value);
        }
        return this;
    }

    public LogstashMarker marker() {
        return Markers.appendEntries(fields);
    }
}
