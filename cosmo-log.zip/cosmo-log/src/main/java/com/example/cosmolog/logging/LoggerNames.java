package com.example.cosmolog.logging;

/**
 * ログ種類ごとの固定ロガー名。
 * Javaクラス名ではなく、logback.xml の appender 振り分けキーとして使う。
 */
public final class LoggerNames {

    public static final String API_ACCESS = "SPRINGBOOT_API_ACCESS_LOG";
    public static final String SERVICE_JNL = "SPRINGBOOT_SERVICE_JNL_LOG";
    public static final String STORAGE_JNL = "SPRINGBOOT_STORAGE_JNL_LOG";
    public static final String HTTP_CLIENT_JNL = "SPRINGBOOT_HTTP_CLIENT_JNL_LOG";
    public static final String CACHE_JNL = "SPRINGBOOT_CACHE_JNL_LOG";
    public static final String SQS_JNL = "SPRINGBOOT_SQS_JNL_LOG";
    /** SQLジャーナルログ(DBCALL)用。顧客設計書(SSD-010)で定義済み。MyBatis Interceptor で指定する。 */
    public static final String SQL_JNL = "SPRINGBOOT_SQL_JNL_LOG";
    public static final String API_LOG = "SPRINGBOOT_API_LOG";
    public static final String ERROR_LOG = "SPRINGBOOT_ERROR_LOG";

    private LoggerNames() {
    }
}
