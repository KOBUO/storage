package com.example.cosmolog.logging.scope.batch;

import com.example.cosmolog.logging.scope.ExecutionScopeMdc;

/**
 * 【バッチ】の実行単位スコープ起点。ジョブ開始で MDC を設定し、終了でクリアする。
 *
 * <pre>{@code
 * try (var scope = BatchLogScope.open("売上集計バッチ", jobExecutionId)) {
 *     // ... ジョブ本体 ...
 * }
 * }</pre>
 *
 * 常駐バッチ（{@code scope.resident}）と仕組みは共通。差分は trace_id の源泉と action のみ。
 */
public final class BatchLogScope {

    private BatchLogScope() {
    }

    /**
     * @param jobName        機能ID(function) = JOB名
     * @param jobExecutionId トレースID(trace_id) = ジョブ実行ID（user にも使用）(TODO: user の値は要確認)
     */
    public static ExecutionScopeMdc open(String jobName, String jobExecutionId) {
        // source_ip はバッチでは無し
        return ExecutionScopeMdc.open(jobName, "BATCH_EXEC", jobExecutionId, jobExecutionId, null);
    }
}
