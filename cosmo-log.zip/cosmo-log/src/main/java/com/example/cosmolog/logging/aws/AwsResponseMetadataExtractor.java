package com.example.cosmolog.logging.aws;

import software.amazon.awssdk.awscore.AwsResponse;
import software.amazon.awssdk.awscore.AwsResponseMetadata;
import software.amazon.awssdk.services.s3.S3ResponseMetadata;

/**
 * AWS SDK v2 のレスポンスから共通メタデータ(aws_request_id 等)を取り出す小さな共通部品。
 * S3 / SQS / KMS / DynamoDB の各アクセス部品から利用する。
 */
public final class AwsResponseMetadataExtractor {

    /** aws_request_id / aws_s3_extended_request_id（S3のみ）。 */
    public record AwsMeta(String requestId, String extendedRequestId) {
    }

    public static AwsMeta extract(AwsResponse response) {
        if (response == null) {
            return new AwsMeta(null, null);
        }
        AwsResponseMetadata metadata = response.responseMetadata();
        String requestId = metadata != null ? metadata.requestId() : null;
        String extendedRequestId = null;
        // 拡張リクエストID(x-amz-id-2)はS3のみ
        if (metadata instanceof S3ResponseMetadata s3Metadata) {
            extendedRequestId = s3Metadata.extendedRequestId();
        }
        return new AwsMeta(requestId, extendedRequestId);
    }

    private AwsResponseMetadataExtractor() {
    }
}
