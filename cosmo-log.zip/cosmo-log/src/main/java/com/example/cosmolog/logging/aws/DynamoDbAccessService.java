package com.example.cosmolog.logging.aws;

import java.time.Instant;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.StructuredLog;
import com.example.cosmolog.logging.aws.AwsResponseMetadataExtractor.AwsMeta;

import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.GetItemResponse;
import software.amazon.awssdk.services.dynamodb.model.PutItemRequest;
import software.amazon.awssdk.services.dynamodb.model.PutItemResponse;

/**
 * DynamoDBアクセス部品。Get/Put 等で DynamoDBアクセスジャーナルログ(AWSCALL) を出力する。
 * DynamoDbClient は遅延生成。type/subtype は TypeSubtypeJsonProvider が付与（subtype=AWSCALL）。
 */
@Component
public class DynamoDbAccessService {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.DYNAMODB_JNL);

    private volatile DynamoDbClient client;

    private DynamoDbClient client() {
        if (client == null) {
            synchronized (this) {
                if (client == null) {
                    client = DynamoDbClient.create();
                }
            }
        }
        return client;
    }

    public Map<String, AttributeValue> getItem(String table, Map<String, AttributeValue> key) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        GetItemResponse response = client().getItem(GetItemRequest.builder().tableName(table).key(key).build());
        journal(requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "getItem");
        return response.item();
    }

    public void putItem(String table, Map<String, AttributeValue> item) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        PutItemResponse response = client().putItem(PutItemRequest.builder().tableName(table).item(item).build());
        journal(requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "putItem");
    }

    private void journal(String requestTimestamp, long startNanos, AwsMeta meta, String op) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        log.info(StructuredLog.create()
                .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                // aws_request_timestamp / aws_response_time は設計上△(案)。要確定。
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .put(LogFields.LATENCY, latencyMs)
                .marker(), "dynamodb journal (" + op + ")");
    }
}
