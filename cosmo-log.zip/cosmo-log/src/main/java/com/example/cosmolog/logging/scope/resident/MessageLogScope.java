package com.example.cosmolog.logging.scope.resident;

import com.example.cosmolog.logging.scope.ExecutionScopeMdc;

/**
 * 【常駐バッチ（メッセージ処理）】の実行単位スコープ起点。
 * メッセージ受信・処理開始で MDC を設定し、メッセージ処理終了でクリアする。
 *
 * <pre>{@code
 * try (var scope = MessageLogScope.open("配信計画メッセージ処理", messageId)) {
 *     // ... 1メッセージの処理 ...
 * }
 * }</pre>
 *
 * バッチ（{@code scope.batch}）と仕組みは共通。差分は trace_id=MessageId である点。
 * ※必要なら BatchLogScope と統合してよい。
 */
public final class MessageLogScope {

    private MessageLogScope() {
    }

    /**
     * @param handlerName 機能ID(function) = メッセージ処理機能
     * @param messageId   トレースID(trace_id) = SQS MessageId（メッセージ属性の traceparent があれば優先）
     */
    public static ExecutionScopeMdc open(String handlerName, String messageId) {
        // user / source_ip は常駐バッチでは無し (TODO: user の値は要確認)
        return ExecutionScopeMdc.open(handlerName, "CONSUME", null, messageId, null);
    }
}
