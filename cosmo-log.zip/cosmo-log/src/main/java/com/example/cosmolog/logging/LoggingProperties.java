package com.example.cosmolog.logging;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * ログ設定保持部品。application.yml の logging.custom.* をバインドする。
 */
@Component
@ConfigurationProperties(prefix = "logging.custom")
public class LoggingProperties {

    /** body の最大出力長。 */
    private int bodyMaxLength = 2048;
    /** message の最大出力長。 */
    private int messageMaxLength = 4096;
    /** マスク対象ヘッダー名（小文字比較）。 */
    private List<String> maskHeaderNames = List.of("authorization", "cookie");
    /** マスク対象ボディ/引数キー。 */
    private List<String> maskBodyKeys = List.of("password", "secret", "token");

    public int getBodyMaxLength() {
        return bodyMaxLength;
    }

    public void setBodyMaxLength(int bodyMaxLength) {
        this.bodyMaxLength = bodyMaxLength;
    }

    public int getMessageMaxLength() {
        return messageMaxLength;
    }

    public void setMessageMaxLength(int messageMaxLength) {
        this.messageMaxLength = messageMaxLength;
    }

    public List<String> getMaskHeaderNames() {
        return maskHeaderNames;
    }

    public void setMaskHeaderNames(List<String> maskHeaderNames) {
        this.maskHeaderNames = maskHeaderNames;
    }

    public List<String> getMaskBodyKeys() {
        return maskBodyKeys;
    }

    public void setMaskBodyKeys(List<String> maskBodyKeys) {
        this.maskBodyKeys = maskBodyKeys;
    }
}
