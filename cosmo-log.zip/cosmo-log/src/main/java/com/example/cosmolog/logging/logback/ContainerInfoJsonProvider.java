package com.example.cosmolog.logging.logback;

import java.io.IOException;

import com.example.cosmolog.logging.container.ContainerInfo;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * 全ログに id / name（アプリケーションスコープ）を付与する logback provider。
 * logback-spring.xml の {@code <providers>} 内に登録する。
 */
public class ContainerInfoJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        generator.writeStringField("id", ContainerInfo.getId());
        generator.writeStringField("name", ContainerInfo.getName());
    }
}
