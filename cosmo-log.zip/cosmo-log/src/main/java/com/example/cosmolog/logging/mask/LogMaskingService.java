package com.example.cosmolog.logging.mask;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.LoggingProperties;

/**
 * マスキング部品。headers / body / args / result / message から
 * 個人情報・機密情報をマスクし、最大長で切り詰める。
 */
@Component
public class LogMaskingService {

    private static final String MASK = "***";

    private final LoggingProperties props;

    public LogMaskingService(LoggingProperties props) {
        this.props = props;
    }

    /** マスク対象ヘッダーを値ごと伏せる。 */
    public Map<String, String> maskHeaders(Map<String, String> headers) {
        if (headers == null) {
            return null;
        }
        Set<String> mask = lowerSet(props.getMaskHeaderNames());
        Map<String, String> out = new LinkedHashMap<>();
        headers.forEach((k, v) -> out.put(k, mask.contains(k.toLowerCase(Locale.ROOT)) ? MASK : v));
        return out;
    }

    /** JSONボディ内のマスク対象キーの値を伏せ、最大長で切り詰める。 */
    public String maskBody(String body) {
        return truncate(maskKeys(body), props.getBodyMaxLength());
    }

    public Object[] maskArgs(Object[] args) {
        if (args == null) {
            return null;
        }
        Object[] out = new Object[args.length];
        for (int i = 0; i < args.length; i++) {
            out[i] = truncate(maskKeys(String.valueOf(args[i])), props.getBodyMaxLength());
        }
        return out;
    }

    public Object maskResult(Object result) {
        if (result == null) {
            return null;
        }
        return truncate(maskKeys(String.valueOf(result)), props.getBodyMaxLength());
    }

    public String maskMessage(String message) {
        return truncate(message, props.getMessageMaxLength());
    }

    private String maskKeys(String text) {
        if (text == null) {
            return null;
        }
        String masked = text;
        for (String key : props.getMaskBodyKeys()) {
            // "key":"value" / key=value 形式の値を伏せる
            masked = masked.replaceAll("(\"" + Pattern.quote(key) + "\"\\s*:\\s*\")[^\"]*(\")", "$1" + MASK + "$2");
            masked = masked.replaceAll("(" + Pattern.quote(key) + "\\s*=\\s*)[^,\\s)}]+", "$1" + MASK);
        }
        return masked;
    }

    public String truncate(String s, int max) {
        if (s == null || s.length() <= max) {
            return s;
        }
        return s.substring(0, max) + "...(truncated)";
    }

    private Set<String> lowerSet(java.util.List<String> values) {
        return values.stream().map(v -> v.toLowerCase(Locale.ROOT)).collect(Collectors.toSet());
    }
}
