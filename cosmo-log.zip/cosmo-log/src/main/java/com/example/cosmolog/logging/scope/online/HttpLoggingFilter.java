package com.example.cosmolog.logging.scope.online;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LogSubtype;
import com.example.cosmolog.logging.LogType;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.StructuredLog;
import com.example.cosmolog.logging.mask.LogMaskingService;
import com.example.cosmolog.logging.scope.ExecutionScopeMdc;
import com.example.cosmolog.logging.scope.online.FunctionActionResolver.FunctionAction;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 【オンライン(API)】の実行単位スコープ起点。HTTPリクエスト単位で:
 *   1. {@link ExecutionScopeMdc} で trace_id/user/source_ip/function/action を MDC 設定
 *   2. request/response をラップしてボディをキャッシュ
 *   3. アクセスジャーナルログ（要求/応答）を出力
 *   4. スコープ終了時に MDC をクリア
 *
 * バッチ/常駐バッチは scope.batch / scope.resident を参照。
 */
@Component
public class HttpLoggingFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.API_ACCESS);

    private static final String HEADER_TRACE_ID = "traceparent";
    private static final String HEADER_USER = "X-User-Id";
    private static final String HEADER_FORWARDED_FOR = "X-Forwarded-For";

    private final FunctionActionResolver functionActionResolver;
    private final LogMaskingService masking;

    public HttpLoggingFilter(FunctionActionResolver functionActionResolver, LogMaskingService masking) {
        this.functionActionResolver = functionActionResolver;
        this.masking = masking;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        ContentCachingRequestWrapper req = new ContentCachingRequestWrapper(request);
        ContentCachingResponseWrapper res = new ContentCachingResponseWrapper(response);

        String traceId = orElseGenerate(request.getHeader(HEADER_TRACE_ID));
        FunctionAction fa = functionActionResolver.resolve(request);
        String url = buildUrl(req);
        long startNanos = System.nanoTime();

        // 実行単位スコープ開始（オンライン）。close() で MDC クリア。
        try (ExecutionScopeMdc scope = ExecutionScopeMdc.open(
                fa.function(), fa.action(), request.getHeader(HEADER_USER), traceId, clientIp(request))) {
            // ジャーナルは MDC が有効なスコープ内(=close前)で出力する
            try {
                chain.doFilter(req, res);
            } finally {
                long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;

                // アクセスジャーナルログ（要求）: headers=リクエストヘッダー / body=リクエストボディ
                log.info(StructuredLog.of(LogType.APP, LogSubtype.APL)
                        .put(LogFields.URL, url)
                        .put(LogFields.HEADERS, masking.maskHeaders(requestHeaders(req)))
                        .put(LogFields.BODY, masking.maskBody(content(req.getContentAsByteArray())))
                        .marker(), "access journal (request)");

                // アクセスジャーナルログ（応答）: headers=レスポンスヘッダー / body=レスポンスボディ
                log.info(StructuredLog.of(LogType.APP, LogSubtype.APL)
                        .put(LogFields.URL, url)
                        .put(LogFields.STATUS, res.getStatus())
                        .put(LogFields.HEADERS, masking.maskHeaders(responseHeaders(res)))
                        .put(LogFields.BODY, masking.maskBody(content(res.getContentAsByteArray())))
                        .put(LogFields.LATENCY, latencyMs)
                        .marker(), "access journal (response)");

                // ContentCachingResponseWrapper は最後に copy しないと実レスポンスが返らない
                res.copyBodyToResponse();
            }
        }
    }

    private String orElseGenerate(String value) {
        return (value == null || value.isBlank()) ? UUID.randomUUID().toString() : value;
    }

    private String clientIp(HttpServletRequest request) {
        String forwarded = request.getHeader(HEADER_FORWARDED_FOR);
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    private String buildUrl(HttpServletRequest request) {
        String query = request.getQueryString();
        return request.getMethod() + " " + request.getRequestURI() + (query != null ? "?" + query : "");
    }

    private Map<String, String> requestHeaders(HttpServletRequest request) {
        Map<String, String> headers = new LinkedHashMap<>();
        Enumeration<String> names = request.getHeaderNames();
        while (names.hasMoreElements()) {
            String name = names.nextElement();
            headers.put(name, request.getHeader(name));
        }
        return headers;
    }

    private Map<String, String> responseHeaders(HttpServletResponse response) {
        Map<String, String> headers = new LinkedHashMap<>();
        for (String name : response.getHeaderNames()) {
            headers.put(name, response.getHeader(name));
        }
        return headers;
    }

    private String content(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
