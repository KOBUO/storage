package com.example.cosmolog.logging.aws;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.MdcKeys;
import com.example.cosmolog.logging.StructuredLog;
import com.example.cosmolog.logging.aws.AwsResponseMetadataExtractor.AwsMeta;
import com.example.cosmolog.logging.scope.ExecutionScopeMdc;

import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

/**
 * SQSアクセス部品。送信/受信時にメッセージジャーナルログを出力する。
 * aws_sqs_message_id は SQS専用。SqsClient は遅延生成。
 */
@Component
public class SqsAccessService {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.SQS_JNL);

    private volatile SqsClient client;

    private SqsClient client() {
        if (client == null) {
            synchronized (this) {
                if (client == null) {
                    client = SqsClient.create();
                }
            }
        }
        return client;
    }

    public String sendMessage(String queueUrl, String body) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();

        SendMessageRequest.Builder builder = SendMessageRequest.builder().queueUrl(queueUrl).messageBody(body);
        // トレース伝播：MDCのtrace_idをメッセージ属性 traceparent に載せる
        String traceId = MDC.get(MdcKeys.TRACE_ID);
        if (traceId != null && !traceId.isBlank()) {
            builder.messageAttributes(Map.of(SqsTraceSupport.TRACEPARENT,
                    MessageAttributeValue.builder().dataType("String").stringValue(traceId).build()));
        }

        SendMessageResponse response = client().sendMessage(builder.build());
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        AwsMeta meta = AwsResponseMetadataExtractor.extract(response);

        log.info(StructuredLog.create()
                .put(LogFields.AWS_SQS_MESSAGE_ID, response.messageId())
                .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .put(LogFields.LATENCY, latencyMs)
                .marker(), "sqs journal (send)");
        return response.messageId();
    }

    public List<Message> receiveMessages(String queueUrl) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        ReceiveMessageResponse response = client().receiveMessage(ReceiveMessageRequest.builder()
                .queueUrl(queueUrl).maxNumberOfMessages(10)
                .messageAttributeNames(SqsTraceSupport.TRACEPARENT) // traceparent 属性を取得
                .build());
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        AwsMeta meta = AwsResponseMetadataExtractor.extract(response);

        for (Message message : response.messages()) {
            // 受信ジャーナルは、そのメッセージの trace_id を MDC に立ててから出力する（trace_id欠落を防ぐ）
            try (ExecutionScopeMdc scope = ExecutionScopeMdc.open(
                    "messageReceive", "RECEIVE", null, SqsTraceSupport.traceId(message), null)) {
                log.info(StructuredLog.create()
                        .put(LogFields.AWS_SQS_MESSAGE_ID, message.messageId())
                        .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                        .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                        .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                        .put(LogFields.LATENCY, latencyMs)
                        .marker(), "sqs journal (receive)");
            }
        }
        return response.messages();
    }
}
