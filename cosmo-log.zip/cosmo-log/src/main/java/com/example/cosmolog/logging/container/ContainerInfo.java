package com.example.cosmolog.logging.container;

/**
 * id / name（アプリケーションスコープ）の保持先。
 * MDCはスレッド単位のため、全スレッド共通の値はここで静的に保持する。
 */
public final class ContainerInfo {

    private static volatile String id = "UNKNOWN";
    private static volatile String name = "UNKNOWN";

    public static String getId() {
        return id;
    }

    public static String getName() {
        return name;
    }

    static void set(String id, String name) {
        ContainerInfo.id = id;
        ContainerInfo.name = name;
    }

    private ContainerInfo() {
    }
}
