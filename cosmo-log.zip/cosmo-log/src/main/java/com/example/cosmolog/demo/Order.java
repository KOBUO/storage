package com.example.cosmolog.demo;

public record Order(String id, String customer, int amount) {
}
