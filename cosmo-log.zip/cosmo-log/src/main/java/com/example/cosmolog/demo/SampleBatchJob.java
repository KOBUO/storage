package com.example.cosmolog.demo;

import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.ApplicationLogger;
import com.example.cosmolog.logging.scope.ExecutionScopeMdc;
import com.example.cosmolog.logging.scope.batch.BatchLogScope;

/**
 * 【バッチ】起点の例。ジョブ開始で MDC 設定 → 終了でクリア。
 * 実プロジェクトでは Spring Batch の Tasklet / CommandLineRunner 等から呼ぶ。
 */
@Component
public class SampleBatchJob {

    private final ApplicationLogger appLogger;
    private final SampleService service;

    public SampleBatchJob(ApplicationLogger appLogger, SampleService service) {
        this.appLogger = appLogger;
        this.service = service;
    }

    public void run(String jobExecutionId) {
        try (ExecutionScopeMdc scope = BatchLogScope.open("売上集計バッチ", jobExecutionId)) {
            appLogger.info("バッチ処理開始");
            service.getOrder("1"); // サービスジャーナルも同じ trace_id/function で出力される
            appLogger.info("バッチ処理終了");
        }
    }
}
