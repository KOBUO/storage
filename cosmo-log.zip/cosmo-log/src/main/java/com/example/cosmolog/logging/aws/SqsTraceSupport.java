package com.example.cosmolog.logging.aws;

import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;

/**
 * SQSメッセージのトレース伝播ヘルパー。
 * 送信側は MDC の trace_id をメッセージ属性 {@code traceparent} に載せ、
 * 受信側は {@code traceparent} があればそれを、無ければ MessageId を trace_id として使う。
 */
public final class SqsTraceSupport {

    public static final String TRACEPARENT = "traceparent";

    private SqsTraceSupport() {
    }

    /** 受信メッセージの trace_id：属性 traceparent 優先、無ければ MessageId。 */
    public static String traceId(Message message) {
        MessageAttributeValue attr = message.messageAttributes().get(TRACEPARENT);
        if (attr != null && attr.stringValue() != null && !attr.stringValue().isBlank()) {
            return attr.stringValue();
        }
        return message.messageId();
    }
}
