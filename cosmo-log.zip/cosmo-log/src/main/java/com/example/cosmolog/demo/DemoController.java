package com.example.cosmolog.demo;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

/**
 * 追加ジャーナル部品の動作確認用。
 *  - /api/price/{sku} : キャッシュジャーナル(CacheJournalAspect)
 *  - /api/external    : 外部アクセスジャーナル(HttpClientJournalInterceptor)
 */
@RestController
public class DemoController {

    private final PricingService pricingService;
    private final RestTemplate restTemplate;

    public DemoController(PricingService pricingService, RestTemplate restTemplate) {
        this.pricingService = pricingService;
        this.restTemplate = restTemplate;
    }

    @GetMapping("/api/price/{sku}")
    public Map<String, Object> price(@PathVariable String sku) {
        return Map.of("sku", sku, "price", pricingService.price(sku));
    }

    @GetMapping("/api/external")
    public ResponseEntity<String> external(@RequestParam String url) {
        return restTemplate.getForEntity(url, String.class);
    }
}
