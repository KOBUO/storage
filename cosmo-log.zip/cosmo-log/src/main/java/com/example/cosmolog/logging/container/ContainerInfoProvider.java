package com.example.cosmolog.logging.container;

import java.net.InetAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.annotation.PostConstruct;

/**
 * コンテナ情報取得部品。
 * アプリ起動時に1回だけ ECS Task ID / Service名 を取得し {@link ContainerInfo} へ保持する。
 * ECS外（ローカル等）では環境変数→ホスト名にフォールバックする。
 */
@Component
public class ContainerInfoProvider {

    private static final Logger log = LoggerFactory.getLogger(ContainerInfoProvider.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @PostConstruct
    public void init() {
        String id = System.getenv("ECS_TASK_ID");
        String name = System.getenv("ECS_SERVICE_NAME");

        String metadataUri = System.getenv("ECS_CONTAINER_METADATA_URI_V4");
        if ((isBlank(id) || isBlank(name)) && !isBlank(metadataUri)) {
            try {
                HttpClient client = HttpClient.newHttpClient();
                HttpRequest request = HttpRequest.newBuilder(URI.create(metadataUri + "/task")).GET().build();
                String body = client.send(request, HttpResponse.BodyHandlers.ofString()).body();
                JsonNode node = MAPPER.readTree(body);
                if (isBlank(id)) {
                    String taskArn = node.path("TaskARN").asText("");
                    id = taskArn.contains("/") ? taskArn.substring(taskArn.lastIndexOf('/') + 1) : taskArn;
                }
                if (isBlank(name)) {
                    name = node.path("ServiceName").asText(node.path("Family").asText(""));
                }
            } catch (Exception e) {
                log.warn("ECS metadata の取得に失敗しました。フォールバックします: {}", e.getMessage());
            }
        }

        if (isBlank(id)) {
            id = hostname();
        }
        if (isBlank(name)) {
            name = System.getProperty("spring.application.name", "cosmo-log");
        }

        ContainerInfo.set(id, name);
        log.info("Container info initialized. id={}, name={}", id, name);
    }

    private String hostname() {
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }

    private boolean isBlank(String s) {
        return s == null || s.isBlank();
    }
}
