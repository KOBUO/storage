package com.example.cosmolog.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.mask.LogMaskingService;

/**
 * 業務ログ出力部品（明示的に出力する業務イベント）。
 * 業務ログ(X)は SPRINGBOOT_API_LOG、業務エラーログ(Y)は SPRINGBOOT_ERROR_LOG へ固定ロガー名で出力する。
 * type / subtype は TypeSubtypeJsonProvider が付与する（type=レベル判定 / subtype=APL）。
 *
 * ※システムログ(Z) は「明示出力していない FW 等の root ログ」であり本部品ではない。
 * ※マトリクス準拠：class_name / method_name は出力しない（サービスジャーナル P,Q のみ）。
 */
@Component
public class ApplicationLogger {

    private static final Logger business = LoggerFactory.getLogger(LoggerNames.API_LOG);
    private static final Logger error = LoggerFactory.getLogger(LoggerNames.ERROR_LOG);

    private final LogMaskingService masking;

    public ApplicationLogger(LogMaskingService masking) {
        this.masking = masking;
    }

    /** 業務ログ(X): trace_id(MDC) / message。 */
    public void info(String message) {
        business.info(StructuredLog.create().marker(), masking.maskMessage(message));
    }

    /** 業務エラーログ(Y): trace_id(MDC) / message / stack_trace。 */
    public void error(String message, Throwable t) {
        error.error(StructuredLog.create().marker(), masking.maskMessage(message), t);
    }
}
