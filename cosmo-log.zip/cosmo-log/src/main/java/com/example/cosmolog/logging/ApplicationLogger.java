package com.example.cosmolog.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.mask.LogMaskingService;

/**
 * 業務ログ出力部品。
 * 業務ログ(X)は SPRINGBOOT_API_LOG(type=app/subtype=APL)、
 * システムログ(Z)は SPRINGBOOT_ERROR_LOG(type=monitor/subtype=SYSTEM) へ固定ロガー名で出力する。
 *
 * ※マトリクス準拠：業務ログ/システムログは class_name / method_name を出力しない
 *   （class_name/method_name はサービスジャーナル P,Q のみ）。
 */
@Component
public class ApplicationLogger {

    private static final Logger business = LoggerFactory.getLogger(LoggerNames.API_LOG);
    private static final Logger error = LoggerFactory.getLogger(LoggerNames.ERROR_LOG);

    private final LogMaskingService masking;

    public ApplicationLogger(LogMaskingService masking) {
        this.masking = masking;
    }

    /** 業務ログ(X): trace_id(MDC) / message。 */
    public void info(String message) {
        business.info(StructuredLog.of(LogType.APP, LogSubtype.APL).marker(), masking.maskMessage(message));
    }

    /** システムログ(Z): trace_id(MDC) / message / stack_trace。 */
    public void error(String message, Throwable t) {
        error.error(StructuredLog.of(LogType.MONITOR, LogSubtype.SYSTEM).marker(), masking.maskMessage(message), t);
    }
}
