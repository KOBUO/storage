package com.example.cosmolog.demo;

import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.ApplicationLogger;
import com.example.cosmolog.logging.scope.ExecutionScopeMdc;
import com.example.cosmolog.logging.scope.resident.MessageLogScope;

/**
 * 【常駐バッチ（メッセージ処理）】起点の例。1メッセージごとに MDC 設定 → 処理終了でクリア。
 * 実プロジェクトでは {@code @SqsListener} 等から onMessage を呼ぶ。
 */
@Component
public class SampleMessageListener {

    private final ApplicationLogger appLogger;

    public SampleMessageListener(ApplicationLogger appLogger) {
        this.appLogger = appLogger;
    }

    // 実際は: @SqsListener("queue") public void onMessage(Message m) { ...
    //   String traceId = SqsTraceSupport.traceId(m); // 属性traceparent優先、無ければMessageId
    //   受信ジャーナルは SqsAccessService 側がメッセージ毎の trace_id を立てて出力する。
    public void onMessage(String messageId, String body) {
        try (ExecutionScopeMdc scope = MessageLogScope.open("配信計画メッセージ処理", messageId)) {
            try {
                appLogger.info("メッセージ処理開始 body=" + body);
                // ... 業務処理（サービスジャーナル等も同じ trace_id で出力される）...
                appLogger.info("メッセージ処理終了");
            } catch (RuntimeException e) {
                // メッセージ処理失敗を業務エラーログに残す（この後 DLQ/リトライへ）
                appLogger.error("メッセージ処理失敗 messageId=" + messageId, e);
                throw e;
            }
        }
    }
}
