package com.example.cosmolog.logging.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LogSubtype;
import com.example.cosmolog.logging.LogType;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.StructuredLog;

/**
 * キャッシュジャーナルログ出力部品。
 * {@code @Cacheable} のメソッド前後でキャッシュアクセスログを出力する。
 *
 * ※マトリクス準拠：キャッシュジャーナル(V)は trace_id(MDC) / message / latency のみ。
 *   class_name / method_name / args / result は出力しない（それらはサービスジャーナル P,Q のみ）。
 *   (TODO: キャッシュのヒット有無/対象キーを message へ載せるかは要確認)
 */
@Aspect
@Component
public class CacheJournalAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.CACHE_JNL);

    @Around("@annotation(org.springframework.cache.annotation.Cacheable)")
    public Object aroundCacheable(ProceedingJoinPoint pjp) throws Throwable {
        long startNanos = System.nanoTime();
        Object result = pjp.proceed();
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;

        log.info(StructuredLog.of(LogType.APP, LogSubtype.APL)
                .put(LogFields.LATENCY, latencyMs)
                .marker(), "cache journal: " + pjp.getSignature().getName());
        return result;
    }
}
