package com.example.cosmolog.logging.aws;

import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.StructuredLog;
import com.example.cosmolog.logging.aws.AwsResponseMetadataExtractor.AwsMeta;

import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.kms.KmsClient;
import software.amazon.awssdk.services.kms.model.DecryptRequest;
import software.amazon.awssdk.services.kms.model.DecryptResponse;
import software.amazon.awssdk.services.kms.model.EncryptRequest;
import software.amazon.awssdk.services.kms.model.EncryptResponse;

/**
 * KMSアクセス部品。暗号化/復号時に KMSアクセスジャーナルログ(AWSCALL) を出力する。
 * KmsClient は遅延生成。type/subtype は TypeSubtypeJsonProvider が付与（subtype=AWSCALL）。
 */
@Component
public class KmsAccessService {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.KMS_JNL);

    private volatile KmsClient client;

    private KmsClient client() {
        if (client == null) {
            synchronized (this) {
                if (client == null) {
                    client = KmsClient.create();
                }
            }
        }
        return client;
    }

    public SdkBytes encrypt(String keyId, byte[] plaintext) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        EncryptResponse response = client().encrypt(EncryptRequest.builder()
                .keyId(keyId).plaintext(SdkBytes.fromByteArray(plaintext)).build());
        journal(requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "encrypt");
        return response.ciphertextBlob();
    }

    public SdkBytes decrypt(byte[] ciphertext) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        DecryptResponse response = client().decrypt(DecryptRequest.builder()
                .ciphertextBlob(SdkBytes.fromByteArray(ciphertext)).build());
        journal(requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "decrypt");
        return response.plaintext();
    }

    private void journal(String requestTimestamp, long startNanos, AwsMeta meta, String op) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        log.info(StructuredLog.create()
                .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                // aws_request_timestamp / aws_response_time は設計上△(案)。要確定。
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .put(LogFields.LATENCY, latencyMs)
                .marker(), "kms journal (" + op + ")");
    }
}
