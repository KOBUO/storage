package com.example.cosmolog.logging;

/** ログ種類の大分類(type)。 */
public final class LogType {

    public static final String APP = "app";
    public static final String MONITOR = "monitor";
    public static final String TRAIL = "trail";

    private LogType() {
    }
}
