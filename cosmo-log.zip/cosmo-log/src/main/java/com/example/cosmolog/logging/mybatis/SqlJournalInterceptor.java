package com.example.cosmolog.logging.mybatis;

import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.StructuredLog;

/**
 * SQLジャーナルログ出力部品（MyBatis Interceptor）。
 * SQL実行(update/query)前後で DBCALL ジャーナルログを出力する。
 *
 * <p>※ 本サンプルは実DB(MyBatis)を持たないため Spring Bean としては登録しない（参照実装）。
 * 実プロジェクトでは MyBatis 設定に登録する:
 * <pre>{@code
 * @Bean
 * org.mybatis.spring.boot.autoconfigure.ConfigurationCustomizer mybatisCustomizer() {
 *     return config -> config.addInterceptor(new SqlJournalInterceptor());
 * }
 * }</pre>
 *
 * <p>masking は LogMaskingService を注入して args に適用するのが望ましい（参照実装では簡略化）。
 * また、ログ4KB制約に備え参照結果(result)はしきい値で制限すること（設計書 項目14 備考）。
 */
@Intercepts({
        @Signature(type = Executor.class, method = "update",
                args = {MappedStatement.class, Object.class}),
        @Signature(type = Executor.class, method = "query",
                args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class})
})
public class SqlJournalInterceptor implements Interceptor {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.SQL_JNL);

    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        MappedStatement mappedStatement = (MappedStatement) invocation.getArgs()[0];

        long startNanos = System.nanoTime();
        try {
            Object result = invocation.proceed();
            long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
            // マトリクス準拠：SQLジャーナル(R)は trace_id(MDC) / message / latency のみ。
            // class_name(ステートメントID) / method_name(SQL種別) / args は出力しない。
            // 必要時は message に概要を載せる（4KB制約・PIIに注意） (TODO: SQL詳細の扱い)
            log.info(StructuredLog.create()
                    .put(LogFields.LATENCY, latencyMs)
                    .marker(), "sql journal: " + mappedStatement.getId());
            return result;
        } catch (Throwable t) {
            long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
            log.error(StructuredLog.create()
                    .put(LogFields.LATENCY, latencyMs)
                    .marker(), "sql journal (error): " + mappedStatement.getId(), t);
            throw t;
        }
    }
}
