package com.example.cosmolog.demo;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

/**
 * キャッシュジャーナルログのデモ用。
 * {@code @Cacheable} なので CacheJournalAspect によりキャッシュアクセスログが出力される。
 * （@Service ではないためサービスジャーナルの対象外）
 */
@Component
public class PricingService {

    @Cacheable("prices")
    public int price(String sku) {
        // 初回のみ重い処理が走る想定（2回目以降はキャッシュヒットでこのメソッドは呼ばれない）
        try {
            Thread.sleep(50);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return Math.abs(sku.hashCode() % 1000);
    }
}
