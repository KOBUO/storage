package com.example.cosmolog.logging.web;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * 外部HTTP用 RestTemplate。
 * BufferingClientHttpRequestFactory でレスポンスを再読込可能にし、
 * ジャーナルインターセプタがボディを読んでも本来の呼出側で読めるようにする。
 */
@Configuration
public class RestClientConfig {

    @Bean
    public RestTemplate restTemplate(HttpClientJournalInterceptor journalInterceptor) {
        RestTemplate restTemplate = new RestTemplate(
                new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
        restTemplate.getInterceptors().add(journalInterceptor);
        return restTemplate;
    }
}
