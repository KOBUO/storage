package com.example.cosmolog.demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.cosmolog.logging.ApplicationLogger;

@RestController
@RequestMapping("/api/orders")
public class SampleController {

    private final SampleService service;
    private final ApplicationLogger appLogger;

    public SampleController(SampleService service, ApplicationLogger appLogger) {
        this.service = service;
        this.appLogger = appLogger;
    }

    @GetMapping("/{id}")
    public Order get(@PathVariable String id) {
        return service.getOrder(id);
    }

    @PostMapping
    public Order create(@RequestBody Order order) {
        return service.createOrder(order);
    }
}
