package com.example.cosmolog.logging.aws;

import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LogSubtype;
import com.example.cosmolog.logging.LogType;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.StructuredLog;
import com.example.cosmolog.logging.aws.AwsResponseMetadataExtractor.AwsMeta;

import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectResponse;

/**
 * S3アクセス部品。S3 API 呼び出しを集約し、ストレージアクセスジャーナルログを出力する。
 * S3Client は遅延生成（リージョン/認証はAWS環境で解決）。
 */
@Component
public class S3AccessService {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.STORAGE_JNL);

    private volatile S3Client client;

    private S3Client client() {
        if (client == null) {
            synchronized (this) {
                if (client == null) {
                    client = S3Client.create();
                }
            }
        }
        return client;
    }

    public void putObject(String bucket, String key, byte[] content) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        PutObjectResponse response = client().putObject(
                PutObjectRequest.builder().bucket(bucket).key(key).build(),
                RequestBody.fromBytes(content));
        journal(bucket, key, requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "putObject");
    }

    public byte[] getObject(String bucket, String key) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        ResponseBytes<GetObjectResponse> response = client().getObjectAsBytes(
                GetObjectRequest.builder().bucket(bucket).key(key).build());
        journal(bucket, key, requestTimestamp, startNanos,
                AwsResponseMetadataExtractor.extract(response.response()), "getObject");
        return response.asByteArray();
    }

    private void journal(String bucket, String key, String requestTimestamp, long startNanos, AwsMeta meta, String op) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        log.info(StructuredLog.of(LogType.APP, LogSubtype.AWSCALL)
                .put(LogFields.BUCKET_NAME, bucket)
                .put(LogFields.PATH, key)
                .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                .put(LogFields.AWS_S3_EXTENDED_REQUEST_ID, meta.extendedRequestId())
                // aws_request_timestamp / aws_response_time は設計上△(案)。要確定。
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .put(LogFields.LATENCY, latencyMs)
                .marker(), "storage journal (" + op + ")");
    }
}
