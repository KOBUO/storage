package com.example.cosmolog.logging;

/**
 * MDCに載せる実行単位スコープの項目キー。
 * 物理名とMDCキーを一致させ、logback の {@code <mdc/>} provider でそのまま出力する。
 */
public final class MdcKeys {

    public static final String FUNCTION = "function";
    public static final String USER = "user";
    public static final String ACTION = "action";
    public static final String TRACE_ID = "trace_id";
    public static final String SOURCE_IP = "source_ip";

    public static final String[] ALL = {FUNCTION, USER, ACTION, TRACE_ID, SOURCE_IP};

    private MdcKeys() {
    }
}
