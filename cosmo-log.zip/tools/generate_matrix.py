#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""出力対象ログ マトリクス(論理名 × L〜Z)を PNG 画像で生成する。EPUBで崩れず拡大も可。"""
from PIL import Image, ImageDraw, ImageFont

FONT = "/System/Library/Fonts/Hiragino Sans GB.ttc"
S = 2  # 解像度倍率
LABEL_W, COL_W, ROW_H, HEAD_H = 300 * S, 42 * S, 38 * S, 46 * S
PAD = 6 * S

cols = ["L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
ALL = set(cols)
# (論理名, present集合, △集合)
rows = [
    ("タイムスタンプ", ALL, set()),
    ("コンテナID", ALL, set()),
    ("コンテナ名", ALL, set()),
    ("ログレベル", ALL, set()),
    ("ログレベル値", ALL, set()),
    ("ロガー名", ALL - {"L"}, set()),
    ("ログ種類", ALL, set()),
    ("スレッド番号", ALL - {"L"}, set()),
    ("機能ID", ALL, set()),
    ("ユーザーID", {"L", "M"}, set()),
    ("操作", {"L", "M"}, set()),
    ("ログ種類詳細", ALL, set()),
    ("トレースID", ALL - {"L", "M"}, set()),
    ("ログメッセージ", ALL, set()),
    ("スタックトレース", {"Y", "Z"}, set()),
    ("クライアントIPアドレス", {"L", "M"}, set()),
    ("URL", {"L", "M", "N", "O", "T", "U"}, set()),
    ("HTTPステータス", {"L", "M", "N", "O", "T", "U"}, set()),
    ("ヘッダ情報", {"N", "O", "T", "U"}, set()),
    ("ボディ情報", {"N", "O", "T", "U"}, set()),
    ("クラス名", {"P", "Q", "X", "Y"}, set()),
    ("メソッド名", {"P", "Q", "X", "Y"}, set()),
    ("引数", {"P", "Q"}, set()),
    ("実行結果", {"P", "Q"}, set()),
    ("バケット名", {"S"}, set()),
    ("パス", {"S"}, set()),
    ("処理時間", {"L", "M", "O", "Q", "R", "S", "U", "V", "W"}, set()),
    ("AWS Request ID", {"S", "U", "W"}, set()),
    ("AWS Request Timestamp", set(), {"S", "U", "W"}),
    ("AWS Response Time", set(), {"S", "U", "W"}),
    ("S3 Extended Request ID", {"S"}, set()),
    ("SQS Message ID", {"W"}, set()),
]

W = LABEL_W + COL_W * len(cols)
H = HEAD_H + ROW_H * len(rows)
img = Image.new("RGB", (W + 1, H + 1), "white")
d = ImageDraw.Draw(img)
f_head = ImageFont.truetype(FONT, 20 * S)
f_label = ImageFont.truetype(FONT, 17 * S)
f_cell = ImageFont.truetype(FONT, 19 * S)

GRID = (170, 170, 170)
HEADBG = (220, 230, 245)
YEL = (255, 242, 204)


def ctext(cx, cy, s, font, fill="black"):
    bb = d.textbbox((0, 0), s, font=font)
    d.text((cx - (bb[2] - bb[0]) / 2, cy - (bb[3] - bb[1]) / 2 - bb[1]), s, font=font, fill=fill)


# header background
d.rectangle([0, 0, W, HEAD_H], fill=HEADBG)
ctext(LABEL_W / 2, HEAD_H / 2, "論理名", f_head)
for j, c in enumerate(cols):
    x = LABEL_W + j * COL_W
    ctext(x + COL_W / 2, HEAD_H / 2, c, f_head)

# rows
for i, (name, present, tri) in enumerate(rows):
    y = HEAD_H + i * ROW_H
    # label (left aligned)
    d.text((PAD, y + ROW_H / 2 - 9 * S), name, font=f_label, fill="black")
    for j, c in enumerate(cols):
        x = LABEL_W + j * COL_W
        if c in tri:
            d.rectangle([x, y, x + COL_W, y + ROW_H], fill=YEL)
            ctext(x + COL_W / 2, y + ROW_H / 2, "△", f_cell)
        elif c in present:
            ctext(x + COL_W / 2, y + ROW_H / 2, "○", f_cell)

# grid lines
for i in range(len(rows) + 2):
    yy = i * ROW_H if i == 0 else HEAD_H + (i - 1) * ROW_H
    yy = HEAD_H + (i - 1) * ROW_H if i >= 1 else 0
    d.line([(0, yy), (W, yy)], fill=GRID, width=1)
d.line([(0, 0), (W, 0)], fill=GRID, width=1)
d.line([(0, HEAD_H), (W, HEAD_H)], fill=GRID, width=2)
for j in range(len(cols) + 1):
    x = LABEL_W + j * COL_W
    d.line([(x, 0), (x, H)], fill=GRID, width=1)
d.line([(0, 0), (0, H)], fill=GRID, width=1)
d.line([(W, 0), (W, H)], fill=GRID, width=1)
d.line([(0, H), (W, H)], fill=GRID, width=1)

import os
os.makedirs("/Users/kobuo/workspace/cosmo-log/book/img", exist_ok=True)
img.save("/Users/kobuo/workspace/cosmo-log/book/img/matrix.png")
print("written book/img/matrix.png", img.size)
