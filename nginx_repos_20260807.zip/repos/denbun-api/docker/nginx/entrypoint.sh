#!/bin/sh
set -eu

ROUTING_FILE_PATH="/shared/routing.json"
ROUTES_JS="/etc/nginx/njs/routes.js"
TEMPLATE="/etc/nginx/templates/nginx.conf.template"
NGINX_CONF="/etc/nginx/nginx.conf"
ERROR_PIPE="/tmp/nginx-error"

REQUIRED_ENV="BACKEND_URL MAX_CONNECTIONS WORKER_CONNECTIONS MAX_BODY_SIZE LIMIT_ZONE_SIZE
LIMIT_CONNECTION
PROXY_CONNECT_TIMEOUT PROXY_READ_TIMEOUT PROXY_SEND_TIMEOUT"

now_timestamp() {
    jq -rn 'now as $time
        | ($time | strflocaltime("%Y-%m-%d %H:%M:%S"))
          + "." + (("00" + (($time * 1000 | floor) % 1000 | tostring)) | .[-3:])'
}

log() {
    level=$1
    message=$2
    case "$level" in
        ERROR) level_value=40000; type=monitor ;;
        WARN)  level_value=30000; type=app ;;
        *)     level_value=20000; type=app ;;
    esac

    jq -c -n \
        --arg timestamp "$(now_timestamp)" \
        --arg id "${CONTAINER_ID:--}" \
        --arg name "${CONTAINER_NAME:--}" \
        --arg level "$level" \
        --argjson level_value "$level_value" \
        --arg type "$type" \
        --arg message "$message" \
        '{timestamp: $timestamp, id: $id, name: $name,
          level: $level, level_value: $level_value, type: $type, thread: "-",
          function: "-", user: "-", action: "-", subtype: "NGINX", trace: "-",
          message: $message}' >&3
}

abort() {
    handled=1
    log ERROR "$1"
    exit 1
}

# 起動処理中の標準エラーを退避し、想定外のエラー（列挙した abort 以外）でも
# 原因（失敗コマンドのエラー出力）を含めて JSON 形式でログを残してから終了する。
# fd3=本来の標準エラー（JSONログ出力先）、fd2=退避ファイル。
STARTUP_STDERR=$(mktemp)
exec 3>&2
exec 2>"$STARTUP_STDERR"

handled=0
on_exit() {
    code=$?
    if [ "$code" -ne 0 ] && [ "$handled" -eq 0 ]; then
        detail=$(tail -n 1 "$STARTUP_STDERR" 2>/dev/null)
        log ERROR "コンテナの起動処理で予期せぬエラーが発生しました。（終了コード: ${code}${detail:+ / $detail}）"
    fi
    rm -f "$STARTUP_STDERR"
}
trap on_exit EXIT

# Nginx のエラーログ行 "2026/01/01 00:00:00 [error] 1#1: メッセージ" から重大度を取り出す。
nginx_log_level() {
    case "$1" in
        *'[emerg]'*|*'[alert]'*|*'[crit]'*|*'[error]'*) echo ERROR ;;
        *'[warn]'*)                                     echo WARN ;;
        *)                                              echo INFO ;;
    esac
}

# ---- コンテナIDおよびコンテナ名の取得 ----
# タスクメタデータエンドポイントは Fargate でのみ提供される。取得できない場合は "-" とする。
CONTAINER_ID="-"
CONTAINER_NAME="-"
if [ -n "${ECS_CONTAINER_METADATA_URI_V4:-}" ]; then
    metadata=$(curl -sf --max-time 3 "$ECS_CONTAINER_METADATA_URI_V4" || true)
    if [ -n "$metadata" ]; then
        CONTAINER_ID=$(echo "$metadata" | jq -r '.DockerId // "-"')
        CONTAINER_NAME=$(echo "$metadata" | jq -r '.Name // "-"')
    fi
fi
export CONTAINER_ID CONTAINER_NAME

# ---- 必須環境変数の検証 ----
for name in $REQUIRED_ENV; do
    eval "value=\${$name:-}"
    [ -n "$value" ] || abort "必須環境変数が設定されていません。（環境変数名: ${name}）"
done

# ---- 転送先定義の決定 ----
# BACKEND_URL は http スキームのみ対応（TLS 終端は ELB）。誤設定を早期に検知する。
case "$BACKEND_URL" in
    http://*) ;;
    *) abort "BACKEND_URL は http:// で指定してください。（値: ${BACKEND_URL}）" ;;
esac
# upstream の server にはポート番号が要るため、含まれない場合は既定値を補う。パス部は除去する。
BACKEND_ADDRESS=${BACKEND_URL#http://}
BACKEND_ADDRESS=${BACKEND_ADDRESS%%/*}
case "$BACKEND_ADDRESS" in
    *:*) ;;
    *)   BACKEND_ADDRESS="$BACKEND_ADDRESS:80" ;;
esac
export BACKEND_ADDRESS

# ---- DNS リゾルバの決定 ----
# resolve による都度再解決のため、コンテナの /etc/resolv.conf から nameserver を取得する。
DNS_RESOLVER=$(awk '/^nameserver/ { print $2; exit }' /etc/resolv.conf)
[ -n "$DNS_RESOLVER" ] || abort "DNS リゾルバを特定できませんでした。（/etc/resolv.conf）"
export DNS_RESOLVER

# ---- 振分け定義の生成 ----
# 適用開始・終了（エポックミリ秒）は振分け処理がリクエスト受信時に判定する。
routes=$(jq -c \
    '{routing: (.routing | map_values({dest, start: .apply_start, end: .apply_end})),
      default_routing: (.default_routing | map_values(map({dest, start: .apply_start})))}' \
    "$ROUTING_FILE_PATH") \
    || abort "振分け定義の生成に失敗しました。"
printf 'export default %s;\n' "$routes" > "$ROUTES_JS"

# ---- Nginx 設定ファイルの生成 ----
# 展開対象を明示し、Nginx 自身の変数（$host など）が置換されないようにする。
EXPAND='${CONTAINER_ID} ${CONTAINER_NAME} ${WORKER_CONNECTIONS}
${LIMIT_CONNECTION} ${MAX_BODY_SIZE} ${LIMIT_ZONE_SIZE} ${BACKEND_ADDRESS} ${MAX_CONNECTIONS} ${DNS_RESOLVER}
${PROXY_CONNECT_TIMEOUT} ${PROXY_READ_TIMEOUT} ${PROXY_SEND_TIMEOUT}'

envsubst "$EXPAND" < "$TEMPLATE" > "$NGINX_CONF"

validation=$(nginx -t -c "$NGINX_CONF" 2>&1) \
    || abort "Nginx 設定ファイルの妥当性検証に失敗しました。（${validation}）"

# ---- Nginx の起動 ----
# Nginx のエラーログは JSON 形式で出力できないため、標準エラー出力を受け取って整形する。
rm -f "$ERROR_PIPE"
mkfifo "$ERROR_PIPE"
while IFS= read -r line; do
    log "$(nginx_log_level "$line")" "$line"
done < "$ERROR_PIPE" &

exec nginx -g 'daemon off;' -c "$NGINX_CONF" 2> "$ERROR_PIPE"
