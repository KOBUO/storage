# 試験ケース — ファイルダウンロード

- 設計根拠: ファイルダウンロード.md
- 対象実装: 本リポジトリの `docker/`
- 前提: 署名付きURLは API（または boto3 の path-style presign）で発行し、ホスト名を nginx に置換したURLで実行する。
- エラー電文 = `{"apiStatus":"<code>","errors":[{"validationErrCd":"<code>","validationMessage":"<reason>"}]}`
- 証跡取得時は接続先を直書きせず、事前に `接続先=http://<実際の接続先>` を実行（この行は証跡に含めない）し、
  `curl -i "$接続先/…"` の形で実行する。署名付きURLも同様に変数へ入れてから使う。

---

## ケース1 署名付きURLのファイルが帯域制限つきでダウンロードできること

- **条件**: 通常のタスク定義でデプロイ。S3 に検証用オブジェクトを配置する:
  s3/hello.txt と、3MB程度のファイル（`head -c 3000000 /dev/zero > large.bin` で作成）。
  署名付きURL（path-style・ホストを nginx に置換済み）は presign.py で発行する:
  `python3 presign.py <バケット> hello.txt http://<接続先>`
- **手順**:
  ```sh
  curl -s -H 'X-BandWidth-Limit: 8' -o out.bin "$署名付きURL_小"   # 取得後、元ファイルと比較
  curl -s -o /dev/null -w '8Mbps: %{time_total}s\n'   -H 'X-BandWidth-Limit: 8'   "$署名付きURL_3MB"
  curl -s -o /dev/null -w '800Mbps: %{time_total}s\n' -H 'X-BandWidth-Limit: 800' "$署名付きURL_3MB"
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 1-1 | 起動成功・コンテナ情報の取得 | タスク起動成功。ログの `id`/`name` にタスクメタデータ由来の値 | 起動は代替済（id/name は Fargate でのみ確認可） |
| 1-2 | **実S3でのダウンロード（Host置換でSigV4が通る）** | 200・取得ファイルが元と一致 | 代替済（MinIO。実S3は AWS で） |
| 1-3 | 帯域制御（Mbps→バイト/秒 換算） | `8` 指定 ≒ サイズ(MB)÷1 秒（3MBなら約3秒）。`800` 指定は即時 | 代替済（3.2s/0.016s） |
| 1-4 | 正常ログ項目・署名の秘匿 | level=INFO / type=app / **url はパスのみ（`X-Amz-*` 等のクエリを含まない）**/ status=200 / latency(ms) / timestamp=JSTミリ秒。ログ全体に `X-Amz-Signature` が出ないこと | 代替済（署名の非出力を確認） |

## ケース2 帯域制限値ヘッダやパスが不正な場合、エラー電文が返ること

- **手順**:
  ```sh
  curl -i "$署名付きURL_小"                                   # ヘッダ無し
  curl -i -H 'X-BandWidth-Limit: abc' "$署名付きURL_小"        # 不正値
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/other/x"          # 対象外パス
  curl -i -H 'X-BandWidth-Limit: 8000000000000000' "$署名付きURL_小"  # 上限超過(16桁)
  curl -i -X POST -H 'X-BandWidth-Limit: 8' "$署名付きURL_小"          # GET/HEAD以外
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/fixed.txt?posVersion=..%2Fx"  # posVersion不正
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 2-1 | 帯域制限値ヘッダ欠落 | **400** + エラー電文（validationMessage=`Bad Request`）。ログ ERROR「帯域制限値が設定されていません。」 | 代替済 |
| 2-2 | 帯域制限値が不正 | 400 + エラー電文。ログ ERROR「帯域制限値が不正です。」 | 代替済 |
| 2-3 | 対象外パス | **404** + エラー電文（`Not Found`）。ログ ERROR「対象外のパスです。」 | 代替済 |
| 2-4 | 帯域制限値が上限超過（16桁等） | **400**（換算後の指数表記による帯域制限バイパスを防止） | 代替済 |
| 2-5 | GET/HEAD 以外のメソッド | **405** + エラー電文（`Method Not Allowed`）。S3 への PUT/DELETE 中継を遮断 | 代替済 |
| 2-6 | posVersion が不正（`../` 等） | **400** + エラー電文。バケット外への参照を遮断 | 代替済 |

## ケース3 S3が返したエラーが加工されずに返却されること

- **手順**: 署名付きURLの署名部分を改ざんして実行。
  ```sh
  curl -i -H 'X-BandWidth-Limit: 8' "$署名を改ざんしたURL"
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 3-1 | S3エラーの透過 | S3 の **403** をステータス・本文（XML `SignatureDoesNotMatch`）とも加工せず返却。Content-Type も S3 のまま | 代替済 |
| 3-2 | S3起因エラーのログ | level=**INFO**（nginxとしては正常処理。message=`-`） | 代替済 |

## ケース4（任意）オフラインファイルがダウンロードできること

- **条件**: オフライン用バケット（`OFFLINE_BUCKET`）に s3/offline/2.0.0/fixed.txt を
  キー `2.0.0/fixed.txt` で配置する。
- **手順**:
  ```sh
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/<固定ファイル名>?posVersion=2.0.0&<署名>"
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/<固定ファイル名>?<署名>"   # posVersion無し
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 4-1 | オブジェクトキーの組み立て | 200。S3キー=`/<OFFLINE_BUCKET>/2.0.0/<固定名>`、転送時のクエリから `posVersion` は除去 | 代替済 |
| 4-2 | posVersion 欠落 | 400 + エラー電文。ログ ERROR「POSバージョンが設定されていません。」 | 代替済 |

---

> 追加検証済（代替）: 同時ダウンロード数上限(`LIMIT_CONNECTION`)超過で503 / 日本語・空白キーのエンコード保持でSigV4破損なし / S3への余計なヘッダ(Cookie/Authorization/X-BandWidth-Limit)除去 / 上流DNSの都度再解決(resolve)。
>
> 対象外: S3接続不可502／応答タイムアウト504（実S3では再現困難。njsとerror_pageの機構は電文受付と同一で代替環境確認済み）／
> 起動異常系（必須env検証は電文受付・本部画面と同一実装。ローカル確認で足りる）／帯域 `0`=無制限（`limit_rate 0` の nginx 仕様）。
