#!/usr/bin/env python3
"""path-style の署名付きURLを発行し、ホストを Nginx に置き換えた試験用URLを表示する。

通常ダウンロード:
    python3 presign.py <バケット名> <オブジェクトキー> <Nginxの接続先>
    例: python3 presign.py test-bucket hello.txt http://localhost:8080

オフラインダウンロード（posVersion をキーに含めて署名し、Nginx へは posVersion をクエリで渡す形に組み替える）:
    python3 presign.py --offline <オフラインバケット> <posVersion> <固定ファイル名> <Nginxの接続先>
    例: python3 presign.py --offline offlinebucket 2.0.0 fixed.txt http://localhost:8080

MinIO 等の代替環境では、環境変数 AWS_ENDPOINT_URL_S3 で S3 エンドポイントを指定する。
"""
import sys

import boto3
from botocore.config import Config


def presign(bucket, key):
    s3 = boto3.client("s3", config=Config(s3={"addressing_style": "path"}))
    return s3.generate_presigned_url(
        "get_object", Params={"Bucket": bucket, "Key": key}, ExpiresIn=3600
    )


def main():
    args = sys.argv[1:]
    if args[:1] == ["--offline"] and len(args) == 5:
        _, bucket, pos_version, filename, nginx = args
        # 署名対象のキーは posVersion を含む最終形。Nginx へは posVersion をクエリで渡す。
        url = presign(bucket, f"{pos_version}/{filename}")
        query = url.split("?", 1)[1]
        nginx_url = f"{nginx.rstrip('/')}/download/offline/{filename}?posVersion={pos_version}&{query}"
        print("S3   :", url)
        print("Nginx:", nginx_url)
    elif len(args) == 3:
        bucket, key, nginx = args
        url = presign(bucket, key)
        # path-style URL は https://<S3ホスト>/<バケット>/<キー>?<署名> の形。ホストを Nginx に置き換える。
        path_and_query = url.split("/", 3)[3]
        print("S3   :", url)
        print("Nginx:", nginx.rstrip("/") + "/download/" + path_and_query)
    else:
        print(__doc__, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
