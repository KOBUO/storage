# ログ部品一覧（確認ケースの参照マスタ）

各部品に安定ID（`P01`〜）を付与。`部品確認ケース.md` の各ケースはこのIDを参照する。
- **logger / 主要キー** … そのログを `grep` で特定するための logger 名（=`name`）と確認フィールド。
- **起点クラス** … 動作の起点となる実装クラス。

| ID | 部品名 | 起点クラス | logger / 主要キー | 出力モード |
|---|---|---|---|---|
| **P01** | コンテナ情報取得 | `ContainerInfoProvider` / `ContainerInfo` / `ContainerInfoJsonProvider` | 全ログ共通 `id`(ホスト名) / `name`(=cosmo-log) | 全モード |
| **P02** | HTTPログ制御 | `HttpLoggingFilter` / `FunctionActionResolver` | `SPRINGBOOT_API_ACCESS_LOG`(url/status/latency)<br>`SPRINGBOOT_API_ACCESS_JNL_LOG`(要求/応答 headers/body) | API |
| **P03** | 実行単位スコープMDC | `ExecutionScopeMdc` / `BatchLogScope` / `MessageLogScope` | MDC: `function`/`action`/`user`/`trace_id`/`source_ip` | 全モード |
| **P04** | サービスジャーナル | `ServiceJournalAspect`（`@Service` AOP） | `SPRINGBOOT_SERVICE_JNL_LOG`(class_name/method_name/args/result/latency) | API/バッチ |
| **P05** | SQLジャーナル | `SqlJournalInterceptor`（MyBatis） | `SPRINGBOOT_SQL_JNL_LOG`(message=ステートメントID/latency) | ※未Bean登録(参照実装) |
| **P06** | 外部HTTPジャーナル | `HttpClientJournalInterceptor` / `RestClientConfig` | `SPRINGBOOT_HTTP_CLIENT_JNL_LOG`(url/status/headers/body/latency) | API |
| **P07** | キャッシュジャーナル | `CacheJournalAspect`（`@Cacheable` AOP） | `SPRINGBOOT_CACHE_JNL_LOG`(message=メソッド名/latency) | API |
| **P08** | 業務ログ | `ApplicationLogger` | `SPRINGBOOT_API_LOG`(info) / `SPRINGBOOT_ERROR_LOG`(error)<br>class_name/method_name/message | 全モード |
| **P09** | マスキング | `LogMaskingService` | 各ジャーナルの body/headers/args/result が `***` / `...(truncated)` | 全モード |
| **P10** | エラーハンドリング | `GlobalExceptionHandler`（`@RestControllerAdvice`） | `SPRINGBOOT_ERROR_LOG`(class_name=GlobalExceptionHandler/stack_trace) + HTTP 400 | API |
| **P11** | 非同期MDC伝播 | `MdcTaskDecorator` / `AsyncConfig` | `app-async-*` スレッドのログに `trace_id` 引継ぎ | API |
| **P12** | S3アクセス | `S3AccessService` | `SPRINGBOOT_STORAGE_JNL_LOG`(bucket_name/path/aws_request_id/aws_s3_extended_request_id) | AWS |
| **P13** | KMSアクセス | `KmsAccessService` | `SPRINGBOOT_KMS_JNL_LOG`(subtype=AWSCALL/aws_request_id) | AWS |
| **P14** | DynamoDBアクセス | `DynamoDbAccessService` | `SPRINGBOOT_DYNAMODB_JNL_LOG`(subtype=AWSCALL/aws_request_id) | AWS |
| **P15** | SQSアクセス/受信証跡 | `SampleMessageListener` / `SqsAccessService` / `SqsTraceSupport` | `SPRINGBOOT_SQS_JNL_LOG`(aws_sqs_message_id) | 常駐 |

> **P05(SQLジャーナル)** はサンプルに実DBが無く Bean 登録していない参照実装。実機 curl では確認不可 → ユニットテスト or 実DB接続時に確認する。
