import React, { useState } from 'react'

function App() {
  const [message, setMessage] = useState('Hello, World!')

  const handleChange = () => {
    setMessage('Hello, GitLab!')
  }

  const handleReset = () => {
    setMessage('Hello, World!')
  }

  return (
    <div className="App">
      <h1>{message}</h1>
      <button onClick={handleChange}>Change</button>
      <button onClick={handleReset}>Reset</button>
    </div>
  )
}

export default App
