import { render, screen, fireEvent } from '@testing-library/react'
import App from './App'

describe('App', () => {
  test('初期メッセージが表示される', () => {
    render(<App />)
    expect(screen.getByText('Hello, World!')).toBeInTheDocument()
  })

  test('Changeボタンでメッセージが変わる', () => {
    render(<App />)
    fireEvent.click(screen.getByRole('button', { name: 'Change' }))
    expect(screen.getByText('Hello, GitLab!')).toBeInTheDocument()
  })

  test('Resetボタンで初期メッセージに戻る', () => {
    render(<App />)
    fireEvent.click(screen.getByRole('button', { name: 'Change' }))
    fireEvent.click(screen.getByRole('button', { name: 'Reset' }))
    expect(screen.getByText('Hello, World!')).toBeInTheDocument()
  })
})
