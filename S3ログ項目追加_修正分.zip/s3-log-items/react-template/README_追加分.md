## 7. コンテナイメージ（Nginx）

ビルドした画面（`pnpm build` で生成される `dist/`）を Nginx のコンテナイメージに同梱して配信します。
コンテナイメージの資材は `docker/` に配置しています。

| ファイル | 内容 |
|---|---|
| `docker/Dockerfile` | コンテナイメージの定義 |
| `docker/entrypoint.sh` | 起動処理（環境変数の検証、`APP_ENV` の埋め込み、Nginx 設定ファイルの生成、Nginx の起動） |
| `docker/nginx.conf.template` | Nginx 設定ファイルのテンプレート。起動時に環境変数を展開して使用します |
| `docker/njs/screen.js` | エラー画面の返却とログ項目の生成 |
| `public/error.html` | エラー時に返却する画面 |

### 7.1. Nginx の動作

| リクエスト | 応答 |
|---|---|
| `dist/` に存在するファイル | そのファイルを返却します |
| `dist/` に存在しない URL | `index.html` を返却します。画面の表示は React が URL に応じて行います |
| `/s3/` から始まる URL | S3 へ中継します（7.4 を参照） |
| `/health` | `200`（ヘルスチェック用） |
| エラーが発生した場合 | `error.html` を返却します（7.2 を参照） |

- 待ち受けポートは `8080` です。
- ログは JSON 形式で標準出力・標準エラー出力へ出力します。
- S3 へ中継した場合は、ログに S3 の Request ID・Extended Request ID・リクエスト時刻・応答時間を出力します。

### 7.2. エラー画面（error.html）

`public/error.html` は必ず配置してください。ファイル名は変更できません。
配置されていない場合、コンテナは起動しません。
本テンプレートの `error.html` は仮の内容のため、プロジェクトに合わせて修正してください。

次の場合に、`error.html` を返却します。ステータスコードはエラーの内容に応じた値になります。

| 返却される場合 | ステータス |
|---|---|
| 同時接続数が上限（`LIMIT_CONNECTION`）を超えた場合 | 503 |
| 許可されていないメソッドの場合（画面は GET / HEAD、S3 への中継は GET / HEAD / PUT 以外） | 405 |
| リクエストのサイズが上限（`MAX_BODY_SIZE`）を超えた場合 | 413 |
| S3 へ接続できない場合 | 502 |
| S3 からの応答がタイムアウトした場合 | 504 |
| S3 がエラーを返却した場合（アクセス拒否、ファイル不存在など） | S3 が返却したステータス |
| リクエストが不正な場合（リクエスト行・ヘッダの不正、URI が長すぎる、対応していないプロトコルなど） | 400 / 414 / 505 など |

存在しない URL へのアクセス（404）では `error.html` ではなく `index.html` を返却します。

修正する際は、次の点に注意してください。

- `error.html` は、エラーが発生した URL のまま返却されます。CSS や画像を参照する場合は `public/` に配置し、`/` から始まるパスで指定してください。
- ビルドで生成されるファイル（`/assets/index-xxxx.css` など）はファイル名がビルドのたびに変わるため、参照できません。

### 7.3. 環境変数

コンテナ起動時に、次の環境変数がすべて設定されていることを検証します。1つでも未設定の場合、コンテナは起動しません。
ECS では、タスク定義の `environmentFiles` で読み込む `.env` に記載してください。

| # | 環境変数 | 内容 | 設定例 |
|---|---|---|---|
| 1 | `APP_ENV` | 環境識別子（4章を参照） | `production` |
| 2 | `WORKER_CONNECTIONS` | ワーカープロセス1つあたりの同時接続数の上限 | `512` |
| 3 | `LIMIT_CONNECTION` | 同時接続数の上限 | `10` |
| 4 | `LIMIT_ZONE_SIZE` | 同時接続数の状態記録用共有メモリのサイズ | `10m` |
| 5 | `S3_ENDPOINT` | 中継先の S3 エンドポイント。バケット名・ポートは含まない | `s3.ap-northeast-1.amazonaws.com` |
| 6 | `S3_PORT` | S3 への接続ポート | `443` |
| 7 | `S3_BUCKET` | 中継先のバケット | `cosmo-screen-files` |
| 8 | `PROXY_CONNECT_TIMEOUT` | S3 への接続タイムアウト | `5s` |
| 9 | `PROXY_READ_TIMEOUT` | S3 からの応答受信のタイムアウト | `60s` |
| 10 | `PROXY_SEND_TIMEOUT` | S3 への送信のタイムアウト | `60s` |
| 11 | `MAX_BODY_SIZE` | リクエストBODYサイズの上限 | `100m` |

5〜11 は S3 への中継で使用します。S3 への中継を削除した場合は不要です（7.4 を参照）。

### 7.4. S3 への中継

`/s3/` から始まる URL へのリクエストを S3 へ中継する設定を、あらかじめ記載しています。
S3 を利用しない場合は、次のコードを削除してください。
削除後は、7.3 の環境変数 5〜11 の設定が不要になります。

#### docker/nginx.conf.template

次の5か所を削除します。

```nginx
    js_var $s3_request_iso;
    js_var $s3_request_msec;
    js_set $s3_request_timestamp screen.s3RequestTimestamp;
    js_set $s3_latency           screen.s3Latency;
```

```nginx
    # S3 へ転送するパス。エンコードを保持するため $request_uri から組み立てる。
    map $request_uri $s3_uri {
        "~^/s3(/.*)$" $1;
        default       "";
    }

    map $upstream_http_x_amz_request_id $s3_request_id {
        ""      "-";
        default $upstream_http_x_amz_request_id;
    }

    map $upstream_http_x_amz_id_2 $s3_extended_request_id {
        ""      "-";
        default $upstream_http_x_amz_id_2;
    }
```

```nginx
    proxy_ssl_server_name on;
    proxy_ssl_name ${S3_ENDPOINT};
    proxy_ssl_verify on;
    proxy_ssl_trusted_certificate /etc/ssl/certs/ca-certificates.crt;

    # S3 のIPは変動するため、resolve で都度再解決する。
    resolver ${DNS_RESOLVER} valid=10s ipv6=off;
    upstream s3 {
        zone s3 64k;
        server ${S3_ENDPOINT}:${S3_PORT} resolve;
        keepalive 32;
    }
```

```nginx
        client_max_body_size ${MAX_BODY_SIZE};
```

```nginx
        # S3 への中継。/s3 を除いた残りをオブジェクトキーとし、バケットを前置して転送する。
        location /s3/ {
            limit_conn connections ${LIMIT_CONNECTION};

            if ($request_method !~ ^(GET|HEAD|PUT)$) {
                return 405;
            }

            # S3 へ送る直前の時刻を保持する。
            set $s3_request_iso  $time_iso8601;
            set $s3_request_msec $msec;

            proxy_connect_timeout ${PROXY_CONNECT_TIMEOUT};
            proxy_read_timeout    ${PROXY_READ_TIMEOUT};
            proxy_send_timeout    ${PROXY_SEND_TIMEOUT};

            proxy_http_version 1.1;
            proxy_set_header Connection "";
            proxy_request_buffering on;
            # S3 が返したエラーも error.html を返却する。
            proxy_intercept_errors on;
            # 静的コンテンツ向けの error_page 404（index.html）を打ち消す。
            error_page 404 /_error;

            proxy_set_header Host ${S3_ENDPOINT};
            # 余計なヘッダを S3 へ渡さない。
            proxy_set_header Authorization "";
            proxy_set_header Cookie "";

            proxy_pass https://s3/${S3_BUCKET}$s3_uri;
        }
```

また、ログの形式（`log_format json`）から S3 の項目を削除します。

修正前
```nginx
            '"latency":$log_latency,'
            '"s3_request_id":"$s3_request_id",'
            '"s3_extended_request_id":"$s3_extended_request_id",'
            '"s3_request_timestamp":"$s3_request_timestamp",'
            '"s3_latency":"$s3_latency"'
```
修正後
```nginx
            '"latency":$log_latency'
```

#### docker/njs/screen.js

次の関数を削除し、`export default` から削除した関数を除きます。

```js
// S3 へ中継しなかった場合は '-' とする。
function s3RequestTimestamp(r) {
    if (!r.variables.s3_request_iso) {
        return '-';
    }
    return formatTimestamp(r.variables.s3_request_iso, r.variables.s3_request_msec);
}

// S3 への接続を再試行した場合、$upstream_* は試行ごとの値を「, 」区切りで持つ。
function upstreamValues(value) {
    return value.split(/[,:]\s*/).map(function (v) { return v.trim(); });
}

// S3 とのやり取りに要した時間（ミリ秒）。再試行した場合は合計する。
function s3Latency(r) {
    if (!r.variables.upstream_response_time) {
        return '-';
    }
    var total = 0;
    upstreamValues(r.variables.upstream_response_time).forEach(function (v) {
        if (v !== '-') {
            total += Number(v);
        }
    });
    return String(Math.round(total * 1000));
}
```

修正前
```js
export default {
    errorPage, logLevel, logMessage, logLatency, logTimestamp,
    s3RequestTimestamp, s3Latency,
};
```
修正後
```js
export default {
    errorPage, logLevel, logMessage, logLatency, logTimestamp,
};
```

#### docker/entrypoint.sh

次の3か所を修正します。

**1. 必須の環境変数から S3 の分を削除する**

修正前
```sh
REQUIRED_ENV="APP_ENV WORKER_CONNECTIONS LIMIT_CONNECTION LIMIT_ZONE_SIZE
S3_ENDPOINT S3_PORT S3_BUCKET MAX_BODY_SIZE
PROXY_CONNECT_TIMEOUT PROXY_READ_TIMEOUT PROXY_SEND_TIMEOUT"
```
修正後
```sh
REQUIRED_ENV="APP_ENV WORKER_CONNECTIONS LIMIT_CONNECTION LIMIT_ZONE_SIZE"
```

**2. DNS リゾルバの決定を削除する**

削除するコード
```sh
# ---- DNS リゾルバの決定 ----
# resolve による都度再解決のため、コンテナの /etc/resolv.conf から nameserver を取得する。
DNS_RESOLVER=$(awk '/^nameserver/ { print $2; exit }' /etc/resolv.conf)
[ -n "$DNS_RESOLVER" ] || abort "DNS リゾルバを特定できませんでした。（/etc/resolv.conf）"
export DNS_RESOLVER
```

**3. 展開対象から S3 の分を削除する**

修正前
```sh
EXPAND='${CONTAINER_ID} ${CONTAINER_NAME} ${WORKER_CONNECTIONS}
${LIMIT_CONNECTION} ${LIMIT_ZONE_SIZE} ${MAX_BODY_SIZE}
${S3_ENDPOINT} ${S3_PORT} ${S3_BUCKET} ${DNS_RESOLVER}
${PROXY_CONNECT_TIMEOUT} ${PROXY_READ_TIMEOUT} ${PROXY_SEND_TIMEOUT}'
```
修正後
```sh
EXPAND='${CONTAINER_ID} ${CONTAINER_NAME} ${WORKER_CONNECTIONS}
${LIMIT_CONNECTION} ${LIMIT_ZONE_SIZE}'
```
