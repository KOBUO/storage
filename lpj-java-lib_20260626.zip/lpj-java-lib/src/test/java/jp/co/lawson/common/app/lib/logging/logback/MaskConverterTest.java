package jp.co.lawson.common.app.lib.logging.logback;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Test;

import jp.co.lawson.common.app.lib.logging.LoggingProperties.MaskRule;

/**
 * {@link MaskConverter} の単体テスト。
 */
class MaskConverterTest {

    /** メール正規表現。 */
    private static final Pattern EMAIL = Pattern.compile("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}");

    /**
     * キー名マスクが文字列値・スカラ値・key=value 形式を伏せること。
     *
     * 試験条件
     * ・keys=[password,token,flag]。文字列値・数値・真偽・key=value を含むテキスト。
     * 観点
     * ・JSON のスカラ値（数値/真偽）は "***"（文字列）化し、key=value 形式も伏せること。
     * 想定結果
     * ・各形式の対象値が *** 化し、対象外（id）は残ること。
     */
    @Test
    void masksKeyNameAcrossForms() {
        String out = MaskConverter.mask(
                "{\"password\":\"p@ss\",\"token\":12345,\"flag\":true,\"id\":1} password=secret",
                new MaskRule(List.of("password", "token", "flag"), List.of()));
        assertThat(out)
                .contains("\"password\":\"***\"")
                .contains("\"token\":\"***\"")
                .contains("\"flag\":\"***\"")
                .contains("\"id\":1")
                .contains("password=***")
                .doesNotContain("secret");
    }

    /**
     * エスケープ付き文字列値も末尾まで伏せること。
     *
     * 試験条件
     * ・keys=[password]。値にエスケープ {@code \"} を含む JSON 文字列。
     * 観点
     * ・エスケープ {@code \"} を含む値も末尾まで伏せること。
     * 想定結果
     * ・password の値が *** 化し、対象外（id）は残ること。
     */
    @Test
    void masksEscapedQuoteValue() {
        String out = MaskConverter.mask("{\"password\":\"a\\\"b\",\"id\":\"1\"}",
                new MaskRule(List.of("password"), List.of()));
        assertThat(out).contains("\"password\":\"***\"").contains("\"id\":\"1\"").doesNotContain("a\\\"b");
    }

    /**
     * 正規表現マスクが値の一致箇所を伏せること。（複数パターン）
     *
     * 試験条件
     * ・patterns=[メール, カード番号]。両方を含むテキスト。
     * 観点
     * ・複数の正規表現をすべて適用し、キーに紐づかない PII を伏せること。
     * 想定結果
     * ・メール・カード番号がいずれも *** 化されること。
     */
    @Test
    void appliesPatterns() {
        String out = MaskConverter.mask("連絡先 taro@example.com / 4111-1111-1111-1111",
                new MaskRule(List.of(), List.of(EMAIL, Pattern.compile("\\d{4}-\\d{4}-\\d{4}-\\d{4}"))));
        assertThat(out).contains("連絡先 *** / ***")
                .doesNotContain("taro@example.com").doesNotContain("4111");
    }

    /**
     * オブジェクトの JSON 文字列でも、キー名（＝ヘッダ名など）で一致した値を伏せること。
     *
     * 試験条件
     * ・keys=[authorization]。headers を JSON 文字列にしたものを渡す。
     * 観点
     * ・JSON 文字列中の `"authorization"`（大小文字無視）に一致した値を伏せ、対象外は残すこと。
     * 想定結果
     * ・Authorization は ***、Accept は素のままであること。
     */
    @Test
    void masksKeyNameInJsonString() {
        String out = MaskConverter.mask("{\"Authorization\":\"Bearer x\",\"Accept\":\"*/*\"}",
                new MaskRule(List.of("authorization"), List.of()));
        assertThat(out).contains("\"Authorization\":\"***\"").contains("\"Accept\":\"*/*\"");
    }

    /**
     * 規則が空／null、テキストが null の場合は変更しないこと。
     *
     * 試験条件
     * ・空規則・null 規則・null テキストを渡す。
     * 観点
     * ・規則が無ければ誤適用せず、null 安全であること。
     * 想定結果
     * ・空規則は本文のまま、null 規則は本文のまま、null テキストは null であること。
     */
    @Test
    void noChangeWhenRuleEmptyOrNull() {
        assertThat(MaskConverter.mask("taro@example.com", new MaskRule(List.of(), List.of())))
                .isEqualTo("taro@example.com");
        assertThat(MaskConverter.mask("x", null)).isEqualTo("x");
        assertThat(MaskConverter.mask(null, new MaskRule(List.of("a"), List.of()))).isNull();
    }
}
