package jp.co.lawson.common.app.lib.logging;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import jp.co.lawson.common.app.lib.logging.LoggingProperties.MaskItem;

/**
 * {@link LoggingProperties} の単体テスト。
 */
class LoggingPropertiesTest {

    @AfterEach
    void resetStatics() {
        LoggingProperties.install(Map.of(), Map.of()); // init で書いた静的状態を空へ戻し、他テストへの波及を防ぐ
    }

    /**
     * init がプロパティを加工し、マスカ参照用の静的フィールドへ反映すること。
     *
     * 試験条件
     * ・mask に body（keys＋patterns）と headers（keys）、limits に上書き・追加・stack-trace を設定し init する。
     * 観点
     * ・マスク規則は出力項目→MaskRule（正規表現はコンパイル済み）へ、上限は既定にマージ（上書き／追加・stack-trace 除外）して反映すること。
     * 想定結果
     * ・maskRules が各項目の規則を保持し、fieldLimits が上書き値・既定値・追加値を保持し、stack-trace は対象外（未登録）であること。
     */
    @Test
    void initWiresMaskRulesAndLimits() {
        LoggingProperties props = new LoggingProperties();

        MaskItem body = new MaskItem();
        body.setKeys(List.of("password"));
        body.setPatterns(List.of("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}"));
        MaskItem headers = new MaskItem();
        headers.setKeys(List.of("authorization"));
        Map<String, MaskItem> mask = new LinkedHashMap<>();
        mask.put("body", body);
        mask.put("headers", headers);
        props.setMask(mask);

        Map<String, Integer> limits = new LinkedHashMap<>();
        limits.put("body", 256);         // 既定を上書き
        limits.put("custom", 64);        // 出力項目を追加
        limits.put("stack-trace", 9999); // masker からは除外される
        props.setLimits(limits);

        props.init();

        // マスク規則：出力項目→MaskRule（正規表現はコンパイル済み）
        assertThat(props.getMask()).containsKeys("body", "headers");
        assertThat(LoggingProperties.maskRules().get("body").keys()).containsExactly("password");
        assertThat(LoggingProperties.maskRules().get("body").patterns()).hasSize(1);
        assertThat(LoggingProperties.maskRules().get("headers").keys()).containsExactly("authorization");
        assertThat(LoggingProperties.maskRules().get("headers").patterns()).isEmpty();

        // 上限：既定＋プロパティ上書き／追加、stack-trace 除外、args は制限しない
        assertThat(props.getLimits()).containsEntry("custom", 64);
        assertThat(LoggingProperties.fieldLimits())
                .containsEntry("body", 256)        // 上書き
                .containsEntry("message", 768)     // 既定
                .containsEntry("result", 1024)     // 既定
                .containsEntry("headers", 512)     // 既定
                .containsEntry("custom", 64)       // 追加項目
                .doesNotContainKey("args")         // 制限しない
                .doesNotContainKey("stack-trace"); // masker 対象外（除外）
    }
}
