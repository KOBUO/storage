package jp.co.lawson.common.app.lib.logging.api;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;
import jp.co.lawson.common.app.lib.logging.constant.MdcKeys;

/**
 * {@link ApiAccessLogFilter} の単体テスト。
 */
class ApiAccessLogFilterTest {

    /** テスト対象。状態を保持しないため全テストで共有する。 */
    private static final ApiAccessLogFilter TARGET = new ApiAccessLogFilter();

    /** アクセスログ（SPRINGBOOT_API_ACCESS_LOG）の出力捕捉用 appender。 */
    private ListAppender<ILoggingEvent> accessAppender;
    /** アクセスジャーナルログ（SPRINGBOOT_API_ACCESS_JNL_LOG）の出力捕捉用 appender。 */
    private ListAppender<ILoggingEvent> journalAppender;
    private Logger accessLogger;
    private Logger journalLogger;

    /** チェーン実行中（MDC 有効中）に観測した MDC 値。 */
    private final Map<String, String> mdcDuringChain = new HashMap<>();

    @BeforeEach
    void attachAppenders() {
        accessLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.API_ACCESS);
        journalLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.API_ACCESS_JNL);
        accessAppender = attach(accessLogger);
        journalAppender = attach(journalLogger);
    }

    @AfterEach
    void detachAppenders() {
        accessLogger.detachAppender(accessAppender);
        accessLogger.setAdditive(true);
        journalLogger.detachAppender(journalAppender);
        journalLogger.setAdditive(true);
        MDC.clear();
    }

    /**
     * 指定ロガーに捕捉用 appender を付与する。
     *
     * @param logger 対象ロガー
     * @return 取り付けた appender
     */
    private static ListAppender<ILoggingEvent> attach(Logger logger) {
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        logger.setLevel(Level.INFO);
        logger.setAdditive(false); // ルートへの伝播を止めてテスト出力を汚さない
        return appender;
    }

    /** チェーン実行中の MDC を控え、レスポンスへ status/body を書く擬似 FilterChain。 */
    private FilterChain chain(int status, String responseBody) {
        return (req, res) -> {
            mdcDuringChain.put(MdcKeys.FUNCTION, MDC.get(MdcKeys.FUNCTION));
            mdcDuringChain.put(MdcKeys.TRACE_ID, MDC.get(MdcKeys.TRACE_ID));
            mdcDuringChain.put(MdcKeys.USER, MDC.get(MdcKeys.USER));
            mdcDuringChain.put(MdcKeys.SOURCE_IP, MDC.get(MdcKeys.SOURCE_IP));
            HttpServletResponse httpRes = (HttpServletResponse) res;
            httpRes.setStatus(status);
            httpRes.addHeader("Content-Type", "application/json"); // responseHeaders のループを通す
            if (responseBody != null) {
                res.getWriter().write(responseBody);
            }
        };
    }

    /**
     * ヘッダ・クエリ・ボディが揃ったリクエストで、アクセスログ1件とジャーナル（要求/応答）2件を出力すること。
     *
     * 試験条件
     * ・X-Trace-ID/X-User-ID/X-Forwarded-For・クエリ・ボディ付き。チェーンが 200 とボディを返却する。
     * 観点
     * ・MDC が設定された状態で 3 件出力し、レスポンスボディを copyBodyToResponse で書き戻すこと。
     * 想定結果
     * ・アクセスログに「アクセスログ」1件、ジャーナルに「アクセスジャーナル（要求）」「アクセスジャーナル（応答）」を出力すること。
     * ・チェーン中の MDC は指定ヘッダの値で、終了後はクリアされ、レスポンスへボディが書き戻されること。
     */
    @Test
    void fullRequestLogsAccessAndJournals() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/orders");
        request.setQueryString("a=1");
        request.addHeader("X-Trace-ID", "t1");
        request.addHeader("X-User-ID", "u1");
        request.addHeader("X-Forwarded-For", "203.0.113.5, 10.0.0.1");
        request.setContent("{\"in\":1}".getBytes(UTF_8));
        MockHttpServletResponse response = new MockHttpServletResponse();

        TARGET.doFilterInternal(request, response, chain(200, "{\"ok\":true}"));

        assertThat(accessAppender.list).hasSize(1);
        assertThat(accessAppender.list.get(0).getFormattedMessage()).isEqualTo("アクセスログ");
        assertThat(journalAppender.list).extracting(ILoggingEvent::getFormattedMessage)
                .containsExactly("アクセスジャーナル（要求）", "アクセスジャーナル（応答）");

        assertThat(mdcDuringChain.get(MdcKeys.FUNCTION)).isEqualTo("POST /api/orders");
        assertThat(mdcDuringChain.get(MdcKeys.TRACE_ID)).isEqualTo("t1");
        assertThat(mdcDuringChain.get(MdcKeys.USER)).isEqualTo("u1");
        assertThat(mdcDuringChain.get(MdcKeys.SOURCE_IP)).isEqualTo("203.0.113.5");

        assertThat(MDC.get(MdcKeys.TRACE_ID)).isNull(); // 終了後にクリア
        assertThat(response.getContentAsString()).isEqualTo("{\"ok\":true}"); // 書き戻し
    }

    /**
     * X-Trace-ID・X-User-ID・X-Forwarded-For・クエリ・ボディが無い場合の既定動作。
     *
     * 試験条件
     * ・ヘッダ・クエリ・ボディなし。チェーンはボディを書かない。
     * 観点
     * ・trace は UUID 自動採番、source_ip は remoteAddr とし、user は MDC に設定しないこと。
     * 想定結果
     * ・3 件出力し、trace は "t1" 以外の非 null、source_ip は remoteAddr、user は MDC 未設定であること。
     */
    @Test
    void missingHeadersGeneratesTraceAndUsesRemoteAddr() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/ping");
        request.setRemoteAddr("198.51.100.7");
        MockHttpServletResponse response = new MockHttpServletResponse();

        TARGET.doFilterInternal(request, response, chain(204, null));

        assertThat(accessAppender.list).hasSize(1);
        assertThat(journalAppender.list).hasSize(2);
        assertThat(mdcDuringChain.get(MdcKeys.TRACE_ID)).isNotNull().isNotEqualTo("t1");
        assertThat(mdcDuringChain.get(MdcKeys.SOURCE_IP)).isEqualTo("198.51.100.7");
        assertThat(mdcDuringChain.get(MdcKeys.USER)).isNull();
    }

    /**
     * X-Trace-ID が空白・X-Forwarded-For が空白の場合も既定動作になること。
     *
     * 試験条件
     * ・X-Trace-ID="  "、X-Forwarded-For="  "。
     * 観点
     * ・空白は無効として扱い、trace は UUID 自動採番、source_ip は remoteAddr とすること。
     * 想定結果
     * ・trace は空白以外の非 null、source_ip は remoteAddr であること。
     */
    @Test
    void blankHeadersAreTreatedAsAbsent() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/ping");
        request.addHeader("X-Trace-ID", "  ");
        request.addHeader("X-User-ID", "  "); // 空白の MDC 値は設定しない分岐を通す
        request.addHeader("X-Forwarded-For", "  ");
        request.setRemoteAddr("198.51.100.9");
        MockHttpServletResponse response = new MockHttpServletResponse();

        TARGET.doFilterInternal(request, response, chain(200, null));

        assertThat(mdcDuringChain.get(MdcKeys.TRACE_ID)).isNotBlank().isNotEqualTo("  ");
        assertThat(mdcDuringChain.get(MdcKeys.SOURCE_IP)).isEqualTo("198.51.100.9");
    }

    /**
     * チェーンが例外を投げても、ログ出力・MDC クリアを行い例外を伝播すること。
     *
     * 試験条件
     * ・FilterChain が status を設定後に ServletException を投げる。
     * 観点
     * ・要求ジャーナルは処理前、アクセスログと応答ジャーナルは finally で出力し、最後に MDC をクリアして例外を伝播すること。
     * 想定結果
     * ・ServletException を伝播し、アクセスログ1件・ジャーナル（要求/応答）2件を出力し、MDC がクリアされること。
     */
    @Test
    void chainExceptionStillLogsAndClearsMdc() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/boom");
        request.addHeader("X-Trace-ID", "t-err");
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain boom = (req, res) -> {
            ((HttpServletResponse) res).setStatus(500);
            throw new ServletException("boom");
        };

        assertThatThrownBy(() -> TARGET.doFilterInternal(request, response, boom))
                .isInstanceOf(ServletException.class);

        assertThat(accessAppender.list).hasSize(1);
        assertThat(journalAppender.list).extracting(ILoggingEvent::getFormattedMessage)
                .containsExactly("アクセスジャーナル（要求）", "アクセスジャーナル（応答）");
        assertThat(MDC.get(MdcKeys.TRACE_ID)).isNull();
    }
}
