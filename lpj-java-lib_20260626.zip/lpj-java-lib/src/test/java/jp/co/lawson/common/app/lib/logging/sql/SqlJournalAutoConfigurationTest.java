package jp.co.lawson.common.app.lib.logging.sql;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.ibatis.session.Configuration;
import org.junit.jupiter.api.Test;
import org.mybatis.spring.boot.autoconfigure.ConfigurationCustomizer;

/**
 * {@link SqlJournalAutoConfiguration} の単体テスト。
 */
class SqlJournalAutoConfigurationTest {

    /** テスト対象。 */
    private static final SqlJournalAutoConfiguration TARGET = new SqlJournalAutoConfiguration();

    /**
     * customizer が MyBatis 設定に SqlJournalInterceptor を登録すること。
     *
     * 試験条件
     * ・sqlJournalConfigurationCustomizer(false) で得た customizer を MyBatis の Configuration に適用する。
     * 観点
     * ・customize で {@link SqlJournalInterceptor} が addInterceptor されること。
     * 想定結果
     * ・Configuration のインターセプターが1件で、{@link SqlJournalInterceptor} 型であること。
     */
    @Test
    void customizerRegistersSqlJournalInterceptor() {
        Configuration configuration = new Configuration();

        ConfigurationCustomizer customizer = TARGET.sqlJournalConfigurationCustomizer(false);
        customizer.customize(configuration);

        assertThat(configuration.getInterceptors())
                .hasSize(1)
                .first().isInstanceOf(SqlJournalInterceptor.class);
    }
}
