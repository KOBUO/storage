package jp.co.lawson.common.app.lib.logging;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;

import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;

/**
 * {@link ApplicationLogger} の単体テスト。
 */
class ApplicationLoggerTest {

    /** テスト対象。（共有シングルトン） */
    private static final ApplicationLogger TARGET = ApplicationLogger.getLogger();

    /** 業務ログ（SPRINGBOOT_API_LOG）の出力捕捉用 appender。 */
    private ListAppender<ILoggingEvent> apiAppender;
    /** 業務エラーログ（SPRINGBOOT_ERROR_LOG）の出力捕捉用 appender。 */
    private ListAppender<ILoggingEvent> errorAppender;
    private Logger apiLogger;
    private Logger errorLogger;

    @BeforeEach
    void attachAppenders() {
        apiLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.API_LOG);
        errorLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.ERROR_LOG);
        apiAppender = attach(apiLogger);
        errorAppender = attach(errorLogger);
    }

    @AfterEach
    void detachAppenders() {
        apiLogger.detachAppender(apiAppender);
        apiLogger.setAdditive(true);
        errorLogger.detachAppender(errorAppender);
        errorLogger.setAdditive(true);
    }

    /**
     * 指定ロガーに捕捉用 appender を付与する。
     *
     * @param logger 対象ロガー
     * @return 取り付けた appender
     */
    private static ListAppender<ILoggingEvent> attach(Logger logger) {
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        logger.setLevel(Level.INFO);
        logger.setAdditive(false); // ルートへの伝播を止めてテスト出力を汚さない
        return appender;
    }

    /**
     * 常に同一の共有インスタンスを返却すること。
     *
     * 試験条件
     * ・getLogger() を複数回呼び出す。
     * 観点
     * ・状態を保持しないため、毎回同じシングルトンを返却すること。
     * 想定結果
     * ・戻り値は非 null かつ同一インスタンスであること。
     */
    @Test
    void getLoggerReturnsSharedSingleton() {
        assertThat(ApplicationLogger.getLogger()).isNotNull().isSameAs(TARGET);
    }

    /**
     * 業務ログを INFO で出力すること。
     *
     * 試験条件
     * ・info(message) を呼び出す。
     * 観点
     * ・業務ログ用ロガーへ INFO レベルで message を出力し、業務エラーログには出力しないこと。
     * 想定結果
     * ・業務ログに INFO のイベントが1件・message 一致。
     * 業務エラーログは空であること。
     */
    @Test
    void infoLogsToApiLogAtInfo() {
        TARGET.info("注文を登録しました");

        assertThat(apiAppender.list).hasSize(1);
        assertThat(apiAppender.list.get(0).getLevel()).isEqualTo(Level.INFO);
        assertThat(apiAppender.list.get(0).getFormattedMessage()).isEqualTo("注文を登録しました");
        assertThat(errorAppender.list).isEmpty();
    }

    /**
     * 例外付きの業務エラーログを ERROR で出力すること。
     *
     * 試験条件
     * ・error(message, 例外) を呼び出す。
     * 観点
     * ・業務エラーログ用ロガーへ ERROR レベルで message と例外を出力すること。
     * 想定結果
     * ・業務エラーログに ERROR のイベントが1件・message 一致・例外（stack_trace）付きであること。
     */
    @Test
    void errorWithThrowableLogsToErrorLogWithStackTrace() {
        RuntimeException boom = new RuntimeException("boom");

        TARGET.error("業務エラー", boom);

        assertThat(errorAppender.list).hasSize(1);
        ILoggingEvent event = errorAppender.list.get(0);
        assertThat(event.getLevel()).isEqualTo(Level.ERROR);
        assertThat(event.getFormattedMessage()).isEqualTo("業務エラー");
        assertThat(event.getThrowableProxy()).isNotNull();
    }

    /**
     * 例外なしの業務エラーログを ERROR で出力すること。
     *
     * 試験条件
     * ・error(message)（例外なし）を呼び出す。
     * 観点
     * ・例外を渡さない場合は stack_trace を付けないこと。
     * 想定結果
     * ・業務エラーログに ERROR のイベントが1件・message 一致・例外（stack_trace）なしであること。
     */
    @Test
    void errorWithoutThrowableLogsToErrorLogWithoutStackTrace() {
        TARGET.error("業務エラー");

        assertThat(errorAppender.list).hasSize(1);
        ILoggingEvent event = errorAppender.list.get(0);
        assertThat(event.getLevel()).isEqualTo(Level.ERROR);
        assertThat(event.getFormattedMessage()).isEqualTo("業務エラー");
        assertThat(event.getThrowableProxy()).isNull();
    }
}
