package jp.co.lawson.common.app.lib.logging;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;

import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;

/**
 * 【全ログ種別 end-to-end 検証】lib の logback 構成（{@code @SpringBootTest}）を起動し、各固定ロガー
 * （ログ種類）へ {@link StructuredLog} で出力して、{@code SanitizingCompositeJsonEncoder} を通った
 * JSON ログが種類ごとに正しく出力されることを stdout/stderr 捕捉で検証する。
 *
 * <p>実トリガ（HTTP/AWS/DB）でなくロガーへ直接出力するため、外部インフラを要さず全種類を一括検証できる。
 * マスク・出力長制限も実 encoder 経由で効くことを併せて確認する。
 */
@SpringBootTest(
        classes = AllLogTypesLoggingIT.TestApp.class,
        webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = {
                "cosmo-app.logging.mask.headers.keys=authorization",
                "cosmo-app.logging.mask.body.keys=password",
                "cosmo-app.logging.limits.body=48"
        })
@ExtendWith(OutputCaptureExtension.class)
class AllLogTypesLoggingIT {

    /** マスク・出力長上限を有効化するための最小 Spring 構成。 */
    @SpringBootConfiguration
    @EnableConfigurationProperties(LoggingProperties.class)
    static class TestApp {
    }

    /** マーカー付きで直接出力する固定ロガー（ジャーナル／アクセス系）。 */
    private static final List<String> MARKER_LOGGERS = List.of(
            LoggerNames.API_ACCESS,
            LoggerNames.API_ACCESS_JNL,
            LoggerNames.SERVICE_JNL,
            LoggerNames.SQL_JNL,
            LoggerNames.STORAGE_JNL,
            "AWSCALL",
            LoggerNames.HTTP_CLIENT_JNL,
            LoggerNames.SQS_JNL,
            LoggerNames.KMS_JNL,
            LoggerNames.DYNAMODB_JNL);

    /**
     * 全ログ種別が、統一フォーマットの JSON で出力されること。
     *
     * 試験条件
     * ・ジャーナル／アクセス系の固定ロガーへ marker 付きで出力し、業務／業務エラーは公開ファサード、
     * 　システムは固定ロガー以外（root）へ出力する。
     * 観点
     * ・各 logger（種類別 appender）が JSON を出し、type／subtype・数値 level_value・値の文字列化・
     * 　stack_trace の統一フォーマットが守られること。
     * 想定結果
     * ・全12種＋システムの logger_name が出力され、種類別の type／subtype と各不変条件が含まれること。
     */
    @Test
    void everyLogTypeIsEmittedWithUnifiedFormat(CapturedOutput out) {
        // ジャーナル／アクセス系：各固定ロガーへ marker 付きで出力
        MARKER_LOGGERS.forEach(name -> LoggerFactory.getLogger(name).info(
                StructuredLog.create().put(LogFields.URL, "GET /x").put(LogFields.STATUS, 200).marker(),
                "log for " + name));
        // 業務ログ／業務エラーログ：公開ファサード経由
        ApplicationLogger.getLogger().info("business log");
        ApplicationLogger.getLogger().error("business error", new RuntimeException("boom"));
        // システムログ：固定ロガー以外（root → SYSTEM）
        LoggerFactory.getLogger("system.check.Sample").info("system log");

        // 全12種＋システムの appender が JSON を出している
        MARKER_LOGGERS.forEach(name ->
                assertThat(out).as(name).contains("\"logger_name\":\"" + name + "\""));
        assertThat(out).contains("\"logger_name\":\"" + LoggerNames.API_LOG + "\"");   // 業務ログ
        assertThat(out).contains("\"logger_name\":\"" + LoggerNames.ERROR_LOG + "\""); // 業務エラーログ

        // 統一フォーマット（種類別 type/subtype・数値 level_value・値は文字列・stack_trace）
        assertThat(out).contains("\"type\":\"trail\"");        // アクセスログ
        assertThat(out).contains("\"subtype\":\"DBCALL\"");    // SQL ジャーナル
        assertThat(out).contains("\"subtype\":\"AWSCALL\"");   // AWS 系
        assertThat(out).contains("\"subtype\":\"SYSTEM\"");    // システムログ
        assertThat(out).contains("\"type\":\"monitor\"");      // 業務エラーログ
        assertThat(out).contains("\"stack_trace\"");           // 〃 スタックトレース
        assertThat(out).contains("\"level_value\":20000");     // INFO は数値
        assertThat(out).contains("\"level_value\":40000");     // ERROR は数値
        assertThat(out).contains("\"status\":\"200\"");        // 値は文字列
    }

    /**
     * マスク・出力長制限が実 encoder 経由で適用されること。
     *
     * 試験条件
     * ・mask に headers.authorization／body.password、limits に body=48 を設定し、
     * 　機密値と長い body を持つアクセスジャーナルを出力する。
     * 観点
     * ・出力時に {@code SanitizingCompositeJsonEncoder} がマスクと出力長制限を適用すること。
     * 想定結果
     * ・機密値が {@code ***} に伏せられ、上限超過の body に {@code ...(truncated)} が付くこと。
     */
    @Test
    void maskingAndLengthLimitApplyThroughEncoder(CapturedOutput out) {
        LoggerFactory.getLogger(LoggerNames.API_ACCESS_JNL).info(
                StructuredLog.create()
                        .put(LogFields.HEADERS, Map.of("Authorization", "Bearer secret-token"))
                        .put(LogFields.BODY,
                                "{\"password\":\"p@ssw0rd\",\"note\":\"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ\"}")
                        .marker(),
                "mask/limit check");

        assertThat(out).contains("\"***\"");                   // マスク適用
        assertThat(out).doesNotContain("p@ssw0rd");            // body の password 値が伏せられた
        assertThat(out).doesNotContain("Bearer secret-token"); // headers の authorization 値が伏せられた
        assertThat(out).contains("(truncated)");               // body が上限超過で制限された
    }
}
