package jp.co.lawson.common.app.lib.logging.logback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * {@link MdcOrderedJsonProvider} の単体テスト。
 */
class MdcOrderedJsonProviderTest {

    /**
     * 指定キーを列挙したテスト対象を組み立てる。
     * （{@code <includeMdcKeyName>} 列挙を模す）
     *
     * @param keys 列挙する MDC キー（取得キー＝出力名）
     * @return 設定済みのテスト対象
     */
    private static MdcOrderedJsonProvider configured(String... keys) {
        MdcOrderedJsonProvider provider = new MdcOrderedJsonProvider();
        for (String key : keys) {
            provider.addIncludeMdcKeyName(key);
        }
        return provider;
    }

    /**
     * MDC を設定してテスト対象に1イベント分を出力させる。
     *
     * @param provider 列挙設定済みのテスト対象
     * @param mdc MDC のキー・値マップ
     * @return 出力された JSON 文字列
     * @throws Exception JSON 生成時の入出力例外
     */
    private static String render(MdcOrderedJsonProvider provider, Map<String, String> mdc) throws Exception {
        StringWriter writer = new StringWriter();
        try (JsonGenerator g = new JsonFactory().createGenerator(writer)) {
            g.writeStartObject();
            ILoggingEvent event = mock(ILoggingEvent.class);
            when(event.getMDCPropertyMap()).thenReturn(mdc);
            provider.writeTo(g, event);
            g.writeEndObject();
        }
        return writer.toString();
    }

    /**
     * MDC の投入順に関係なく、列挙順で出力すること。
     *
     * 試験条件
     * ・列挙＝function/user/action/trace、MDC は別順（trace/action/user/function）で投入。
     * 観点
     * ・出力順は MDC の投入順ではなく、列挙した順に従うこと。
     * 想定結果
     * ・function→user→action→trace の順で値が出力されること。
     */
    @Test
    void writesListedOrderWithValues() throws Exception {
        Map<String, String> mdc = new LinkedHashMap<>();
        mdc.put("trace", "t1");
        mdc.put("action", "POST");
        mdc.put("user", "u1");
        mdc.put("function", "/api/x");
        assertThat(render(configured("function", "user", "action", "trace"), mdc))
                .contains("\"function\":\"/api/x\",\"user\":\"u1\",\"action\":\"POST\",\"trace\":\"t1\"");
    }

    /**
     * 値が無いキーは文字列 "null" で出力されること。
     *
     * 試験条件
     * ・列挙＝function/user/action/trace、MDC は空。
     * 観点
     * ・値が無くてもキーは出力し、値は文字列 "null" にすること。
     * 想定結果
     * ・function/user/action/trace とも値が "null"であること。
     */
    @Test
    void writesNullStringForAbsentKeys() throws Exception {
        assertThat(render(configured("function", "user", "action", "trace"), Map.of()))
                .contains("\"function\":\"null\"", "\"user\":\"null\"", "\"action\":\"null\"", "\"trace\":\"null\"");
    }

    /**
     * 列挙していないキーは出力しないこと。
     * （ホワイトリスト）
     *
     * 試験条件
     * ・列挙＝function のみ、MDC に function と secretKey。
     * 観点
     * ・列挙したキーだけ出力し、未列挙キーは出力しないこと。
     * 想定結果
     * ・function は出力され、secretKey は出力されないこと。
     */
    @Test
    void onlyListedKeysAreOutput() throws Exception {
        String json = render(configured("function"), Map.of("function", "f", "secretKey", "leak"));
        assertThat(json).contains("\"function\":\"f\"").doesNotContain("secretKey", "leak");
    }

    /**
     * 取得キーと出力名が異なる場合、出力名で出力すること。
     *
     * 試験条件
     * ・{@code <entry>}traceId:trace を設定、MDC に traceId=abc。
     * 観点
     * ・取得キー traceId の値を、出力名 trace に変換して出力すること。
     * 想定結果
     * ・trace=abc を出力し、traceId は出力されないこと。
     */
    @Test
    void mapsMdcKeyToDifferentOutputName() throws Exception {
        MdcOrderedJsonProvider provider = new MdcOrderedJsonProvider();
        provider.addEntry("traceId:trace");
        String json = render(provider, Map.of("traceId", "abc"));
        assertThat(json).contains("\"trace\":\"abc\"").doesNotContain("traceId");
    }

    /**
     * {@code <entry>} に ":" が無い場合、取得キー＝出力名として扱うこと。
     *
     * 試験条件
     * ・addEntry("function")（":" 無し）を設定、MDC に function=f。
     * 観点
     * ・":" 無しは取得キーと出力名を同名のエントリとして追加すること。
     * 想定結果
     * ・function=f を出力すること。
     */
    @Test
    void addEntryWithoutColonUsesSameName() throws Exception {
        MdcOrderedJsonProvider provider = new MdcOrderedJsonProvider();
        provider.addEntry("function");
        assertThat(render(provider, Map.of("function", "f"))).contains("\"function\":\"f\"");
    }

    /**
     * null・空白の指定は無視されること。
     *
     * 試験条件
     * ・addIncludeMdcKeyName と addEntry に null・空文字・空白を指定する。
     * 観点
     * ・無効な指定はエントリに追加されないこと。
     * 想定結果
     * ・何も出力されないこと。
     * （空の JSON オブジェクト）
     */
    @Test
    void ignoresNullOrBlankSpecs() throws Exception {
        MdcOrderedJsonProvider provider = new MdcOrderedJsonProvider();
        provider.addIncludeMdcKeyName(null);
        provider.addIncludeMdcKeyName("  ");
        provider.addEntry(null);
        provider.addEntry("");
        assertThat(render(provider, Map.of("function", "f"))).isEqualTo("{}");
    }
}
