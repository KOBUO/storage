package jp.co.lawson.common.app.lib.logging.sqs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;

import io.awspring.cloud.sqs.config.SqsMessageListenerContainerFactory;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;

/**
 * {@link ResidentSqsConfig} の単体テスト。
 */
class ResidentSqsConfigTest {

    /** テスト対象。 */
    private static final ResidentSqsConfig TARGET = new ResidentSqsConfig();

    /**
     * interceptor を適用したリスナーコンテナファクトリを生成すること。
     *
     * 試験条件
     * ・SqsAsyncClient と SqsReceiveJournalInterceptor を引数に @Bean メソッドを実行する。
     * 観点
     * ・builder で SQS クライアントと interceptor を設定したファクトリを返却すること。
     * 想定結果
     * ・非 null のファクトリが返却されること。
     */
    @Test
    void buildsFactoryWithInterceptor() {
        SqsAsyncClient client = mock(SqsAsyncClient.class);
        SqsReceiveJournalInterceptor interceptor = new SqsReceiveJournalInterceptor();

        SqsMessageListenerContainerFactory<Object> factory =
                TARGET.defaultSqsListenerContainerFactory(client, interceptor);

        assertThat(factory).isNotNull();
    }
}
