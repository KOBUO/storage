package jp.co.lawson.common.app.lib.logging.api;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;

/**
 * リクエストボディを入口で全読みしてキャッシュし、再読込可能にする {@link HttpServletRequestWrapper} 実装クラス。
 */
public class CachedBodyRequestWrapper extends HttpServletRequestWrapper {

    // 入口で全読みしたリクエストボディ
    private final byte[] cachedBody;

    /**
     * リクエストボディを全読みしてキャッシュする。
     *
     * @param request 元の HTTP リクエスト
     * @throws IOException ボディの読み取りに失敗した場合
     */
    public CachedBodyRequestWrapper(HttpServletRequest request) throws IOException {
        super(request);
        this.cachedBody = request.getInputStream().readAllBytes();
    }

    /**
     * キャッシュしたリクエストボディを返却する。
     *
     * @return リクエストボディのバイト列（ボディが無い場合は長さ 0）
     */
    public byte[] getCachedBody() {
        return cachedBody;
    }

    /**
     * キャッシュから読み込む {@link ServletInputStream} を返却する（毎回先頭から再読込できる）。
     *
     * @return キャッシュ済みボディの入力ストリーム
     */
    @Override
    public ServletInputStream getInputStream() {
        return new CachedBodyServletInputStream(cachedBody);
    }

    /**
     * キャッシュから読み込む {@link BufferedReader} を返却する。
     *
     * @return キャッシュ済みボディのリーダー
     */
    @Override
    public BufferedReader getReader() {
        String enc = getCharacterEncoding();
        Charset charset = enc != null ? Charset.forName(enc) : StandardCharsets.UTF_8;
        return new BufferedReader(new InputStreamReader(new ByteArrayInputStream(cachedBody), charset));
    }

    // キャッシュ済みボディを供給する ServletInputStream
    private static final class CachedBodyServletInputStream extends ServletInputStream {

        private final ByteArrayInputStream in;

        CachedBodyServletInputStream(byte[] body) {
            this.in = new ByteArrayInputStream(body);
        }

        @Override
        public int read() {
            return in.read();
        }

        @Override
        public boolean isFinished() {
            return in.available() == 0;
        }

        @Override
        public boolean isReady() {
            return true;
        }

        @Override
        public void setReadListener(ReadListener readListener) {
            throw new UnsupportedOperationException();
        }
    }
}
