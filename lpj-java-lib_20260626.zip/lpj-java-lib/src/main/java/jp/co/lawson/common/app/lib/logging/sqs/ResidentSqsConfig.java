package jp.co.lawson.common.app.lib.logging.sqs;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.awspring.cloud.sqs.config.SqsMessageListenerContainerFactory;

import software.amazon.awssdk.services.sqs.SqsAsyncClient;

/**
 * 常駐バッチ（{@code @SqsListener}）のリスナーコンテナファクトリを上書きして {@link SqsReceiveJournalInterceptor} を全リスナーに適用する設定クラス。
 */
@Configuration
@ConditionalOnClass(SqsMessageListenerContainerFactory.class)
@ConditionalOnProperty(prefix = "cosmo-app.logging.sqs", name = "enabled", havingValue = "true", matchIfMissing = false)
public class ResidentSqsConfig {

    /**
     * 受信ジャーナル interceptor を適用したリスナーコンテナファクトリを生成する。
     * 利用者が独自に {@link SqsMessageListenerContainerFactory} を定義済みの場合は本 Bean を生成しない（{@code @ConditionalOnMissingBean}）。
     *
     * @param sqsAsyncClient Spring Cloud AWS が構成する SQS クライアント
     * @param interceptor 受信ジャーナル interceptor
     * @return interceptor を適用したリスナーコンテナファクトリ
     */
    @Bean
    @ConditionalOnMissingBean(SqsMessageListenerContainerFactory.class)
    SqsMessageListenerContainerFactory<Object> defaultSqsListenerContainerFactory(
            SqsAsyncClient sqsAsyncClient, SqsReceiveJournalInterceptor interceptor) {
        return SqsMessageListenerContainerFactory.<Object>builder()
                .sqsAsyncClient(sqsAsyncClient)
                .messageInterceptor(interceptor)
                .build();
    }
}
