package jp.co.lawson.common.app.lib.logging.sqs;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import io.awspring.cloud.sqs.listener.SqsHeaders;
import io.awspring.cloud.sqs.listener.interceptor.MessageInterceptor;

import jp.co.lawson.common.app.lib.logging.StructuredLog;
import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;
import jp.co.lawson.common.app.lib.logging.constant.MdcKeys;

/**
 * {@code @SqsListener} の受信前後にフックしてメッセージ受信ジャーナルを出力するインターセプタークラス。
 */
@Component
@ConditionalOnClass(MessageInterceptor.class)
@ConditionalOnProperty(prefix = "cosmo-app.logging.sqs", name = "enabled", havingValue = "true", matchIfMissing = false)
public class SqsReceiveJournalInterceptor implements MessageInterceptor<Object> {

    // メッセージジャーナルログ
    private static final Logger journalLog = LoggerFactory.getLogger(LoggerNames.SQS_JNL);

    /**
     * メッセージ受信時に MDC を設定し、受信ジャーナルログを出力する。
     *
     * @param message 受信メッセージ
     * @return 受信メッセージ（変更せず返却する）
     */
    @Override
    public Message<Object> intercept(Message<Object> message) {
        MessageHeaders headers = message.getHeaders();
        String messageId = messageId(headers);

        // MDC スコープ開始（afterProcessing でクリア）。null は設定しない（→ provider が "null" 出力）
        put(MdcKeys.FUNCTION, function(headers)); // 受信キュー名
        put(MdcKeys.TRACE_ID, messageId);         // trace には SQS メッセージID を使用する
        // action／user／source_ip は概念上なし → 未設定（"null" を出力）

        // メッセージジャーナル: 受信証跡。発生元・受信メタは取得不可のため null。（キーは出力）
        journalLog.info(StructuredLog.create()
                .putNullable(LogFields.LATENCY, null)
                .putNullable(LogFields.AWS_REQUEST_ID, null)
                .put(LogFields.AWS_SQS_MESSAGE_ID, messageId)
                .putNullable(LogFields.AWS_REQUEST_TIMESTAMP, null)
                .putNullable(LogFields.AWS_RESPONSE_TIME, null)
                .marker(), "メッセージ受信ジャーナル");
        return message;
    }

    /**
     * 処理完了時に MDC をクリアする（失敗時のエラーログは出力せず、例外はそのまま伝播する）。
     *
     * @param message 受信メッセージ
     * @param t 処理で発生した例外（無ければ null）
     */
    @Override
    public void afterProcessing(Message<Object> message, Throwable t) {
        // 失敗時のエラーログは業務側（ApplicationLogger.error）が出力する。例外はそのまま伝播（リトライ/DLQ）
        MDC.clear(); // メッセージ境界でスレッドの MDC をクリア
    }

    // 値があれば MDC へ設定する（null は設定しない）。
    private static void put(String key, String value) {
        if (value != null) {
            MDC.put(key, value);
        }
    }

    // Spring Cloud AWS は Spring メッセージIDに SQS 採番の MessageId を設定するため、
    // headers.getId() が aws_sqs_message_id（SQS MessageId）になる。（送信側 response.messageId() と一致・実機確認済み）
    private static String messageId(MessageHeaders headers) {
        var id = headers.getId();
        return id != null ? id.toString() : null;
    }

    /** function: 受信キュー名を機能IDとして使用する（取得不可時は null）。 */
    private static String function(MessageHeaders headers) {
        Object queue = headers.get(SqsHeaders.SQS_QUEUE_NAME_HEADER);
        return queue != null ? queue.toString() : null;
    }
}
