package jp.co.lawson.common.app.lib.logging.constant;

/**
 * Marker で付与する項目の物理名を定義するクラス。
 */
public final class LogFields {

    /** ログ種類 */
    public static final String TYPE = "type";
    /** ログ種類詳細 */
    public static final String SUBTYPE = "subtype";

    /** アクセス先 URL */
    public static final String URL = "url";
    /** HTTP ステータス */
    public static final String STATUS = "status";
    /** ヘッダー */
    public static final String HEADERS = "headers";
    /** ボディ */
    public static final String BODY = "body";

    /** 発生元のクラス名 */
    public static final String CLASS_NAME = "class_name";
    /** 発生元のメソッド名 */
    public static final String METHOD_NAME = "method_name";
    /** 引数 */
    public static final String ARGS = "args";
    /** 結果 */
    public static final String RESULT = "result";

    /** 処理時間 */
    public static final String LATENCY = "latency";

    /** AWS リクエスト ID */
    public static final String AWS_REQUEST_ID = "aws_request_id";
    /** AWS リクエスト時刻 */
    public static final String AWS_REQUEST_TIMESTAMP = "aws_request_timestamp";
    /** AWS 応答時間 */
    public static final String AWS_RESPONSE_TIME = "aws_response_time";
    /** SQS メッセージ ID */
    public static final String AWS_SQS_MESSAGE_ID = "aws_sqs_message_id";

    private LogFields() {
    }
}
