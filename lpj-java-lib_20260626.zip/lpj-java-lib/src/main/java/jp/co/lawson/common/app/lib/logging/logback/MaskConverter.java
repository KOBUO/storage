package jp.co.lawson.common.app.lib.logging.logback;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jp.co.lawson.common.app.lib.logging.LoggingProperties.MaskRule;

/**
 * 文字列に出力項目のマスク規則（キー名／正規表現）を適用するロジッククラス。
 */
public final class MaskConverter {

    // マスク後に設定する値
    private static final String MASK = "***";

    /**
     * プライベートコンストラクタ。
     * 外部からのインスタンス化を禁止する。
     */
    private MaskConverter() {
    }

    /**
     * 文字列へマスク規則（(1)キー名一致 (2)正規表現）を適用して返却する。
     * （変化が無ければ同じ文字列を返却する）
     * オブジェクトの出力項目は JSON 文字列にしてから渡す前提で、キー名はその文字列中の `"key"` に一致させる。
     *
     * @param text 対象文字列（出力項目の値。オブジェクトは JSON 文字列）
     * @param rule マスク規則（null なら無変換）
     * @return マスク後の文字列（{@code text} が null なら null）
     */
    public static String mask(String text, MaskRule rule) {
        if (text == null || rule == null) {
            return text;
        }
        String masked = text;
        // (1) キー名ベース（キー名は大小文字を無視＝(?i)）
        for (String key : rule.keys()) {
            String q = Pattern.quote(key);
            // "key":"value"（文字列値。エスケープ \" を含む値も末尾まで）
            masked = masked.replaceAll("(?i)(\"" + q + "\"\\s*:\\s*\")(?:\\\\.|[^\"\\\\])*(\")", "$1" + MASK + "$2");
            // "key":123 / true / false / null（非文字列のスカラ値）→ "key":"***"（文字列化。JSON 構造を壊さないため）
            masked = masked.replaceAll("(?i)(\"" + q + "\"\\s*:\\s*)(?:-?\\d[\\d.eE+-]*|true|false|null)", "$1\"" + MASK + "\"");
            // key=value（クエリ / フォーム / フリーテキスト形式）
            masked = masked.replaceAll("(?i)(" + q + "\\s*=\\s*)[^,&;\\s)}]+", "$1" + MASK);
        }
        // (2) 正規表現ベース
        for (Pattern p : rule.patterns()) {
            masked = p.matcher(masked).replaceAll(Matcher.quoteReplacement(MASK));
        }
        return masked;
    }
}
