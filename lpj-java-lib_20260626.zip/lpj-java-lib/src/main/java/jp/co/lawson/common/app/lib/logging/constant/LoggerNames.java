package jp.co.lawson.common.app.lib.logging.constant;

/**
 * ログ種類ごとの固定ロガー名を定義するクラス。
 */
public final class LoggerNames {

    /** アクセスログ */
    public static final String API_ACCESS = "SPRINGBOOT_API_ACCESS_LOG";
    /** アクセスジャーナルログ */
    public static final String API_ACCESS_JNL = "SPRINGBOOT_API_ACCESS_JNL_LOG";
    /** サービスジャーナルログ */
    public static final String SERVICE_JNL = "SPRINGBOOT_SERVICE_JNL_LOG";
    /** ストレージアクセスジャーナルログ */
    public static final String STORAGE_JNL = "SPRINGBOOT_STORAGE_JNL_LOG";
    /** 外部HTTPアクセスジャーナルログ */
    public static final String HTTP_CLIENT_JNL = "SPRINGBOOT_HTTP_CLIENT_JNL_LOG";
    /** メッセージ受信ジャーナルログ(SQS) */
    public static final String SQS_JNL = "SPRINGBOOT_SQS_JNL_LOG";
    /** SQLジャーナルログ */
    public static final String SQL_JNL = "SPRINGBOOT_SQL_JNL_LOG";
    /** KMSアクセスジャーナルログ */
    public static final String KMS_JNL = "SPRINGBOOT_KMS_JNL_LOG";
    /** DynamoDBアクセスジャーナルログ */
    public static final String DYNAMODB_JNL = "SPRINGBOOT_DYNAMODB_JNL_LOG";
    /** 業務ログ */
    public static final String API_LOG = "SPRINGBOOT_API_LOG";
    /** 業務エラーログ */
    public static final String ERROR_LOG = "SPRINGBOOT_ERROR_LOG";

    private LoggerNames() {
    }
}
