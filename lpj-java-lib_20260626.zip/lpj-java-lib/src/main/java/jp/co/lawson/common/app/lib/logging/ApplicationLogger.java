package jp.co.lawson.common.app.lib.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;

/**
 * 業務イベントを業務ログ／業務エラーログとして出力するロガークラス。
 */
public final class ApplicationLogger {

    // 業務ログ用ロガー（SPRINGBOOT_API_LOG）
    private static final Logger BUSINESS = LoggerFactory.getLogger(LoggerNames.API_LOG);
    // 業務エラーログ用ロガー（SPRINGBOOT_ERROR_LOG）
    private static final Logger ERROR = LoggerFactory.getLogger(LoggerNames.ERROR_LOG);
    // 共有シングルトン
    private static final ApplicationLogger INSTANCE = new ApplicationLogger();

    /**
     * プライベートコンストラクタ。
     * 外部からのインスタンス化を禁止する。
     */
    private ApplicationLogger() {
    }

    /**
     * 共有の {@link ApplicationLogger} を返却する。
     *
     * @return {@link ApplicationLogger}
     */
    public static ApplicationLogger getLogger() {
        return INSTANCE;
    }

    /**
     * 業務ログを INFO で出力する。
     *
     * @param message 出力するメッセージ
     */
    public void info(String message) {
        BUSINESS.info(message);
    }

    /**
     * 業務エラーログを ERROR で出力する。
     * （スタックトレース付き）
     *
     * @param message 出力するメッセージ
     * @param t 出力する例外
     */
    public void error(String message, Throwable t) {
        ERROR.error(message, t);
    }

    /**
     * 業務エラーログを ERROR で出力する。
     * （スタックトレースなし）
     *
     * @param message 出力するメッセージ
     */
    public void error(String message) {
        ERROR.error(message);
    }
}
