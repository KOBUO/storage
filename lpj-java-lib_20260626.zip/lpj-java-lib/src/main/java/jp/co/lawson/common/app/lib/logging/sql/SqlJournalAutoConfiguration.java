package jp.co.lawson.common.app.lib.logging.sql;

import org.mybatis.spring.boot.autoconfigure.ConfigurationCustomizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * {@link SqlJournalInterceptor} を MyBatis に登録する自動設定クラス。
 */
@Configuration
@ConditionalOnClass(ConfigurationCustomizer.class)
@ConditionalOnProperty(prefix = "cosmo-app.logging.sql", name = "enabled", havingValue = "true", matchIfMissing = false)
public class SqlJournalAutoConfiguration {

    /**
     * SQLジャーナルログのインターセプターを MyBatis の設定へ登録する。
     * 起動時に実行し、{@link SqlJournalInterceptor} を追加する。
     *
     * @param errorOnly {@code cosmo-app.logging.sql.error-only}（既定 false＝全 SQL を出力）
     * @return {@link ConfigurationCustomizer}
     */
    @Bean
    ConfigurationCustomizer sqlJournalConfigurationCustomizer(
            @Value("${cosmo-app.logging.sql.error-only:false}") boolean errorOnly) {
        return configuration -> configuration.addInterceptor(new SqlJournalInterceptor(errorOnly));
    }
}
