package jp.co.lawson.common.app.lib.logging.api;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingResponseWrapper;

import org.jspecify.annotations.NonNull;

import jp.co.lawson.common.app.lib.logging.StructuredLog;
import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;
import jp.co.lawson.common.app.lib.logging.constant.MdcKeys;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * アクセスログ／アクセスジャーナルログ（要求/応答）を出力する Servlet フィルタクラス。
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
@ConditionalOnClass(OncePerRequestFilter.class)
@ConditionalOnProperty(prefix = "cosmo-app.logging.api", name = "enabled", havingValue = "true", matchIfMissing = false)
public class ApiAccessLogFilter extends OncePerRequestFilter {

    // アクセスログ：1リクエスト1件のサマリ
    private static final Logger accessLog = LoggerFactory.getLogger(LoggerNames.API_ACCESS);
    // アクセスジャーナルログ：要求/応答の詳細
    private static final Logger journalLog = LoggerFactory.getLogger(LoggerNames.API_ACCESS_JNL);

    // 取得元ヘッダ名
    private static final String HEADER_TRACE = "X-Trace-ID";
    private static final String HEADER_USER = "X-User-ID";
    private static final String HEADER_FORWARDED_FOR = "X-Forwarded-For";

    /**
     * アクセスログ／アクセスジャーナルログ（要求/応答）を出力し、リクエスト前後で実行単位の MDC スコープを設定する。
     *
     * @param request HTTP リクエスト
     * @param response HTTP レスポンス
     * @param chain 後続のフィルタチェーン
     * @throws ServletException 後続処理で発生したサーブレット例外
     * @throws IOException 入出力例外
     */
    @Override
    protected void doFilterInternal(
        @NonNull HttpServletRequest request, 
        @NonNull HttpServletResponse response,
        @NonNull FilterChain chain) throws ServletException, IOException {

        // リクエストは入口でボディを全読みし、再読込可能にラップする（要求ジャーナルを処理前にボディ付きで出力するため）
        CachedBodyRequestWrapper req = new CachedBodyRequestWrapper(request);
        ContentCachingResponseWrapper res = new ContentCachingResponseWrapper(response);

        String traceId = req.getHeader(HEADER_TRACE);
        if (traceId == null || traceId.isBlank()) {
            traceId = UUID.randomUUID().toString(); // X-Trace-ID が無ければ自動採番
        }
        String action = req.getMethod() + " " + req.getRequestURI(); // function は当面 action と同値
        String function = action;
        String url = buildUrl(req); // マスクは appender 層

        // 実行単位スコープ(MDC)：put → finally で MDC.clear()。（境界で一掃）
        putMdc(MdcKeys.FUNCTION, function);
        putMdc(MdcKeys.ACTION, action);
        putMdc(MdcKeys.USER, req.getHeader(HEADER_USER));
        putMdc(MdcKeys.TRACE_ID, traceId);
        putMdc(MdcKeys.SOURCE_IP, clientIp(req));
        try {
            // アクセスジャーナル（要求）は処理実行前に出力する。前後ペア統一で status/latency は null
            journalLog.info(StructuredLog.create()
                    .put(LogFields.URL, url)
                    .putNullable(LogFields.STATUS, null)
                    .put(LogFields.HEADERS, requestHeaders(req))
                    .put(LogFields.BODY, content(req.getCachedBody()))
                    .putNullable(LogFields.LATENCY, null)
                    .marker(), "アクセスジャーナル（要求）");

            long startNanos = System.nanoTime();
            try {
                chain.doFilter(req, res);
            } finally {
                // ログ出力が例外を投げても実レスポンスは必ず書き戻す。（copyBodyToResponse を独立 finally に）
                try {
                    long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;

                    // アクセスログ（サマリ）と アクセスジャーナル（応答）は処理後に出力する
                    accessLog.info(StructuredLog.create()
                            .put(LogFields.URL, url)
                            .put(LogFields.STATUS, res.getStatus())
                            .put(LogFields.LATENCY, latencyMs)
                            .marker(), "アクセスログ");

                    journalLog.info(StructuredLog.create()
                            .put(LogFields.URL, url)
                            .put(LogFields.STATUS, res.getStatus())
                            .put(LogFields.HEADERS, responseHeaders(res))
                            .put(LogFields.BODY, content(res.getContentAsByteArray()))
                            .put(LogFields.LATENCY, latencyMs)
                            .marker(), "アクセスジャーナル（応答）");
                } finally {
                    res.copyBodyToResponse(); // コピーしなければ実レスポンスへボディが反映されない
                }
            }
        } finally {
            MDC.clear();
        }
    }

    /**
     * 値があれば MDC へ設定する（null／空白は設定しない＝provider が "null" を出力する）。
     *
     * @param key MDC キー
     * @param value 設定値（null／空白は無視）
     */
    private static void putMdc(String key, String value) {
        if (value != null && !value.isBlank()) {
            MDC.put(key, value);
        }
    }

    /**
     * クライアント IP を求める（{@code X-Forwarded-For} の先頭、無ければ remoteAddr）。
     *
     * @param request HTTP リクエスト
     * @return クライアント IP
     */
    private String clientIp(HttpServletRequest request) {
        String forwarded = request.getHeader(HEADER_FORWARDED_FOR);
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    /**
     * URL（メソッド＋URI＋クエリ文字列）を組み立てる。
     *
     * @param request HTTP リクエスト
     * @return 「メソッド URI[?クエリ]」形式の URL
     */
    private String buildUrl(HttpServletRequest request) {
        String query = request.getQueryString();
        return request.getMethod() + " " + request.getRequestURI() + (query != null ? "?" + query : "");
    }

    /**
     * リクエストヘッダーを Map 化する。
     *
     * @param request HTTP リクエスト
     * @return ヘッダー名→値のマップ
     */
    private Map<String, String> requestHeaders(HttpServletRequest request) {
        Map<String, String> headers = new LinkedHashMap<>();
        Enumeration<String> names = request.getHeaderNames();
        while (names.hasMoreElements()) {
            String name = names.nextElement();
            headers.put(name, request.getHeader(name));
        }
        return headers;
    }

    /**
     * レスポンスヘッダーを Map 化する。
     *
     * @param response HTTP レスポンス
     * @return ヘッダー名→値のマップ
     */
    private Map<String, String> responseHeaders(HttpServletResponse response) {
        Map<String, String> headers = new LinkedHashMap<>();
        for (String name : response.getHeaderNames()) {
            headers.put(name, response.getHeader(name));
        }
        return headers;
    }

    /**
     * バイト列を UTF-8 文字列に変換する。
     *
     * @param bytes 対象バイト列（呼び出し元の {@code getCachedBody()}／{@code getContentAsByteArray()} は非 null）
     * @return 文字列（空なら null）
     */
    private String content(byte[] bytes) {
        if (bytes.length == 0) {
            return null;
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
