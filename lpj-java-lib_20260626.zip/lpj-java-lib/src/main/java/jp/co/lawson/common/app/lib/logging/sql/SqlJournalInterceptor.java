package jp.co.lawson.common.app.lib.logging.sql;

import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.logstash.logback.marker.LogstashMarker;

import jp.co.lawson.common.app.lib.logging.StructuredLog;
import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;

/**
 * SQL 実行（update / query）をフックして SQLジャーナルログを出力するインターセプタークラス。
 */
@Intercepts({
        @Signature(type = Executor.class, method = "update",
                args = {MappedStatement.class, Object.class}),
        @Signature(type = Executor.class, method = "query",
                args = {MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class})
})
public class SqlJournalInterceptor implements Interceptor {

    // SQLジャーナルログのロガー
    private static final Logger journalLog = LoggerFactory.getLogger(LoggerNames.SQL_JNL);

    // true=例外時のみ出力 / false=成功・例外とも出力。（全SQL）
    private final boolean errorOnly;

    /**
     * 出力範囲を指定してインターセプターを生成する。
     *
     * @param errorOnly true なら例外時のみ出力、false なら全 SQL を出力する
     */
    public SqlJournalInterceptor(boolean errorOnly) {
        this.errorOnly = errorOnly;
    }

    /**
     * SQL 実行をフックし、実行後にジャーナルログを出力する。
     * 成功時は INFO（{@code errorOnly} のときは出力しない）、例外時は ERROR で実行 SQL（message）と処理時間（marker）を
     * 出力し、例外はそのまま再スローする。
     * スタックトレースは例外時のみ appender が付与する。
     *
     * @param invocation MyBatis の実行情報（[0]=MappedStatement / [1]=パラメータ）
     * @return SQL 実行の結果（query=結果リスト / update=更新行数）
     * @throws Throwable SQL 実行で発生した例外（ログ出力後そのまま再スロー）
     */
    @Override
    public Object intercept(Invocation invocation) throws Throwable {
        MappedStatement mappedStatement = (MappedStatement) invocation.getArgs()[0];
        Object parameter = invocation.getArgs().length > 1 ? invocation.getArgs()[1] : null;
        String sql = normalize(mappedStatement.getBoundSql(parameter).getSql());

        long startNanos = System.nanoTime();
        try {
            Object result = invocation.proceed();
            if (!errorOnly) {
                journalLog.info(latencyMarker(startNanos), sql);
            }
            return result;
        } catch (Throwable t) {
            journalLog.error(latencyMarker(startNanos), sql, t);
            throw t;
        }
    }

    /**
     * 開始時刻からの経過ミリ秒を latency として保持する marker を組み立てる。
     *
     * @param startNanos 計測開始時刻（{@link System#nanoTime()}）
     * @return latency（経過ミリ秒）を保持する marker
     */
    private static LogstashMarker latencyMarker(long startNanos) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        return StructuredLog.create().put(LogFields.LATENCY, latencyMs).marker();
    }

    /**
     * mapper XML の連続空白・改行を1スペースに集約する。
     *
     * @param sql 整形前の SQL
     * @return 空白を集約した SQL（null はそのまま）
     */
    private static String normalize(String sql) {
        return sql == null ? null : sql.replaceAll("\\s+", " ").trim();
    }
}
