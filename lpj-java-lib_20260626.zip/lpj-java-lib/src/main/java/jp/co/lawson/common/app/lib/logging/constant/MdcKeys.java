package jp.co.lawson.common.app.lib.logging.constant;

/**
 * MDC に設定する実行単位スコープの項目キーを定義するクラス。
 */
public final class MdcKeys {

    /** 機能ID */
    public static final String FUNCTION = "function";
    /** ユーザー */
    public static final String USER = "user";
    /** 操作種別 */
    public static final String ACTION = "action";
    /** トレースID */
    public static final String TRACE_ID = "trace";
    /** 送信元IP */
    public static final String SOURCE_IP = "source_ip";

    private MdcKeys() {
    }
}
