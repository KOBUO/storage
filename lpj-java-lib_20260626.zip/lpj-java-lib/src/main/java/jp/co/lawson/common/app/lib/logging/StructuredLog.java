package jp.co.lawson.common.app.lib.logging;

import java.util.LinkedHashMap;
import java.util.Map;

import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;

/**
 * ログ1件ごとに、出力時に設定する項目を組み立てるビルダークラス。
 */
public final class StructuredLog {

    // 値なしを表す統一プレースホルダ
    public static final String NULL = "null";

    // 追加した項目のマップ（項目名→値）
    private final Map<String, Object> fields = new LinkedHashMap<>();

    /**
     * プライベートコンストラクタ。
     * 外部からのインスタンス化を禁止する。
     */
    private StructuredLog() {
    }

    /**
     * 新しいビルダーを生成する。
     *
     * @return 項目を保持しないビルダー
     */
    public static StructuredLog create() {
        return new StructuredLog();
    }

    /**
     * 項目を追加する。
     * 値が null の場合は追加しない。
     * （その項目を保持しないログ種類では出力されない）
     *
     * @param key 項目名
     * @param value 値（数値・真偽値は文字列化。null は無視）
     * @return このビルダー
     */
    public StructuredLog put(String key, Object value) {
        if (value != null) {
            fields.put(key, normalize(value));
        }
        return this;
    }

    /**
     * 項目を追加する。
     * 値が null の場合は文字列 "null" を出力する。
     * 前後ペア（要求/応答・開始/終了）で項目セットを揃え、片側にのみ値がある項目を
     * もう一方では "null" として出力するために用いる。
     *
     * @param key 項目名
     * @param value 値（null は "null" として出力）
     * @return このビルダー
     */
    public StructuredLog putNullable(String key, Object value) {
        fields.put(key, value == null ? NULL : normalize(value));
        return this;
    }

    /**
     * 数値・真偽値を文字列化する（JSON の数値型／真偽型を使用しない統一方針）。
     * Map／配列／文字列等はそのまま。
     *
     * @param value 正規化前の値
     * @return 数値・真偽値なら文字列、それ以外はそのまま
     */
    private static Object normalize(Object value) {
        return (value instanceof Number || value instanceof Boolean) ? value.toString() : value;
    }

    /**
     * 組み立てた項目を logstash の marker にする。
     *
     * @return 追加項目を保持する {@link LogstashMarker}
     */
    public LogstashMarker marker() {
        return Markers.appendEntries(fields);
    }
}
