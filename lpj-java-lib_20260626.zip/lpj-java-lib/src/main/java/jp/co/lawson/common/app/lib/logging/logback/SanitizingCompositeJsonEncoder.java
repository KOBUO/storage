package jp.co.lawson.common.app.lib.logging.logback;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.Set;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.TextNode;

import net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder;

import ch.qos.logback.classic.spi.ILoggingEvent;

import jp.co.lawson.common.app.lib.logging.LoggingProperties;
import jp.co.lawson.common.app.lib.logging.LoggingProperties.MaskRule;

/**
 * 生成した JSON 1行を、出力項目ごとにマスク・出力長制限してから出力する encoder クラス。
 *
 * <p>appender は {@code <encoder>} を1つしか保持できないため、マスクと出力長制限の両方を
 * この単一のカスタム encoder にまとめて適用する。マスクのロジックは {@link MaskConverter} に分離し、
 * 出力長制限（UTF-8 バイト切詰）は本クラスが行う。
 */
public class SanitizingCompositeJsonEncoder extends LoggingEventCompositeJsonEncoder {

    // JSON の parse／再シリアライズ用（スレッドセーフ）
    private static final ObjectMapper MAPPER = new ObjectMapper();

    // 出力長制限時に付与する接尾辞
    private static final String TRUNCATED_SUFFIX = "...(truncated)";

    /**
     * 親 encoder で JSON を生成し、出力項目ごとにマスク・出力長制限を適用して返却する。
     *
     * @param event ログイベント
     * @return マスク・制限後の JSON バイト列
     */
    @Override
    public byte[] encode(ILoggingEvent event) {
        return apply(super.encode(event));
    }

    /**
     * JSON 1行を解析し、対象の出力項目ごとに 文字列化→マスク→出力長制限→（可能なら）構造復元 を行う。
     * 解析・再シリアライズに失敗した場合は素のまま返却する。（ログ欠落を避ける）
     *
     * @param raw 親 encoder が生成した1行（末尾に改行を含む）
     * @return 加工後のバイト列。
     * 変化が無い／解析できない場合は {@code raw} をそのまま返却する
     */
    static byte[] apply(byte[] raw) {
        try {
            String line = new String(raw, StandardCharsets.UTF_8);
            int end = line.length();
            while (end > 0 && (line.charAt(end - 1) == '\n' || line.charAt(end - 1) == '\r')) {
                end--;
            }
            JsonNode root = MAPPER.readTree(line.substring(0, end));
            if (!root.isObject()) {
                return raw;
            }
            ObjectNode obj = (ObjectNode) root;
            boolean changed = false;
            for (String field : targets()) {
                JsonNode node = obj.get(field);
                if (node == null) {
                    continue;
                }
                JsonNode applied = applyField(field, node);
                if (applied != node) {
                    obj.set(field, applied);
                    changed = true;
                }
            }
            if (!changed) {
                return raw;
            }
            return (obj.toString() + line.substring(end)).getBytes(StandardCharsets.UTF_8);
        } catch (Exception e) {
            return raw;
        }
    }

    /**
     * 出力項目1つ分の値に、マスク・出力長制限を適用する。
     * オブジェクト／配列は JSON 文字列にしてから処理し、変化があれば構造へ戻す（戻せなければ文字列）。
     *
     * @param field 出力項目名
     * @param node 出力項目の値ノード
     * @return 加工後のノード。
     * 無変化なら同じ {@code node} を返却する
     */
    private static JsonNode applyField(String field, JsonNode node) {
        MaskRule rule = LoggingProperties.maskRules().get(field);
        int limit = limitFor(field);
        boolean textual = node.isTextual();
        // 文字列ノードはそのテキスト、オブジェクト／配列は JSON 文字列（toString は例外を投げない）
        String text = textual ? node.asText() : node.toString();
        String out = text;
        if (rule != null) {
            out = MaskConverter.mask(out, rule);
        }
        if (limit > 0) {
            out = truncate(out, limit);
        }
        if (out.equals(text)) {
            return node;
        }
        if (textual) {
            return TextNode.valueOf(out); // 文字列項目は文字列のまま
        }
        try {
            return MAPPER.readTree(out); // オブジェクト／配列は構造へ戻す
        } catch (Exception e) {
            return TextNode.valueOf(out); // 戻せない（truncate で壊れた等）→ 文字列にする
        }
    }

    /**
     * マスク規則または出力長上限が登録された出力項目名の集合を返却する。
     *
     * @return 対象の出力項目名
     */
    private static Set<String> targets() {
        Set<String> fields = new LinkedHashSet<>(LoggingProperties.maskRules().keySet());
        fields.addAll(LoggingProperties.fieldLimits().keySet());
        return fields;
    }

    /**
     * 出力項目名に対応する UTF-8 バイト上限を返却する。
     * （上限は {@code LoggingProperties} が参照用の静的フィールドへ反映している）
     *
     * @param fieldName 出力項目名
     * @return 上限バイト数。
     * 未登録 / null は -1（制限対象外）
     */
    static int limitFor(String fieldName) {
        if (fieldName == null) {
            return -1;
        }
        Integer v = LoggingProperties.fieldLimits().get(fieldName);
        return v == null ? -1 : v;
    }

    /**
     * 最大バイト数（UTF-8）で制限する。
     * 超過時は末尾に ...(truncated) を付け、サフィックス込みで max バイト以内に収める。
     * （マルチバイト文字はコードポイント境界で制限する）
     *
     * @param s 対象文字列
     * @param maxBytes 最大バイト数
     * @return 制限後の文字列（{@code s} が null なら null、上限以下ならそのまま）
     */
    static String truncate(String s, int maxBytes) {
        if (s == null) {
            return null;
        }
        if (s.getBytes(StandardCharsets.UTF_8).length <= maxBytes) {
            return s;
        }
        int suffixBytes = TRUNCATED_SUFFIX.getBytes(StandardCharsets.UTF_8).length;
        // 上限がサフィックス長以下の場合は、サフィックスを付けず本文を上限バイトまで制限する（出力が上限を超えないようにする）
        boolean withSuffix = maxBytes > suffixBytes;
        int budget = withSuffix ? maxBytes - suffixBytes : maxBytes;
        StringBuilder sb = new StringBuilder();
        int used = 0;
        int i = 0;
        // 上限超過時のみ到達するため、必ず予算超過で break する（コードポイント境界で制限する）
        while (true) {
            int cp = s.codePointAt(i);
            int bw = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8).length;
            if (used + bw > budget) {
                break;
            }
            sb.appendCodePoint(cp);
            used += bw;
            i += Character.charCount(cp);
        }
        return withSuffix ? sb + TRUNCATED_SUFFIX : sb.toString();
    }
}
