// =====================================================================================
// lpj-java-lib（ログ出力部品ライブラリ）ビルド定義
//
// 【Windows 環境への移管時に必要なもの】※依存・プラグインはすべて mavenCentral から取得
//   ■ ツールチェーン
//       - JDK    : Amazon Corretto 25
//       - Gradle : 9.5.1（gradle/wrapper 同梱）
//   ■ ビルドプラグイン
//       - io.spring.dependency-management : 1.1.7
//   ■ BOM（バージョン管理。下記 starter のバージョンはここで解決）
//       - org.springframework.boot:spring-boot-dependencies        : 4.0.6
//       - io.awspring.cloud:spring-cloud-aws-dependencies           : 4.0.2
//   ■ 実行時に必須（implementation＝ログ出力の中核。常に使用）
//       - net.logstash.logback:logstash-logback-encoder             : 8.1
//   ■ 利用アプリが提供する前提（compileOnly＝使う機能の依存だけ利用者が追加。@ConditionalOnClass で有効化）
//       - org.springframework.boot:spring-boot-starter-web          : 4.0.6  (BOM)   … API アクセスログ
//       - io.awspring.cloud:spring-cloud-aws-starter-sqs            : 4.0.2  (BOM)   … SQS 受信ジャーナル
//       - software.amazon.awssdk:sqs                                : 2.42.36 (Cloud AWS BOM) … 同上
//       - org.mybatis:mybatis                                       : 3.5.16         … SQL ジャーナル
//       - org.mybatis.spring.boot:mybatis-spring-boot-autoconfigure : 3.0.3
//   ※ テスト専用依存（spring-boot-starter-test 等）は実行時には不要。
//   ※ 推移的依存は上記 BOM/starter から mavenCentral 経由で解決される。
//     オフライン環境では `gradle :lpj-java-lib:dependencies` の runtimeClasspath を一覧化してミラーすること。
// =====================================================================================

plugins {
    // ライブラリなので Spring Boot プラグイン（bootJar/実行可能 jar）は適用しない。
    // java-library は java プラグインを内包する。
    `java-library`
    // バージョンを Spring Boot / Spring Cloud AWS の BOM で揃えるため dependency-management を使う。
    id("io.spring.dependency-management") version "1.1.7"
    // テストカバレッジ計測。
    jacoco
}

group = "jp.co.lawson.common.app"
version = "0.0.1-SNAPSHOT"

// --- 依存バージョンの一元管理（移管時はこのブロックを参照） ---
val springBootVersion = "4.0.6"
val springCloudAwsVersion = "4.0.2"
val logstashEncoderVersion = "8.1"
val mybatisVersion = "3.5.16"
val mybatisSpringBootVersion = "3.0.3"

java {
    toolchain {
        // Amazon Corretto 25。
        languageVersion = JavaLanguageVersion.of(25)
    }
}

// メソッド引数名を保持（AspectJ CodeSignature.getParameterNames 用）。
tasks.withType<JavaCompile>().configureEach {
    options.compilerArgs.add("-parameters")
}

repositories {
    mavenCentral()
}

dependencyManagement {
    imports {
        mavenBom("org.springframework.boot:spring-boot-dependencies:$springBootVersion")
        mavenBom("io.awspring.cloud:spring-cloud-aws-dependencies:$springCloudAwsVersion")
    }
}

dependencies {
    // ── 実行時に必須（implementation：ログ出力の中核。常に使用）
    implementation("net.logstash.logback:logstash-logback-encoder:$logstashEncoderVersion")  // JSON ログ provider / encoder
    // 接続部品（KMS/DynamoDB/SQS送受信）は lib に含めない。lib はログ部品のみ。

    // ── ビルド専用（@ConfigurationProperties のメタデータ生成）
    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")

    // ── 利用アプリが提供する前提（compileOnly：lib には同梱せず、利用者が使う機能の依存だけ追加する。各機能は @ConditionalOnClass で有効化）
    compileOnly("org.springframework.boot:spring-boot-starter-web")                          // API アクセスログ（OncePerRequestFilter）
    compileOnly("io.awspring.cloud:spring-cloud-aws-starter-sqs")                            // SQS 受信ジャーナル（@SqsListener / MessageInterceptor）
    compileOnly("software.amazon.awssdk:sqs")                                                // SQS 受信ジャーナル（SqsAsyncClient 型参照）
    compileOnly("org.mybatis:mybatis:$mybatisVersion")                                       // SQL ジャーナル（MyBatis Interceptor）
    compileOnly("org.mybatis.spring.boot:mybatis-spring-boot-autoconfigure:$mybatisSpringBootVersion")

    // ── テスト専用（compileOnly の機能依存はテストでも必要なので明示）
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.springframework.boot:spring-boot-starter-web")
    testImplementation("io.awspring.cloud:spring-cloud-aws-starter-sqs")
    testImplementation("software.amazon.awssdk:sqs")
    testImplementation("org.mybatis:mybatis:$mybatisVersion")
    testImplementation("org.mybatis.spring.boot:mybatis-spring-boot-autoconfigure:$mybatisSpringBootVersion")
    // Boot プラグイン未適用のため JUnit Platform launcher を明示（Gradle 9 のテスト実行に必要）。
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.named<Test>("test") {
    useJUnitPlatform()
    finalizedBy(tasks.named("jacocoTestReport"))
}

tasks.named<JacocoReport>("jacocoTestReport") {
    dependsOn(tasks.named("test"))
    reports {
        csv.required = true
        html.required = true
    }
}
