## アクセスログ出力（API用）

### 部品概要

#### 目的

HTTP リクエスト単位でログスコープを開始し、アクセスログ（1件サマリ）とアクセスジャーナル（要求/応答）を出力する。

#### 前提

  - Spring MVC（Servlet環境）で動作することを前提とする。（WebFlux 非対応）  
    `@Component` としてスキャンされ、`org.springframework.web.filter.OncePerRequestFilter` として API リクエストの前後にフックする。
  - `application.yml`（`cosmo-app.logging.api.enabled=true`）で有効化して使用する。（既定 OFF）
  - アクセスジャーナルログは本フィルタが出力する前提。  
    **既存のアクセスジャーナル用 `AccessLogInterceptor implements HandlerInterceptor` は登録しない**こと。（両方登録すると二重出力）  
    注：利用者側で `@Configuration`（`WebMvcConfigurer#addInterceptors`）登録しないこと。

#### 特記事項

  - `OncePerRequestFilter` を継承し `doFilterInternal` を実装することで、HTTP リクエストの前後で処理を挟む。
  - `@Order(Ordered.HIGHEST_PRECEDENCE)` を付けて**最も外側**のフィルタにすることで、  
    後続の全処理を MDC スコープの中に入れる。（既存部品のフィルタよりも外側になる）
  - レスポンスを確実に返却するため、`org.springframework.web.util.ContentCachingResponseWrapper` は最後に必ず `copyBodyToResponse()` を呼び出す。（キャッシュしたボディを本物のレスポンスへ書き戻す）
  - アクセスログ用（`"SPRINGBOOT_API_ACCESS_LOG"`）/ アクセスジャーナル用（`"SPRINGBOOT_API_ACCESS_JNL_LOG"`）の `org.slf4j.Logger` は固定ロガー名のため  
    `static final` フィールドでクラスロード時に1度だけ取得し、全リクエストで共有する。
    `Logger` はスレッドセーフでステートレスなので再利用して問題ない。
  - リクエストは入口でボディを全読みする `jp.co.lawson.common.app.lib.logging.api.CachedBodyRequestWrapper`（再読込可能）でラップし、アクセスジャーナル（要求）を**処理実行前**にボディ付きで出力する。  
    ボディを入口で消費するため、フォーム（`application/x-www-form-urlencoded`）の `getParameter` 再パースには非対応。（JSON API 前提）

### 処理フロー

本部品は以下のような処理フローで動作する。

1. リクエストボディを入口で全読みしキャッシュするため、引数（`jakarta.servlet.http.HttpServletRequest`）を `CachedBodyRequestWrapper`（再読込可能）でラップする。
2. ボディをキャッシュするため、引数（`jakarta.servlet.http.HttpServletResponse`）を `ContentCachingResponseWrapper` でラップする。
3. 以下の処理でリクエスト元IPアドレスを取得する。
    1. `CachedBodyRequestWrapper.getHeader("X-Forwarded-For")` から、クライアントIPアドレスを取得する。
    2. クライアントIPアドレスが存在する場合
        1. クライアントIPアドレスの1件目をリクエスト元IPアドレスとする。
    3. クライアントIPアドレスが存在しない場合
        1. `CachedBodyRequestWrapper.getRemoteAddr()` をリクエスト元IPアドレスとする。
4. 以下の表の内容を、`org.slf4j.MDC` に追加する。

    | キー          | 設定値                                                               |
    | ------------- | -------------------------------------------------------------------- |
    | `"function"`  | `getMethod()` + " " + `getRequestURI()`                              |
    | `"action"`    | `getMethod()` + " " + `getRequestURI()`                              |
    | `"user"`      | `getHeader("X-User-ID")`                                             |
    | `"trace"`     | `getHeader("X-Trace-ID")`（無ければ `UUID.randomUUID()` で自動採番） |
    | `"source_ip"` | リクエスト元IPアドレス                                               |

5. 以下の処理で URL を取得する。
    1. `getQueryString()` から、クエリ文字列を取得する。
    2. クエリ文字列が null 以外の場合、クエリ文字列を 「"?" + クエリ文字列」とする。
    3. `getMethod()` + " " + `getRequestURI()` + クエリ文字列を URL とする。
6. **処理実行前**に、以下の処理でアクセスジャーナルログ（要求）を出力する。
    1. `CachedBodyRequestWrapper.getHeaderNames()`、`getHeader()` から、リクエストヘッダーのマップを生成する。
    2. `CachedBodyRequestWrapper.getCachedBody()`（入口で全読みしたボディ）を `UTF-8` で文字列に変換し、リクエストボディの文字列を生成する。（null または 0桁の場合、null）
    3. 以下の表の内容で、 `net.logstash.logback.marker.LogstashMarker` を生成する。

        | キー        | 設定値                     |
        | ----------- | -------------------------- |
        | `"url"`     | URL                        |
        | `"status"`  | `null`                     |
        | `"headers"` | リクエストヘッダーのマップ |
        | `"body"`    | リクエストボディの文字列   |
        | `"latency"` | `null`                     |

    4. アクセスジャーナル用（`"SPRINGBOOT_API_ACCESS_JNL_LOG"`）の `Logger` から、以下の内容でログを出力する。

        | 引数     | 設定値                         |
        | -------- | ------------------------------ |
        | `marker` | 生成した `LogstashMarker`      |
        | `msg`    | `"アクセスジャーナル（要求）"` |

7. 処理開始時間（ns）を取得する。（`System.nanoTime()`）
8. 引数（`jakarta.servlet.FilterChain`）から、`FilterChain.doFilter()` で後続フィルタ・コントローラを実行する。
9. 処理終了時間（ns）を取得し、開始との差分から処理時間（ms）を算出する。
10. `finally` で以下の処理でアクセスログを出力する。
    1. 以下の表の内容で、 `LogstashMarker` を生成する。

        | キー        | 設定値                                      |
        | ----------- | ------------------------------------------- |
        | `"url"`     | URL                                         |
        | `"status"`  | `ContentCachingResponseWrapper.getStatus()` |
        | `"latency"` | 処理時間（ms）                              |

    2. アクセスログ用（`"SPRINGBOOT_API_ACCESS_LOG"`）の `Logger` から、以下の内容でログを出力する。

        | 引数     | 設定値                    |
        | -------- | ------------------------- |
        | `marker` | 生成した `LogstashMarker` |
        | `msg`    | `"アクセスログ"`          |

11. `finally` で以下の処理でアクセスジャーナルログ（応答）を出力する。
    1. `ContentCachingResponseWrapper.getHeaderNames()`、`getHeader()` から、レスポンスヘッダーのマップを生成する。
    2. `ContentCachingResponseWrapper.getContentAsByteArray()` から、`UTF-8` で文字列に変換し、レスポンスボディの文字列を生成する。（null または 0桁の場合、null）
    3. 以下の表の内容で、 `LogstashMarker` を生成する。

        | キー        | 設定値                                      |
        | ----------- | ------------------------------------------- |
        | `"url"`     | URL                                         |
        | `"status"`  | `ContentCachingResponseWrapper.getStatus()` |
        | `"headers"` | レスポンスヘッダーのマップ                  |
        | `"body"`    | レスポンスボディの文字列                    |
        | `"latency"` | 処理時間（ms）                              |

    4. アクセスジャーナル用（`"SPRINGBOOT_API_ACCESS_JNL_LOG"`）の `Logger` から、以下の内容でログを出力する。

        | 引数     | 設定値                         |
        | -------- | ------------------------------ |
        | `marker` | 生成した `LogstashMarker`      |
        | `msg`    | `"アクセスジャーナル（応答）"` |

12. `ContentCachingResponseWrapper.copyBodyToResponse()` でレスポンス返却する。
13. `finally` で MDC を全 remove する。

### クラス一覧／メソッド一覧

| クラス                                                       | メソッド                                                                 | 概要                                                                                                               |
| ------------------------------------------------------------ | ------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------ |
| `jp.co.lawson.common.app.lib.logging.api.ApiAccessLogFilter` | `doFilterInternal(HttpServletRequest, HttpServletResponse, FilterChain)` | アクセスログ／アクセスジャーナルログを出力するフィルタ本体                                                         |
| `CachedBodyRequestWrapper`                                   | `getCachedBody()` ／ `getInputStream()` ／ `getReader()`                 | リクエストボディを入口で全読みしてキャッシュし、再読込可能にする。要求ジャーナルを処理前にボディ付きで出力するため |

### 利用ガイド

本機能は Spring MVC（`spring-boot-starter-web`）に依存するため、**利用者が依存に追加する**。（Web アプリは通常すでに保持。依存が無い場合は `@ConditionalOnClass(OncePerRequestFilter)` により本フィルタは無効）  
コンポーネントスキャンに含めたうえで、`application.yml` で有効化する。

```yaml
cosmo-app:
  logging:
    api:
      enabled: true   # 既定 false
```

---
