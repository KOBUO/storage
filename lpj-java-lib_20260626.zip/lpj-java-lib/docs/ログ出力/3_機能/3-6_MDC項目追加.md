## MDC項目追加

### 部品概要

#### 目的

`org.slf4j.MDC`（実行単位スコープ項目）を、appender 定義で列挙した順・項目名でログイベントに追加する。

#### 前提

  - ログに出力項目を追加するため、provider（`net.logstash.logback.composite.JsonProvider`）として appender に登録して使用する。
  - provider として機能させるために、`net.logstash.logback.composite.AbstractJsonProvider<ILoggingEvent>` を継承して実装する。
  - 出力する項目・順序を特定するために、appender 定義の列挙（`<includeMdcKeyName>` ／ `<entry>`）から出力エントリ（取得キー・出力名）を構築する。
  - MDC 値を取得するために、`event.getMDCPropertyMap()` を使用する。

#### 特記事項

  - 値を取得できない場合、その項目は `"null"` を出力する。
  - appender 定義で列挙したキー以外は出力しない。

### 処理フロー

本部品は以下のような処理フローで動作する。

#### アプリケーション起動時

> 注：logback が appender 定義を読み込むときに、1回だけ実行される。

1. 出力エントリ（取得キー・出力名のリスト）を空で初期化する。
2. appender 定義の列挙を列挙順に処理し、出力エントリへ追加する。
    1. `<includeMdcKeyName>name</includeMdcKeyName>` の場合
        1. 取得キー＝出力名 のエントリを追加する。
    2. `<entry>取得キー:出力名</entry>` の場合
        1. 取得キーと出力名を分けたエントリを追加する。（`:` 無しは取得キー＝出力名）

#### ログ出力時

> 注：ログ1件ごとに実行される。

1. 引数（`ILoggingEvent`）から、`ILoggingEvent.getMDCPropertyMap()` を使用して MDC マップを取得する。
2. 出力エントリを列挙順に繰り返し、引数（`JsonGenerator`）から、`JsonGenerator.writeStringField(..)` を使用して、以下の内容を出力する。

    | 項目名               | 設定値                                                                           |
    | -------------------- | -------------------------------------------------------------------------------- |
    | 出力エントリの出力名 | 出力エントリの取得キーに一致する MDC マップの設定値（存在しない場合は `"null"`） |

### クラス一覧／メソッド一覧

| クラス                   | メソッド                                | 概要                                                           |
| ------------------------ | --------------------------------------- | -------------------------------------------------------------- |
| `MdcOrderedJsonProvider` | `writeTo(JsonGenerator, ILoggingEvent)` | 列挙順に MDC 項目を出力                                        |
| 〃                       | `addIncludeMdcKeyName(String)`          | `<includeMdcKeyName>` の列挙設定（取得キー＝出力名）           |
| 〃                       | `addEntry(String)`                      | `<entry>` の列挙設定（取得キー:出力名 を分離、`:` 無しは同名） |

### 利用ガイド

appender の encoder（`jp.co.lawson.common.app.lib.logging.logback.SanitizingCompositeJsonEncoder`）の `<providers>` に本 provider を登録し、出力する MDC を列挙する。  
取得キーと出力名が異なる場合は `<entry>取得キー:出力名</entry>` を使用する。

```xml
<appender name="APP" class="ch.qos.logback.core.ConsoleAppender">
    <encoder class="jp.co.lawson.common.app.lib.logging.logback.SanitizingCompositeJsonEncoder">
        <providers>
            <!-- 他の provider … -->
            <provider class="jp.co.lawson.common.app.lib.logging.logback.MdcOrderedJsonProvider">
                <includeMdcKeyName>function</includeMdcKeyName>
                <includeMdcKeyName>trace</includeMdcKeyName>
                <!-- 取得キーと出力名が異なる場合（MDC キー userId を user として出力） -->
                <entry>userId:user</entry>
            </provider>
        </providers>
    </encoder>
</appender>
```

出力例：

```json
{ "...": "...", "function": "/api/x", "trace": "t1", "user": "u1" }
```

---
