## SQLジャーナルログ出力（MyBatis用）

### 部品概要

#### 目的

MyBatis の SQL 実行（update / query）をフックし、実行後に SQLジャーナルログを出力する。

#### 前提

  - SQL 実行をフックするために、MyBatis の `org.apache.ibatis.plugin.Interceptor` として実装する。
  - `application.yml`（`cosmo-app.logging.sql.enabled=true`）で有効化して使用する。（既定 OFF）
  - 出力範囲は `cosmo-app.logging.sql.error-only` で切り替える。（`false`＝全 SQL／`true`＝例外時のみ。  
    既定 `false`）
  - 有効時に MyBatis へ登録するために、自動設定（`SqlJournalAutoConfiguration`）が `ConfigurationCustomizer` 経由で本インターセプターを追加する。
  - 出力先は固定ロガー名 `SPRINGBOOT_SQL_JNL_LOG`。（subtype `DBCALL`）
  - 処理時間を測るために、`invocation.proceed()` の前後の経過時間を計測する。

#### 特記事項

  - message は実行 SQL のみ。（mapper XML の連続空白は1スペースに集約する。  
    バインド値は出力しない）
  - 成功は INFO（`type=app`・stdout）、例外は ERROR。（`type=monitor`・stderr・`stack_trace`）  
    type と出力先は appender が振り分ける。
  - 処理時間（`latency`）は成功・例外とも marker で出力する。  
    `stack_trace` は例外時のみ。
  - 例外はログ出力後そのまま再スローする。（リトライ等を妨げない）

### 処理フロー

本部品は以下のような処理フローで動作する。

1. 引数（`Invocation`）の `MappedStatement` と SQL パラメータ（バインド値）から実行 SQL（`getBoundSql(parameter).getSql()`）を取得し、連続空白を1スペースに集約する。
2. 計測を開始し、`Invocation.proceed()` で SQL を実行する。
    1. 成功した場合
        1. INFO で実行 SQL（message）と処理時間（marker）を出力し、結果を返却する。（`error-only=true` のときは成功時は出力しない）
    2. 例外が発生した場合
        1. ERROR で実行 SQL（message）・処理時間（marker）・例外を出力し、例外を再スローする。

### クラス一覧／メソッド一覧

| クラス                        | メソッド                              | 概要                                                   |
| ----------------------------- | ------------------------------------- | ------------------------------------------------------ |
| `SqlJournalInterceptor`       | `intercept(Invocation)`               | SQL 実行をフックして SQLジャーナルログを出力           |
| `SqlJournalAutoConfiguration` | `sqlJournalConfigurationCustomizer()` | yml 有効時に interceptor を MyBatis へ登録する自動設定 |

### 利用ガイド

本機能は MyBatis（`org.mybatis:mybatis` / `mybatis-spring-boot-autoconfigure`）に依存するため、**利用者が依存に追加する**。（MyBatis 利用アプリは通常すでに保持。依存が無い場合は `@ConditionalOnClass(ConfigurationCustomizer)` により無効）  
MyBatis を使用する Spring Boot アプリで、本ライブラリをコンポーネントスキャンに含めたうえで `application.yml` で有効化する。（手動の Bean 定義は不要）  
有効化すると `SqlJournalAutoConfiguration` がインターセプターを MyBatis に登録し、全 Mapper の SQL がフックされる。

```yaml
cosmo-app:
  logging:
    sql:
      enabled: true       # 既定 false
      error-only: false   # true=例外時のみ / false=全SQL（既定）
```

出力例（成功時）：

```json
{ "...": "...", "subtype": "DBCALL", "message": "SELECT * FROM user WHERE id = ?", "latency": "3" }
```

---
