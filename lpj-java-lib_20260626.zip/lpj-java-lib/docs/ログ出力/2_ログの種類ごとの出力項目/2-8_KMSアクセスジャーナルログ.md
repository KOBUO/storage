## KMSアクセスジャーナルログ

| 論理名             | 物理名                  | 設定値の説明（appender が値を得る経路）                             |
| ------------------ | ----------------------- | ------------------------------------------------------------------- |
| タイムスタンプ     | `timestamp`             | logback 標準 `<timestamp>`                                          |
| コンテナID         | `id`                    | logback で環境変数 `CONTAINER_ID` を参照（未設定時 `"null"`）       |
| コンテナ名         | `name`                  | logback で環境変数 `CONTAINER_NAME` を参照（未設定時 `"null"`）     |
| ログレベル         | `level`                 | logback 標準 `<logLevel>`                                           |
| ログレベル値       | `level_value`           | logback 標準 `<logLevelValue>`（**数値**）                          |
| ロガー名           | `logger_name`           | logback 標準 `<loggerName>`                                         |
| ログ種類           | `type`                  | appender で固定。`"app"`                                            |
| ログ種類詳細       | `subtype`               | appender で固定。`"AWSCALL"`                                        |
| スレッド           | `thread`                | logback 標準 `<threadName>`                                         |
| 機能ID             | `function`              | `MDC("function")`（[MDC項目追加](#mdc項目追加)）                    |
| トレースID         | `trace`                 | `MDC("trace")`                                                      |
| メッセージ         | `message`               | [出力長制限](#出力長制限)（マスク後に切詰・上限はプロパティ）       |
| 処理時間           | `latency`               | `marker`                                                            |
| AWS リクエストID   | `aws_request_id`        | `marker`（応答メタ）                                                |
| AWS リクエスト時刻 | `aws_request_timestamp` | `marker`                                                            |
| AWS 応答時間       | `aws_response_time`     | `marker`（＝`latency`）                                             |
| クラス名           | `class_name`            | [発生元（クラス名・メソッド名）追加](#発生元クラス名メソッド名追加) |
| メソッド名         | `method_name`           | [発生元（クラス名・メソッド名）追加](#発生元クラス名メソッド名追加) |
