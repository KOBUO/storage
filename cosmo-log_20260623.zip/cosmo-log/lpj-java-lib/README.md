# lpj-java-lib — 共通ログ出力ライブラリ（ドロップイン）

Spring Boot 4 / Spring Cloud AWS 4 系アプリ向けの **構造化ログ出力部品**一式。
依存追加＋コンポーネントスキャンに含めるだけで、アクセス/ジャーナル/業務/システムの各ログが
JSON で自動出力される「ドロップイン」設計。実装パッケージは `jp.co.xxx.common.app.lib`
（`xxx` は顧客名の仮置き。合流時に実値へ置換する → 下記「2. パッケージ名の置換」）。

> **このリポジトリの位置づけ**: 単体の Gradle サブプロジェクトとして実装・検証済み。
> 最終的には **既存の共通ライブラリ（別リポジトリ）へ本ソースをドロップインで合流**させる
> （統合方針 = B）。本 README はその合流手順書を兼ねる。

---

## 1. 合流するファイル一覧（コピー対象）

| 区分 | パス | 件数 | 必須 |
|---|---|---|---|
| 実装 | `src/main/java/jp/co/xxx/common/app/lib/**` | 28 クラス | ✅ |
| ログ設定 | `src/main/resources/logback-spring.xml` | 1 | ✅ |
| ログ設定 | `src/main/resources/logback/appender-*.xml` | 12 | ✅ |
| テスト | `src/test/java/**`（`com.example.democaller` 含む） | 7 | 推奨 |

`build/` は生成物なのでコピー不要。`logback-spring.xml` は `<include resource="logback/appender-*.xml"/>`
でクラスパス相対 include しているため、**`logback/` 配下を同じ相対位置に置けばそのまま動く**。

### パッケージ構成（実装）
```
jp.co.xxx.common.app.lib
├─ ApplicationLogger / CallerResolver / StructuredLog        … 共通基盤
├─ LogFields / LoggerNames / MdcKeys / LogType / LogSubtype  … 定数・列挙
├─ LoggingProperties                                          … @ConfigurationProperties(logging.custom.*)
├─ logback.{ContainerInfo,MdcOrdered,TypeSubtype}JsonProvider … logback JSON provider（xml から FQCN 参照）
├─ mask.LogMaskingService                                     … マスキング
├─ aspect.ServiceJournalAspect                                … サービスジャーナル(P/Q)
├─ mybatis.SqlJournalInterceptor                              … SQLジャーナル(R)
├─ scope.ExecutionScopeMdc / scope.batch.BatchLogScope        … 実行単位MDC
├─ scope.online.{HttpLoggingFilter,FunctionActionResolver}    … アクセスログ/ジャーナル(L/M/N/O)
├─ scope.resident.{ResidentSqsConfig,SqsJournalMessageInterceptor} … 常駐SQS(W)
├─ web.{HttpClientJournalInterceptor,RestClientConfig}        … 外部HTTPジャーナル(T/U)
└─ aws.{Kms,DynamoDb,Sqs}AccessService / AwsResponseMetadataExtractor / SqsTraceSupport … AWSCALL
```

---

## 2. パッケージ名の置換（`xxx` → 実値）

合流先の名前空間に合わせ、**`jp.co.xxx.common.app.lib` を実際の名前空間へ一括置換**する。
影響範囲は src 配下の全 java/xml（`jp.co.xxx` 文字列を含むのは 47 箇所）＋ディレクトリパス＋下記。

置換が必要な箇所（漏れやすい順）:
1. **ソースのパッケージ宣言・import**（`jp.co.xxx.common.app.lib...`）
2. **ディレクトリ階層** `src/.../java/jp/co/xxx/...`（IDE のパッケージリネームで一括）
3. **logback xml の provider FQCN**（文字列参照のため IDE リネームに追従しない・要手動）:
   - `jp.co.xxx.common.app.lib.logback.ContainerInfoJsonProvider`
   - `jp.co.xxx.common.app.lib.logback.MdcOrderedJsonProvider`
   - `jp.co.xxx.common.app.lib.logback.TypeSubtypeJsonProvider`
4. **build の `group`**（`jp.co.xxx.common.app`）

> IDE を使わない場合の目安: `jp.co.xxx`（ドット）と `jp/co/xxx`（パス）の2系統を置換し、
> ディレクトリを `git mv` で移動。置換後に `appender-*.xml` の FQCN を grep で再確認すること。

---

## 3. 合流先ビルドに必要な依存

合流先（既存共通ライブラリ）の build に以下が無ければ追加する。バージョンは BOM 管理を推奨。

**BOM（バージョン整合）**
- `org.springframework.boot:spring-boot-dependencies:4.0.6`
- `io.awspring.cloud:spring-cloud-aws-dependencies:4.0.2`

**実装（このライブラリの公開API。`api`/`implementation` は合流先の方針に合わせる）**
| 依存 | 用途 |
|---|---|
| `spring-boot-starter-web` | Filter / HandlerMapping / RestClient / jakarta.servlet |
| `spring-boot-starter-aspectj` | `@Aspect`（サービスジャーナル） |
| `net.logstash.logback:logstash-logback-encoder:8.1` | JSON ログ provider（logback-classic を内包） |
| `io.awspring.cloud:spring-cloud-aws-starter-sqs` | `@SqsListener` / `MessageInterceptor` |
| `software.amazon.awssdk:s3` | `AwsResponseMetadataExtractor`（S3ResponseMetadata 参照） |
| `software.amazon.awssdk:sqs` / `:kms` / `:dynamodb` | 各 AWSCALL アクセス部品 |

**コンパイルのみ**
- `org.mybatis:mybatis:3.5.16`（`SqlJournalInterceptor`。MyBatis 不使用アプリでも本体は動くよう compileOnly）

**注釈処理**
- `spring-boot-configuration-processor`（`LoggingProperties` の設定メタデータ生成。任意）

**テスト**
- `spring-boot-starter-test` / `org.junit.platform:junit-platform-launcher`
- `org.mybatis:mybatis:3.5.16` / `com.h2database:h2`（SQLジャーナルの H2 結合テスト用）

---

## 4. 有効化（配線）

### 4-1. コンポーネントスキャン
アプリの起点が lib パッケージを **スキャン対象に含める**こと。
```java
@SpringBootApplication(scanBasePackages = {"<アプリのbase>", "jp.co.<実値>.common.app.lib"})
```
※ lib パッケージがアプリの base package 配下にあるなら追記不要。

### 4-2. logback
`logback-spring.xml` をクラスパス先頭に置く（合流先に既存の logback がある場合は
`appender-*.xml` を取り込むか、provider 定義をマージする）。

### 4-3. プロパティ（application.yml）
```yaml
logging:
  custom:                  # LoggingProperties にバインド
    body-max-length: 2048
    message-max-length: 4096
    mask-header-names: [authorization, cookie]
    mask-body-keys: [password, secret, token]
    mask-body-patterns: []   # 値パターンマスク（正規表現）。既定空の opt-in
lpj:
  logging:
    sqs:
      enabled: true        # 常駐SQSログ部品の有効/無効（既定 true）
```

---

## 5. ドロップインの効き方（自動 vs 呼び出し側依存）

| 種別 | 部品 | 有効化 |
|---|---|---|
| **自動**（scan で差し込み） | HttpLoggingFilter / ServiceJournalAspect / SqlJournalInterceptor※ / HttpClientJournalInterceptor / SqsJournalMessageInterceptor / 各 JsonProvider | アプリは何も書かなくてよい |
| **呼び出し側依存** | `ApplicationLogger`（業務ログ X / 業務エラー Y） | 開発者が明示的に呼ぶ。呼ばなければ業務ログは出ない（＝それ以外のログは出る） |

※ `SqlJournalInterceptor` は MyBatis の `Interceptor`。MyBatis 構成へ plugin 登録が必要（自動構成があれば Bean 登録で拾わせる）。

### 条件付き Bean（合流時の競合に注意）
- `RestClientConfig`: `@ConditionalOnMissingBean(RestTemplate.class)` … アプリ側に RestTemplate があればそちらを尊重。
- `ResidentSqsConfig` / `SqsJournalMessageInterceptor`: `@ConditionalOnProperty(lpj.logging.sqs.enabled, 既定true)`。
  **アプリが独自に `SqsMessageListenerContainerFactory` を定義すると本部品が無効化される** → その場合は自作
  ファクトリにも `SqsJournalMessageInterceptor` を `messageInterceptor(...)` で追加すること（詳細はログ部品詳細設計書「常駐SQS共通ログ部品」の注意書き）。

---

## 6. 合流時の注意点

- **テストヘルパー `com.example.democaller.DemoCaller`**: `CallerResolver` が「lib 自身のパッケージを除外し、
  最初のアプリ業務フレームを発生元とする」挙動を検証するため、**意図的に lib 外パッケージ**に置いている。
  合流先でも lib パッケージ外（任意の非 `jp.co.<実値>.common.app.lib` パッケージ）に維持すること。
- **logback の provider FQCN**（§2-3）はリネーム時に追従しないので必ず手動確認。
- `ApplicationLogger` を呼ぶ業務コードは lib に依存する（呼び出し箇所は lib 無しではコンパイル不可）。
  これが唯一「実装と分離できない」結合点。
- lib 本体は `com.example`（検証アプリ）に一切依存しない（確認済み）。`app.mode` にも非依存。

---

## 7. 検証状況

3モード（API/単発/常駐）＋ AWS（KMS/DynamoDB）＋ SQS（ElasticMQ）を実機検証済み。
単体/結合テスト 25 件パス。詳細はルートの設計書（`ログ設計書.md` / `ログ部品詳細設計書.md` /
`部品一覧.md` / `部品確認ケース.md`）を参照。
