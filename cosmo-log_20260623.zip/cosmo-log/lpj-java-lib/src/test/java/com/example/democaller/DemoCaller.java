package com.example.democaller;

import jp.co.xxx.common.app.lib.CallerResolver;

/**
 * CallerResolver の発生元解決を検証するための、ライブラリ外パッケージのヘルパー。
 * （lib＝jp.co.xxx.common.app.lib 配下は CallerResolver が除外するため、
 *  「アプリの業務コード」役として lib 外パッケージに置く）
 */
public final class DemoCaller {

    private DemoCaller() {
    }

    /** ここから CallerResolver.resolve() を呼ぶと、発生元はこのクラス（lib外）になるはず。 */
    public static StackWalker.StackFrame resolveFrom() {
        return CallerResolver.resolve();
    }
}
