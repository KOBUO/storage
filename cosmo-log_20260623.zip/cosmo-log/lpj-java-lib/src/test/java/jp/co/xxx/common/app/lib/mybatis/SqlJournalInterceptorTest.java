package jp.co.xxx.common.app.lib.mybatis;

import static java.nio.charset.StandardCharsets.UTF_8;
import static java.util.stream.Collectors.joining;
import static org.assertj.core.api.Assertions.assertThat;

import javax.sql.DataSource;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.datasource.unpooled.UnpooledDataSource;
import org.apache.ibatis.mapping.Environment;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.apache.ibatis.transaction.jdbc.JdbcTransactionFactory;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.LoggerFactory;

import jp.co.xxx.common.app.lib.LoggerNames;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import net.logstash.logback.encoder.LogstashEncoder;

/**
 * SqlJournalInterceptor を H2 + MyBatis に実際に組み込み、SQL 実行時に
 * SQLジャーナル(DBCALL) が latency 付きで出力されることを検証する結合テスト。
 */
class SqlJournalInterceptorTest {

    private final Logger sqlLogger = (Logger) LoggerFactory.getLogger(LoggerNames.SQL_JNL);
    private final ListAppender<ILoggingEvent> appender = new ListAppender<>();

    interface SampleMapper {
        @Update("CREATE TABLE IF NOT EXISTS t (id INT PRIMARY KEY, v VARCHAR(50))")
        void createTable();

        @Update("INSERT INTO t (id, v) VALUES (#{id}, #{v})")
        void insert(@Param("id") int id, @Param("v") String v);

        @Select("SELECT v FROM t WHERE id = #{id}")
        String find(@Param("id") int id);
    }

    @AfterEach
    void detach() {
        sqlLogger.detachAppender(appender);
    }

    @Test
    void emitsSqlJournalWithLatencyOnRealSqlExecution() {
        appender.start();
        sqlLogger.addAppender(appender);

        DataSource ds = new UnpooledDataSource(
                "org.h2.Driver", "jdbc:h2:mem:sqljnl;DB_CLOSE_DELAY=-1", "sa", "");
        org.apache.ibatis.session.Configuration config =
                new org.apache.ibatis.session.Configuration(
                        new Environment("test", new JdbcTransactionFactory(), ds));
        config.addInterceptor(new SqlJournalInterceptor()); // ★検証対象を plugin として登録
        config.addMapper(SampleMapper.class);
        SqlSessionFactory factory = new SqlSessionFactoryBuilder().build(config);

        String found;
        try (SqlSession session = factory.openSession(true)) {
            SampleMapper mapper = session.getMapper(SampleMapper.class);
            mapper.createTable();
            mapper.insert(1, "hello");
            found = mapper.find(1);
        }

        // 1) インターセプタが結果を素通しする（壊さない）
        assertThat(found).isEqualTo("hello");
        // 2) SQLジャーナルが出力されている（update/query 各回）
        assertThat(appender.list).isNotEmpty();

        // 3) ジャーナルに message(=ステートメントID) と latency が含まれる
        LogstashEncoder encoder = new LogstashEncoder();
        encoder.setContext(sqlLogger.getLoggerContext());
        encoder.start();
        String json = appender.list.stream()
                .map(e -> new String(encoder.encode(e), UTF_8))
                .collect(joining("\n"));
        encoder.stop();

        assertThat(json).contains("sql journal:");
        assertThat(json).contains("\"latency\"");
        // class_name/method_name のキーが両方とも出力される（全種共通の横展開）。
        assertThat(json).contains("\"class_name\"");
        assertThat(json).contains("\"method_name\"");
        // 発生元解決はライブラリ自身(SqlJournalInterceptor 等 jp.co.xxx.common.app.lib 配下)を
        // 確実に除外する＝発生元が lib のクラスになっていないこと。
        assertThat(json).doesNotContain("\"class_name\":\"jp.co.xxx.common.app.lib");
    }
}
