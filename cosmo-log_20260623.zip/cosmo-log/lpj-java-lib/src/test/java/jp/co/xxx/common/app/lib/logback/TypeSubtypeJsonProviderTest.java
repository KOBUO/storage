package jp.co.xxx.common.app.lib.logback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.StringWriter;

import org.junit.jupiter.api.Test;

import jp.co.xxx.common.app.lib.LoggerNames;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * type はレベルから(ERROR→monitor / 他→app)、subtype は logger_name から
 * (固定ロガー→対応値 / それ以外→SYSTEM)導出されることを検証する。
 */
class TypeSubtypeJsonProviderTest {

    private final TypeSubtypeJsonProvider provider = new TypeSubtypeJsonProvider();

    private String render(Level level, String loggerName) throws Exception {
        StringWriter writer = new StringWriter();
        try (JsonGenerator g = new JsonFactory().createGenerator(writer)) {
            g.writeStartObject();
            ILoggingEvent event = mock(ILoggingEvent.class);
            when(event.getLevel()).thenReturn(level);
            when(event.getLoggerName()).thenReturn(loggerName);
            provider.writeTo(g, event);
            g.writeEndObject();
        }
        return writer.toString();
    }

    @Test
    void errorLevelBecomesMonitor() throws Exception {
        assertThat(render(Level.ERROR, LoggerNames.ERROR_LOG)).contains("\"type\":\"monitor\"");
    }

    @Test
    void nonErrorLevelBecomesApp() throws Exception {
        assertThat(render(Level.INFO, LoggerNames.API_LOG)).contains("\"type\":\"app\"");
    }

    @Test
    void knownLoggerResolvesSubtype() throws Exception {
        assertThat(render(Level.INFO, LoggerNames.SQS_JNL)).contains("\"subtype\":\"AWSCALL\"");
        assertThat(render(Level.INFO, LoggerNames.SQL_JNL)).contains("\"subtype\":\"DBCALL\"");
    }

    @Test
    void unknownLoggerIsSystem() throws Exception {
        assertThat(render(Level.INFO, "com.example.foo.Bar")).contains("\"subtype\":\"SYSTEM\"");
    }
}
