package jp.co.xxx.common.app.lib.mask;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import jp.co.xxx.common.app.lib.LoggingProperties;

/**
 * ヘッダー/ボディ/URL のマスキングと最大長切り詰めを検証する。
 */
class LogMaskingServiceTest {

    private LogMaskingService masking;

    @BeforeEach
    void setUp() {
        LoggingProperties props = new LoggingProperties();
        props.setMaskHeaderNames(List.of("authorization", "cookie"));
        props.setMaskBodyKeys(List.of("password", "token"));
        props.setBodyMaxLength(2048);
        props.setMessageMaxLength(10);
        masking = new LogMaskingService(props);
    }

    @Test
    void masksConfiguredHeadersCaseInsensitively() {
        Map<String, String> out = masking.maskHeaders(Map.of("Authorization", "Bearer x", "Accept", "*/*"));
        assertThat(out.get("Authorization")).isEqualTo("***");
        assertThat(out.get("Accept")).isEqualTo("*/*");
    }

    @Test
    void masksJsonBodyKeys() {
        String out = masking.maskBody("{\"id\":\"1\",\"password\":\"p@ss\",\"token\":\"abc\"}");
        assertThat(out).contains("\"password\":\"***\"").contains("\"token\":\"***\"").contains("\"id\":\"1\"");
    }

    @Test
    void masksNonStringJsonValues() {
        // 数値/真偽 の値もマスクされる（従来は文字列値しか伏せられず漏れていた）。
        String out = masking.maskBody("{\"id\":1,\"password\":12345,\"token\":true,\"note\":\"x\"}");
        assertThat(out)
                .contains("\"password\":***")
                .contains("\"token\":***")
                .contains("\"id\":1")        // マスク対象外キーはそのまま
                .contains("\"note\":\"x\"");
    }

    @Test
    void appliesOptInValuePatterns() {
        // mask-body-patterns（既定空の opt-in）。メールアドレスを正規表現で伏せる。
        LoggingProperties props = new LoggingProperties();
        props.setMaskBodyKeys(List.of("password"));
        props.setMaskBodyPatterns(List.of("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}"));
        props.setBodyMaxLength(2048);
        LogMaskingService withPatterns = new LogMaskingService(props);

        String out = withPatterns.maskBody("{\"memo\":\"連絡先 taro@example.com まで\"}");
        assertThat(out).contains("連絡先 *** まで").doesNotContain("taro@example.com");
    }

    @Test
    void valuePatternsDisabledByDefault() {
        // 既定（パターン未設定）では本文の値はそのまま＝誤爆しない。
        assertThat(masking.maskBody("{\"memo\":\"taro@example.com\"}")).contains("taro@example.com");
    }

    @Test
    void masksUrlQueryValues() {
        assertThat(masking.maskUrl("GET /login?token=secret&id=1")).isEqualTo("GET /login?token=***&id=1");
    }

    @Test
    void truncatesMessageOverMaxLength() {
        assertThat(masking.maskMessage("0123456789ABCDEF")).startsWith("0123456789").endsWith("(truncated)");
    }

    @Test
    void nullSafe() {
        assertThat(masking.maskHeaders(null)).isNull();
        assertThat(masking.maskBody(null)).isNull();
        assertThat(masking.maskUrl(null)).isNull();
    }
}
