package jp.co.xxx.common.app.lib.scope;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import jp.co.xxx.common.app.lib.MdcKeys;
import jp.co.xxx.common.app.lib.scope.batch.BatchLogScope;

/**
 * 実行単位スコープが MDC を設定し、close() で必ずクリアすることを検証する。
 */
class ExecutionScopeMdcTest {

    @AfterEach
    void clear() {
        MDC.clear();
    }

    @Test
    void setsAndClearsMdc() {
        try (ExecutionScopeMdc scope = ExecutionScopeMdc.open("f", "a", "u", "t", "ip")) {
            assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("f");
            assertThat(MDC.get(MdcKeys.ACTION)).isEqualTo("a");
            assertThat(MDC.get(MdcKeys.USER)).isEqualTo("u");
            assertThat(MDC.get(MdcKeys.TRACE_ID)).isEqualTo("t");
            assertThat(MDC.get(MdcKeys.SOURCE_IP)).isEqualTo("ip");
        }
        for (String key : MdcKeys.ALL) {
            assertThat(MDC.get(key)).as(key).isNull();
        }
    }

    @Test
    void blankValuesAreNotSet() {
        try (ExecutionScopeMdc scope = ExecutionScopeMdc.open("f", "a", null, "t", "")) {
            assertThat(MDC.get(MdcKeys.USER)).isNull();
            assertThat(MDC.get(MdcKeys.SOURCE_IP)).isNull();
            assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("f");
        }
    }

    @Test
    void nestedScopeRestoresOuterValuesOnClose() {
        // 外側スコープの上に内側スコープを重ね、内側 close 後に外側の値へ確実に戻ること（ネスト安全）。
        try (ExecutionScopeMdc outer = ExecutionScopeMdc.open("outerFn", "OUTER", "u1", "t1", "ip1")) {
            try (ExecutionScopeMdc inner = ExecutionScopeMdc.open("innerFn", "INNER", null, "t2", null)) {
                assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("innerFn");
                assertThat(MDC.get(MdcKeys.TRACE_ID)).isEqualTo("t2");
                // 内側で未設定のキーは外側の値を継承せず除去される
                assertThat(MDC.get(MdcKeys.USER)).isNull();
                assertThat(MDC.get(MdcKeys.SOURCE_IP)).isNull();
            }
            // 内側 close → 外側の値が復元される
            assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("outerFn");
            assertThat(MDC.get(MdcKeys.ACTION)).isEqualTo("OUTER");
            assertThat(MDC.get(MdcKeys.USER)).isEqualTo("u1");
            assertThat(MDC.get(MdcKeys.TRACE_ID)).isEqualTo("t1");
            assertThat(MDC.get(MdcKeys.SOURCE_IP)).isEqualTo("ip1");
        }
        // 外側 close → 全クリア
        for (String key : MdcKeys.ALL) {
            assertThat(MDC.get(key)).as(key).isNull();
        }
    }

    @Test
    void batchScopeSetsFunctionAndActionButNotTraceId() {
        // 統一方針：バッチは user/trace_id を採番せず null（実源泉が無いため）
        try (ExecutionScopeMdc scope = BatchLogScope.open("売上集計バッチ")) {
            assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("売上集計バッチ");
            assertThat(MDC.get(MdcKeys.ACTION)).isEqualTo("BATCH_EXEC");
            assertThat(MDC.get(MdcKeys.TRACE_ID)).isNull();
            assertThat(MDC.get(MdcKeys.USER)).isNull();
        }
    }

}
