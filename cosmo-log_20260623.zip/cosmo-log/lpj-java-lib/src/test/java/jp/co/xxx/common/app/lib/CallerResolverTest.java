package jp.co.xxx.common.app.lib;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import com.example.democaller.DemoCaller;

/**
 * CallerResolver が「ライブラリ(jp.co.xxx.common.app.lib)・フレームワークを除外した
 * 最初のフレーム＝発生元の業務コード」を返すことを検証する。
 */
class CallerResolverTest {

    @Test
    void resolvesNearestNonLibNonFrameworkFrame() {
        // lib 外パッケージ(com.example.democaller)のヘルパー経由で呼ぶと、そのヘルパーが発生元になる。
        StackWalker.StackFrame frame = DemoCaller.resolveFrom();
        assertThat(frame).isNotNull();
        assertThat(frame.getClassName()).isEqualTo("com.example.democaller.DemoCaller");
        assertThat(frame.getMethodName()).isEqualTo("resolveFrom");
    }

    @Test
    void putCallerAddsClassAndMethodKeys() {
        // putCaller はキーを必ず出す（解決できれば値、できなければ null）。
        StructuredLog log = CallerResolver.putCaller(StructuredLog.create());
        assertThat(log).isNotNull();
    }
}
