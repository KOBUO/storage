package jp.co.xxx.common.app.lib.logback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * MDC項目 function / user / action / trace_id が「設計書の固定順」で出力され、
 * 値が無いキーは（統一方針どおり）null で出力されることを検証する。
 */
class MdcOrderedJsonProviderTest {

    private final MdcOrderedJsonProvider provider = new MdcOrderedJsonProvider();

    private String render(Map<String, String> mdc) throws Exception {
        StringWriter writer = new StringWriter();
        try (JsonGenerator g = new JsonFactory().createGenerator(writer)) {
            g.writeStartObject();
            ILoggingEvent event = mock(ILoggingEvent.class);
            when(event.getMDCPropertyMap()).thenReturn(mdc);
            provider.writeTo(g, event);
            g.writeEndObject();
        }
        return writer.toString();
    }

    @Test
    void writesFixedOrderWithValues() throws Exception {
        Map<String, String> mdc = new LinkedHashMap<>();
        // あえて設計と逆順に投入しても、出力は固定順になること
        mdc.put("trace_id", "t1");
        mdc.put("action", "POST");
        mdc.put("user", "u1");
        mdc.put("function", "/api/x");
        assertThat(render(mdc))
                .contains("\"function\":\"/api/x\",\"user\":\"u1\",\"action\":\"POST\",\"trace_id\":\"t1\"");
    }

    @Test
    void writesNullStringForAbsentKeys() throws Exception {
        // 統一方針：値なしは JSON null ではなく文字列 "null"
        String json = render(Map.of());
        assertThat(json)
                .contains("\"function\":\"null\"")
                .contains("\"user\":\"null\"")
                .contains("\"action\":\"null\"")
                .contains("\"trace_id\":\"null\"");
    }
}
