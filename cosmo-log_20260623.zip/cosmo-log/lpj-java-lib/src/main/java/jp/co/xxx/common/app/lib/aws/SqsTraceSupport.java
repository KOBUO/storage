package jp.co.xxx.common.app.lib.aws;

import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;

/**
 * SQSメッセージのトレース伝播ヘルパー。
 * 送信側は MDC の trace_id をメッセージ属性 {@code traceparent} に載せる。
 * 受信側は {@code traceparent} があればそれを trace_id として使い、無ければ統一方針により
 * 生成・フォールバックせず {@code null}（@SqsListener 経路の SqsJournalMessageInterceptor と一致）。
 */
public final class SqsTraceSupport {

    public static final String TRACEPARENT = "traceparent";

    private SqsTraceSupport() {
    }

    /** 受信メッセージの trace_id：属性 traceparent から取得、無ければ null（MessageId 等にフォールバックしない）。 */
    public static String traceId(Message message) {
        MessageAttributeValue attr = message.messageAttributes().get(TRACEPARENT);
        if (attr != null && attr.stringValue() != null && !attr.stringValue().isBlank()) {
            return attr.stringValue();
        }
        return null;
    }
}
