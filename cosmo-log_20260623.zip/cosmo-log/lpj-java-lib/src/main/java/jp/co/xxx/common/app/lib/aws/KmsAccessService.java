package jp.co.xxx.common.app.lib.aws;

import java.time.Instant;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.CallerResolver;
import jp.co.xxx.common.app.lib.LogFields;
import jp.co.xxx.common.app.lib.LoggerNames;
import jp.co.xxx.common.app.lib.StructuredLog;
import jp.co.xxx.common.app.lib.aws.AwsResponseMetadataExtractor.AwsMeta;

import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.kms.KmsClient;
import software.amazon.awssdk.services.kms.model.DecryptRequest;
import software.amazon.awssdk.services.kms.model.DecryptResponse;
import software.amazon.awssdk.services.kms.model.EncryptRequest;
import software.amazon.awssdk.services.kms.model.EncryptResponse;

/**
 * KMSアクセス部品。暗号化/復号時に KMSアクセスジャーナルログ(AWSCALL) を出力する。
 * KmsClient は遅延生成。type/subtype は TypeSubtypeJsonProvider が付与（subtype=AWSCALL）。
 */
@Component
public class KmsAccessService {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.KMS_JNL);

    private volatile KmsClient client;

    private KmsClient client() {
        if (client == null) {
            synchronized (this) {
                if (client == null) {
                    client = KmsClient.create();
                }
            }
        }
        return client;
    }

    public SdkBytes encrypt(String keyId, byte[] plaintext) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        try {
            EncryptResponse response = client().encrypt(EncryptRequest.builder()
                    .keyId(keyId).plaintext(SdkBytes.fromByteArray(plaintext)).build());
            journal(requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "encrypt");
            return response.ciphertextBlob();
        } catch (RuntimeException e) {
            journalError(requestTimestamp, startNanos, "encrypt", e);
            throw e;
        }
    }

    public SdkBytes decrypt(byte[] ciphertext) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        try {
            DecryptResponse response = client().decrypt(DecryptRequest.builder()
                    .ciphertextBlob(SdkBytes.fromByteArray(ciphertext)).build());
            journal(requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "decrypt");
            return response.plaintext();
        } catch (RuntimeException e) {
            journalError(requestTimestamp, startNanos, "decrypt", e);
            throw e;
        }
    }

    private void journal(String requestTimestamp, long startNanos, AwsMeta meta, String op) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        log.info(CallerResolver.putCaller(StructuredLog.create())
                .put(LogFields.LATENCY, latencyMs)
                .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .marker(), "kms journal (" + op + ")");
    }

    /** AWS呼び出し失敗時のジャーナル（type=monitor / stack_trace 付き）。証跡を残すため必ず出す。 */
    private void journalError(String requestTimestamp, long startNanos, String op, Throwable t) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        log.error(CallerResolver.putCaller(StructuredLog.create())
                .put(LogFields.LATENCY, latencyMs)
                .putNullable(LogFields.AWS_REQUEST_ID, null)
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .marker(), "kms journal (" + op + " error)", t);
    }
}
