package jp.co.xxx.common.app.lib.scope;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.MDC;

import jp.co.xxx.common.app.lib.MdcKeys;

/**
 * 実行単位スコープの MDC を設定し、close() で必ず元に戻す共通部品。
 * オンライン(API) / バッチ / 常駐バッチ のいずれの起点からも利用する。
 *
 * <pre>{@code
 * try (var scope = ExecutionScopeMdc.open(function, action, user, traceId, sourceIp)) {
 *     // ... この間のログに function/user/action/trace_id/source_ip が付与される ...
 * } // ← ここで MDC を open 前の状態へ復元
 * }</pre>
 *
 * <p>open 時に対象キーの現在値を退避し、close で復元する（外側スコープを壊さない＝ネスト安全）。
 * 設定しない（null/空）キーはスコープ内では除去され、close で元の値に戻る。
 */
public final class ExecutionScopeMdc implements AutoCloseable {

    /** open 直前の MDC 値（対象キーのみ）。close で復元する。 */
    private final Map<String, String> previous;

    private ExecutionScopeMdc(Map<String, String> previous) {
        this.previous = previous;
    }

    /** function/user/action/trace_id/source_ip を MDC へ設定する。null/空は除去（＝そのキーは出力されない）。 */
    public static ExecutionScopeMdc open(String function, String action, String user,
                                         String traceId, String sourceIp) {
        Map<String, String> previous = new HashMap<>();
        for (String key : MdcKeys.ALL) {
            previous.put(key, MDC.get(key)); // 現在値を退避（null 可）
        }
        set(MdcKeys.FUNCTION, function);
        set(MdcKeys.ACTION, action);
        set(MdcKeys.USER, user);
        set(MdcKeys.TRACE_ID, traceId);
        set(MdcKeys.SOURCE_IP, sourceIp);
        return new ExecutionScopeMdc(previous);
    }

    /** 値があれば設定、null/空なら除去（外側の値を継承しない）。 */
    private static void set(String key, String value) {
        if (value != null && !value.isBlank()) {
            MDC.put(key, value);
        } else {
            MDC.remove(key);
        }
    }

    @Override
    public void close() {
        for (String key : MdcKeys.ALL) {
            String prev = previous.get(key);
            if (prev != null) {
                MDC.put(key, prev);
            } else {
                MDC.remove(key);
            }
        }
    }
}
