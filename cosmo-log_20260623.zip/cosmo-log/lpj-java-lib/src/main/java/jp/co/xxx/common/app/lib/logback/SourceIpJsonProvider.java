package jp.co.xxx.common.app.lib.logback;

import java.io.IOException;

import jp.co.xxx.common.app.lib.MdcKeys;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * アクセスログ(M) 専用に {@code source_ip} を出力する provider。
 *
 * <p>標準の {@code <mdc>} provider は MDC に値が無いキーを<b>出力しない</b>が、
 * 本ライブラリの統一方針「キーは出力し、値が無ければ文字列 {@code "null"}」に合わせ、
 * 値が無くても {@code "source_ip":"null"} を出力する。
 * （{@code source_ip} はアクセスログ L・M のみ。appender-access.xml でのみ使用する）
 */
public class SourceIpJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        String value = event.getMDCPropertyMap().get(MdcKeys.SOURCE_IP);
        generator.writeStringField(MdcKeys.SOURCE_IP, value != null ? value : "null");
    }
}
