package jp.co.xxx.common.app.lib;

/**
 * Marker で付与する（＝ログ出力時にその場で設定する）項目の物理名。
 * MDC・logback組み込み・独自provider 由来の項目はここには含めない。
 */
public final class LogFields {

    public static final String TYPE = "type";
    public static final String SUBTYPE = "subtype";

    public static final String URL = "url";
    public static final String STATUS = "status";
    public static final String HEADERS = "headers";
    public static final String BODY = "body";

    public static final String CLASS_NAME = "class_name";
    public static final String METHOD_NAME = "method_name";
    public static final String ARGS = "args";
    public static final String RESULT = "result";

    public static final String BUCKET_NAME = "bucket_name";
    public static final String PATH = "path";
    public static final String LATENCY = "latency";

    public static final String AWS_REQUEST_ID = "aws_request_id";
    public static final String AWS_REQUEST_TIMESTAMP = "aws_request_timestamp";
    public static final String AWS_RESPONSE_TIME = "aws_response_time";
    public static final String AWS_S3_EXTENDED_REQUEST_ID = "aws_s3_extended_request_id";
    public static final String AWS_SQS_MESSAGE_ID = "aws_sqs_message_id";

    private LogFields() {
    }
}
