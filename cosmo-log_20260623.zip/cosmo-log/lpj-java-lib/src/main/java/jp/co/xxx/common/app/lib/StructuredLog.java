package jp.co.xxx.common.app.lib;

import java.util.LinkedHashMap;
import java.util.Map;

import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;

/**
 * ログ出力1回ぶんの「その場で設定する項目」を組み立てるビルダー。
 *
 * <pre>{@code
 * logger.info(StructuredLog.create()
 *         .put(LogFields.URL, url)
 *         .put(LogFields.STATUS, status)
 *         .marker(), "message");
 * }</pre>
 *
 * null値は出力しない（その項目を持たないログ種類では自然に欠落する）。
 * type / subtype は Marker では持たせず、{@code TypeSubtypeJsonProvider} が
 * レベルと logger_name から導出して付与する。
 */
public final class StructuredLog {

    private final Map<String, Object> fields = new LinkedHashMap<>();

    private StructuredLog() {
    }

    public static StructuredLog create() {
        return new StructuredLog();
    }

    public StructuredLog put(String key, Object value) {
        if (value != null) {
            fields.put(key, value);
        }
        return this;
    }

    /**
     * null でもキーを出力する（{@code "key":null}）。
     * 前後ペア（要求/応答・開始/終了）で項目セットを揃え、片側にしか値が無い項目を
     * もう一方では {@code null} として出力するために使う。
     */
    public StructuredLog putNullable(String key, Object value) {
        fields.put(key, value);
        return this;
    }

    public LogstashMarker marker() {
        return Markers.appendEntries(fields);
    }
}
