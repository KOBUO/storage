package jp.co.xxx.common.app.lib.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.LogFields;
import jp.co.xxx.common.app.lib.LoggerNames;
import jp.co.xxx.common.app.lib.StructuredLog;
import jp.co.xxx.common.app.lib.mask.LogMaskingService;

/**
 * サービスジャーナルログ出力部品。
 * {@code @Service} のメソッド実行前後で「開始(P)/終了(Q)」のジャーナルログを出力する。
 * function / user / action / trace_id は MDC から自動的に付与される。
 */
@Aspect
@Component
public class ServiceJournalAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.SERVICE_JNL);

    private final LogMaskingService masking;

    public ServiceJournalAspect(LogMaskingService masking) {
        this.masking = masking;
    }

    @Around("@within(org.springframework.stereotype.Service)")
    public Object aroundService(ProceedingJoinPoint pjp) throws Throwable {
        String className = pjp.getSignature().getDeclaringTypeName();
        String methodName = pjp.getSignature().getName();

        // サービスジャーナルログ（開始）
        // 前後ペア統一：終了(Q)のみの result / latency は開始側では null 出力
        log.info(StructuredLog.create()
                .put(LogFields.CLASS_NAME, className)
                .put(LogFields.METHOD_NAME, methodName)
                .put(LogFields.ARGS, masking.maskArgs(pjp.getArgs()))
                .putNullable(LogFields.RESULT, null)
                .putNullable(LogFields.LATENCY, null)
                .marker(), "service journal (start)");

        long startNanos = System.nanoTime();
        try {
            Object result = pjp.proceed();
            long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;

            // サービスジャーナルログ（終了）。前後ペア統一で args も出力
            log.info(StructuredLog.create()
                    .put(LogFields.CLASS_NAME, className)
                    .put(LogFields.METHOD_NAME, methodName)
                    .put(LogFields.ARGS, masking.maskArgs(pjp.getArgs()))
                    .put(LogFields.RESULT, masking.maskResult(result))
                    .put(LogFields.LATENCY, latencyMs)
                    .marker(), "service journal (end)");
            return result;
        } catch (Throwable t) {
            long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
            // 例外時は result ではなく stack_trace を出力する（result は null、項目セットは揃える）
            log.error(StructuredLog.create()
                    .put(LogFields.CLASS_NAME, className)
                    .put(LogFields.METHOD_NAME, methodName)
                    .put(LogFields.ARGS, masking.maskArgs(pjp.getArgs()))
                    .putNullable(LogFields.RESULT, null)
                    .put(LogFields.LATENCY, latencyMs)
                    .marker(), "service journal (error)", t);
            throw t;
        }
    }
}
