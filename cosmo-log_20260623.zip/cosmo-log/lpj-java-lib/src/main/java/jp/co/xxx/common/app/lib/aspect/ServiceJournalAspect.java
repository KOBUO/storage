package jp.co.xxx.common.app.lib.aspect;

import java.util.LinkedHashMap;
import java.util.Map;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.CodeSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.LogFields;
import jp.co.xxx.common.app.lib.LoggerNames;
import jp.co.xxx.common.app.lib.StructuredLog;
import jp.co.xxx.common.app.lib.mask.LogMaskingService;

/**
 * サービスジャーナルログ出力部品。
 * {@code @Service} のメソッド実行前後で「開始(P)/終了(Q)」のジャーナルログを出力する。
 * function / user / action / trace_id は MDC から自動的に付与される。
 */
@Aspect
@Component
public class ServiceJournalAspect {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.SERVICE_JNL);

    private final LogMaskingService masking;

    public ServiceJournalAspect(LogMaskingService masking) {
        this.masking = masking;
    }

    @Around("@within(org.springframework.stereotype.Service)")
    public Object aroundService(ProceedingJoinPoint pjp) throws Throwable {
        String className = pjp.getSignature().getDeclaringTypeName();
        String methodName = pjp.getSignature().getName();
        Object[] args = namedArgs(pjp); // 引数は不変なので1回だけ整形して使い回す

        // サービスジャーナルログ（開始）
        // 前後ペア統一：終了(Q)のみの result / latency は開始側では null 出力
        log.info(StructuredLog.create()
                .put(LogFields.CLASS_NAME, className)
                .put(LogFields.METHOD_NAME, methodName)
                .put(LogFields.ARGS, args)
                .putNullable(LogFields.RESULT, null)
                .putNullable(LogFields.LATENCY, null)
                .marker(), "service journal (start)");

        long startNanos = System.nanoTime();
        try {
            Object result = pjp.proceed();
            long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;

            // サービスジャーナルログ（終了）。前後ペア統一で args も出力
            log.info(StructuredLog.create()
                    .put(LogFields.CLASS_NAME, className)
                    .put(LogFields.METHOD_NAME, methodName)
                    .put(LogFields.ARGS, args)
                    .put(LogFields.RESULT, masking.maskResult(result))
                    .put(LogFields.LATENCY, latencyMs)
                    .marker(), "service journal (end)");
            return result;
        } catch (Throwable t) {
            long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
            // 例外時は result ではなく stack_trace を出力する（result は null、項目セットは揃える）
            log.error(StructuredLog.create()
                    .put(LogFields.CLASS_NAME, className)
                    .put(LogFields.METHOD_NAME, methodName)
                    .put(LogFields.ARGS, args)
                    .putNullable(LogFields.RESULT, null)
                    .put(LogFields.LATENCY, latencyMs)
                    .marker(), "service journal (error)", t);
            throw t;
        }
    }

    /**
     * 引数を {@code [{"パラメータ名": 値}, ...]} の形に整形する。
     * パラメータ名は AspectJ の {@link CodeSignature}（要 {@code -parameters} コンパイル）から取得。
     * 値は：文字列＝マスク／数値・真偽＝文字列化／オブジェクト＝そのまま（jackson が構造化）／なし＝{@code "null"}。
     */
    private Object[] namedArgs(ProceedingJoinPoint pjp) {
        Object[] values = pjp.getArgs();
        String[] names = (pjp.getSignature() instanceof CodeSignature cs) ? cs.getParameterNames() : null;
        Object[] out = new Object[values.length];
        for (int i = 0; i < values.length; i++) {
            String name = (names != null && i < names.length && names[i] != null) ? names[i] : "arg" + i;
            Map<String, Object> entry = new LinkedHashMap<>();
            entry.put(name, maskArgValue(values[i]));
            out[i] = entry;
        }
        return out;
    }

    private Object maskArgValue(Object value) {
        if (value == null) {
            return StructuredLog.NULL;                    // "null"
        }
        if (value instanceof CharSequence) {
            return masking.maskBody(value.toString());    // 文字列はマスク・最大長
        }
        if (value instanceof Number || value instanceof Boolean) {
            return value.toString();                      // 数値・真偽も文字列（統一方針）
        }
        return value;                                     // オブジェクトはネスト保持（jackson が構造化）
    }
}
