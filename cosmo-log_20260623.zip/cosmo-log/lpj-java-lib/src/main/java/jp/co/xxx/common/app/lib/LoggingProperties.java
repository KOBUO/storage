package jp.co.xxx.common.app.lib;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * ログ設定保持部品。application.yml の logging.custom.* をバインドする。
 */
@Component
@ConfigurationProperties(prefix = "logging.custom")
public class LoggingProperties {

    /** body の最大出力長。 */
    private int bodyMaxLength = 2048;
    /** message の最大出力長。 */
    private int messageMaxLength = 4096;
    /** マスク対象ヘッダー名（小文字比較）。 */
    private List<String> maskHeaderNames = List.of("authorization", "cookie");
    /** マスク対象ボディ/引数キー。 */
    private List<String> maskBodyKeys = List.of("password", "secret", "token");
    /**
     * 値パターンによるマスク（正規表現）。キーに紐づかない PII（メール/カード番号/電話/マイナンバー等）を
     * 本文中から伏せたい場合に設定する。<b>既定は空＝従来どおりキー名ベースのみ</b>（誤爆を避けるため opt-in）。
     * 各パターンのマッチ部分全体が {@code ***} に置換される。
     */
    private List<String> maskBodyPatterns = List.of();

    public int getBodyMaxLength() {
        return bodyMaxLength;
    }

    public void setBodyMaxLength(int bodyMaxLength) {
        this.bodyMaxLength = bodyMaxLength;
    }

    public int getMessageMaxLength() {
        return messageMaxLength;
    }

    public void setMessageMaxLength(int messageMaxLength) {
        this.messageMaxLength = messageMaxLength;
    }

    public List<String> getMaskHeaderNames() {
        return maskHeaderNames;
    }

    public void setMaskHeaderNames(List<String> maskHeaderNames) {
        this.maskHeaderNames = maskHeaderNames;
    }

    public List<String> getMaskBodyKeys() {
        return maskBodyKeys;
    }

    public void setMaskBodyKeys(List<String> maskBodyKeys) {
        this.maskBodyKeys = maskBodyKeys;
    }

    public List<String> getMaskBodyPatterns() {
        return maskBodyPatterns;
    }

    public void setMaskBodyPatterns(List<String> maskBodyPatterns) {
        this.maskBodyPatterns = maskBodyPatterns;
    }
}
