package jp.co.xxx.common.app.lib.scope.online;

import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest;

/**
 * 【オンライン(API)】機能・アクション解決部品。
 * HTTPリクエストから function / action を決定する。
 */
@Component
public class FunctionActionResolver {

    public record FunctionAction(String function, String action) {
    }

    public FunctionAction resolve(HttpServletRequest request) {
        // function は action と同値（例: "GET /api/orders/1"）。
        // 実運用で機能IDを別管理する場合は、ここを機能IDの解決に差し替える。
        String action = request.getMethod() + " " + request.getRequestURI();
        return new FunctionAction(action, action);
    }
}
