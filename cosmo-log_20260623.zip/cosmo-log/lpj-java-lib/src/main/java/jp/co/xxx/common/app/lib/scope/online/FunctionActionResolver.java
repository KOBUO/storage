package jp.co.xxx.common.app.lib.scope.online;

import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest;

/**
 * 【オンライン(API)】機能・アクション解決部品。
 * HTTPリクエストから function / action を決定する。
 */
@Component
public class FunctionActionResolver {

    public record FunctionAction(String function, String action) {
    }

    public FunctionAction resolve(HttpServletRequest request) {
        return new FunctionAction(deriveFunction(request), request.getMethod() + " " + request.getRequestURI());
    }

    /** 例: /api/orders/1 -> "orders"。実運用ではルーティング定義とのマッピング表で解決する。 */
    private String deriveFunction(HttpServletRequest request) {
        String[] parts = request.getRequestURI().split("/");
        if (parts.length >= 3) {
            return parts[2];
        }
        return request.getRequestURI();
    }
}
