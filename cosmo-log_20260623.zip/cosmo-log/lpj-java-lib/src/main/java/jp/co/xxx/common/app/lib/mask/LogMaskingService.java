package jp.co.xxx.common.app.lib.mask;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.LoggingProperties;

/**
 * マスキング部品。headers / body / args / result / message から
 * 個人情報・機密情報をマスクし、最大長で切り詰める。
 *
 * <p>マスクは2系統。(1) <b>キー名ベース</b>（{@code mask-body-keys}）＝該当キーの値を伏せる。
 * 文字列値 {@code "key":"v"} だけでなく、数値/真偽/null など <b>非文字列のJSON値</b>
 * （{@code "key":123} 等）や {@code key=value} 形式も対象。(2) <b>値パターンベース</b>
 * （{@code mask-body-patterns}、既定空の opt-in）＝キーに紐づかない PII を正規表現で伏せる。
 * いずれも request / response 双方に同一設定で適用される。
 */
@Component
public class LogMaskingService {

    private static final String MASK = "***";

    private final LoggingProperties props;

    /** 値パターンマスク（{@code logging.custom.mask-body-patterns}）の事前コンパイル結果。既定は空。 */
    private final List<Pattern> bodyPatterns;

    public LogMaskingService(LoggingProperties props) {
        this.props = props;
        this.bodyPatterns = new ArrayList<>();
        for (String regex : props.getMaskBodyPatterns()) {
            this.bodyPatterns.add(Pattern.compile(regex));
        }
    }

    /** マスク対象ヘッダーを値ごと伏せる。 */
    public Map<String, String> maskHeaders(Map<String, String> headers) {
        if (headers == null) {
            return null;
        }
        Set<String> mask = lowerSet(props.getMaskHeaderNames());
        Map<String, String> out = new LinkedHashMap<>();
        headers.forEach((k, v) -> out.put(k, mask.contains(k.toLowerCase(Locale.ROOT)) ? MASK : v));
        return out;
    }

    /** JSONボディ内のマスク対象キーの値を伏せ、最大長で切り詰める。 */
    public String maskBody(String body) {
        return truncate(maskKeys(body), props.getBodyMaxLength());
    }

    /** URLのクエリ文字列内のマスク対象キー（?key=value / &key=value）を伏せる。 */
    public String maskUrl(String url) {
        if (url == null) {
            return null;
        }
        String masked = url;
        for (String key : props.getMaskBodyKeys()) {
            masked = masked.replaceAll("([?&]" + Pattern.quote(key) + "=)[^&\\s]*", "$1" + MASK);
        }
        return masked;
    }

    public Object maskResult(Object result) {
        if (result == null) {
            return null;
        }
        return truncate(maskKeys(String.valueOf(result)), props.getBodyMaxLength());
    }

    public String maskMessage(String message) {
        return truncate(message, props.getMessageMaxLength());
    }

    private String maskKeys(String text) {
        if (text == null) {
            return null;
        }
        String masked = text;
        // (1) キー名ベース
        for (String key : props.getMaskBodyKeys()) {
            String q = Pattern.quote(key);
            // "key":"value"（文字列値。エスケープ \" を含む値も末尾まで）
            masked = masked.replaceAll("(\"" + q + "\"\\s*:\\s*\")(?:\\\\.|[^\"\\\\])*(\")", "$1" + MASK + "$2");
            // "key":123 / true / false / null（非文字列のJSON値。先頭が " でないもの）
            masked = masked.replaceAll("(\"" + q + "\"\\s*:\\s*)(?!\")[^,}\\]\\s][^,}\\]]*", "$1" + MASK);
            // key=value（クエリ/フォーム/フリーテキスト形式）
            masked = masked.replaceAll("(" + q + "\\s*=\\s*)[^,\\s)}]+", "$1" + MASK);
        }
        // (2) 値パターンベース（opt-in。既定空）
        for (Pattern p : bodyPatterns) {
            masked = p.matcher(masked).replaceAll(Matcher.quoteReplacement(MASK));
        }
        return masked;
    }

    public String truncate(String s, int max) {
        if (s == null || s.length() <= max) {
            return s;
        }
        return s.substring(0, max) + "...(truncated)";
    }

    private Set<String> lowerSet(java.util.List<String> values) {
        return values.stream().map(v -> v.toLowerCase(Locale.ROOT)).collect(Collectors.toSet());
    }
}
