package jp.co.xxx.common.app.lib.aws;

import java.time.Instant;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.CallerResolver;
import jp.co.xxx.common.app.lib.LogFields;
import jp.co.xxx.common.app.lib.LoggerNames;
import jp.co.xxx.common.app.lib.MdcKeys;
import jp.co.xxx.common.app.lib.StructuredLog;
import jp.co.xxx.common.app.lib.aws.AwsResponseMetadataExtractor.AwsMeta;
import jp.co.xxx.common.app.lib.scope.ExecutionScopeMdc;

import software.amazon.awssdk.services.sqs.SqsClient;
import software.amazon.awssdk.services.sqs.model.Message;
import software.amazon.awssdk.services.sqs.model.MessageAttributeValue;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageRequest;
import software.amazon.awssdk.services.sqs.model.ReceiveMessageResponse;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;

/**
 * SQSアクセス部品。送信/受信時にメッセージジャーナルログを出力する。
 * aws_sqs_message_id は SQS専用。SqsClient は遅延生成。
 */
@Component
public class SqsAccessService {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.SQS_JNL);

    private volatile SqsClient client;

    private SqsClient client() {
        if (client == null) {
            synchronized (this) {
                if (client == null) {
                    client = SqsClient.create();
                }
            }
        }
        return client;
    }

    public String sendMessage(String queueUrl, String body) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();

        SendMessageRequest.Builder builder = SendMessageRequest.builder().queueUrl(queueUrl).messageBody(body);
        // トレース伝播：MDCのtrace_idをメッセージ属性 traceparent に載せる
        String traceId = MDC.get(MdcKeys.TRACE_ID);
        if (traceId != null && !traceId.isBlank()) {
            builder.messageAttributes(Map.of(SqsTraceSupport.TRACEPARENT,
                    MessageAttributeValue.builder().dataType("String").stringValue(traceId).build()));
        }

        try {
            SendMessageResponse response = client().sendMessage(builder.build());
            long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
            AwsMeta meta = AwsResponseMetadataExtractor.extract(response);

            log.info(CallerResolver.putCaller(StructuredLog.create())
                    .put(LogFields.LATENCY, latencyMs)
                    .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                    .put(LogFields.AWS_SQS_MESSAGE_ID, response.messageId())
                    .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                    .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                    .marker(), "sqs journal (send)");
            return response.messageId();
        } catch (RuntimeException e) {
            journalError(requestTimestamp, startNanos, "send", e);
            throw e;
        }
    }

    public List<Message> receiveMessages(String queueUrl) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        ReceiveMessageResponse response;
        try {
            response = client().receiveMessage(ReceiveMessageRequest.builder()
                    .queueUrl(queueUrl).maxNumberOfMessages(10)
                    .messageAttributeNames(SqsTraceSupport.TRACEPARENT) // traceparent 属性を取得
                    .build());
        } catch (RuntimeException e) {
            journalError(requestTimestamp, startNanos, "receive", e);
            throw e;
        }
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        AwsMeta meta = AwsResponseMetadataExtractor.extract(response);

        for (Message message : response.messages()) {
            // 受信ジャーナルは、そのメッセージの trace_id を MDC に立ててから出力する（trace_id欠落を防ぐ）
            try (ExecutionScopeMdc scope = ExecutionScopeMdc.open(
                    "messageReceive", "RECEIVE", null, SqsTraceSupport.traceId(message), null)) {
                log.info(CallerResolver.putCaller(StructuredLog.create())
                        .put(LogFields.LATENCY, latencyMs)
                        .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                        .put(LogFields.AWS_SQS_MESSAGE_ID, message.messageId())
                        .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                        .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                        .marker(), "sqs journal (receive)");
            }
        }
        return response.messages();
    }

    /** SQS呼び出し失敗時のジャーナル（type=monitor / stack_trace 付き）。 */
    private void journalError(String requestTimestamp, long startNanos, String op, Throwable t) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        log.error(CallerResolver.putCaller(StructuredLog.create())
                .put(LogFields.LATENCY, latencyMs)
                .putNullable(LogFields.AWS_REQUEST_ID, null)
                .putNullable(LogFields.AWS_SQS_MESSAGE_ID, null)
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .marker(), "sqs journal (" + op + " error)", t);
    }
}
