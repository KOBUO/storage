package jp.co.xxx.common.app.lib.scope.batch;

import jp.co.xxx.common.app.lib.scope.ExecutionScopeMdc;

/**
 * 【バッチ】の実行単位スコープ起点。ジョブ開始で MDC を設定し、終了でクリアする。
 *
 * <pre>{@code
 * try (var scope = BatchLogScope.open("売上集計バッチ", jobExecutionId)) {
 *     // ... ジョブ本体 ...
 * }
 * }</pre>
 *
 * 常駐バッチ（{@code scope.resident}）と仕組みは共通。差分は trace_id の源泉と action のみ。
 */
public final class BatchLogScope {

    private BatchLogScope() {
    }

    /**
     * @param jobName 機能ID(function) = JOB名
     */
    public static ExecutionScopeMdc open(String jobName) {
        // 統一方針：user / trace_id は実源泉（バッチ基盤の実行ID・実行ユーザー等）が無ければ
        // 採番・固定値にせず null（未設定なら null で気付けるように）。source_ip はバッチでは無し。
        // TODO: 実源泉（実行時引数・ジョブ実行ID 等）が決まったら設定する。
        return ExecutionScopeMdc.open(jobName, "BATCH_EXEC", null, null, null);
    }
}
