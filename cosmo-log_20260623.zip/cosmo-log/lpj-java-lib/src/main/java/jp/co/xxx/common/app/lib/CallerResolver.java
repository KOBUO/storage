package jp.co.xxx.common.app.lib;

/**
 * 固定ロガー名のログで「発生元（呼び出し元の業務コード）」の class_name / method_name を
 * StackWalker で自動取得する共有部品。
 *
 * <p>本ライブラリ自身（{@code jp.co.xxx.common.app.lib} 配下）と既知のフレームワーク/JDK を除外し、
 * 最初に現れたフレームを「アプリの業務コード＝発生元」とみなす。利用側アプリのパッケージ名に依存しない
 * （ドロップイン利用のため、利用側の base package をライブラリが知らなくてよい）。
 *
 * <p>発生元が特定できない場合（例：アクセスログのように出力時に業務コードがスタック上に無い）は
 * 統一方針に従い class_name / method_name を {@code null} で出力する（キーは出す）。
 */
public final class CallerResolver {

    /** 本ライブラリ自身のパッケージ（発生元から除外）。 */
    private static final String LIB_PREFIX = "jp.co.xxx.common.app.lib";

    /** 発生元から除外するフレームワーク/ランタイムのパッケージ接頭辞。 */
    private static final String[] FRAMEWORK_PREFIXES = {
            "java.", "jakarta.", "javax.", "jdk.", "sun.", "com.sun.",
            "org.springframework.", "io.awspring.", "software.amazon.",
            "org.apache.", "ch.qos.logback.", "net.logstash.", "com.fasterxml.",
            "org.aspectj.", "org.slf4j.", "org.mybatis.", "reactor.", "io.micrometer."
    };

    private CallerResolver() {
    }

    /** 発生元フレーム（lib・フレームワーク以外の最初のフレーム）。無ければ null。 */
    public static StackWalker.StackFrame resolve() {
        return StackWalker.getInstance().walk(stream -> stream
                .filter(CallerResolver::isApplicationFrame)
                .findFirst().orElse(null));
    }

    private static boolean isApplicationFrame(StackWalker.StackFrame frame) {
        String cn = frame.getClassName();
        if (cn.startsWith(LIB_PREFIX)) {
            return false;
        }
        for (String prefix : FRAMEWORK_PREFIXES) {
            if (cn.startsWith(prefix)) {
                return false;
            }
        }
        return true;
    }

    /**
     * class_name / method_name を付与する。発生元が取れなければ {@code null}（キーは出力）。
     * 設計の項目順（body と args の間）に合わせ、各部品では他の marker 項目より前に呼ぶ。
     */
    public static StructuredLog putCaller(StructuredLog log) {
        StackWalker.StackFrame f = resolve();
        return log
                .putNullable(LogFields.CLASS_NAME, f != null ? f.getClassName() : null)
                .putNullable(LogFields.METHOD_NAME, f != null ? f.getMethodName() : null);
    }
}
