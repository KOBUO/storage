package jp.co.xxx.common.app.lib.logback;

import java.io.IOException;
import java.util.Map;

import jp.co.xxx.common.app.lib.MdcKeys;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * 実行単位スコープ(MDC)項目 function / user / action / trace_id を
 * <b>固定順</b>で出力する provider。
 *
 * <p>標準の {@code <mdc/>} provider は MDC マップ（順序非保証）のまま出力するため
 * JSON のキー順が非決定になる。これを避けるため、設計書の項目順で明示出力する。
 *
 * <p>スコープ外（root のフレームワークログ等）で値が無い場合も、
 * 統一方針「キーは出力し値は文字列 {@code "null"}」に従い {@code "null"} を出力する。
 *
 * <p>{@code source_ip} はアクセスログ(L・M)のみに出力するため本 provider では扱わず、
 * 必要な appender 側で個別に出力する。
 */
public class MdcOrderedJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        Map<String, String> mdc = event.getMDCPropertyMap();
        writeOrNull(generator, MdcKeys.FUNCTION, mdc.get(MdcKeys.FUNCTION));
        writeOrNull(generator, MdcKeys.USER, mdc.get(MdcKeys.USER));
        writeOrNull(generator, MdcKeys.ACTION, mdc.get(MdcKeys.ACTION));
        writeOrNull(generator, MdcKeys.TRACE_ID, mdc.get(MdcKeys.TRACE_ID));
    }

    private static void writeOrNull(JsonGenerator generator, String field, String value) throws IOException {
        // 統一方針：値なしは JSON null ではなく文字列 "null" を出力する。
        generator.writeStringField(field, value != null ? value : "null");
    }
}
