package jp.co.xxx.common.app.lib.scope.resident;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


import io.awspring.cloud.sqs.config.SqsMessageListenerContainerFactory;

import software.amazon.awssdk.services.sqs.SqsAsyncClient;

/**
 * 常駐バッチ（@SqsListener）のリスナーコンテナファクトリを上書きし、
 * 共通の {@link SqsJournalMessageInterceptor} を全リスナーに適用する。
 *
 * <p>既定の {@code defaultSqsListenerContainerFactory} を置き換える（@SqsListener が既定で参照する Bean 名）。
 * {@code SqsAsyncClient} は Spring Cloud AWS の自動構成（ローカルは ElasticMQ エンドポイント）をそのまま使う。
 *
 * <p>有効/無効は **ライブラリ固有プロパティ `lpj.logging.sqs.enabled`**（既定 true）で制御。
 * アプリの `app.mode` 規約には依存しない（＝ライブラリとして自己完結）。@SqsListener が無ければ
 * このファクトリは生成されるだけで何も起動しない。
 *
 * <p><b>注意</b>: アプリ側が独自に {@code SqsMessageListenerContainerFactory} を定義すると本ファクトリが
 * 置き換わり {@link SqsJournalMessageInterceptor} が登録されず受信ログが出なくなる。その場合は自作ファクトリ
 * にも {@code SqsJournalMessageInterceptor}（Bean）を {@code messageInterceptor(...)} で追加すること。
 * 詳細はログ部品詳細設計書「常駐SQS共通ログ部品」の注意書きを参照。
 */
@Configuration
@ConditionalOnProperty(prefix = "lpj.logging.sqs", name = "enabled", havingValue = "true", matchIfMissing = true)
public class ResidentSqsConfig {

    @Bean
    SqsMessageListenerContainerFactory<Object> defaultSqsListenerContainerFactory(
            SqsAsyncClient sqsAsyncClient, SqsJournalMessageInterceptor interceptor) {
        return SqsMessageListenerContainerFactory.<Object>builder()
                .sqsAsyncClient(sqsAsyncClient)
                .messageInterceptor(interceptor)
                .build();
    }
}
