package jp.co.xxx.common.app.lib.logback;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * {@code level_value}（ログレベルの数値）を<b>文字列</b>で出力する provider。
 *
 * <p>logstash 標準の {@code <logLevelValue>} は JSON 数値型（{@code "level_value":20000}）で出すが、
 * 本ライブラリの統一方針「JSON の値はすべて文字列（数値型を使わない）」に合わせ、
 * {@code "level_value":"20000"} と文字列で出力する。
 */
public class LevelValueStringJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        generator.writeStringField("level_value", String.valueOf(event.getLevel().toInt()));
    }
}
