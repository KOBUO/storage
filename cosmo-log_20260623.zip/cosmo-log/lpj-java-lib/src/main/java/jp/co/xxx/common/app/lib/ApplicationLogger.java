package jp.co.xxx.common.app.lib;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.mask.LogMaskingService;

/**
 * 業務ログ出力部品（明示的に出力する業務イベント）。
 * 業務ログ(X)は SPRINGBOOT_API_LOG、業務エラーログ(Y)は SPRINGBOOT_ERROR_LOG へ固定ロガー名で出力する。
 * type / subtype は TypeSubtypeJsonProvider が付与する（type=レベル判定 / subtype=APL）。
 *
 * ※固定ロガー名のため発生元が分からなくなるので、StackWalker で**呼び出し元の**
 *   class_name / method_name を自動取得して付与する（実装者は info/error を呼ぶだけ）。
 * ※システムログ(Z) は「明示出力していない FW 等の root ログ」であり本部品ではない。
 */
@Component
public class ApplicationLogger {

    private static final Logger business = LoggerFactory.getLogger(LoggerNames.API_LOG);
    private static final Logger error = LoggerFactory.getLogger(LoggerNames.ERROR_LOG);

    private final LogMaskingService masking;

    public ApplicationLogger(LogMaskingService masking) {
        this.masking = masking;
    }

    /** 業務ログ(X): trace_id(MDC) / message / class_name / method_name。 */
    public void info(String message) {
        business.info(base().marker(), masking.maskMessage(message));
    }

    /** 業務エラーログ(Y): trace_id(MDC) / message / stack_trace / class_name / method_name。 */
    public void error(String message, Throwable t) {
        error.error(base().marker(), masking.maskMessage(message), t);
    }

    /** 呼び出し元（この部品を呼んだ業務コード）の class_name / method_name を自動取得する。 */
    private StructuredLog base() {
        return CallerResolver.putCaller(StructuredLog.create());
    }
}
