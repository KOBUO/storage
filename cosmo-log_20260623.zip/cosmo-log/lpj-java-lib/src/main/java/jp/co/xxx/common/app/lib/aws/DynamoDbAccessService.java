package jp.co.xxx.common.app.lib.aws;

import java.time.Instant;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.CallerResolver;
import jp.co.xxx.common.app.lib.LogFields;
import jp.co.xxx.common.app.lib.LoggerNames;
import jp.co.xxx.common.app.lib.StructuredLog;
import jp.co.xxx.common.app.lib.aws.AwsResponseMetadataExtractor.AwsMeta;

import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.GetItemRequest;
import software.amazon.awssdk.services.dynamodb.model.GetItemResponse;
import software.amazon.awssdk.services.dynamodb.model.PutItemRequest;
import software.amazon.awssdk.services.dynamodb.model.PutItemResponse;

/**
 * DynamoDBアクセス部品。Get/Put 等で DynamoDBアクセスジャーナルログ(AWSCALL) を出力する。
 * DynamoDbClient は遅延生成。type/subtype は TypeSubtypeJsonProvider が付与（subtype=AWSCALL）。
 */
@Component
public class DynamoDbAccessService {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.DYNAMODB_JNL);

    private volatile DynamoDbClient client;

    private DynamoDbClient client() {
        if (client == null) {
            synchronized (this) {
                if (client == null) {
                    client = DynamoDbClient.create();
                }
            }
        }
        return client;
    }

    public Map<String, AttributeValue> getItem(String table, Map<String, AttributeValue> key) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        try {
            GetItemResponse response = client().getItem(GetItemRequest.builder().tableName(table).key(key).build());
            journal(requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "getItem");
            return response.item();
        } catch (RuntimeException e) {
            journalError(requestTimestamp, startNanos, "getItem", e);
            throw e;
        }
    }

    public void putItem(String table, Map<String, AttributeValue> item) {
        String requestTimestamp = Instant.now().toString();
        long startNanos = System.nanoTime();
        try {
            PutItemResponse response = client().putItem(PutItemRequest.builder().tableName(table).item(item).build());
            journal(requestTimestamp, startNanos, AwsResponseMetadataExtractor.extract(response), "putItem");
        } catch (RuntimeException e) {
            journalError(requestTimestamp, startNanos, "putItem", e);
            throw e;
        }
    }

    private void journal(String requestTimestamp, long startNanos, AwsMeta meta, String op) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        log.info(CallerResolver.putCaller(StructuredLog.create())
                .put(LogFields.LATENCY, latencyMs)
                .put(LogFields.AWS_REQUEST_ID, meta.requestId())
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .marker(), "dynamodb journal (" + op + ")");
    }

    /** AWS呼び出し失敗時のジャーナル（type=monitor / stack_trace 付き）。 */
    private void journalError(String requestTimestamp, long startNanos, String op, Throwable t) {
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        log.error(CallerResolver.putCaller(StructuredLog.create())
                .put(LogFields.LATENCY, latencyMs)
                .putNullable(LogFields.AWS_REQUEST_ID, null)
                .put(LogFields.AWS_REQUEST_TIMESTAMP, requestTimestamp)
                .put(LogFields.AWS_RESPONSE_TIME, latencyMs)
                .marker(), "dynamodb journal (" + op + " error)", t);
    }
}
