package jp.co.xxx.common.app.lib.logback;

import java.io.IOException;
import java.util.Map;

import jp.co.xxx.common.app.lib.LogFields;
import jp.co.xxx.common.app.lib.LogSubtype;
import jp.co.xxx.common.app.lib.LogType;
import jp.co.xxx.common.app.lib.LoggerNames;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * 全ログに type / subtype を付与する provider。
 *
 * <ul>
 *   <li><b>type</b> はログレベルから導出：{@code ERROR → monitor} / それ以外 → {@code app}。</li>
 *   <li><b>subtype</b> は logger_name から導出。固定ロガー(SPRINGBOOT_*)に該当しないもの
 *       （＝実装で明示出力していないフレームワーク等のログ＝<b>システムログ</b>）は {@code SYSTEM}。</li>
 * </ul>
 *
 * これにより、明示出力しない root(システムログ) でも type/subtype が付与される。
 * Marker では type/subtype を持たせない（重複防止）。
 */
public class TypeSubtypeJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    /** logger_name → subtype（該当しなければ SYSTEM）。 */
    private static final Map<String, String> SUBTYPE = Map.ofEntries(
            Map.entry(LoggerNames.SQL_JNL, LogSubtype.DBCALL),
            Map.entry(LoggerNames.STORAGE_JNL, LogSubtype.AWSCALL),
            Map.entry(LoggerNames.SQS_JNL, LogSubtype.AWSCALL),
            Map.entry(LoggerNames.KMS_JNL, LogSubtype.AWSCALL),
            Map.entry(LoggerNames.DYNAMODB_JNL, LogSubtype.AWSCALL),
            Map.entry(LoggerNames.API_ACCESS, LogSubtype.APL),
            Map.entry(LoggerNames.API_ACCESS_JNL, LogSubtype.APL),
            Map.entry(LoggerNames.SERVICE_JNL, LogSubtype.APL),
            Map.entry(LoggerNames.HTTP_CLIENT_JNL, LogSubtype.APL),
            Map.entry(LoggerNames.API_LOG, LogSubtype.APL),
            Map.entry(LoggerNames.ERROR_LOG, LogSubtype.APL));

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        boolean isError = event.getLevel().toInt() >= Level.ERROR.toInt();
        generator.writeStringField(LogFields.TYPE, isError ? LogType.MONITOR : LogType.APP);
        generator.writeStringField(LogFields.SUBTYPE, SUBTYPE.getOrDefault(event.getLoggerName(), LogSubtype.SYSTEM));
    }
}
