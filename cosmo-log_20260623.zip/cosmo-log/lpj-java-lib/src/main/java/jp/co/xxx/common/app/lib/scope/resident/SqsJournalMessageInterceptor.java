package jp.co.xxx.common.app.lib.scope.resident;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.ApplicationLogger;
import jp.co.xxx.common.app.lib.LogFields;
import jp.co.xxx.common.app.lib.LoggerNames;
import jp.co.xxx.common.app.lib.MdcKeys;
import jp.co.xxx.common.app.lib.StructuredLog;
import jp.co.xxx.common.app.lib.aws.SqsTraceSupport;

import io.awspring.cloud.sqs.listener.SqsHeaders;
import io.awspring.cloud.sqs.listener.interceptor.MessageInterceptor;

/**
 * 【常駐バッチ（@SqsListener）共通】のログ出力部品。
 * Spring Cloud AWS の {@link MessageInterceptor} として全 {@code @SqsListener} の受信前後にフックし、
 * 業務リスナーがログを意識しなくて済むようにする（オンラインの HttpLoggingFilter と同じ思想）。
 *
 * <ul>
 *   <li>{@code intercept}（受信時）: MDC スコープ(function/action/trace_id)を張り、メッセージジャーナル(W)を出力</li>
 *   <li>{@code afterProcessing}（終了時）: 失敗時は業務エラーログ(Y)を出力し、MDC をクリア</li>
 * </ul>
 *
 * <p>MDC はスレッドローカル。SINGLE_MESSAGE 処理では intercept→リスナー→afterProcessing が
 * 同一スレッドで動くため、業務リスナーのログにも function/trace_id 等が自動付与される。
 *
 * <p>trace_id はメッセージ属性 {@code traceparent} から取得し、統一方針で無ければ {@code null}
 * （SQS MessageId 等にフォールバックしない）。受信の AWS メタ(aws_request_id 等)は Spring 側が
 * SDK 受信を握るため取得できず {@code null}。
 */
@Component
@ConditionalOnProperty(prefix = "lpj.logging.sqs", name = "enabled", havingValue = "true", matchIfMissing = true)
public class SqsJournalMessageInterceptor implements MessageInterceptor<Object> {

    /** メッセージジャーナルログ(W)。 */
    private static final Logger journalLog = LoggerFactory.getLogger(LoggerNames.SQS_JNL);

    /** 常駐受信の action は固定。 */
    private static final String ACTION_CONSUME = "CONSUME";

    private final ApplicationLogger appLogger;

    public SqsJournalMessageInterceptor(ApplicationLogger appLogger) {
        this.appLogger = appLogger;
    }

    @Override
    public Message<Object> intercept(Message<Object> message) {
        MessageHeaders headers = message.getHeaders();
        String messageId = messageId(headers);

        // MDC スコープ開始（afterProcessing でクリア）。null/空は設定しない（→ provider が null 出力）。
        put(MdcKeys.FUNCTION, function(headers));
        put(MdcKeys.ACTION, ACTION_CONSUME);
        put(MdcKeys.TRACE_ID, traceId(headers));
        // user / source_ip は常駐では無し

        // メッセージジャーナル(W): 受信証跡。発生元・受信メタは取得不可のため null（キーは出力）。
        journalLog.info(StructuredLog.create()
                .putNullable(LogFields.CLASS_NAME, null)
                .putNullable(LogFields.METHOD_NAME, null)
                .putNullable(LogFields.LATENCY, null)
                .putNullable(LogFields.AWS_REQUEST_ID, null)
                .put(LogFields.AWS_SQS_MESSAGE_ID, messageId)
                .putNullable(LogFields.AWS_REQUEST_TIMESTAMP, null)
                .putNullable(LogFields.AWS_RESPONSE_TIME, null)
                .marker(), "sqs journal (receive)");
        return message;
    }

    @Override
    public void afterProcessing(Message<Object> message, Throwable t) {
        try {
            if (t != null) {
                // 失敗を業務エラーログ(Y)に残す（MDC 有効なうちに）。この後 DLQ/リトライへ。
                appLogger.error("メッセージ処理失敗 messageId=" + messageId(message.getHeaders()), t);
            }
        } finally {
            for (String key : MdcKeys.ALL) {
                MDC.remove(key);
            }
        }
    }

    private static void put(String key, String value) {
        if (value != null && !value.isBlank()) {
            MDC.put(key, value);
        }
    }

    private static String messageId(MessageHeaders headers) {
        var id = headers.getId();
        return id != null ? id.toString() : null;
    }

    /** trace_id: メッセージ属性 traceparent から取得、無ければ null（フォールバックしない）。 */
    private static String traceId(MessageHeaders headers) {
        Object tp = headers.get(SqsTraceSupport.TRACEPARENT);
        return (tp != null && !tp.toString().isBlank()) ? tp.toString() : null;
    }

    /** function: 受信キュー名を機能IDとして使う。 */
    private static String function(MessageHeaders headers) {
        Object queue = headers.get(SqsHeaders.SQS_QUEUE_NAME_HEADER);
        return queue != null ? queue.toString() : "sqs";
    }
}
