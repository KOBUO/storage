package jp.co.xxx.common.app.lib.web;

import java.time.Duration;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * 外部HTTP用 RestTemplate。
 * BufferingClientHttpRequestFactory でレスポンスを再読込可能にし、
 * ジャーナルインターセプタがボディを読んでも本来の呼出側で読めるようにする。
 *
 * <p>アプリ側が独自に RestTemplate を定義している場合は譲る（{@code @ConditionalOnMissingBean}）。
 * 無限待ちを避けるため接続/読取タイムアウトを既定で設定する。
 */
@Configuration
public class RestClientConfig {

    @Bean
    @ConditionalOnMissingBean(RestTemplate.class)
    public RestTemplate restTemplate(HttpClientJournalInterceptor journalInterceptor) {
        SimpleClientHttpRequestFactory factory = new SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(Duration.ofSeconds(5));
        factory.setReadTimeout(Duration.ofSeconds(10));
        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(factory));
        restTemplate.getInterceptors().add(journalInterceptor);
        return restTemplate;
    }
}
