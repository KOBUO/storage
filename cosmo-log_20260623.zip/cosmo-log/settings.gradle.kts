rootProject.name = "cosmo-log"

// マルチプロジェクト構成。
// - tranning     : これまでの資材（ログ部品サンプル一式）
// - lpj-java-lib : 別端末で同名 git clone してくる Java ライブラリ（現状は枠だけ）
include("tranning")
include("lpj-java-lib")
