# cosmo-log — Spring Boot 構造化ログ サンプル実装

`ログ設計書.md`（顧客設計書 **SSD-010 処理方式設計書** 反映済み）の設計を Spring Boot (Gradle) で実装したサンプル。
ログ種類ごとの**固定ロガー名 (`logger_name`)** で **32項目を構造化(JSON)** 出力し、
**stdout / stderr に振り分けて** CloudWatch Logs に収集させる。

- 出力先は **stdout / stderr**（ファイル出力ではない）。ERROR→stderr、それ以外→stdout（`LevelFilter`）。
- ログ種類の区別は `logger_name` のJSONフィールドで行う（appenderは**ログの種類ごと**に `logback/appender-*.xml` を定義）。
- 設計の根拠・項目定義・出力対象ログマトリクスは [`ログ設計書.md`](./ログ設計書.md) を参照。

## ドキュメント / 設計書（EPUB）

3レベル（要件・項目定義 / 設計書 / 実装ガイド）のMarkdownを `book/` に置き、出先で読めるEPUBにまとめている。未確定は **(TODO)** で明示。

| 成果物 | 内容 |
|---|---|
| `book/01_要件・項目定義（Excel資料レベル）.md` | ログ種類・項目定義・取得方法・出力対象マトリクス |
| `book/02_設計書（Markdownレベル）.md` | スコープ・MDC・出力基盤・部品設計 |
| `book/03_実装ガイド（実装レベル）.md` | logback/appender・MDCスコープ・ECS取得(Java+sh)・各部品コード |
| `Springbootログ設計書.epub` | 上記3部を1冊にしたEPUB（Apple Books等で閲覧） |
| `ログ設計.xlsx` | 上流共有用のExcel（`make xlsx` で生成） |

ワークフロー：**`book/` のMarkdownを編集 → `make book` → `open "Springbootログ設計書.epub"`（Apple Booksで確認）**。

```bash
make book    # EPUB を再生成（要 pandoc）
make xlsx    # Excel を生成（要 python3 + openpyxl）
make docs    # 両方
make clean   # 生成物を削除
```

---

## 1. 全体像

```
                         ┌─────────────────────────── HTTPリクエスト ───────────────────────────┐
                         │                                                                      │
   X-Trace-Id / X-User-Id / X-Forwarded-For                                                     │
                         ▼                                                                      │
            ┌───────────────────────────┐                                                       │
            │   HttpLoggingFilter        │  ① MDC設定: trace_id/user/source_ip/function/action  │
            │  (OncePerRequestFilter)    │  ② req/resp を ContentCaching でラップ                │
            └───────────────────────────┘                                                       │
                         │ chain.doFilter                                                        │
                         ▼                                                                      │
            ┌───────────────────────────┐                                                       │
            │  SampleController          │                                                       │
            └───────────────────────────┘                                                       │
                         ▼                                                                      │
            ┌───────────────────────────┐   ServiceJournalAspect (@Around @Service)             │
            │  SampleService (@Service)  │── 開始/終了/エラー のジャーナルを出力 ───────────────┐ │
            └───────────────────────────┘                                                     │ │
                         │  appLogger.info(...)                                                │ │
                         ▼                                                                     │ │
            ┌───────────────────────────┐                                                     │ │
            │  ApplicationLogger         │── 業務ログ / 業務エラーログ ────────────────────────┤ │
            └───────────────────────────┘                                                     │ │
                         │                                                                     │ │
   ① 戻りで HttpLoggingFilter が                                                               │ │
      アクセスジャーナル(要求/応答)を出力 ──────────────────────────────────────────────────┘ │
      finally で MDC クリア ──────────────────────────────────────────────────────────────────┘

   すべてのログ → StructuredLog(Marker) + 固定ロガー名 → logback → stdout(ERROR以外)/stderr(ERROR) → CloudWatch Logs
```

---

## 2. 32項目はどこから来るか（供給元の4系統）

設計の「スコープ」をそのまま実装の供給経路に対応させている。

| 供給元 | 項目 | 実装箇所 |
|---|---|---|
| **logback 組み込み provider** | timestamp, level, level_value, logger_name, thread, message, stack_trace | `logback/appender-*.xml` の `<providers>` |
| **独自 provider**（アプリスコープ） | id, name | `ContainerInfoJsonProvider`（環境変数 `CONTAINER_ID` / `CONTAINER_NAME` を直接読む） |
| **MDC**（実行単位スコープ） | function, user, action, trace_id, source_ip | `HttpLoggingFilter` が set → finally で clear |
| **Marker**（ログイベント/メソッド/AWS呼び出しスコープ） | type, subtype, url, status, headers, body, class_name, method_name, args, result, bucket_name, path, latency, aws_* | `StructuredLog` ビルダー |

> ポイント：MDC に載せるのは「複数ログで使い回す実行単位スコープの値」だけ。
> その場で確定する値・logback が持つ値・固定値・AWS呼び出し結果は Marker で出力時に付与する。

---

## 3. クラス構成

> ⚠ **2026-06-22 改訂**: `logging/` 一式は共通ライブラリ **lpj-java-lib（`jp.co.xxx.common.app.lib`）** へ移設済み（依存追加＋コンポーネントスキャンで有効化＝ドロップイン。詳細は `移行メモ.md`）。本アプリ(tranning)側は `CosmoLogApplication` / `config` / `demo`（検証用）のみ。以下のツリーは**移設前の参考**で、`logging/` 配下は現在 lib に存在する（パッケージは `jp.co.xxx.common.app.lib.*`）。

```
src/main/java/com/example/cosmolog/
├── CosmoLogApplication.java                  … エントリポイント
├── logging/
│   ├── LoggerNames.java                       … 固定ロガー名(11種)の定数
│   ├── LogType.java / LogSubtype.java         … type / subtype の定数
│   ├── MdcKeys.java                           … MDCキー(function/user/action/trace_id/source_ip)
│   ├── LogFields.java                         … Markerで付与する項目の物理名
│   ├── StructuredLog.java                     … 項目を組み立てて Marker 化するビルダー
│   ├── LoggingProperties.java                 … @ConfigurationProperties(logging.custom.*)
│   ├── ApplicationLogger.java                 … 業務ログ / 業務エラーログ出力部品
│   ├── logback/
│   │   └── ContainerInfoJsonProvider.java     … 環境変数 CONTAINER_ID/CONTAINER_NAME を読み id/name を全ログに付与する provider
│   ├── mask/
│   │   └── LogMaskingService.java             … headers/body/args/result/message/url のマスク・切詰め
│   ├── aws/
│   │   ├── AwsResponseMetadataExtractor.java  … aws_request_id / 拡張ID 抽出の共通部品
│   │   ├── SqsAccessService.java              … SQS送受信 → メッセージジャーナル
│   │   ├── KmsAccessService.java              … KMS暗号/復号 → KMSジャーナル
│   │   └── DynamoDbAccessService.java         … DynamoDB Get/Put → DynamoDBジャーナル
│   ├── mybatis/
│   │   └── SqlJournalInterceptor.java         … SQL実行 → DBCALLジャーナル(参照実装)
│   ├── scope/                                 … 実行区分別の実行単位スコープ起点（MDC）
│   │   ├── ExecutionScopeMdc.java             …   共通：MDC set/clear(try-with-resources)
│   │   ├── online/                            …   【API】
│   │   │   ├── HttpLoggingFilter.java         …     HTTPリクエスト起点 + アクセスログ/ジャーナル
│   │   │   └── FunctionActionResolver.java    …     function / action 解決
│   │   ├── batch/BatchLogScope.java           …   【バッチ】ジョブ起点
│   │   └── resident/MessageLogScope.java      …   【常駐バッチ】メッセージ処理起点
│   ├── web/                                   … 外部HTTPジャーナル（全区分共通）
│   │   ├── HttpClientJournalInterceptor.java  …   外部HTTP → 外部アクセスジャーナル
│   │   └── RestClientConfig.java              …   上記Interceptor付き RestTemplate
│   └── aspect/
│       └── ServiceJournalAspect.java          … @Service の開始/終了/エラー ジャーナル
└── demo/                                      … 動作確認用(API/バッチ/常駐の起点デモ含む)

src/main/resources/
├── application.yml                            … LoggingProperties へバインド
├── logback-spring.xml                         … include + logger_name→appender 振り分け
└── logback/                                    … ログの種類ごとに appender-*.xml を定義（各定義内で out/err を決定）
    ├── appender-access.xml                      … アクセスログ(INFO→stdout)
    ├── appender-access-jnl.xml                  … アクセスジャーナル(INFO→stdout)
    ├── appender-service-jnl.xml                 … サービスジャーナル(INFO→stdout / ERROR→stderr の2 appender)
    ├── appender-sql-jnl.xml                     … SQLジャーナル(INFO→stdout / ERROR→stderr の2 appender)
    ├── appender-storage-jnl.xml                 … ストレージアクセスジャーナル(INFO→stdout・定義のみ存置)
    ├── appender-http-client-jnl.xml            … 外部アクセスジャーナル(INFO→stdout)
    ├── appender-sqs-jnl.xml                     … メッセージジャーナル(SQS, INFO→stdout)
    ├── appender-kms-jnl.xml                     … KMSアクセスジャーナル(INFO→stdout)
    ├── appender-dynamodb-jnl.xml               … DynamoDBアクセスジャーナル(INFO→stdout)
    ├── appender-app.xml                         … 業務ログ(INFO→stdout)
    ├── appender-error.xml                       … 業務エラーログ(ERROR→stderr)
    └── appender-system.xml                      … システムログ/root(INFO→stdout / ERROR→stderr の2 appender)
```

---

## 4. ログ種類 → ロガー名 → 出力（stdout / stderr）

`logback-spring.xml` が**ログの種類ごと**の `appender-*.xml` を `<include>` し、各 `logger_name` の `<logger>` で振り分ける。

出力先は全て **stdout（ERROR以外）/ stderr（ERROR）**。ログ種類は `logger_name` で区別する。レベルは SSD-010 準拠。

| ログ種類 | logger_name | レベル | 出力する部品 |
|---|---|---|---|
| アクセスログ | SPRINGBOOT_API_ACCESS_LOG | INFO | `HttpLoggingFilter`（サマリ1件） |
| アクセスジャーナル | SPRINGBOOT_API_ACCESS_JNL_LOG | INFO | `HttpLoggingFilter`（要求/応答） |
| サービスジャーナル | SPRINGBOOT_SERVICE_JNL_LOG | INFO | `ServiceJournalAspect` |
| SQLジャーナル | SPRINGBOOT_SQL_JNL_LOG | INFO | `SqlJournalInterceptor`（MyBatis・参照実装） |
| ストレージアクセスジャーナル | SPRINGBOOT_STORAGE_JNL_LOG | INFO | （定義のみ存置・部品 `S3AccessService` は廃止） |
| 外部アクセスジャーナル | SPRINGBOOT_HTTP_CLIENT_JNL_LOG | INFO | `HttpClientJournalInterceptor` |
| メッセージジャーナル(SQS) | SPRINGBOOT_SQS_JNL_LOG | DEBUG/INFO/WARN | `SqsAccessService` |
| KMSアクセスジャーナル | SPRINGBOOT_KMS_JNL_LOG | INFO | `KmsAccessService` |
| DynamoDBアクセスジャーナル | SPRINGBOOT_DYNAMODB_JNL_LOG | INFO | `DynamoDbAccessService` |
| 業務ログ | SPRINGBOOT_API_LOG | DEBUG/INFO/WARN | `ApplicationLogger#info` |
| 業務エラーログ | SPRINGBOOT_ERROR_LOG | ERROR | `ApplicationLogger#error` |
| システムログ | （固定名なし・root） | INFO〜ERROR | 明示出力なし（Spring/Tomcat等のFW） |

> appender は**ログの種類ごと**に `logback/appender-*.xml` を定義し、`logback-spring.xml` が include する。
> 各定義の中で stdout(`System.out`) / stderr(`System.err`) を決定する。INFO と ERROR の両方を出す種類
> （サービスジャーナル / SQLジャーナル / システムログ(root)）は同一ファイルに out用・err用の ConsoleAppender を2つ定義し
> `LevelFilter` で振り分ける。基本ルール（ERROR→stderr / 他→stdout, CloudWatch収集）は不変。
> type/subtype は `TypeSubtypeJsonProvider` が付与（type=レベル判定、subtype=logger_name導出）。
> **システムログ**=固定ロガーに該当しない root のログ（明示出力していないFW等）。

> ログ種類は `logger_name` のJSONフィールドで区別する。新ログ種類の追加は「logger_name 定数追加 → `appender-*.xml` 1本 → `<logger>` 1行」。

---

## 5. ビルドと実行

> 必要環境: **Amazon Corretto JDK 25** / **Gradle 9.5.1** / **Spring Boot 4.0.6**。
> Gradle ラッパー(`gradlew`)同梱済みのため、JDK さえあればビルドできる。
> **ローカル環境構築の詳細手順は [`環境構築.md`](環境構築.md) を参照**（JDK導入・Docker・SQS/AWS検証・トラブルシュート）。

```bash
# 0) JDK(Corretto 25)を導入（管理者パスワードが要る）
brew install --cask corretto

# 1) Gradle ラッパー生成（gradle 本体 or IDE のGradle連携が必要。一度だけ）
#    gradle 未導入なら: brew install gradle
gradle wrapper --gradle-version 9.5.1

# 2) 起動
./gradlew bootRun
```

ログは **stdout / stderr に 1行JSON** で出る（ERRORは stderr）。`bootRun` のコンソールに表示される。
本番(ECS)では CloudWatch Logs が stdout/stderr を収集する。logger_name でログ種類を抽出する。

### 動作確認

```bash
# 業務ログ + サービスジャーナル(開始/終了) + アクセスログ + アクセスジャーナル(要求/応答)
curl -s "http://localhost:8080/api/orders/1" \
  -H "X-Trace-Id: trace-abc" -H "X-User-Id: user-001"

# リクエストボディの password がマスクされることを確認
curl -s -X POST "http://localhost:8080/api/orders" \
  -H "Content-Type: application/json" \
  -d '{"id":"9","customer":"山田太郎","amount":500,"password":"p@ss"}'

# 業務エラーログ(stack_trace付き / SPRINGBOOT_ERROR_LOG) + サービスジャーナル(エラー)
curl -s "http://localhost:8080/api/orders/error"

# 外部アクセスジャーナル(HTTP_CLIENT_JNL)。外部疎通が必要
curl -s "http://localhost:8080/api/external?url=https://example.com"
```

> SQS(`SqsAccessService`) は AWS 実環境(認証・リージョン)が必要なため
> デモのHTTP経路からは呼び出していない。`StructuredLog` + 固定ロガー名のパターンは他部品と同一。
> SQL(`SqlJournalInterceptor`) は MyBatis 依存を `compileOnly` にした参照実装で、実DB接続時に登録する。

---

## 5-2. 起動モード（API / 単発バッチ / 常駐バッチ）

`app.mode` で同一プロジェクト・同一 JAR を3形態で起動できる。各起点クラスは
`@ConditionalOnProperty(name="app.mode", havingValue=...)` でモード別に Bean 登録される。
コンテナ情報(id/name)・JSON出力・各ジャーナルは**どのモードでも共通で効く**。

| モード | 値 | 起点クラス | 主なログ |
|---|---|---|---|
| API（既定） | `api` | `SampleController` / `DemoController` + `HttpLoggingFilter` | アクセスログ(M) / アクセスジャーナル(N・O) |
| 単発バッチ | `batch` | `batch/SampleBatchRunner` → `SampleBatchJob` | 業務ログ(X) / サービスジャーナル。実行後に `exit` |
| 常駐バッチ | `resident` | `demo/SampleMessageListener`（`@SqsListener`） | メッセージジャーナル(W) / 業務ログ(X) |

### bootRun で起動

```bash
# API（既定。web 起動）
./gradlew bootRun

# 単発バッチ（web を起動しない）
./gradlew bootRun --args='--app.mode=batch --spring.main.web-application-type=none'

# 常駐バッチ（SQS。ローカルは ElasticMQ を使う → 次節）
./gradlew bootRun --args='--app.mode=resident --spring.main.web-application-type=none --spring.profiles.active=local'
```

### IntelliJ IDEA Run/Debug（VM options）

| モード | VM options |
|---|---|
| API | `-Dapp.mode=api`（既定なので省略可） |
| 単発バッチ | `-Dapp.mode=batch -Dspring.main.web-application-type=none` |
| 常駐バッチ | `-Dapp.mode=resident -Dspring.main.web-application-type=none -Dspring.profiles.active=local` |

### 常駐バッチをローカルで動かす（ElasticMQ）

本番は AWS SQS 依存。ローカルでは **ElasticMQ（Docker）を SQS 互換エンドポイント**として立て、
アプリ（IntelliJ / bootRun）はそのキューを `@SqsListener` でポーリングする。アプリ自体は Docker に入れない。

```bash
# 1) ElasticMQ 起動（sample-queue を自動作成）。管理UI: http://localhost:9325
docker compose up -d

# 2) 常駐バッチ起動（local profile で接続先を localhost:9324 に向ける）
./gradlew bootRun --args='--app.mode=resident --spring.main.web-application-type=none --spring.profiles.active=local'

# 3) 別シェルからテストメッセージ送信（aws cli の例）
aws sqs send-message \
  --endpoint-url http://localhost:9324 \
  --queue-url http://localhost:9324/000000000000/sample-queue \
  --message-body '{"hello":"world"}' \
  --message-attributes 'traceparent={DataType=String,StringValue=trace-local-1}'
```

> `app.sqs.queue-name`（既定 `sample-queue`）で監視キューを指定する。
> `traceparent` 属性を付けるとその値が `trace_id` になる（無ければ `null`。SQS MessageId 等にフォールバックしない＝統一方針）。
> 接続先エンドポイントは `application-local.yml` の `spring.cloud.aws.sqs.endpoint`。
> `local` profile を付けなければ実 AWS SQS に接続する。

### 常駐バッチの失敗 → 再試行 → DLQ

`elasticmq.conf` で `sample-queue` に DLQ(`sample-queue-dlq`, `maxReceiveCount=2`)を設定済み。
メッセージ本文に `fail` を含めると `SampleMessageListener` が例外を投げ、業務エラーログ(Y)を出して再 throw する。
ack されないため可視性タイムアウト(10秒)後に再配信され、2回失敗で DLQ へ移送される。

```bash
aws sqs send-message --endpoint-url http://localhost:9324 \
  --queue-url http://localhost:9324/000000000000/sample-queue \
  --message-body '{"task":"fail-me"}'
# → SPRINGBOOT_ERROR_LOG が2回 → 以降は sample-queue-dlq に滞留
```

## 5-3. AWS アクセス部品(KMS / DynamoDB)を LocalStack で確認

`docker compose up -d localstack`(`localhost:4566`)で KMS/DynamoDB をローカル起動。
リソースを `ap-northeast-1` に作成し、AWS 用 env を付けて API を起動して叩く。

```bash
# リソース作成（コンテナ内蔵の awslocal を使用。リージョンをアプリと揃える）
R=ap-northeast-1
docker exec cosmo-log-localstack awslocal --region $R dynamodb create-table --table-name demo-table \
  --attribute-definitions AttributeName=id,AttributeType=S --key-schema AttributeName=id,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST
KID=$(docker exec cosmo-log-localstack awslocal --region $R kms create-key --query 'KeyMetadata.KeyId' --output text)
docker exec cosmo-log-localstack awslocal --region $R kms create-alias --alias-name alias/demo --target-key-id "$KID"

# AWS SDK v2 は AWS_ENDPOINT_URL で LocalStack に向く。
export AWS_ENDPOINT_URL=http://localhost:4566 AWS_REGION=ap-northeast-1 \
       AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test
./gradlew bootRun --args='--app.mode=api'

curl -s localhost:8080/api/aws/kms     # KMS_JNL(AWSCALL)
curl -s localhost:8080/api/aws/dynamo  # DYNAMODB_JNL(AWSCALL)
```

## 5-4. テスト

```bash
./gradlew test    # ログ中核のユニットテスト(provider/マスキング/MDCスコープ)
./gradlew build   # 上記 + bootJar
```

---

## 6. 出力イメージ

`GET /api/orders/1`（`X-Trace-Id: trace-abc`, `X-User-Id: user-001`）で **stdout** に出る1行JSON（抜粋）。

サービスジャーナル（`logger_name=SPRINGBOOT_SERVICE_JNL_LOG`）:
```json
{"timestamp":"2026-06-05 16:20:00.123","level":"INFO","level_value":20000,
 "logger_name":"SPRINGBOOT_SERVICE_JNL_LOG","thread":"http-nio-8080-exec-1",
 "message":"service journal (start)","id":"<task-id>","name":"cosmo-log",
 "trace_id":"trace-abc","user":"user-001","source_ip":"127.0.0.1",
 "function":"orders","action":"GET /api/orders/1",
 "type":"app","subtype":"APL",
 "class_name":"com.example.cosmolog.demo.SampleService","method_name":"getOrder","args":["1"]}
```

業務ログ（`logger_name=SPRINGBOOT_API_LOG`。発生元 class_name/method_name は StackWalker で自動取得）:
```json
{"timestamp":"...","level":"INFO","level_value":20000,"logger_name":"SPRINGBOOT_API_LOG",
 "thread":"http-nio-8080-exec-1","message":"注文を取得しました id=1","id":"...","name":"cosmo-log",
 "trace_id":"trace-abc","user":"user-001","source_ip":"127.0.0.1","function":"orders","action":"GET /api/orders/1",
 "type":"app","subtype":"APL",
 "class_name":"com.example.cosmolog.demo.SampleService","method_name":"getOrder"}
```

アクセスジャーナル 応答（`logger_name=SPRINGBOOT_API_ACCESS_JNL_LOG`）:
```json
{"timestamp":"...","logger_name":"SPRINGBOOT_API_ACCESS_JNL_LOG","message":"access journal (response)",
 "trace_id":"trace-abc","function":"orders","action":"GET /api/orders/1","source_ip":"127.0.0.1",
 "type":"app","subtype":"APL","url":"GET /api/orders/1","status":200,
 "headers":{"Content-Type":"application/json"},"body":"{\"id\":\"1\",...}","latency":12}
```

---

## 7. 設定（application.yml）

`LoggingProperties` にバインドされ、マスク・切詰めに使われる。

```yaml
logging:
  custom:
    body-max-length: 2048          # body/args/result の最大長
    message-max-length: 4096       # message の最大長
    mask-header-names:             # 値を *** にするヘッダー
      - authorization
      - cookie
      - set-cookie
      - x-api-key
    mask-body-keys:                # "key":"value" / key=value を *** にするキー
      - password
      - secret
      - token
      - accessKey
      - secretKey
```

---

## 8. 部品追加の共通パターン

全ジャーナル部品は**「`StructuredLog` で固有項目を組み立て、固定ロガー名の `Logger` に出力する」**だけ。
function/user/action/trace_id/source_ip は MDC から、id/name は provider から自動付与されるため、
各部品は**そのログ固有の項目だけ**を組み立てればよい（例: `DynamoDbAccessService`）。

```java
private static final Logger log = LoggerFactory.getLogger(LoggerNames.DYNAMODB_JNL);

log.info(StructuredLog.of(LogType.APP, LogSubtype.AWSCALL)
        .put(LogFields.AWS_REQUEST_ID, meta.requestId())
        .put(LogFields.LATENCY, latencyMs)
        .marker(), "dynamodb journal");
```

### 残りの未実装（設計の論点が先）

| 部品 | 状況 |
|---|---|
| KmsAccessService / DynamoDbAccessService | AWSメタデータ抽出は `AwsResponseMetadataExtractor` を流用可能だが、**出力先ログ種類(logger_name)が設計未定義**。決定後に実装する。 |
| AuroraDBアクセス | SQLジャーナルは `SqlJournalInterceptor` でカバー（実DB接続時に登録）。 |

---

## 9. 注意・未確定事項

- **検証状況**: Amazon Corretto 25 / Gradle 9.5.1 / Spring Boot 4.0.6 で `./gradlew build`(ユニットテスト含む)成功。
  3モード(API/単発/常駐)・S3/KMS/DynamoDB(LocalStack)・常駐の失敗→再試行→DLQ を実機で確認済み。
- `type` / `subtype` のログ種類ごとの割当は設計書で未確定の箇所があり、本サンプルは `app`/`APL`・`monitor`/`APL` 等で仮置き（各 `StructuredLog.of(...)` 呼び出しで指定）。確定値が決まれば呼び出し箇所を直すだけ。
- `function` は実装上「実行単位スコープ＝リクエスト中のみ」MDCに存在するため、起動時やリクエスト外のシステムログには付与されない（バッチ/常駐バッチでは各起点でMDC設定する想定）。
- `latency` と `aws_response_time` の重複は設計書セクション9の論点のまま（未確定）。`aws_request_timestamp` / `aws_response_time` は設計マトリクスで△(案)。
- **SQLジャーナルの固定ロガー名 `SPRINGBOOT_SQL_JNL_LOG` は顧客設計書(SSD-010)で定義済み**。**KMS / DynamoDB** も `SPRINGBOOT_KMS_JNL_LOG` / `SPRINGBOOT_DYNAMODB_JNL_LOG`（AWSCALL）として追加定義・実装済み（マトリクスL〜Z外の追加ログ種類）。
- 元資料(SSD-010)に **`pid`（プロセスID）** 項目があるが合意済み32項目に含まれない（採否要確認）。
- AWS SDK(SQS) はクライアントを遅延生成し、デモ経路からは呼ばないため起動時にAWS認証は不要。実呼び出し時のみ認証/リージョン解決が走る。
