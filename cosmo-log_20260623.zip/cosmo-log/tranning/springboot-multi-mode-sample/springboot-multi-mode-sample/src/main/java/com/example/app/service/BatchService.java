package com.example.app.service;

import com.example.app.mapper.SampleMapper;
import org.springframework.stereotype.Service;

@Service
public class BatchService {

    private final SampleMapper sampleMapper;

    public BatchService(SampleMapper sampleMapper) {
        this.sampleMapper = sampleMapper;
    }

    public void execute() {
        Integer result = sampleMapper.selectOne();
        System.out.println("batch executed. result=" + result);
    }
}
