package com.example.app.service;

import com.example.app.mapper.SampleMapper;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicBoolean;

@Service
public class ResidentService {

    private final AtomicBoolean running = new AtomicBoolean(true);
    private final SampleMapper sampleMapper;

    public ResidentService(SampleMapper sampleMapper) {
        this.sampleMapper = sampleMapper;
    }

    public void start() {
        System.out.println("resident batch started");

        Runtime.getRuntime().addShutdownHook(new Thread(this::stop));

        while (running.get()) {
            try {
                Integer result = sampleMapper.selectOne();
                System.out.println("resident batch running. result=" + result);
                Thread.sleep(10_000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                stop();
            }
        }

        System.out.println("resident batch stopped");
    }

    public void stop() {
        running.set(false);
    }
}
