package com.example.app.config;

public final class AppMode {

    public static final String API = "api";
    public static final String BATCH = "batch";
    public static final String RESIDENT = "resident";

    private AppMode() {
    }
}
