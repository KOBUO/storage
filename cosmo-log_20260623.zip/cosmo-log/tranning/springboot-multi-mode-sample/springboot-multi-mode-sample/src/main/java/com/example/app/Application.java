package com.example.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.env.Environment;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    /**
     * 起動確認用。
     * 不要になったら削除して問題ありません。
     */
    @Bean
    ApplicationRunner checkAppMode(Environment environment) {
        return args -> {
            System.out.println("app.mode = " + environment.getProperty("app.mode"));
            System.out.println("spring.main.web-application-type = "
                    + environment.getProperty("spring.main.web-application-type"));
        };
    }
}
