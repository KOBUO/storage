package com.example.app.controller;

import com.example.app.service.ApiService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@ConditionalOnProperty(name = "app.mode", havingValue = "api")
public class SampleController {

    private final ApiService apiService;

    public SampleController(ApiService apiService) {
        this.apiService = apiService;
    }

    @GetMapping("/sample")
    public String sample() {
        return apiService.execute();
    }
}
