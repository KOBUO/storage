package com.example.app.service;

import com.example.app.mapper.SampleMapper;
import org.springframework.stereotype.Service;

@Service
public class ApiService {

    private final SampleMapper sampleMapper;

    public ApiService(SampleMapper sampleMapper) {
        this.sampleMapper = sampleMapper;
    }

    public String execute() {
        Integer result = sampleMapper.selectOne();
        return "api executed. result=" + result;
    }
}
