package com.example.app.batch;

import com.example.app.service.BatchService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "app.mode", havingValue = "batch")
public class SampleBatchRunner implements CommandLineRunner {

    private final BatchService batchService;

    public SampleBatchRunner(BatchService batchService) {
        this.batchService = batchService;
    }

    @Override
    public void run(String... args) {
        try {
            System.out.println("SampleBatchRunner started");
            batchService.execute();
            System.exit(0);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
