package com.example.app.resident;

import com.example.app.service.ResidentService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "app.mode", havingValue = "resident")
public class ResidentBatchRunner implements CommandLineRunner {

    private final ResidentService residentService;

    public ResidentBatchRunner(ResidentService residentService) {
        this.residentService = residentService;
    }

    @Override
    public void run(String... args) {
        System.out.println("ResidentBatchRunner started");
        residentService.start();
    }
}
