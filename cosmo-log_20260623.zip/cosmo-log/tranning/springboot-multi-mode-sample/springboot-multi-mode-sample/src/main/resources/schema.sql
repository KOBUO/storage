CREATE TABLE IF NOT EXISTS sample (
    id INT PRIMARY KEY,
    name VARCHAR(100)
);

INSERT INTO sample (id, name)
SELECT 1, 'test'
WHERE NOT EXISTS (
    SELECT 1 FROM sample WHERE id = 1
);
