# springboot-multi-mode-sample

Spring Boot で API / 単発バッチ / 常駐バッチを同じプロジェクトに共存させる最小サンプルです。

## パッケージ構成

```text
src/main/java/com/example/app/
├── Application.java
├── controller/
│   └── SampleController.java
├── batch/
│   └── SampleBatchRunner.java
├── resident/
│   └── ResidentBatchRunner.java
├── service/
│   ├── ApiService.java
│   ├── BatchService.java
│   └── ResidentService.java
├── mapper/
│   └── SampleMapper.java
└── config/
    └── AppMode.java
```

## 起動方法

### API

```bash
./gradlew bootRun --args='--app.mode=api'
```

確認:

```bash
curl http://localhost:8080/sample
```

### 単発バッチ

```bash
./gradlew bootRun --args='--app.mode=batch --spring.main.web-application-type=none'
```

### 常駐バッチ

```bash
./gradlew bootRun --args='--app.mode=resident --spring.main.web-application-type=none'
```

## IntelliJ IDEA Run/Debug Configuration

### API起動

VM options:

```text
-Dapp.mode=api
```

### 単発バッチ起動

VM options:

```text
-Dapp.mode=batch -Dspring.main.web-application-type=none
```

### 常駐バッチ起動

VM options:

```text
-Dapp.mode=resident -Dspring.main.web-application-type=none
```

## H2ファイルDB

`application.yml` で以下を指定しています。

```yaml
spring:
  datasource:
    url: jdbc:h2:file:./data/sampledb;MODE=PostgreSQL;AUTO_SERVER=TRUE
```

Working directory がプロジェクトルートの場合、以下が作成されます。

```text
data/sampledb.mv.db
```
