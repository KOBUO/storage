package com.example.cosmolog.demo;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.cosmolog.config.AppMode;

/**
 * 追加ジャーナル部品の動作確認用。
 *  - /api/external : 外部アクセスジャーナル(HttpClientJournalInterceptor)
 */
@RestController
@ConditionalOnProperty(name = "app.mode", havingValue = AppMode.API, matchIfMissing = true)
public class DemoController {

    private final RestTemplate restTemplate;

    public DemoController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @GetMapping("/api/external")
    public ResponseEntity<String> external(@RequestParam String url) {
        return restTemplate.getForEntity(url, String.class);
    }
}
