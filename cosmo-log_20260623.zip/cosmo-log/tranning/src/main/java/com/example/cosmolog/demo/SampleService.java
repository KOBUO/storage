package com.example.cosmolog.demo;

import org.springframework.stereotype.Service;

import jp.co.xxx.common.app.lib.ApplicationLogger;

/**
 * デモ用サービス。{@code @Service} なので ServiceJournalAspect により
 * 開始/終了のサービスジャーナルログが自動出力される。
 */
@Service
public class SampleService {

    private final ApplicationLogger appLogger;

    public SampleService(ApplicationLogger appLogger) {
        this.appLogger = appLogger;
    }

    public Order getOrder(String id) {
        if ("error".equals(id)) {
            throw new IllegalArgumentException("order not found: " + id);
        }
        appLogger.info("注文を取得しました id=" + id);
        return new Order(id, "山田太郎", 1200);
    }

    public Order createOrder(Order order) {
        appLogger.info("注文を登録しました id=" + order.id());
        return order;
    }
}
