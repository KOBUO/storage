package com.example.cosmolog.demo;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.example.cosmolog.config.AppMode;
import jp.co.xxx.common.app.lib.ApplicationLogger;

import io.awspring.cloud.sqs.annotation.SqsListener;

/**
 * 【常駐バッチ（メッセージ処理）】の業務リスナー（検証用）。{@code app.mode=resident} のときだけ登録。
 *
 * <p>受信ジャーナル(W)・MDCスコープ(function/action/trace_id)・失敗時の業務エラーログ(Y)は
 * 共通部品 {@link jp.co.xxx.common.app.lib.scope.resident.SqsJournalMessageInterceptor} が
 * 受信前後で自動出力する。ここは <b>業務処理だけ</b> を書く（HttpLoggingFilter と同じ思想）。
 */
@Component
@ConditionalOnProperty(name = "app.mode", havingValue = AppMode.RESIDENT)
public class SampleMessageListener {

    private final ApplicationLogger appLogger;

    public SampleMessageListener(ApplicationLogger appLogger) {
        this.appLogger = appLogger;
    }

    @SqsListener("${app.sqs.queue-name}")
    public void onMessage(Message<String> message) {
        String body = message.getPayload();
        appLogger.info("メッセージ処理開始 body=" + body);
        // 【検証用】本文に "fail" を含むと処理失敗（業務エラーログは interceptor が出力→再配信/DLQ）。
        if (body != null && body.contains("fail")) {
            throw new RuntimeException("意図的な処理失敗(検証用): " + body);
        }
        appLogger.info("メッセージ処理終了");
    }
}
