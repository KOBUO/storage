package com.example.cosmolog.batch;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.example.cosmolog.config.AppMode;
import com.example.cosmolog.demo.SampleBatchJob;

/**
 * 【単発バッチ】の起動起点。{@code app.mode=batch} のときだけ登録され、
 * 起動直後に {@link SampleBatchJob} を1回実行して JVM を終了する。
 *
 * 起動例:
 * <pre>{@code
 * ./gradlew bootRun --args='--app.mode=batch --spring.main.web-application-type=none'
 * }</pre>
 *
 * MDC(function/trace_id 等)とエラーハンドリングは {@link SampleBatchJob} 側が持つ。
 * ここは起動して終了コードを制御するだけ（ジョブID等の採番はしない）。
 */
@Component
@ConditionalOnProperty(name = "app.mode", havingValue = AppMode.BATCH)
public class SampleBatchRunner implements CommandLineRunner {

    private final SampleBatchJob batchJob;

    public SampleBatchRunner(SampleBatchJob batchJob) {
        this.batchJob = batchJob;
    }

    @Override
    public void run(String... args) {
        try {
            // アプリ側でのジョブID採番はしない（trace_id 等はバッチスコープが設定）
            batchJob.run();
            System.exit(0);
        } catch (Exception e) {
            // 失敗の業務エラーログは SampleBatchJob 側で出力済み。終了コードのみここで制御する。
            System.exit(1);
        }
    }
}
