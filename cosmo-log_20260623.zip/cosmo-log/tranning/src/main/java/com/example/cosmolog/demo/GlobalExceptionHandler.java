package com.example.cosmolog.demo;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import jp.co.xxx.common.app.lib.ApplicationLogger;

/**
 * 例外を業務エラーログ(SPRINGBOOT_ERROR_LOG)へ出力する。
 * stack_trace は logger.error(msg, throwable) 経由で付与される。
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private final ApplicationLogger appLogger;

    public GlobalExceptionHandler(ApplicationLogger appLogger) {
        this.appLogger = appLogger;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> handleBadRequest(IllegalArgumentException e) {
        appLogger.error("業務エラーが発生しました: " + e.getMessage(), e);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", e.getMessage()));
    }
}
