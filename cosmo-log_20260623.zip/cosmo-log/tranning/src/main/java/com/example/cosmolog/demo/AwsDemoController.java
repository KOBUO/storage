package com.example.cosmolog.demo;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.cosmolog.config.AppMode;
import jp.co.xxx.common.app.lib.aws.DynamoDbAccessService;
import jp.co.xxx.common.app.lib.aws.KmsAccessService;
import jp.co.xxx.common.app.lib.aws.SqsAccessService;

import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

/**
 * AWS アクセス部品(KMS / DynamoDB)の動作確認用。
 * ローカルは LocalStack へ向ける（環境変数 AWS_ENDPOINT_URL=http://localhost:4566）。
 *  - /api/aws/kms    : KMSアクセスジャーナル(KMS_JNL, AWSCALL)
 *  - /api/aws/dynamo : DynamoDBアクセスジャーナル(DYNAMODB_JNL, AWSCALL)
 */
@RestController
@ConditionalOnProperty(name = "app.mode", havingValue = AppMode.API, matchIfMissing = true)
public class AwsDemoController {

    private final KmsAccessService kms;
    private final DynamoDbAccessService dynamo;
    private final SqsAccessService sqs;
    private final String queueUrl;

    public AwsDemoController(KmsAccessService kms, DynamoDbAccessService dynamo, SqsAccessService sqs,
                            @Value("${app.sqs.queue-url:http://localhost:9324/000000000000/sample-queue}") String queueUrl) {
        this.kms = kms;
        this.dynamo = dynamo;
        this.sqs = sqs;
        this.queueUrl = queueUrl;
    }

    /** SQS 送信の確認用。送信ジャーナル(SQS_JNL, sqs journal (send)) が出るか検証する。 */
    @GetMapping("/api/aws/sqs-send")
    public Map<String, Object> sqsSend() {
        String messageId = sqs.sendMessage(queueUrl, "{\"hello\":\"send\"}");
        return Map.of("messageId", messageId);
    }

    @GetMapping("/api/aws/kms")
    public Map<String, Object> kms() {
        SdkBytes cipher = kms.encrypt("alias/demo", "secret-data".getBytes(StandardCharsets.UTF_8));
        SdkBytes plain = kms.decrypt(cipher.asByteArray());
        return Map.of("decrypted", new String(plain.asByteArray(), StandardCharsets.UTF_8));
    }

    @GetMapping("/api/aws/dynamo")
    public Map<String, Object> dynamo() {
        Map<String, AttributeValue> item = new LinkedHashMap<>();
        item.put("id", AttributeValue.fromS("1"));
        item.put("val", AttributeValue.fromS("demo-value"));
        dynamo.putItem("demo-table", item);
        Map<String, AttributeValue> got = dynamo.getItem("demo-table", Map.of("id", AttributeValue.fromS("1")));
        return Map.of("val", got.getOrDefault("val", AttributeValue.fromS("")).s());
    }
}
