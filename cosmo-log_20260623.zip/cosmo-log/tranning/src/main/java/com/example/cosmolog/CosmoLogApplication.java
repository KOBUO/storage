package com.example.cosmolog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * ログ出力部品は共通ライブラリ {@code jp.co.xxx.common.app.lib}（lpj-java-lib）へ外出しした。
 * 依存追加＋下記コンポーネントスキャンで、ライブラリ内の Filter/Aspect/Interceptor/provider 等が
 * 自動的に有効になる（＝ドロップイン。ライブラリが無くてもアプリ自体は動く）。
 */
@SpringBootApplication(scanBasePackages = {"com.example.cosmolog", "jp.co.xxx.common.app.lib"})
public class CosmoLogApplication {

    public static void main(String[] args) {
        SpringApplication.run(CosmoLogApplication.class, args);
    }
}
