package com.example.cosmolog.demo;

import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.ApplicationLogger;
import jp.co.xxx.common.app.lib.scope.ExecutionScopeMdc;
import jp.co.xxx.common.app.lib.scope.batch.BatchLogScope;

/**
 * 【バッチ】起点の例。ジョブ開始で MDC 設定 → 終了でクリア。
 * 実プロジェクトでは Spring Batch の Tasklet / CommandLineRunner 等から呼ぶ。
 */
@Component
public class SampleBatchJob {

    private final ApplicationLogger appLogger;
    private final SampleService service;

    public SampleBatchJob(ApplicationLogger appLogger, SampleService service) {
        this.appLogger = appLogger;
        this.service = service;
    }

    public void run() {
        try (ExecutionScopeMdc scope = BatchLogScope.open("売上集計バッチ")) {
            try {
                appLogger.info("バッチ処理開始");
                service.getOrder("1"); // サービスジャーナルも同じ trace_id/function で出力される
                appLogger.info("バッチ処理終了");
            } catch (RuntimeException e) {
                // ジョブ失敗を業務エラーログに残す（trace_id 等は MDC から付与）
                appLogger.error("バッチ処理失敗", e);
                throw e;
            }
        }
    }
}
