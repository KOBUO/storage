package com.example.cosmolog.demo;

import static org.mockito.Mockito.mock;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import jp.co.xxx.common.app.lib.ApplicationLogger;

/**
 * デモ用 SampleController の単体テスト（standaloneSetup＝Springコンテキスト/ライブラリ部品なし）。
 * 正常系200・業務例外の400(GlobalExceptionHandler)・POST を検証する。
 */
class SampleControllerTest {

    private MockMvc mvc;

    @BeforeEach
    void setup() {
        ApplicationLogger logger = mock(ApplicationLogger.class);          // ログ部品はモック
        SampleService service = new SampleService(logger);                 // 実ロジック
        SampleController controller = new SampleController(service, logger);
        mvc = MockMvcBuilders.standaloneSetup(controller)
                .setControllerAdvice(new GlobalExceptionHandler(logger))
                .build();
    }

    @Test
    void getOrderReturns200() throws Exception {
        mvc.perform(get("/api/orders/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("1"))
                .andExpect(jsonPath("$.customer").value("山田太郎"))
                .andExpect(jsonPath("$.amount").value(1200));
    }

    @Test
    void getOrderErrorReturns400ViaAdvice() throws Exception {
        mvc.perform(get("/api/orders/error"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.error").value("order not found: error"));
    }

    @Test
    void createOrderReturns200Echo() throws Exception {
        mvc.perform(post("/api/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"id\":\"X1\",\"customer\":\"山田\",\"amount\":100}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("X1"))
                .andExpect(jsonPath("$.amount").value(100));
    }
}
