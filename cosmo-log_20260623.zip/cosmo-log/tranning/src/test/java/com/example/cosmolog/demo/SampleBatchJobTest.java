package com.example.cosmolog.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import jp.co.xxx.common.app.lib.ApplicationLogger;

/**
 * デモ用 SampleBatchJob の単体テスト。バッチスコープ内でサービスを実行し、
 * 終了時に MDC がクリアされること（try-with-resources）を検証する。
 */
class SampleBatchJobTest {

    @AfterEach
    void clear() {
        MDC.clear();
    }

    @Test
    void runExecutesServiceAndClearsMdc() {
        ApplicationLogger logger = mock(ApplicationLogger.class);
        SampleService service = mock(SampleService.class);
        when(service.getOrder("1")).thenReturn(new Order("1", "x", 1));

        new SampleBatchJob(logger, service).run();

        verify(service).getOrder("1");
        // BatchLogScope の try-with-resources でスコープ終了時に MDC がクリアされる
        assertThat(MDC.get("function")).isNull();
        assertThat(MDC.get("action")).isNull();
    }
}
