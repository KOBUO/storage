plugins {
    java
    id("org.springframework.boot") version "4.0.6"
    id("io.spring.dependency-management") version "1.1.7"
}

group = "com.example"
version = "0.0.1-SNAPSHOT"

java {
    toolchain {
        // Amazon Corretto 25 を使う。Gradle 9.5.1 が JDK25 toolchain に対応。
        languageVersion = JavaLanguageVersion.of(25)
    }
}

// Spring Cloud AWS（@SqsListener）。4.0.x は Spring Boot 4 / Spring Framework 7 対応。
val springCloudAwsVersion = "4.0.2"

repositories {
    mavenCentral()
}

dependencyManagement {
    imports {
        // Spring Cloud AWS の BOM。awssdk のバージョンもこちらに揃える（明示 BOM は持たない）。
        mavenBom("io.awspring.cloud:spring-cloud-aws-dependencies:$springCloudAwsVersion")
    }
}

dependencies {
    // マルチプロジェクト参照：同リポジトリ内の lpj-java-lib に依存。
    implementation(project(":lpj-java-lib"))

    // ※ ログ系の依存（logback-encoder / aspectj / cache / mybatis / configuration-processor）は
    //    lpj-java-lib が api で公開するため、ここでは宣言しない（ドロップイン。詳細は 移行メモ.md）。

    // アプリ自身の関心：Web / 常駐 SQS リスナー(@SqsListener) / AWS SDK（デモ controller が型を直接利用）。
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("io.awspring.cloud:spring-cloud-aws-starter-sqs")
    implementation("software.amazon.awssdk:dynamodb")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
}

tasks.named<Test>("test") {
    useJUnitPlatform()
}
