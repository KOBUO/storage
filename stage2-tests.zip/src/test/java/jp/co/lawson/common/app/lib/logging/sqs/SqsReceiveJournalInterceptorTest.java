package jp.co.lawson.common.app.lib.logging.sqs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.StringWriter;
import java.util.UUID;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import net.logstash.logback.marker.LogstashMarker;

import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;
import jp.co.lawson.common.app.lib.logging.constant.MdcKeys;

/**
 * {@link SqsReceiveJournalInterceptor} の単体テスト。
 */
class SqsReceiveJournalInterceptorTest {

    /** function に設定するジョブ識別子（モックの戻り値）。 */
    private static final String JOB_IDENTIFIER = "sample-job-001-3f2c";
    /** marker を JSON へ起こす用。 */
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** テスト対象。jobIdentifier を返すモックを注入して生成する。 */
    private SqsReceiveJournalInterceptor target;

    /** 受信ジャーナルログ（SPRINGBOOT_SQS_JNL_LOG）の出力捕捉用 appender。 */
    private ListAppender<ILoggingEvent> journalAppender;
    private Logger journalLogger;

    @BeforeEach
    void setUp() {
        SqsJobArgumentProvider jobArgumentProvider = mock(SqsJobArgumentProvider.class);
        when(jobArgumentProvider.getJobIdentifier()).thenReturn(JOB_IDENTIFIER);
        target = new SqsReceiveJournalInterceptor(jobArgumentProvider);

        journalLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.SQS_JNL);
        journalAppender = new ListAppender<>();
        journalAppender.start();
        journalLogger.addAppender(journalAppender);
        journalLogger.setLevel(Level.INFO);
        journalLogger.setAdditive(false); // ルートへの伝播を止めてテスト出力を汚さない
    }

    @AfterEach
    void detachAppender() {
        journalLogger.detachAppender(journalAppender);
        journalLogger.setAdditive(true);
        MDC.clear();
    }

    /**
     * 受信メッセージのモックを組み立てる。
     *
     * @param id メッセージ ID（null 可）
     * @return モック化した受信メッセージ
     */
    @SuppressWarnings("unchecked")
    private static Message<Object> message(UUID id) {
        MessageHeaders headers = mock(MessageHeaders.class);
        when(headers.getId()).thenReturn(id);
        Message<Object> message = mock(Message.class);
        when(message.getHeaders()).thenReturn(headers);
        return message;
    }

    /**
     * メッセージ ID 付きの受信で、MDC を設定し受信ジャーナルを出力すること。
     *
     * 試験条件
     * ・メッセージ ID 付きのメッセージを intercept する。
     * 観点
     * ・function＝ジョブ識別子（DI）、trace＝メッセージ ID を MDC に設定し、action／user は設定しないこと。
     * 想定結果
     * ・受信メッセージをそのまま返却し、ジャーナルに「メッセージ受信ジャーナル」を1件出力すること。
     * ・MDC は function＝ジョブ識別子・trace＝メッセージ ID、action／user は未設定であること。
     */
    @Test
    void interceptSetsMdcAndLogsJournal() {
        UUID id = UUID.randomUUID();
        Message<Object> message = message(id);

        Message<Object> returned = target.intercept(message);

        assertThat(returned).isSameAs(message);
        assertThat(journalAppender.list).hasSize(1);
        assertThat(journalAppender.list.get(0).getFormattedMessage()).isEqualTo("メッセージ受信ジャーナル");
        assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo(JOB_IDENTIFIER);
        assertThat(MDC.get(MdcKeys.TRACE_ID)).isEqualTo(id.toString());
        assertThat(MDC.get(MdcKeys.ACTION)).isNull();
        assertThat(MDC.get(MdcKeys.USER)).isNull();
    }

    /**
     * メッセージ ID が無い場合でも function はジョブ識別子を設定し、trace は設定しないこと。
     *
     * 試験条件
     * ・メッセージ ID なしのメッセージを intercept する。
     * 観点
     * ・function は DI のジョブ識別子を設定し、取得不可の trace は MDC に設定しないこと。
     * 想定結果
     * ・ジャーナル1件で、function＝ジョブ識別子、trace／action／user は未設定であること。
     */
    @Test
    void interceptWithoutMessageIdStillSetsFunction() {
        target.intercept(message(null));

        assertThat(journalAppender.list).hasSize(1);
        assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo(JOB_IDENTIFIER);
        assertThat(MDC.get(MdcKeys.TRACE_ID)).isNull();
        assertThat(MDC.get(MdcKeys.ACTION)).isNull();
        assertThat(MDC.get(MdcKeys.USER)).isNull();
    }

    /**
     * 処理完了時に MDC をクリアすること。
     *
     * 試験条件
     * ・MDC に値がある状態で afterProcessing を実行する。
     * 観点
     * ・afterProcessing は MDC.clear() のみ行うこと。
     * 想定結果
     * ・MDC が空になること。
     */
    @Test
    void afterProcessingClearsMdc() {
        MDC.put(MdcKeys.FUNCTION, "x");

        target.afterProcessing(message(null), null);

        assertThat(MDC.get(MdcKeys.FUNCTION)).isNull();
    }

    /** イベントの marker（追加項目）を JSON ノードへ変換する。 */
    private static JsonNode markerOf(ILoggingEvent event) {
        try {
            StringWriter sw = new StringWriter();
            try (JsonGenerator gen = MAPPER.getFactory().createGenerator(sw)) {
                gen.setCodec(MAPPER);
                gen.writeStartObject();
                for (var marker : event.getMarkerList()) {
                    ((LogstashMarker) marker).writeTo(gen);
                }
                gen.writeEndObject();
            }
            return MAPPER.readTree(sw.toString());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * 受信ジャーナルの marker が、aws_sqs_message_id＝メッセージ ID、他の AWS メタ項目は "-" であること。
     *
     * 試験条件
     * ・メッセージ ID 付きで intercept する。
     * 観点
     * ・marker（構造化フィールド）の各値が想定どおりであること（件数・メッセージ文字列だけにしない）。
     * 想定結果
     * ・aws_sqs_message_id＝メッセージ ID、latency／aws_request_id／aws_request_timestamp／aws_response_time＝"-" であること。
     */
    @Test
    void interceptMarkerHasMessageIdAndPlaceholderForOthers() {
        UUID id = UUID.randomUUID();
        target.intercept(message(id));

        JsonNode marker = markerOf(journalAppender.list.get(0));
        assertThat(marker.path(LogFields.AWS_SQS_MESSAGE_ID).asText()).as("messageId").isEqualTo(id.toString());
        assertThat(marker.path(LogFields.LATENCY).asText()).isEqualTo("-");
        assertThat(marker.path(LogFields.AWS_REQUEST_ID).asText()).isEqualTo("-");
        assertThat(marker.path(LogFields.AWS_REQUEST_TIMESTAMP).asText()).isEqualTo("-");
        assertThat(marker.path(LogFields.AWS_RESPONSE_TIME).asText()).isEqualTo("-");
    }

    /**
     * メッセージ ID が無い場合、aws_sqs_message_id キー自体が出力されないこと（put は null を捨てる）。
     *
     * 試験条件
     * ・メッセージ ID なしで intercept する。
     * 観点
     * ・put（null 無視）と putNullable（"-" 出力）の非対称を確認すること。
     * 想定結果
     * ・aws_sqs_message_id は項目なし、putNullable の latency は "-" であること。
     */
    @Test
    void interceptWithoutMessageIdOmitsMessageIdKey() {
        target.intercept(message(null));

        JsonNode marker = markerOf(journalAppender.list.get(0));
        assertThat(marker.has(LogFields.AWS_SQS_MESSAGE_ID)).as("messageId null は put でキー省略").isFalse();
        assertThat(marker.path(LogFields.LATENCY).asText()).isEqualTo("-");
    }
}
