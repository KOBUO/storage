package jp.co.lawson.common.app.lib.logging.sql;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Invocation;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.StringWriter;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import net.logstash.logback.marker.LogstashMarker;

import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;

/**
 * {@link SqlJournalInterceptor} の単体テスト。
 */
class SqlJournalInterceptorTest {

    /** テスト対象。（全 SQL 出力モード）状態を保持しないため全テストで共有する。 */
    private static final SqlJournalInterceptor TARGET = new SqlJournalInterceptor(false);

    /** テスト対象。（例外時のみ出力モード） */
    private static final SqlJournalInterceptor TARGET_ERROR_ONLY = new SqlJournalInterceptor(true);

    /** SQLジャーナルロガーに付け替える、出力イベント捕捉用 appender。 */
    private ListAppender<ILoggingEvent> appender;
    private Logger sqlLogger;

    @BeforeEach
    void attachAppender() {
        sqlLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.SQL_JNL);
        appender = new ListAppender<>();
        appender.start();
        sqlLogger.addAppender(appender);
        sqlLogger.setLevel(Level.INFO);
        sqlLogger.setAdditive(false); // ルートへの伝播を止めてテスト出力を汚さない
    }

    @AfterEach
    void detachAppender() {
        sqlLogger.detachAppender(appender);
        sqlLogger.setAdditive(true);
    }

    /**
     * 指定 SQL・引数で {@link Invocation} を組み立てる。
     * {@code args[0]} を {@link MappedStatement} とみなす。
     *
     * @param sql {@code getBoundSql().getSql()} が返却する SQL（null 可）
     * @param args インターセプト対象メソッドの引数（先頭が MappedStatement）
     * @return モック化した {@link Invocation}
     */
    private static Invocation invocationWith(String sql, Object[] args) {
        BoundSql boundSql = mock(BoundSql.class);
        when(boundSql.getSql()).thenReturn(sql);
        when(((MappedStatement) args[0]).getBoundSql(any())).thenReturn(boundSql);
        Invocation invocation = mock(Invocation.class);
        when(invocation.getArgs()).thenReturn(args);
        return invocation;
    }

    /** 直近に捕捉したログイベント。 */
    private ILoggingEvent lastEvent() {
        return appender.list.get(appender.list.size() - 1);
    }

    /**
     * 成功時、整形した実行 SQL を INFO・marker（処理時間）付きで出力すること。
     *
     * 試験条件
     * ・proceed() が正常終了する。
     * SQL に改行・連続空白を含む。
     * 観点
     * ・SQL の連続空白を1スペースに畳み、message は実行 SQL のみであること。
     * （件数等は付けない）
     * 想定結果
     * ・INFO で message が「SELECT * FROM t」。
     * marker（latency）が付くこと。
     */
    @Test
    void successLogsNormalizedSqlAtInfo() throws Throwable {
        Invocation invocation = invocationWith("SELECT *\n  FROM t", new Object[] {mock(MappedStatement.class), null});
        when(invocation.proceed()).thenReturn(List.of("a", "b"));

        TARGET.intercept(invocation);

        assertThat(lastEvent().getLevel()).isEqualTo(Level.INFO);
        assertThat(lastEvent().getFormattedMessage()).isEqualTo("SELECT * FROM t");
        assertThat(lastEvent().getMarkerList()).isNotEmpty();
    }

    /**
     * 実行例外時、実行 SQL を ERROR・例外付きで出力し、例外をそのまま再スローすること。
     *
     * 試験条件
     * ・proceed() が例外を投げる。
     * 観点
     * ・例外時は message に実行 SQL、例外を付けて ERROR 出力し、同じ例外を再スローすること。
     * （stack_trace は appender）
     * 想定結果
     * ・ERROR で message「UPDATE t」・スタックトレース付き。
     * 投げた例外がそのまま伝播すること。
     */
    @Test
    void failureLogsSqlAndRethrows() throws Throwable {
        Invocation invocation = invocationWith("UPDATE t", new Object[] {mock(MappedStatement.class), null});
        RuntimeException boom = new RuntimeException("boom");
        when(invocation.proceed()).thenThrow(boom);

        assertThatThrownBy(() -> TARGET.intercept(invocation)).isSameAs(boom);

        assertThat(lastEvent().getLevel()).isEqualTo(Level.ERROR);
        assertThat(lastEvent().getFormattedMessage()).isEqualTo("UPDATE t");
        assertThat(lastEvent().getThrowableProxy()).isNotNull();
    }

    /**
     * SQL が取得できない（null）場合も落ちず出力すること。
     *
     * 試験条件
     * ・getBoundSql().getSql() が null を返却する。
     * 観点
     * ・SQL が null でも整形でぬるぽにならず、message は null とすること。
     * 想定結果
     * ・INFO で message が空であること。
     * （SQL=null）
     */
    @Test
    void nullSqlIsHandled() throws Throwable {
        Invocation invocation = invocationWith(null, new Object[] {mock(MappedStatement.class), null});
        when(invocation.proceed()).thenReturn(List.of("only"));

        TARGET.intercept(invocation);

        assertThat(lastEvent().getFormattedMessage()).isNull();
    }

    /**
     * 引数がパラメータを含まない（要素1つ）場合も、パラメータ null として動くこと。
     *
     * 試験条件
     * ・args が MappedStatement 1要素のみ。
     * （パラメータ無し）
     * 観点
     * ・args の要素数が1なら、SQL 取得のパラメータを null として扱うこと。
     * 想定結果
     * ・message が「SELECT 9」であること。
     */
    @Test
    void singleArgUsesNullParameter() throws Throwable {
        Invocation invocation = invocationWith("SELECT 9", new Object[] {mock(MappedStatement.class)});
        when(invocation.proceed()).thenReturn(List.of("x"));

        TARGET.intercept(invocation);

        assertThat(lastEvent().getFormattedMessage()).isEqualTo("SELECT 9");
    }

    /**
     * 例外時のみモードで成功した場合、ログを出力しないこと。
     *
     * 試験条件
     * ・errorOnly=true のインターセプターで proceed() が正常終了する。
     * 観点
     * ・例外時のみモードでは、成功時の INFO 出力を行わないこと。
     * 想定結果
     * ・ログイベントが1件も出ないこと。
     */
    @Test
    void errorOnlyModeSkipsSuccessLog() throws Throwable {
        Invocation invocation = invocationWith("SELECT 1", new Object[] {mock(MappedStatement.class), null});
        when(invocation.proceed()).thenReturn(List.of("a"));

        TARGET_ERROR_ONLY.intercept(invocation);

        assertThat(appender.list).isEmpty();
    }

    /**
     * 例外時のみモードで例外が発生した場合、ERROR で出力し再スローすること。
     *
     * 試験条件
     * ・errorOnly=true のインターセプターで proceed() が例外を投げる。
     * 観点
     * ・例外時のみモードでも、例外時は通常どおり ERROR 出力し例外を再スローすること。
     * 想定結果
     * ・ERROR で message「UPDATE t」。
     * 投げた例外がそのまま伝播すること。
     */
    @Test
    void errorOnlyModeStillLogsOnFailure() throws Throwable {
        Invocation invocation = invocationWith("UPDATE t", new Object[] {mock(MappedStatement.class), null});
        RuntimeException boom = new RuntimeException("boom");
        when(invocation.proceed()).thenThrow(boom);

        assertThatThrownBy(() -> TARGET_ERROR_ONLY.intercept(invocation)).isSameAs(boom);

        assertThat(lastEvent().getLevel()).isEqualTo(Level.ERROR);
        assertThat(lastEvent().getFormattedMessage()).isEqualTo("UPDATE t");
    }

    /** marker（追加項目）を JSON ノードへ変換する。 */
    private static JsonNode markerOf(ILoggingEvent event) {
        try {
            StringWriter sw = new StringWriter();
            try (JsonGenerator gen = MAPPER.getFactory().createGenerator(sw)) {
                gen.setCodec(MAPPER);
                gen.writeStartObject();
                for (var marker : event.getMarkerList()) {
                    ((LogstashMarker) marker).writeTo(gen);
                }
                gen.writeEndObject();
            }
            return MAPPER.readTree(sw.toString());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /** marker を JSON へ起こす用。 */
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /**
     * 成功・例外いずれの出力でも、marker の latency が数値文字列で存在すること。
     *
     * 試験条件
     * ・成功（INFO）／例外（ERROR）の2パスで intercept する。
     * 観点
     * ・marker の latency キーが存在し、値が文字列化された非負整数であること（件数だけにしない）。
     * 想定結果
     * ・両パスとも latency が数字列（\\d+）で出力されること。
     */
    @Test
    void markerLatencyIsNumericStringOnSuccessAndFailure() throws Throwable {
        // 成功パス
        Invocation ok = invocationWith("SELECT 1", new Object[] {mock(MappedStatement.class), null});
        when(ok.proceed()).thenReturn(List.of("a"));
        TARGET.intercept(ok);
        assertThat(markerOf(lastEvent()).path(LogFields.LATENCY).asText()).matches("\\d+");

        // 例外パス
        Invocation ng = invocationWith("UPDATE t", new Object[] {mock(MappedStatement.class), null});
        when(ng.proceed()).thenThrow(new RuntimeException("boom"));
        assertThatThrownBy(() -> TARGET.intercept(ng)).isInstanceOf(RuntimeException.class);
        assertThat(markerOf(lastEvent()).path(LogFields.LATENCY).asText()).matches("\\d+");
    }
}
