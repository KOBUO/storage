package jp.co.lawson.common.app.lib.logging.sqs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.DefaultApplicationArguments;

/**
 * {@link SqsJobArgumentProvider} の単体テスト。
 */
class SqsJobArgumentProviderTest {

    /**
     * 第1引数を JobIdentifier として取得すること。
     *
     * 試験条件
     * ・非オプション引数を1つ（JOB-A）渡して生成する。
     * 観点
     * ・第1引数を jobIdentifier に採用すること。
     * 想定結果
     * ・jobIdentifier＝JOB-A であること。
     */
    @Test
    void resolvesIdentifierFromFirstArg() {
        SqsJobArgumentProvider p = new SqsJobArgumentProvider(new DefaultApplicationArguments("JOB-A"));

        assertThat(p.getJobIdentifier()).isEqualTo("JOB-A");
    }

    /**
     * 第2引数以降は使用せず、第1引数のみを JobIdentifier とすること。
     *
     * 試験条件
     * ・非オプション引数を2つ（JOB-A／EXTRA）渡して生成する。
     * 観点
     * ・識別子のみを保持し、余分な引数は無視すること。
     * 想定結果
     * ・jobIdentifier＝JOB-A であること。
     */
    @Test
    void ignoresExtraNonOptionArgs() {
        SqsJobArgumentProvider p = new SqsJobArgumentProvider(new DefaultApplicationArguments("JOB-A", "EXTRA"));

        assertThat(p.getJobIdentifier()).isEqualTo("JOB-A");
    }

    /**
     * 第1引数（JobIdentifier）が無い場合、例外を送出すること。
     *
     * 試験条件
     * ・非オプション引数なしで生成する。
     * 観点
     * ・JobIdentifier 未設定を不正として扱うこと。
     * 想定結果
     * ・IllegalArgumentException を送出すること。
     */
    @Test
    void throwsWhenJobIdentifierMissing() {
        assertThatThrownBy(() -> new SqsJobArgumentProvider(new DefaultApplicationArguments()))
                .isInstanceOf(IllegalArgumentException.class);
    }

    /**
     * 第1引数（JobIdentifier）が空白のみの場合、例外を送出すること。
     *
     * 試験条件
     * ・非オプション引数に空白文字のみを渡して生成する。
     * 観点
     * ・空白のみの JobIdentifier を不正として扱うこと。
     * 想定結果
     * ・IllegalArgumentException を送出すること。
     */
    @Test
    void throwsWhenJobIdentifierBlank() {
        assertThatThrownBy(() -> new SqsJobArgumentProvider(new DefaultApplicationArguments(" ")))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
