package jp.co.lawson.common.app.lib.logging;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

import net.logstash.logback.composite.loggingevent.LogstashMarkersJsonProvider;
import net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder;
import net.logstash.logback.marker.LogstashMarker;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggingEvent;

/**
 * {@link StructuredLog} の単体テスト。
 */
class StructuredLogTest {

    /**
     * marker を 1 件のログイベントとしてエンコードし、項目の JSON を返却する。
     *
     * @param marker 付与するマーカー
     * @return エンコード後の JSON
     */
    private String encode(LogstashMarker marker) {
        LoggerContext context = new LoggerContext();
        LoggingEventCompositeJsonEncoder encoder = new LoggingEventCompositeJsonEncoder();
        encoder.setContext(context);
        encoder.getProviders().addProvider(new LogstashMarkersJsonProvider());
        encoder.start();

        Logger logger = context.getLogger("test");
        LoggingEvent event = new LoggingEvent("fqcn", logger, Level.INFO, "msg", null, null);
        event.addMarker(marker);
        return new String(encoder.encode(event), UTF_8);
    }

    /**
     * put は null を捨て、数値・真偽値を文字列化し、文字列はそのまま出力すること。
     *
     * 試験条件
     * ・put で 数値・真偽値・文字列・null を追加して marker を生成する。
     * 観点
     * ・null は項目化せず、数値/真偽値は文字列、文字列はそのまま出力すること。
     * 想定結果
     * ・"num":"12"・"bool":"true"・"str":"x" が出力され、null の項目は出力されないこと。
     */
    @Test
    void putSkipsNullAndStringifiesScalars() {
        String out = encode(StructuredLog.create()
                .put("num", 12)
                .put("bool", true)
                .put("str", "x")
                .put("none", null)
                .marker());

        assertThat(out).contains("\"num\":\"12\"");
        assertThat(out).contains("\"bool\":\"true\"");
        assertThat(out).contains("\"str\":\"x\"");
        assertThat(out).doesNotContain("none");
    }

    /**
     * putNullable は null を文字列 "null" として出力すること。
     *
     * 試験条件
     * ・putNullable で null と数値を追加して marker を生成する。
     * 観点
     * ・値なしを欠落させず文字列 "null" で揃え、値ありは文字列化すること。
     * 想定結果
     * ・"absent":"null"・"present":"5" が出力されること。
     */
    @Test
    void putNullableOutputsNullPlaceholder() {
        String out = encode(StructuredLog.create()
                .putNullable("absent", null)
                .putNullable("present", 5)
                .marker());

        assertThat(out).contains("\"absent\":\"-\"");
        assertThat(out).contains("\"present\":\"5\"");
    }

    /**
     * Map・配列・その他オブジェクトは文字列化せず、構造のまま出力すること（normalize は数値/真偽のみ文字列化）。
     *
     * 試験条件
     * ・put で Map と List を追加して marker を生成する。
     * 観点
     * ・数値・真偽以外（Map/配列）は toString 化せず、JSON 構造として出力すること。
     * 想定結果
     * ・"obj":{"k":"v"}・"arr":["a","b"] が構造のまま出力されること。
     */
    @Test
    void putKeepsMapAndArrayAsStructure() {
        String out = encode(StructuredLog.create()
                .put("obj", java.util.Map.of("k", "v"))
                .put("arr", java.util.List.of("a", "b"))
                .marker());

        assertThat(out).contains("\"obj\":{\"k\":\"v\"}");
        assertThat(out).contains("\"arr\":[\"a\",\"b\"]");
    }
}
