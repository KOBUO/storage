// TODO errorCode は仮値。API共通仕様書で確定する。
var ERRORS = {
    XXX1: { status: 503, message: 'リクエストのレートまたは同時接続数が上限を超えました。' },
    XXX2: { status: 500, message: 'サーバ内部でエラーが発生しました。' },
};

var INTERNAL_ERROR = 'XXX2';

function errorCodeOf(status) {
    for (var code in ERRORS) {
        if (ERRORS[code].status === status) {
            return code;
        }
    }
    return null;
}

function respondError(r, code) {
    var error = ERRORS[code];
    r.variables.error_code = code;
    r.headersOut['Content-Type'] = 'application/json';
    r.return(error.status, JSON.stringify({
        status: String(error.status),
        errors: [{ errorCode: code, errorMessage: error.message }],
    }));
}

// Nginx が生成したエラー応答を JSON 形式に差し替える。
// error_page からの呼び出し時点では r.status が未確定のため、$status から元の応答コードを取る。
function errorResponse(r) {
    var code = errorCodeOf(Number(r.variables.status));
    respondError(r, code || INTERNAL_ERROR);
}

function logLevel(r) {
    return r.variables.error_code ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    var code = r.variables.error_code;
    return code ? ERRORS[code].message : '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { errorResponse, logLevel, logMessage, logLatency, logTimestamp };
