var BANDWIDTH_HEADER = 'nwBandwidthControlHeader';
var POS_VERSION_PARAMETER = 'posVersion';
var CONTEXT_PATH = '/download/';
var OFFLINE_PATH = '/download/offline/';

// fromS3 は S3 が返却したエラーを変換したもの、generatedByNginx は Nginx 自身が生成したもの。
// TODO errorCode は仮値。API共通仕様書で確定する。
var ERRORS = {
    XXX1: { status: 400, message: '帯域制限値が設定されていません。' },
    XXX2: { status: 400, message: '帯域制限値が不正です。' },
    XXX3: { status: 400, message: 'POSバージョンが設定されていません。' },
    XXX4: { status: 404, message: '対象外のパスです。' },
    XXX5: { status: 403, message: 'ファイルへのアクセスが許可されていません。', fromS3: true },
    XXX6: { status: 404, message: 'ファイルが存在しません。', fromS3: true },
    XXX7: { status: null, message: 'S3 からエラーが返却されました。', fromS3: true },
    XXX8: { status: 502, message: 'S3 へ接続できません。', generatedByNginx: true },
    XXX9: { status: 504, message: 'S3 からの応答がタイムアウトしました。', generatedByNginx: true },
    XXX10: { status: 500, message: 'サーバ内部でエラーが発生しました。', generatedByNginx: true },
};

var BANDWIDTH_MISSING = 'XXX1';
var BANDWIDTH_INVALID = 'XXX2';
var POS_VERSION_MISSING = 'XXX3';
var PATH_NOT_SUPPORTED = 'XXX4';
var S3_OTHER_ERROR = 'XXX7';
var INTERNAL_ERROR = 'XXX10';

// S3 が応答を返していれば受信バイト数が入る。未接続・無応答の場合は Nginx 自身が生成した応答。
function respondedByS3(r) {
    var received = r.variables.upstream_bytes_received;
    return Boolean(received) && received !== '0';
}

function errorCodeOf(status, origin) {
    for (var code in ERRORS) {
        if (ERRORS[code][origin] && ERRORS[code].status === status) {
            return code;
        }
    }
    return null;
}

function respondError(r, code, status) {
    var error = ERRORS[code];
    var responseStatus = status || error.status;
    r.variables.error_code = code;
    r.headersOut['Content-Type'] = 'application/json';
    r.return(responseStatus, JSON.stringify({
        status: String(responseStatus),
        errors: [{ errorCode: code, errorMessage: error.message }],
    }));
}

function queryParameters(r) {
    var parameters = {};
    (r.variables.args || '').split('&').forEach(function (pair) {
        if (!pair) {
            return;
        }
        var separator = pair.indexOf('=');
        var name = separator < 0 ? pair : pair.substring(0, separator);
        parameters[name] = separator < 0 ? '' : pair.substring(separator + 1);
    });
    return parameters;
}

// クエリパラメータが残る場合のみ "?" を付けた文字列を返す。
function buildQuery(parameters) {
    var query = Object.keys(parameters).map(function (name) {
        return name + '=' + parameters[name];
    }).join('&');
    return query ? '?' + query : '';
}

// オフラインファイルダウンロードは、バケット名と POSバージョンを Nginx がオブジェクトキーへ組み込む。
function buildOfflineKey(r) {
    var parameters = queryParameters(r);
    var posVersion = parameters[POS_VERSION_PARAMETER];
    if (!posVersion) {
        return null;
    }
    delete parameters[POS_VERSION_PARAMETER];
    r.variables.s3_args = buildQuery(parameters);

    var fileName = r.uri.substring(OFFLINE_PATH.length);
    return '/' + r.variables.offline_bucket + '/' + posVersion + '/' + fileName;
}

function handle(r) {
    var bandwidth = r.headersIn[BANDWIDTH_HEADER];
    if (!bandwidth) {
        respondError(r, BANDWIDTH_MISSING);
        return;
    }
    if (!/^[0-9]+$/.test(bandwidth)) {
        respondError(r, BANDWIDTH_INVALID);
        return;
    }

    if (!r.uri.startsWith(CONTEXT_PATH)) {
        respondError(r, PATH_NOT_SUPPORTED);
        return;
    }

    var key;
    if (r.uri.startsWith(OFFLINE_PATH)) {
        key = buildOfflineKey(r);
        if (!key) {
            respondError(r, POS_VERSION_MISSING);
            return;
        }
    } else {
        key = r.uri.substring(CONTEXT_PATH.length - 1);
        r.variables.s3_args = r.variables.args ? '?' + r.variables.args : '';
    }

    r.variables.limit_rate = bandwidth;
    r.variables.s3_key = key;
    r.internalRedirect('@s3');
}

// Nginx が生成したエラー応答、および S3 が返却したエラー応答を、エラー電文に差し替える。
// error_page からの呼び出し時点では r.status が未確定のため、$status から元の応答コードを取る。
function errorResponse(r) {
    var status = Number(r.variables.status);
    if (respondedByS3(r)) {
        var code = errorCodeOf(status, 'fromS3');
        respondError(r, code || S3_OTHER_ERROR, status);
        return;
    }
    respondError(r, errorCodeOf(status, 'generatedByNginx') || INTERNAL_ERROR);
}

function logLevel(r) {
    var code = r.variables.error_code;
    return code && !ERRORS[code].fromS3 ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    var code = r.variables.error_code;
    return code ? ERRORS[code].message : '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { handle, errorResponse, logLevel, logMessage, logLatency, logTimestamp };
