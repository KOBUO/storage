#!/bin/sh
set -eu

# ---- コンテナIDおよびコンテナ名の取得 ----
# タスクメタデータエンドポイントは Fargate でのみ提供される。取得できない場合は "-" とする。
CONTAINER_ID="-"
CONTAINER_NAME="-"
if [ -n "${ECS_CONTAINER_METADATA_URI_V4:-}" ]; then
    metadata=$(curl -sf --max-time 3 "$ECS_CONTAINER_METADATA_URI_V4" || true)
    if [ -n "$metadata" ]; then
        CONTAINER_ID=$(echo "$metadata" | jq -r '.DockerId // "-"')
        CONTAINER_NAME=$(echo "$metadata" | jq -r '.Name // "-"')
    fi
fi
export CONTAINER_ID CONTAINER_NAME

exec python loader.py
