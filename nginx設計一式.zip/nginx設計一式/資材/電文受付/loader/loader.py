#!/usr/bin/env python3
"""ルーティング情報を Aurora DB から取得し、共有ボリュームへ出力する。

ワンショット実行。異常時は非0で終了し、Nginx コンテナを起動させない。
"""
import json
import os
import sys
from datetime import datetime

import psycopg2

ROUTING_FILE_PATH = "/shared/routing.json"

# TODO 列名はテーブル定義書の入手後に確定する。
SQL_ROUTING = """
SELECT store_code, request_context_path, request_version, routing_url
FROM routing
"""

SQL_DEFAULT_ROUTING = """
SELECT request_context_path, request_version, routing_url
FROM default_routing
"""


def log_error(message):
    now = datetime.now()
    record = {
        "timestamp": now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}",
        "id": os.environ.get("CONTAINER_ID", "-"),
        "name": os.environ.get("CONTAINER_NAME", "-"),
        "level": "ERROR",
        "level_value": 40000,
        "type": "monitor",
        "thread": "-",
        "function": "-",
        "user": "-",
        "action": "-",
        "subtype": "NGINX",
        "trace": "-",
        "message": message,
    }
    print(json.dumps(record, ensure_ascii=False), file=sys.stderr)


def abort(message):
    log_error(message)
    sys.exit(1)


def required_env(name):
    value = os.environ.get(name)
    if not value:
        abort(f"必須環境変数が設定されていません。（環境変数名: {name}）")
    return value


def connect():
    host = required_env("DATABASE_HOST")
    port = required_env("DATABASE_PORT")
    try:
        return psycopg2.connect(
            host=host,
            port=port,
            dbname=required_env("DATABASE_NAME"),
            user=required_env("DATABASE_USER"),
            password=required_env("DATABASE_PASSWORD"),
            connect_timeout=int(os.environ.get("DATABASE_CONNECT_TIMEOUT", "5")),
        )
    except psycopg2.Error:
        abort(f"データベースへの接続に失敗しました。（接続先: {host}:{port}）")


def fetch(connection):
    """検索キーからルーティング先のURLを引ける形に整形する。"""
    routing = {}
    default_routing = {}

    with connection.cursor() as cursor:
        try:
            cursor.execute(SQL_ROUTING)
            for store_code, context_path, version, url in cursor.fetchall():
                routing[f"{store_code}|{context_path}|{version}"] = url
        except psycopg2.Error:
            abort("ルーティング情報の取得に失敗しました。（対象: routing）")

        try:
            cursor.execute(SQL_DEFAULT_ROUTING)
            for context_path, version, url in cursor.fetchall():
                default_routing[f"{context_path}|{version}"] = url
        except psycopg2.Error:
            abort("ルーティング情報の取得に失敗しました。（対象: default_routing）")

    if not default_routing:
        abort("デフォルトルーティング情報が取得できませんでした。")

    return {"routing": routing, "default_routing": default_routing}


def write(routing_information, path):
    # 書き込み途中のファイルを Nginx に読ませないため、一時ファイル経由で差し替える。
    temporary_path = path + ".tmp"
    try:
        with open(temporary_path, "w", encoding="utf-8") as f:
            json.dump(routing_information, f, ensure_ascii=False)
        os.replace(temporary_path, path)
    except OSError:
        abort(f"ルーティング情報ファイルの出力に失敗しました。（出力先: {path}）")


def main():
    connection = connect()
    try:
        routing_information = fetch(connection)
    finally:
        connection.close()
    write(routing_information, ROUTING_FILE_PATH)


if __name__ == "__main__":
    main()
