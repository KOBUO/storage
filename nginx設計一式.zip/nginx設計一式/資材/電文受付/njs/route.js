import routes from '/etc/nginx/njs/routes.js';

var STORE_CODE_HEADER = 'X-Store-Cd';

// generatedByNginx は Nginx 自身が生成する応答であることを示す。
// Nginx はステータス以外に理由を示す情報を持たないため、これらは1ステータスにつき1件とする。
// TODO errorCode は仮値。API共通仕様書で確定する。
var ERRORS = {
    XXX1: { status: 400, message: '店舗コードが設定されていません。' },
    XXX2: { status: 404, message: 'ルーティング先が特定できません。' },
    XXX3: { status: 503, message: 'リクエストのレートまたは同時接続数が上限を超えました。', generatedByNginx: true },
    XXX4: { status: 502, message: 'バックエンドサービスへ接続できません。', generatedByNginx: true },
    XXX5: { status: 504, message: 'バックエンドサービスからの応答がタイムアウトしました。', generatedByNginx: true },
    XXX6: { status: 500, message: 'サーバ内部でエラーが発生しました。', generatedByNginx: true },
};

var STORE_CODE_MISSING = 'XXX1';
var ROUTE_NOT_FOUND = 'XXX2';
var INTERNAL_ERROR = 'XXX6';

function nginxErrorCodeOf(status) {
    for (var code in ERRORS) {
        if (ERRORS[code].generatedByNginx && ERRORS[code].status === status) {
            return code;
        }
    }
    return null;
}

function respondError(r, code) {
    var error = ERRORS[code];
    // ログ出力時に応答したエラーを参照できるよう保持する。
    r.variables.error_code = code;
    r.headersOut['Content-Type'] = 'application/json';
    r.return(error.status, JSON.stringify({
        status: String(error.status),
        errors: [{ errorCode: code, errorMessage: error.message }],
    }));
}

// リクエストURI /{コンテキストパス}/{バージョン}/{API名} から検索キーの構成要素を取り出す。
function splitUri(uri) {
    var segments = uri.split('/').filter(function (segment) {
        return segment !== '';
    });
    if (segments.length < 2) {
        return null;
    }
    return { contextPath: segments[0], version: segments[1] };
}

function lookupUpstream(storeCode, path) {
    var storeKey = storeCode + '|' + path.contextPath + '|' + path.version;
    var defaultKey = path.contextPath + '|' + path.version;
    return routes.routing[storeKey] || routes.default_routing[defaultKey] || null;
}

function handle(r) {
    var storeCode = r.headersIn[STORE_CODE_HEADER];
    if (!storeCode) {
        respondError(r, STORE_CODE_MISSING);
        return;
    }

    var path = splitUri(r.uri);
    var upstream = path ? lookupUpstream(storeCode, path) : null;
    if (!upstream) {
        respondError(r, ROUTE_NOT_FOUND);
        return;
    }

    r.variables.upstream = upstream;
    r.internalRedirect('@backend');
}

// Nginx が生成したエラー応答を JSON 形式に差し替える。
// error_page からの呼び出し時点では r.status が未確定のため、$status から元の応答コードを取る。
function errorResponse(r) {
    var code = nginxErrorCodeOf(Number(r.variables.status));
    respondError(r, code || INTERNAL_ERROR);
}

// エラーコードが設定されているのは、Nginx がエラー応答を返した場合のみ。
// バックエンドサービスが返したエラーは Nginx としては正常処理のため INFO とする。
function logLevel(r) {
    return r.variables.error_code ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    var code = r.variables.error_code;
    return code ? ERRORS[code].message : '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { handle, errorResponse, logLevel, logMessage, logLatency, logTimestamp };
