package jp.co.lawson.common.app.lib.logging.api;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;

import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import jakarta.servlet.ServletInputStream;

/**
 * {@link CachedBodyRequestWrapper} の単体テスト。
 */
class CachedBodyRequestWrapperTest {

    /**
     * 指定ボディ・文字エンコーディングのリクエストを組み立てる。
     *
     * @param body リクエストボディ
     * @param encoding 文字エンコーディング（null 可）
     * @return モックリクエスト
     */
    private static MockHttpServletRequest request(String body, String encoding) {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setContent(body.getBytes(UTF_8));
        if (encoding != null) {
            request.setCharacterEncoding(encoding);
        }
        return request;
    }

    /**
     * ボディをキャッシュし、入力ストリームで（複数回）再読込できること。
     *
     * 試験条件
     * ・ボディ付きリクエストをラップする。
     * 観点
     * ・getCachedBody とキャッシュ済みストリームから同じボディを取得できること。
     * ・getInputStream を再度呼び出しても、新しいストリームが先頭から同じボディを再読込できること。
     * 想定結果
     * ・getCachedBody・getInputStream とも元のボディに一致し、読み切ると isFinished が true になること。
     * ・2 回目の getInputStream も未読（isFinished=false）から始まり、元のボディに一致すること。
     */
    @Test
    void cachesBodyAndReadsViaInputStream() throws IOException {
        CachedBodyRequestWrapper wrapper = new CachedBodyRequestWrapper(request("{\"x\":1}", null));

        assertThat(new String(wrapper.getCachedBody(), UTF_8)).isEqualTo("{\"x\":1}");

        // 1 回目：読み切ると isFinished=true
        ServletInputStream in = wrapper.getInputStream();
        assertThat(in.isReady()).isTrue();
        assertThat(in.isFinished()).isFalse();
        assertThat(new String(in.readAllBytes(), UTF_8)).isEqualTo("{\"x\":1}");
        assertThat(in.isFinished()).isTrue();

        // 2 回目：再取得したストリームが先頭から再読込できる（要求ジャーナル→業務処理の二度読みを担保）
        ServletInputStream again = wrapper.getInputStream();
        assertThat(again.isFinished()).as("再取得は未読から開始").isFalse();
        assertThat(new String(again.readAllBytes(), UTF_8)).as("二度目も先頭から同一ボディ").isEqualTo("{\"x\":1}");
    }

    /**
     * getReader が request の文字エンコーディングを使用すること。
     *
     * 試験条件
     * ・文字エンコーディング UTF-8 を指定したリクエストをラップする。
     * 観点
     * ・指定エンコーディングでボディをリーダーから読めること。
     * 想定結果
     * ・リーダーから元のボディを読めること。
     */
    @Test
    void getReaderUsesRequestEncoding() throws IOException {
        CachedBodyRequestWrapper wrapper = new CachedBodyRequestWrapper(request("あ", "UTF-8"));

        assertThat(wrapper.getReader().readLine()).isEqualTo("あ");
    }

    /**
     * 文字エンコーディング未指定なら UTF-8 を使用すること。
     *
     * 試験条件
     * ・文字エンコーディングを指定しないリクエストをラップする。
     * 観点
     * ・エンコーディングが無い場合は UTF-8 で読むこと。
     * 想定結果
     * ・リーダーから元のボディ（マルチバイト）を読めること。
     */
    @Test
    void getReaderDefaultsToUtf8() throws IOException {
        CachedBodyRequestWrapper wrapper = new CachedBodyRequestWrapper(request("あ", null));

        assertThat(wrapper.getReader().readLine()).isEqualTo("あ");
    }

    /**
     * setReadListener は非対応で例外を投げること。
     *
     * 試験条件
     * ・キャッシュ済み入力ストリームの setReadListener を呼ぶ。
     * 観点
     * ・非同期読み取りは未対応とすること。
     * 想定結果
     * ・UnsupportedOperationException を投げること。
     */
    @Test
    void setReadListenerThrows() throws IOException {
        ServletInputStream in = new CachedBodyRequestWrapper(request("x", null)).getInputStream();

        assertThatThrownBy(() -> in.setReadListener(null)).isInstanceOf(UnsupportedOperationException.class);
    }
}
