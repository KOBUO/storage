package jp.co.lawson.common.app.lib.logging.api;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletResponse;
import net.logstash.logback.marker.LogstashMarker;

import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;
import jp.co.lawson.common.app.lib.logging.constant.MdcKeys;

/**
 * {@link ApiAccessLogFilter} の単体テスト。
 *
 * <p>各テストは MDC（チェーン実行中の値）と marker（url／status／headers／body／latency）の両方を検証する。
 * 固定メッセージは廃止され、ログのメッセージは空文字（{@code ""}）。要求/応答ジャーナルは出力順で区別する。
 */
class ApiAccessLogFilterTest {

    /** テスト対象。状態を保持しないため全テストで共有する。 */
    private static final ApiAccessLogFilter TARGET = new ApiAccessLogFilter();
    /** marker（LogstashMarker）を JSON へ起こす用。 */
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** アクセスログ（SPRINGBOOT_API_ACCESS_LOG）の出力捕捉用 appender。 */
    private ListAppender<ILoggingEvent> accessAppender;
    /** アクセスジャーナルログ（SPRINGBOOT_API_ACCESS_JNL_LOG）の出力捕捉用 appender。 */
    private ListAppender<ILoggingEvent> journalAppender;
    private Logger accessLogger;
    private Logger journalLogger;

    /** チェーン実行中（MDC 有効中）に観測した MDC 値。 */
    private final Map<String, String> mdcDuringChain = new HashMap<>();

    @BeforeEach
    void attachAppenders() {
        accessLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.API_ACCESS);
        journalLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.API_ACCESS_JNL);
        accessAppender = attach(accessLogger);
        journalAppender = attach(journalLogger);
    }

    @AfterEach
    void detachAppenders() {
        accessLogger.detachAppender(accessAppender);
        accessLogger.setAdditive(true);
        journalLogger.detachAppender(journalAppender);
        journalLogger.setAdditive(true);
        MDC.clear();
    }

    /**
     * 指定ロガーに捕捉用 appender を付与する。
     *
     * @param logger 対象ロガー
     * @return 取り付けた appender
     */
    private static ListAppender<ILoggingEvent> attach(Logger logger) {
        ListAppender<ILoggingEvent> appender = new ListAppender<>();
        appender.start();
        logger.addAppender(appender);
        logger.setLevel(Level.INFO);
        logger.setAdditive(false); // ルートへの伝播を止めてテスト出力を汚さない
        return appender;
    }

    /** チェーン実行中の MDC を控える（全キー）。 */
    private void captureMdc() {
        for (String key : new String[] {MdcKeys.FUNCTION, MdcKeys.ACTION, MdcKeys.TRACE_ID, MdcKeys.USER, MdcKeys.SOURCE_IP}) {
            mdcDuringChain.put(key, MDC.get(key));
        }
    }

    /** チェーン実行中の MDC を控え、レスポンスへ status/header/body を書く擬似 FilterChain。 */
    private FilterChain chain(int status, String responseBody) {
        return (req, res) -> {
            captureMdc();
            HttpServletResponse httpRes = (HttpServletResponse) res;
            httpRes.setStatus(status);
            httpRes.addHeader("Content-Type", "application/json"); // responseHeaders のループを通す
            if (responseBody != null) {
                res.getWriter().write(responseBody);
            }
        };
    }

    /** イベントの marker（追加項目）を JSON ノードへ変換する。 */
    private static JsonNode markerOf(ILoggingEvent event) {
        try {
            StringWriter sw = new StringWriter();
            try (JsonGenerator gen = MAPPER.getFactory().createGenerator(sw)) {
                gen.setCodec(MAPPER); // Map 値（headers 等）の writeObject に codec が要る
                gen.writeStartObject();
                for (var marker : event.getMarkerList()) {
                    ((LogstashMarker) marker).writeTo(gen);
                }
                gen.writeEndObject();
            }
            return MAPPER.readTree(sw.toString());
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * ヘッダ・クエリ・ボディが揃ったリクエスト（クエリパラメータ指定ケース）。
     *
     * 観点：アクセスログ1件＋ジャーナル（要求/応答）2件を出力し、各 marker と MDC（action 含む）が期待どおりであること。
     */
    @Test
    void fullRequestLogsAccessAndJournals() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/orders");
        request.setQueryString("a=1");
        request.addHeader("X-Trace-ID", "t1");
        request.addHeader("X-User-ID", "u1");
        request.addHeader("X-Forwarded-For", "203.0.113.5, 10.0.0.1");
        request.setContent("{\"in\":1}".getBytes(UTF_8));
        MockHttpServletResponse response = new MockHttpServletResponse();

        TARGET.doFilterInternal(request, response, chain(200, "{\"ok\":true}"));

        // 件数・メッセージ（固定メッセージ廃止 → 空文字）
        assertThat(accessAppender.list).hasSize(1);
        assertThat(journalAppender.list).hasSize(2);
        assertThat(accessAppender.list.get(0).getFormattedMessage()).as("access message").isEmpty();
        assertThat(journalAppender.list).extracting(ILoggingEvent::getFormattedMessage).containsExactly("", "");

        JsonNode reqJnl = markerOf(journalAppender.list.get(0)); // 要求（処理前）
        JsonNode access = markerOf(accessAppender.list.get(0));  // サマリ
        JsonNode resJnl = markerOf(journalAppender.list.get(1)); // 応答（処理後）

        // url はクエリ込み（function/action はクエリ無し＝下の MDC で確認）
        assertThat(reqJnl.path("url").asText()).as("req url").isEqualTo("POST /api/orders?a=1");
        assertThat(access.path("url").asText()).as("access url").isEqualTo("POST /api/orders?a=1");
        assertThat(resJnl.path("url").asText()).as("res url").isEqualTo("POST /api/orders?a=1");

        // 要求ジャーナル：status/latency は前後ペア統一で "null"、headers・body は要求側
        assertThat(reqJnl.path("status").asText()).as("req status").isEqualTo("-");
        assertThat(reqJnl.path("latency").asText()).as("req latency").isEqualTo("-");
        assertThat(reqJnl.path("headers").path("X-Trace-ID").asText()).isEqualTo("t1");
        assertThat(reqJnl.path("headers").path("X-User-ID").asText()).isEqualTo("u1");
        assertThat(reqJnl.path("headers").path("X-Forwarded-For").asText()).isEqualTo("203.0.113.5, 10.0.0.1");
        assertThat(reqJnl.path("body").asText()).as("req body").isEqualTo("{\"in\":1}");

        // アクセスログ（サマリ）：url/status/latency のみ。headers・body は持たない
        assertThat(access.path("status").asText()).as("access status").isEqualTo("200");
        assertThat(access.path("latency").asText()).as("access latency 数値文字列").matches("\\d+");
        assertThat(access.has("headers")).as("access に headers 無し").isFalse();
        assertThat(access.has("body")).as("access に body 無し").isFalse();

        // 応答ジャーナル：status・latency は実値、headers・body は応答側
        assertThat(resJnl.path("status").asText()).as("res status").isEqualTo("200");
        assertThat(resJnl.path("latency").asText()).as("res latency 数値文字列").matches("\\d+");
        assertThat(resJnl.path("headers").path("Content-Type").asText()).isEqualTo("application/json");
        assertThat(resJnl.path("body").asText()).as("res body").isEqualTo("{\"ok\":true}");

        // MDC（チェーン中）。function/action はクエリを含まない
        assertThat(mdcDuringChain.get(MdcKeys.FUNCTION)).as("function").isEqualTo("POST /api/orders");
        assertThat(mdcDuringChain.get(MdcKeys.ACTION)).as("action").isEqualTo("POST /api/orders");
        assertThat(mdcDuringChain.get(MdcKeys.USER)).as("user").isEqualTo("u1");
        assertThat(mdcDuringChain.get(MdcKeys.TRACE_ID)).as("trace").isEqualTo("t1");
        assertThat(mdcDuringChain.get(MdcKeys.SOURCE_IP)).as("source_ip").isEqualTo("203.0.113.5");

        assertThat(MDC.get(MdcKeys.TRACE_ID)).as("終了後クリア").isNull();
        assertThat(response.getContentAsString()).as("書き戻し").isEqualTo("{\"ok\":true}");
    }

    /**
     * X-Trace-ID・X-User-ID・X-Forwarded-For・クエリ・ボディが無い場合の既定動作。
     *
     * 観点：trace は UUID 自動採番、source_ip は remoteAddr、user は未設定。url にクエリは付かず、headers は空・body は無し。
     */
    @Test
    void missingHeadersGeneratesTraceAndUsesRemoteAddr() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/ping");
        request.setRemoteAddr("198.51.100.7");
        MockHttpServletResponse response = new MockHttpServletResponse();

        TARGET.doFilterInternal(request, response, chain(204, null));

        assertThat(accessAppender.list).hasSize(1);
        assertThat(journalAppender.list).hasSize(2);

        JsonNode reqJnl = markerOf(journalAppender.list.get(0));
        JsonNode access = markerOf(accessAppender.list.get(0));
        JsonNode resJnl = markerOf(journalAppender.list.get(1));

        assertThat(reqJnl.path("url").asText()).isEqualTo("GET /api/ping");
        assertThat(access.path("url").asText()).isEqualTo("GET /api/ping");
        assertThat(resJnl.path("url").asText()).isEqualTo("GET /api/ping");

        // 要求：status/latency="null"、headers は空、body は無し
        assertThat(reqJnl.path("status").asText()).isEqualTo("-");
        assertThat(reqJnl.path("latency").asText()).isEqualTo("-");
        assertThat(reqJnl.path("headers").size()).as("要求 headers 空").isZero();
        assertThat(reqJnl.has("body")).as("空ボディは body 項目なし").isFalse();

        assertThat(access.path("status").asText()).isEqualTo("204");
        assertThat(access.path("latency").asText()).matches("\\d+");

        // 応答：status=204、Content-Type のみ、body 無し
        assertThat(resJnl.path("status").asText()).isEqualTo("204");
        assertThat(resJnl.path("latency").asText()).matches("\\d+");
        assertThat(resJnl.path("headers").path("Content-Type").asText()).isEqualTo("application/json");
        assertThat(resJnl.has("body")).isFalse();

        // MDC
        assertThat(mdcDuringChain.get(MdcKeys.FUNCTION)).isEqualTo("GET /api/ping");
        assertThat(mdcDuringChain.get(MdcKeys.ACTION)).isEqualTo("GET /api/ping");
        assertThat(mdcDuringChain.get(MdcKeys.TRACE_ID)).isNotNull().isNotEqualTo("t1");
        assertThat(mdcDuringChain.get(MdcKeys.SOURCE_IP)).isEqualTo("198.51.100.7");
        assertThat(mdcDuringChain.get(MdcKeys.USER)).as("user 未設定").isNull();

        assertThat(MDC.get(MdcKeys.TRACE_ID)).isNull();
    }

    /**
     * X-Trace-ID・X-User-ID・X-Forwarded-For が空白の場合も既定動作になること。
     *
     * 観点：空白は無効として trace は自動採番・source_ip は remoteAddr・user 未設定。空白ヘッダは要求 headers には残る。
     */
    @Test
    void blankHeadersAreTreatedAsAbsent() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/ping");
        request.addHeader("X-Trace-ID", "  ");
        request.addHeader("X-User-ID", "  ");
        request.addHeader("X-Forwarded-For", "  ");
        request.setRemoteAddr("198.51.100.9");
        MockHttpServletResponse response = new MockHttpServletResponse();

        TARGET.doFilterInternal(request, response, chain(200, null));

        assertThat(accessAppender.list).hasSize(1);
        assertThat(journalAppender.list).hasSize(2);

        JsonNode reqJnl = markerOf(journalAppender.list.get(0));
        JsonNode access = markerOf(accessAppender.list.get(0));
        JsonNode resJnl = markerOf(journalAppender.list.get(1));

        assertThat(reqJnl.path("url").asText()).isEqualTo("GET /api/ping");
        assertThat(reqJnl.path("status").asText()).isEqualTo("-");
        assertThat(reqJnl.path("latency").asText()).isEqualTo("-");
        assertThat(reqJnl.path("headers").path("X-Trace-ID").asText()).as("空白でも要求 headers には出る").isEqualTo("  ");
        assertThat(reqJnl.has("body")).isFalse();

        assertThat(access.path("status").asText()).isEqualTo("200");
        assertThat(access.path("latency").asText()).matches("\\d+");

        assertThat(resJnl.path("status").asText()).isEqualTo("200");
        assertThat(resJnl.path("headers").path("Content-Type").asText()).isEqualTo("application/json");
        assertThat(resJnl.has("body")).isFalse();

        assertThat(mdcDuringChain.get(MdcKeys.FUNCTION)).isEqualTo("GET /api/ping");
        assertThat(mdcDuringChain.get(MdcKeys.ACTION)).isEqualTo("GET /api/ping");
        assertThat(mdcDuringChain.get(MdcKeys.TRACE_ID)).isNotBlank().isNotEqualTo("  ");
        assertThat(mdcDuringChain.get(MdcKeys.SOURCE_IP)).isEqualTo("198.51.100.9");
        assertThat(mdcDuringChain.get(MdcKeys.USER)).as("空白 user は未設定").isNull();

        assertThat(MDC.get(MdcKeys.TRACE_ID)).isNull();
    }

    /**
     * チェーンが例外を投げても、ログ出力・MDC クリアを行い例外を伝播すること。
     *
     * 観点：要求は処理前、サマリと応答は finally で status=500 を出力し、最後に MDC をクリアして例外を伝播すること。
     */
    @Test
    void chainExceptionStillLogsAndClearsMdc() {
        MockHttpServletRequest request = new MockHttpServletRequest("GET", "/api/boom");
        request.addHeader("X-Trace-ID", "t-err");
        MockHttpServletResponse response = new MockHttpServletResponse();
        FilterChain boom = (req, res) -> {
            captureMdc();
            ((HttpServletResponse) res).setStatus(500);
            throw new ServletException("boom");
        };

        assertThatThrownBy(() -> TARGET.doFilterInternal(request, response, boom))
                .isInstanceOf(ServletException.class);

        assertThat(accessAppender.list).hasSize(1);
        assertThat(journalAppender.list).hasSize(2);

        JsonNode reqJnl = markerOf(journalAppender.list.get(0));
        JsonNode access = markerOf(accessAppender.list.get(0));
        JsonNode resJnl = markerOf(journalAppender.list.get(1));

        assertThat(reqJnl.path("url").asText()).isEqualTo("GET /api/boom");
        assertThat(reqJnl.path("status").asText()).isEqualTo("-");
        assertThat(reqJnl.path("latency").asText()).isEqualTo("-");
        assertThat(reqJnl.path("headers").path("X-Trace-ID").asText()).isEqualTo("t-err");
        assertThat(reqJnl.has("body")).isFalse();

        assertThat(access.path("status").asText()).isEqualTo("500");
        assertThat(access.path("latency").asText()).matches("\\d+");

        assertThat(resJnl.path("status").asText()).isEqualTo("500");
        assertThat(resJnl.path("latency").asText()).matches("\\d+");
        assertThat(resJnl.path("headers").size()).as("boom は応答ヘッダを足さない").isZero();
        assertThat(resJnl.has("body")).isFalse();

        assertThat(mdcDuringChain.get(MdcKeys.FUNCTION)).isEqualTo("GET /api/boom");
        assertThat(mdcDuringChain.get(MdcKeys.ACTION)).isEqualTo("GET /api/boom");
        assertThat(mdcDuringChain.get(MdcKeys.TRACE_ID)).isEqualTo("t-err");
        assertThat(mdcDuringChain.get(MdcKeys.SOURCE_IP)).isEqualTo("127.0.0.1"); // XFF 無し → remoteAddr 既定
        assertThat(mdcDuringChain.get(MdcKeys.USER)).isNull();

        assertThat(MDC.get(MdcKeys.TRACE_ID)).isNull();
    }
}
