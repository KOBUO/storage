package jp.co.lawson.common.app.lib.logging.logback;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import net.logstash.logback.composite.loggingevent.MessageJsonProvider;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggingEvent;

import jp.co.lawson.common.app.lib.logging.LoggingProperties;
import jp.co.lawson.common.app.lib.logging.LoggingProperties.MaskRule;

/**
 * {@link SanitizingCompositeJsonEncoder} の単体テスト。
 */
class SanitizingCompositeJsonEncoderTest {

    @AfterEach
    void resetStatics() {
        LoggingProperties.install(Map.of(), Map.of());
    }

    /**
     * JSON 1行（末尾改行付き）のバイト列を組み立てる。
     *
     * @param json JSON 文字列
     * @return 末尾に改行を付けた UTF-8 バイト列
     */
    private static byte[] line(String json) {
        return (json + "\n").getBytes(UTF_8);
    }

    /**
     * オブジェクト項目はキー名一致で値だけ伏せ、構造を保つこと。
     *
     * 試験条件
     * ・headers 規則 keys=[authorization]。headers がオブジェクトの行。
     * 観点
     * ・JSON 文字列化してキー名一致でマスクし、構造へ戻すこと。
     * 想定結果
     * ・Authorization が ***、Accept は素のまま、headers はオブジェクトのままであること。
     */
    @Test
    void masksObjectFieldKeepingStructure() {
        LoggingProperties.install(Map.of("headers", new MaskRule(List.of("authorization"), List.of())), Map.of());
        byte[] out = SanitizingCompositeJsonEncoder.apply(
                line("{\"headers\":{\"Authorization\":\"Bearer x\",\"Accept\":\"*/*\"}}"));
        assertThat(new String(out, UTF_8))
                .contains("\"headers\":{\"Authorization\":\"***\",\"Accept\":\"*/*\"}")
                .doesNotContain("Bearer x");
    }

    /**
     * 文字列項目はその文字列内をキー名で伏せること。
     *
     * 試験条件
     * ・body 規則 keys=[password]。body が JSON 文字列の行。
     * 観点
     * ・文字列項目はテキストへ直接マスクすること。
     * 想定結果
     * ・p@ss が残らず *** 化されること。
     */
    @Test
    void masksStringField() {
        LoggingProperties.install(Map.of("body", new MaskRule(List.of("password"), List.of())), Map.of());
        byte[] out = SanitizingCompositeJsonEncoder.apply(line("{\"body\":\"{\\\"password\\\":\\\"p@ss\\\"}\"}"));
        assertThat(new String(out, UTF_8)).contains("***").doesNotContain("p@ss");
    }

    /**
     * 文字列項目は上限超過で末尾に ...(truncated) を付けて切ること。
     *
     * 試験条件
     * ・body 上限 20。長い body 文字列の行。
     * 観点
     * ・文字列項目に出力長制限を適用すること。
     * 想定結果
     * ・(truncated) を含むこと。
     */
    @Test
    void truncatesStringField() {
        LoggingProperties.install(Map.of(), Map.of("body", 20));
        byte[] out = SanitizingCompositeJsonEncoder.apply(line("{\"body\":\"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ\"}"));
        assertThat(new String(out, UTF_8)).contains("(truncated)");
    }

    /**
     * オブジェクト項目が上限超過で JSON が壊れたら文字列へフォールバックすること。
     *
     * 試験条件
     * ・headers 上限 20。headers がオブジェクトで、JSON 文字列が上限超過。
     * 観点
     * ・切詰で構造へ戻せない場合は文字列で出すこと。
     * 想定結果
     * ・(truncated) を含み、headers が文字列（先頭 {@code {}）になること。
     */
    @Test
    void objectFieldFallsBackToStringWhenTruncated() {
        LoggingProperties.install(Map.of(), Map.of("headers", 20));
        byte[] out = SanitizingCompositeJsonEncoder.apply(
                line("{\"headers\":{\"X-A\":\"0123456789ABCDEFGHIJKLMNOPQRST\",\"X-B\":\"y\"}}"));
        assertThat(new String(out, UTF_8)).contains("(truncated)").contains("\"headers\":\"{");
    }

    /**
     * 対象項目が無い／一致しないなど変化が無ければ素のバイトを返却すること。
     *
     * 試験条件
     * ・body 規則 keys=[nomatch]、headers 上限あり。body に一致なし・headers は行に存在しない。
     * 観点
     * ・未一致・未登場の項目は変化させず、再シリアライズしないこと。
     * 想定結果
     * ・入力と同一のバイト列（同一参照）を返却すること。
     */
    @Test
    void returnsRawWhenUnchanged() {
        LoggingProperties.install(Map.of("body", new MaskRule(List.of("nomatch"), List.of())), Map.of("headers", 100));
        byte[] raw = line("{\"body\":\"hello\",\"x\":1}");
        assertThat(SanitizingCompositeJsonEncoder.apply(raw)).isSameAs(raw);
    }

    /**
     * トップレベルがオブジェクトでなければ素のまま返却すること。
     *
     * 試験条件
     * ・JSON 配列の行。
     * 観点
     * ・オブジェクト以外は処理対象外とすること。
     * 想定結果
     * ・入力と同一参照を返却すること。
     */
    @Test
    void returnsRawWhenNotObject() {
        byte[] raw = line("[\"a\",\"b\"]");
        assertThat(SanitizingCompositeJsonEncoder.apply(raw)).isSameAs(raw);
    }

    /**
     * JSON として解析できなければ素のまま返却すること。（fail-safe）
     *
     * 試験条件
     * ・JSON でないバイト列。
     * 観点
     * ・解析失敗時もログを欠落させないこと。
     * 想定結果
     * ・入力と同一参照を返却すること。
     */
    @Test
    void returnsRawWhenMalformed() {
        byte[] raw = "not json".getBytes(UTF_8);
        assertThat(SanitizingCompositeJsonEncoder.apply(raw)).isSameAs(raw);
    }

    /**
     * 末尾が CRLF・全て改行でも安全に処理すること。（fail-safe）
     *
     * 試験条件
     * ・{@code \r\n} のみ（JSON 本文なし）のバイト列。
     * 観点
     * ・末尾の {@code \r}／{@code \n} を除去し、本文が空でも落ちないこと。
     * 想定結果
     * ・入力と同一参照を返却すること。
     */
    @Test
    void handlesCrlfAndAllNewlines() {
        byte[] raw = "\r\n".getBytes(UTF_8);
        assertThat(SanitizingCompositeJsonEncoder.apply(raw)).isSameAs(raw);
    }

    /**
     * encode 経由でも出力長制限が適用されること。
     *
     * 試験条件
     * ・message 上限 2。MessageJsonProvider のみの encoder で message="msg" を encode する。
     * 観点
     * ・親 encoder の出力に apply が適用されること。
     * 想定結果
     * ・message が 2 バイトに切られること。
     */
    @Test
    void encodeAppliesLimit() {
        LoggingProperties.install(Map.of(), Map.of("message", 2));
        LoggerContext context = new LoggerContext();
        SanitizingCompositeJsonEncoder encoder = new SanitizingCompositeJsonEncoder();
        encoder.setContext(context);
        encoder.getProviders().addProvider(new MessageJsonProvider());
        encoder.start();

        Logger logger = context.getLogger("test");
        LoggingEvent event = new LoggingEvent("fqcn", logger, Level.INFO, "msg", null, null);
        assertThat(new String(encoder.encode(event), UTF_8)).contains("\"message\":\"ms\"");
    }

    /**
     * 出力項目名に応じた上限値を返却すること。
     *
     * 試験条件
     * ・body 上限 10 を充填する。
     * 観点
     * ・登録済みは上限値、未登録／null は -1 を返却すること。
     * 想定結果
     * ・body=10、未登録=-1、null=-1 であること。
     */
    @Test
    void limitForReturnsConfiguredOrMinusOne() {
        LoggingProperties.install(Map.of(), Map.of("body", 10));
        assertThat(SanitizingCompositeJsonEncoder.limitFor("body")).isEqualTo(10);
        assertThat(SanitizingCompositeJsonEncoder.limitFor("missing")).isEqualTo(-1);
        assertThat(SanitizingCompositeJsonEncoder.limitFor(null)).isEqualTo(-1);
    }

    /**
     * 上限以下・null はそのまま返却すること。
     *
     * 試験条件
     * ・上限内の文字列、および null を指定する。
     * 観点
     * ・制限不要・null 安全であること。
     * 想定結果
     * ・上限内はそのまま、null は null であること。
     */
    @Test
    void truncateReturnsAsIsWithinLimitOrNull() {
        assertThat(SanitizingCompositeJsonEncoder.truncate("abc", 10)).isEqualTo("abc");
        assertThat(SanitizingCompositeJsonEncoder.truncate(null, 10)).isNull();
    }

    /**
     * 上限超過は接尾辞付きでバイト上限内に収めること。
     *
     * 試験条件
     * ・40 バイト上限に 46 バイトの ASCII を指定する。
     * 観点
     * ・末尾に ...(truncated) を付け、上限バイト以内にすること。
     * 想定結果
     * ・(truncated) で終わり、UTF-8 で 40 バイト以内であること。
     */
    @Test
    void truncatesOverMaxBytesWithSuffix() {
        String out = SanitizingCompositeJsonEncoder.truncate("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 40);
        assertThat(out).endsWith("(truncated)").startsWith("0123456789");
        assertThat(out.getBytes(UTF_8).length).isLessThanOrEqualTo(40);
    }

    /**
     * マルチバイトはバイト境界で制限すること。
     *
     * 試験条件
     * ・UTF-8 3 バイトの「あ」×30（90 バイト）を 40 バイト上限で指定する。
     * 観点
     * ・文字数でなくバイトで制限し、コードポイント境界で割れないこと。
     * 想定結果
     * ・(truncated) で終わり、UTF-8 で 40 バイト以内であること。
     */
    @Test
    void truncatesMultibyteByByte() {
        String out = SanitizingCompositeJsonEncoder.truncate("あ".repeat(30), 40);
        assertThat(out).endsWith("(truncated)");
        assertThat(out.getBytes(UTF_8).length).isLessThanOrEqualTo(40);
    }

    /**
     * 上限が接尾辞長以下なら接尾辞を付けず本文を上限バイトまで制限すること。
     *
     * 試験条件
     * ・接尾辞より短い 2 バイト上限で 6 バイトの ASCII を指定する。
     * 観点
     * ・出力が上限を超えないよう、接尾辞なしで制限すること。
     * 想定結果
     * ・先頭 2 バイトのみ（"ab"）になること。
     */
    @Test
    void truncatesWithoutSuffixWhenLimitTiny() {
        assertThat(SanitizingCompositeJsonEncoder.truncate("abcdef", 2)).isEqualTo("ab");
    }

    /**
     * 上限が接尾辞長（14 バイト）ちょうどなら接尾辞を付けず上限バイトまで制限すること。
     *
     * 試験条件
     * ・接尾辞 ...(truncated) と同じ 14 バイト上限で、20 バイトの ASCII を指定する。
     * 観点
     * ・上限＝接尾辞長の等号境界（{@code maxBytes > suffixBytes} が false）で接尾辞を付けないこと。
     * 想定結果
     * ・先頭 14 バイトのみ（接尾辞なし）になること。
     */
    @Test
    void truncatesWithoutSuffixAtSuffixLengthBoundary() {
        assertThat(SanitizingCompositeJsonEncoder.truncate("0123456789ABCDEFGHIJ", 14)).isEqualTo("0123456789ABCD");
    }

    /**
     * マスク対象と出力長制限対象が別項目で同時に登場しても、1パスで両方適用すること。
     *
     * 試験条件
     * ・body 規則 keys=[password]、message 上限 5。両項目を持つ1行。
     * 観点
     * ・targets() の和集合を走査し、複数項目の変更を1回の処理で蓄積すること。
     * 想定結果
     * ・message は 5 バイトに切られ、body の password が *** 化され、元値が残らないこと。
     */
    @Test
    void appliesMaskAndTruncateToMultipleFieldsInOnePass() {
        LoggingProperties.install(
                Map.of("body", new MaskRule(List.of("password"), List.of())),
                Map.of("message", 5));
        byte[] out = SanitizingCompositeJsonEncoder.apply(
                line("{\"message\":\"0123456789\",\"body\":\"{\\\"password\\\":\\\"p@ss\\\"}\"}"));
        assertThat(new String(out, UTF_8))
                .contains("\"message\":\"01234\"")
                .contains("***")
                .doesNotContain("0123456789")
                .doesNotContain("p@ss");
    }

    /**
     * 暗号化対象キーは大文字小文字が異なってもマスクされること。
     */
    @Test
    void masksKeyCaseInsensitively() {
        LoggingProperties.install(Map.of("headers", new MaskRule(List.of("authorization"), List.of())), Map.of());
        byte[] out = SanitizingCompositeJsonEncoder.apply(
                line("{\"headers\":{\"Authorization\":\"valA\",\"AUTHORIZATION\":\"valB\"}}"));
        assertThat(new String(out, UTF_8))
                .contains("\"Authorization\":\"***\"")
                .contains("\"AUTHORIZATION\":\"***\"")
                .doesNotContain("valA").doesNotContain("valB");
    }

    /**
     * 異なる階層にある複数の暗号化対象キーがすべてマスクされること。
     */
    @Test
    void masksKeysAtAllNestingLevels() {
        LoggingProperties.install(Map.of("body", new MaskRule(List.of("password"), List.of())), Map.of());
        byte[] out = SanitizingCompositeJsonEncoder.apply(line(
                "{\"body\":{\"password\":\"secret1\",\"inner\":{\"password\":\"secret2\",\"more\":{\"password\":\"secret3\"}}}}"));
        assertThat(new String(out, UTF_8))
                .contains("\"password\":\"***\"")
                .doesNotContain("secret1").doesNotContain("secret2").doesNotContain("secret3");
    }

    /**
     * keys 指定と patterns 指定を併用しても、互いに干渉せず両方適用されること。
     */
    @Test
    void appliesBothKeysAndPatternsWithoutInterference() {
        LoggingProperties.install(
                Map.of("body", new MaskRule(List.of("password"),
                        List.of(Pattern.compile("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}")))),
                Map.of());
        byte[] out = SanitizingCompositeJsonEncoder.apply(
                line("{\"body\":{\"password\":\"p@ss\",\"email\":\"a@b.com\",\"keep\":\"hello\"}}"));
        assertThat(new String(out, UTF_8))
                .contains("\"password\":\"***\"")
                .contains("\"email\":\"***\"")
                .contains("\"keep\":\"hello\"")
                .doesNotContain("p@ss").doesNotContain("a@b.com");
    }

    /**
     * 暗号化対象キー名より1文字少ない／多いキーはマスクされないこと。
     */
    @Test
    void doesNotMaskKeysOneCharShorterOrLonger() {
        LoggingProperties.install(Map.of("body", new MaskRule(List.of("password"), List.of())), Map.of());
        byte[] out = SanitizingCompositeJsonEncoder.apply(
                line("{\"body\":{\"password\":\"hit\",\"passwor\":\"short\",\"passwords\":\"long\"}}"));
        assertThat(new String(out, UTF_8))
                .contains("\"password\":\"***\"")
                .contains("\"passwor\":\"short\"")
                .contains("\"passwords\":\"long\"")
                .doesNotContain("hit");
    }

    /**
     * 暗号化対象キーの値が配列・オブジェクトの場合はマスクされないこと（文字列値のみ対象）。
     */
    @Test
    void doesNotMaskArrayOrObjectValues() {
        LoggingProperties.install(Map.of("body", new MaskRule(List.of("secret"), List.of())), Map.of());
        byte[] out = SanitizingCompositeJsonEncoder.apply(line(
                "{\"body\":{\"secret\":\"plain\",\"arr\":{\"secret\":[\"x\",\"y\"]},\"obj\":{\"secret\":{\"k\":\"v\"}}}}"));
        assertThat(new String(out, UTF_8))
                .contains("\"secret\":\"***\"")          // 文字列値はマスク
                .contains("\"secret\":[\"x\",\"y\"]")    // 配列値はそのまま
                .contains("\"secret\":{\"k\":\"v\"}")    // オブジェクト値はそのまま
                .doesNotContain("plain");
    }

    /**
     * 値にエスケープ記号（\" \\）を含んでも、終端を誤認せず正しくマスクすること。
     */
    @Test
    void handlesEscapedCharactersInValue() {
        LoggingProperties.install(Map.of("body", new MaskRule(List.of("password"), List.of())), Map.of());
        byte[] out = SanitizingCompositeJsonEncoder.apply(
                line("{\"body\":{\"password\":\"a\\\"b\\\\c\",\"next\":\"keep\"}}"));
        assertThat(new String(out, UTF_8))
                .contains("\"password\":\"***\"")
                .contains("\"next\":\"keep\""); // 終端を誤認していれば next が壊れる
    }

    /**
     * 同一項目にマスクと出力長制限の両方が設定されても、マスク→制限の順で正しく動作すること。
     */
    @Test
    void masksThenTruncatesSameField() {
        LoggingProperties.install(
                Map.of("body", new MaskRule(List.of("password"), List.of())),
                Map.of("body", 40));
        byte[] out = SanitizingCompositeJsonEncoder.apply(
                line("{\"body\":\"password=topsecret&x=" + "A".repeat(30) + "\"}"));
        assertThat(new String(out, UTF_8))
                .contains("password=***")
                .contains("(truncated)")
                .doesNotContain("topsecret");
    }

    /**
     * 可変項目（message/body/result/headers）がすべて上限を大幅超過しても、1行が 4KB 以内に収まること。
     */
    @Test
    void keepsLineWithin4KbWhenVariableFieldsOversized() {
        LoggingProperties.install(Map.of(),
                Map.of("message", 768, "body", 1024, "result", 1024, "headers", 512));
        String big = "A".repeat(6000);
        String json = "{"
                + "\"message\":\"" + big + "\","
                + "\"headers\":{\"X-Big\":\"" + big + "\"},"
                + "\"body\":\"" + big + "\","
                + "\"result\":\"" + big + "\""
                + "}";

        byte[] out = SanitizingCompositeJsonEncoder.apply(line(json));
        String oneLine = new String(out, UTF_8).stripTrailing(); // 終端改行を除いた JSON 1件

        assertThat(oneLine.getBytes(UTF_8).length).as("1行 4KB 以内").isLessThanOrEqualTo(4096);
        assertThat(oneLine).contains("(truncated)"); // 可変項目が制限された
    }
}
