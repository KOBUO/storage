package jp.co.lawson.common.app.lib.logging;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.util.OptionHelper;
import net.logstash.logback.composite.loggingevent.LoggingEventPatternJsonProvider;

import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;
import jp.co.lawson.common.app.lib.logging.logback.SanitizingCompositeJsonEncoder;

/**
 * 【全ログ種別 end-to-end 検証】lib の logback 構成（{@code @SpringBootTest}）を起動し、各固定ロガー
 * （ログ種類）へ {@link StructuredLog} で出力して、{@code SanitizingCompositeJsonEncoder} を通った
 * JSON ログが種類ごとに正しく出力されることを stdout/stderr 捕捉で検証する。
 *
 * <p>各出力行を JSON として解析し、共通エンベロープ・種類別 type/subtype・MDC・発生元・marker・stack_trace
 * の全項目を想定値で突合する。マスク・出力長制限・環境変数依存項目（id/name）・4KB 制限も併せて確認する。
 */
@SpringBootTest(
        classes = AllLogTypesLoggingIT.TestApp.class,
        webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = {
                "cosmo-app.logging.mask.headers.keys=authorization",
                "cosmo-app.logging.mask.body.keys=password",
                "cosmo-app.logging.limits.body=48"
        })
@ExtendWith(OutputCaptureExtension.class)
class AllLogTypesLoggingIT {

    /** マスク・出力長上限を有効化するための最小 Spring 構成。 */
    @SpringBootConfiguration
    @EnableConfigurationProperties(LoggingProperties.class)
    static class TestApp {
    }

    /** JSON parse 用。 */
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** マーカー付きで直接出力する固定ロガー（ジャーナル／アクセス系）。 */
    private static final List<String> MARKER_LOGGERS = List.of(
            LoggerNames.API_ACCESS,
            LoggerNames.API_ACCESS_JNL,
            LoggerNames.SERVICE_JNL,
            LoggerNames.SQL_JNL,
            LoggerNames.STORAGE_JNL,
            "AWSCALL",
            LoggerNames.HTTP_CLIENT_JNL,
            LoggerNames.SQS_JNL,
            LoggerNames.KMS_JNL,
            LoggerNames.DYNAMODB_JNL);

    /** logger_name で出力1行を特定し JSON へ parse する（1物理行前提）。 */
    private static JsonNode logLineOf(CapturedOutput out, String loggerName) {
        String line = out.getAll().lines()
                .filter(l -> l.contains("\"logger_name\":\"" + loggerName + "\""))
                .findFirst()
                .orElseThrow(() -> new AssertionError("no log line for " + loggerName));
        try {
            return MAPPER.readTree(line);
        } catch (Exception e) {
            throw new AssertionError("invalid JSON for " + loggerName + ": " + line, e);
        }
    }

    /** 全種別に共通するエンベロープ項目を検証する。 */
    private static void assertEnvelope(JsonNode log, String loggerName, String level, int levelValue, String message) {
        assertThat(log.path("timestamp").asText()).isNotBlank();
        assertThat(log.path("id").isTextual()).isTrue();   // 既定は "null"
        assertThat(log.path("name").isTextual()).isTrue();
        assertThat(log.path("level").asText()).isEqualTo(level);
        assertThat(log.path("level_value").isNumber()).isTrue();
        assertThat(log.path("level_value").asInt()).isEqualTo(levelValue);
        assertThat(log.path("logger_name").asText()).isEqualTo(loggerName);
        assertThat(log.path("thread").asText()).isNotBlank();
        assertThat(log.path("message").asText()).isEqualTo(message);
    }

    /**
     * 全ログ種別が、種類別の type／subtype・共通エンベロープ・MDC・marker・stack_trace の
     * すべての項目を想定どおりの値で出力すること。
     *
     * <p>ループでまとめず、各ログ種別を1件ずつ明示的に全項目検証する。
     * 環境変数未設定のため id／name は "-"（C 未設定観点）。
     */
    @Test
    void everyLogTypeEmitsAllExpectedFields(CapturedOutput out) {
        MARKER_LOGGERS.forEach(name -> LoggerFactory.getLogger(name).info(
                StructuredLog.create().put(LogFields.URL, "GET /x").put(LogFields.STATUS, 200).marker(),
                "log for " + name));
        ApplicationLogger.getLogger().info("business log");
        ApplicationLogger.getLogger().error("business error", new RuntimeException("boom"));
        LoggerFactory.getLogger("system.check.Sample").info("system log");

        // ── アクセスログ（type=trail・subtype 無し・MDC: function/user/action/source_ip）
        JsonNode access = logLineOf(out, LoggerNames.API_ACCESS);
        assertEnvelope(access, LoggerNames.API_ACCESS, "INFO", 20000, "log for " + LoggerNames.API_ACCESS);
        assertThat(access.path("id").asText()).isEqualTo("-");
        assertThat(access.path("name").asText()).isEqualTo("-");
        assertThat(access.path("type").asText()).isEqualTo("trail");
        assertThat(access.has("subtype")).isFalse();
        assertThat(access.path("class_name").asText()).contains("AllLogTypesLoggingIT");
        assertThat(access.path("method_name").asText()).isNotBlank().isNotEqualTo("-");
        assertThat(access.path("function").asText()).isEqualTo("-");
        assertThat(access.path("user").asText()).isEqualTo("-");
        assertThat(access.path("action").asText()).isEqualTo("-");
        assertThat(access.path("source_ip").asText()).isEqualTo("-");
        assertThat(access.has("trace")).isFalse();
        assertThat(access.path("url").asText()).isEqualTo("GET /x");
        assertThat(access.path("status").asText()).isEqualTo("200");
        assertThat(access.has("stack_trace")).isFalse();
        assertExactFields(access,
                "timestamp", "id", "name", "level", "level_value", "logger_name", "type", "thread",
                "function", "user", "action", "source_ip", "message", "class_name", "method_name", "url", "status");

        // ── ジャーナル系（type=app・MDC: function/trace・発生元あり・marker url/status）を種別ごとに明示検証
        assertAppJournal(out, LoggerNames.API_ACCESS_JNL, "APL");   // アクセスジャーナル
        assertAppJournal(out, LoggerNames.SERVICE_JNL, "APL");      // サービスジャーナル
        assertAppJournal(out, LoggerNames.SQL_JNL, "DBCALL");       // SQL ジャーナル
        assertAppJournal(out, LoggerNames.STORAGE_JNL, "AWSCALL");  // ストレージジャーナル
        assertAppJournal(out, "AWSCALL", "AWSCALL");                // AWSCALL ロガー
        assertAppJournal(out, LoggerNames.HTTP_CLIENT_JNL, "APL");  // 外部アクセスジャーナル
        assertAppJournal(out, LoggerNames.SQS_JNL, "AWSCALL");      // SQS 受信ジャーナル
        assertAppJournal(out, LoggerNames.KMS_JNL, "AWSCALL");      // KMS ジャーナル
        assertAppJournal(out, LoggerNames.DYNAMODB_JNL, "AWSCALL"); // DynamoDB ジャーナル

        // ── 業務ログ（type=app/APL・marker 無し）
        JsonNode app = logLineOf(out, LoggerNames.API_LOG);
        assertEnvelope(app, LoggerNames.API_LOG, "INFO", 20000, "business log");
        assertThat(app.path("id").asText()).isEqualTo("-");
        assertThat(app.path("name").asText()).isEqualTo("-");
        assertThat(app.path("type").asText()).isEqualTo("app");
        assertThat(app.path("subtype").asText()).isEqualTo("APL");
        assertThat(app.path("class_name").asText()).contains("AllLogTypesLoggingIT");
        assertThat(app.path("method_name").asText()).isNotBlank().isNotEqualTo("-");
        assertThat(app.path("function").asText()).isEqualTo("-");
        assertThat(app.path("trace").asText()).isEqualTo("-");
        assertThat(app.has("url")).isFalse();
        assertThat(app.has("status")).isFalse();
        assertThat(app.has("stack_trace")).isFalse();
        assertExactFields(app,
                "timestamp", "id", "name", "level", "level_value", "logger_name", "type", "subtype",
                "thread", "function", "trace", "message", "class_name", "method_name");

        // ── 業務エラーログ（type=monitor/APL・stack_trace あり）
        JsonNode err = logLineOf(out, LoggerNames.ERROR_LOG);
        assertEnvelope(err, LoggerNames.ERROR_LOG, "ERROR", 40000, "business error");
        assertThat(err.path("id").asText()).isEqualTo("-");
        assertThat(err.path("name").asText()).isEqualTo("-");
        assertThat(err.path("type").asText()).isEqualTo("monitor");
        assertThat(err.path("subtype").asText()).isEqualTo("APL");
        assertThat(err.path("class_name").asText()).contains("AllLogTypesLoggingIT");
        assertThat(err.path("method_name").asText()).isNotBlank().isNotEqualTo("-");
        assertThat(err.path("function").asText()).isEqualTo("-");
        assertThat(err.path("trace").asText()).isEqualTo("-");
        assertThat(err.path("stack_trace").asText()).contains("RuntimeException").contains("boom");
        assertExactFields(err,
                "timestamp", "id", "name", "level", "level_value", "logger_name", "type", "subtype",
                "thread", "function", "trace", "message", "class_name", "method_name", "stack_trace");

        // ── システムログ（type=app/SYSTEM・発生元 provider 無し）
        JsonNode sys = logLineOf(out, "system.check.Sample");
        assertEnvelope(sys, "system.check.Sample", "INFO", 20000, "system log");
        assertThat(sys.path("id").asText()).isEqualTo("-");
        assertThat(sys.path("name").asText()).isEqualTo("-");
        assertThat(sys.path("type").asText()).isEqualTo("app");
        assertThat(sys.path("subtype").asText()).isEqualTo("SYSTEM");
        assertThat(sys.path("function").asText()).isEqualTo("-");
        assertThat(sys.path("trace").asText()).isEqualTo("-");
        assertThat(sys.has("class_name")).isFalse();
        assertThat(sys.has("method_name")).isFalse();
        assertThat(sys.has("stack_trace")).isFalse();
        assertExactFields(sys,
                "timestamp", "id", "name", "level", "level_value", "logger_name", "type", "subtype",
                "thread", "function", "trace", "message");
    }

    /** ログの出力項目（JSON のキー集合）が想定どおりで、想定外の項目が含まれないことを検証する。 */
    private static void assertExactFields(JsonNode log, String... expected) {
        java.util.List<String> actual = new java.util.ArrayList<>();
        log.fieldNames().forEachRemaining(actual::add);
        assertThat(actual).containsExactlyInAnyOrder(expected);
    }

    /**
     * ジャーナル系1種別（type=app・MDC function/trace・発生元あり・marker url/status・stack_trace 無し）の
     * 全項目を検証する。種別ごとに明示的に呼び出す（ループでまとめない）。
     *
     * @param out 捕捉出力
     * @param logger 対象ロガー名
     * @param subtype 期待する subtype
     */
    private static void assertAppJournal(CapturedOutput out, String logger, String subtype) {
        JsonNode log = logLineOf(out, logger);
        assertEnvelope(log, logger, "INFO", 20000, "log for " + logger);
        assertThat(log.path("id").asText()).isEqualTo("-");
        assertThat(log.path("name").asText()).isEqualTo("-");
        assertThat(log.path("type").asText()).isEqualTo("app");
        assertThat(log.path("subtype").asText()).isEqualTo(subtype);
        assertThat(log.path("class_name").asText()).contains("AllLogTypesLoggingIT");
        assertThat(log.path("method_name").asText()).isNotBlank().isNotEqualTo("-");
        assertThat(log.path("function").asText()).isEqualTo("-");
        assertThat(log.path("trace").asText()).isEqualTo("-");
        assertThat(log.path("url").asText()).isEqualTo("GET /x");
        assertThat(log.path("status").asText()).isEqualTo("200");
        assertThat(log.has("stack_trace")).isFalse();
        assertExactFields(log,
                "timestamp", "id", "name", "level", "level_value", "logger_name", "type", "subtype",
                "thread", "function", "trace", "message", "class_name", "method_name", "url", "status");
    }

    /**
     * マスク・出力長制限が実 encoder 経由で適用されること。
     *
     * 観点：出力時に {@code SanitizingCompositeJsonEncoder} がマスクと出力長制限を適用すること。
     */
    @Test
    void maskingAndLengthLimitApplyThroughEncoder(CapturedOutput out) {
        LoggerFactory.getLogger(LoggerNames.API_ACCESS_JNL).info(
                StructuredLog.create()
                        .put(LogFields.HEADERS, Map.of("Authorization", "Bearer secret-token"))
                        .put(LogFields.BODY,
                                "{\"password\":\"p@ssw0rd\",\"note\":\"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ\"}")
                        .marker(),
                "mask/limit check");

        assertThat(out).contains("\"***\"");                   // マスク適用
        assertThat(out).doesNotContain("p@ssw0rd");            // body の password 値が伏せられた
        assertThat(out).doesNotContain("Bearer secret-token"); // headers の authorization 値が伏せられた
        assertThat(out).contains("(truncated)");               // body が上限超過で制限された
    }

    /**
     * メッセージと stack_trace を最大まで膨らませても、実 encoder を通した1行が 4KB 以内に収まること。
     *
     * 観点：message は encoder（既定 768）、stack_trace は appender（既定 2560）で制限され、行全体が 4KB を超えないこと。
     * 併せて stack_trace の改行が \n エスケープされ1物理行に収まることも確認する（G）。
     */
    @Test
    void errorLineStaysWithin4KbWhenMessageAndStackTraceMaxedOut(CapturedOutput out) {
        RuntimeException deep = new RuntimeException("root");
        for (int i = 0; i < 80; i++) {
            deep = new RuntimeException("layer " + i + " " + "x".repeat(50), deep); // stack_trace を上限超へ
        }
        ApplicationLogger.getLogger().error("ERR4KB-" + "M".repeat(5000), deep);

        String errLine = out.getAll().lines()
                .filter(l -> l.contains("ERR4KB-")) // 先頭の目印は message 制限後も残る
                .findFirst().orElseThrow();

        assertThat(errLine.getBytes(UTF_8).length).isLessThanOrEqualTo(4096);
        assertThat(errLine).contains("(truncated)");     // message が上限超過で制限
        assertThat(errLine).contains("\"stack_trace\""); // stack_trace も出力（1物理行に収まる）
    }

    /**
     * 環境変数 CONTAINER_ID／CONTAINER_NAME が設定されていれば id／name に反映されること（C 設定観点）。
     *
     * <p>{@code ${CONTAINER_ID:--}} は config 解決時に評価されるため、独立した {@link LoggerContext} を
     * 用意し、システムプロパティを設定した状態で encoder を start() して反映を確認する（全体構成に影響しない）。
     */
    @Test
    void idAndNameReflectContainerWhenSet() throws Exception {
        LoggerContext ctx = new LoggerContext();
        ctx.putProperty("CONTAINER_ID", "cid-1");
        ctx.putProperty("CONTAINER_NAME", "cname-1");
        // ${CONTAINER_ID:--} は本番では Joran が config 解決時に substVars で置換する。テストも同じ解決を再現する。
        String pattern = OptionHelper.substVars(
                "{\"id\":\"${CONTAINER_ID:--}\",\"name\":\"${CONTAINER_NAME:--}\"}", ctx);
        // 未設定なら "null" に解決されることも同時に確認（C 未設定観点の機構レベル裏取り）
        assertThat(OptionHelper.substVars("${CONTAINER_ID:--}", new LoggerContext()))
                .isEqualTo("-");

        SanitizingCompositeJsonEncoder encoder = new SanitizingCompositeJsonEncoder();
        encoder.setContext(ctx);
        LoggingEventPatternJsonProvider idName = new LoggingEventPatternJsonProvider();
        idName.setPattern(pattern);
        encoder.getProviders().addProvider(idName);
        encoder.start();

        Logger logger = ctx.getLogger("env-test");
        LoggingEvent event = new LoggingEvent("fqcn", logger, Level.INFO, "x", null, null);
        JsonNode json = MAPPER.readTree(new String(encoder.encode(event), UTF_8));
        assertThat(json.path("id").asText()).isEqualTo("cid-1");
        assertThat(json.path("name").asText()).isEqualTo("cname-1");
    }
}
