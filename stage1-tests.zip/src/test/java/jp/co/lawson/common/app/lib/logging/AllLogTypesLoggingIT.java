package jp.co.lawson.common.app.lib.logging;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.util.OptionHelper;
import net.logstash.logback.composite.loggingevent.LoggingEventPatternJsonProvider;

import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;
import jp.co.lawson.common.app.lib.logging.logback.SanitizingCompositeJsonEncoder;

/**
 * 【全ログ種別 end-to-end 検証】lib の logback 構成（{@code @SpringBootTest}）を起動し、各固定ロガー
 * （ログ種類）へ {@link StructuredLog} で出力して、{@code SanitizingCompositeJsonEncoder} を通った
 * JSON ログが種類ごとに正しく出力されることを stdout/stderr 捕捉で検証する。
 *
 * <p>各出力行を JSON として解析し、共通エンベロープ・種類別 type/subtype・MDC・発生元・marker・stack_trace
 * の全項目を想定値で突合する。マスク・出力長制限・環境変数依存項目（id/name）・4KB 制限も併せて確認する。
 */
@SpringBootTest(
        classes = AllLogTypesLoggingIT.TestApp.class,
        webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = {
                "cosmo-app.logging.mask.headers.keys=authorization",
                "cosmo-app.logging.mask.body.keys=password",
                "cosmo-app.logging.limits.body=48"
        })
@ExtendWith(OutputCaptureExtension.class)
class AllLogTypesLoggingIT {

    /** マスク・出力長上限を有効化するための最小 Spring 構成。 */
    @SpringBootConfiguration
    @EnableConfigurationProperties(LoggingProperties.class)
    static class TestApp {
    }

    /** JSON parse 用。 */
    private static final ObjectMapper MAPPER = new ObjectMapper();

    /** マーカー付きで直接出力する固定ロガー（ジャーナル／アクセス系）。 */
    private static final List<String> MARKER_LOGGERS = List.of(
            LoggerNames.API_ACCESS,
            LoggerNames.API_ACCESS_JNL,
            LoggerNames.SERVICE_JNL,
            LoggerNames.SQL_JNL,
            LoggerNames.STORAGE_JNL,
            "AWSCALL",
            LoggerNames.HTTP_CLIENT_JNL,
            LoggerNames.SQS_JNL,
            LoggerNames.KMS_JNL,
            LoggerNames.DYNAMODB_JNL);

    /** logger_name で出力1行を特定し JSON へ parse する（1物理行前提）。 */
    private static JsonNode logLineOf(CapturedOutput out, String loggerName) {
        String line = out.getAll().lines()
                .filter(l -> l.contains("\"logger_name\":\"" + loggerName + "\""))
                .findFirst()
                .orElseThrow(() -> new AssertionError("no log line for " + loggerName));
        try {
            return MAPPER.readTree(line);
        } catch (Exception e) {
            throw new AssertionError("invalid JSON for " + loggerName + ": " + line, e);
        }
    }

    /** 全種別に共通するエンベロープ項目を検証する。 */
    private static void assertEnvelope(JsonNode log, String loggerName, String level, int levelValue, String message) {
        assertThat(log.path("timestamp").asText()).as(loggerName + " timestamp").isNotBlank();
        assertThat(log.path("id").isTextual()).as(loggerName + " id").isTrue();   // 既定は "null"
        assertThat(log.path("name").isTextual()).as(loggerName + " name").isTrue();
        assertThat(log.path("level").asText()).as(loggerName + " level").isEqualTo(level);
        assertThat(log.path("level_value").isNumber()).as(loggerName + " level_value 数値").isTrue();
        assertThat(log.path("level_value").asInt()).as(loggerName + " level_value").isEqualTo(levelValue);
        assertThat(log.path("logger_name").asText()).as(loggerName + " logger_name").isEqualTo(loggerName);
        assertThat(log.path("thread").asText()).as(loggerName + " thread").isNotBlank();
        assertThat(log.path("message").asText()).as(loggerName + " message").isEqualTo(message);
    }

    /**
     * 全ログ種別が、種類別の type／subtype・共通エンベロープ・MDC・marker・stack_trace の
     * すべての項目を想定どおりの値で出力すること。
     *
     * 観点：各行を JSON として解析し、全項目（省略なし）が種類別の期待値であること。
     * 環境変数未設定のため id／name は "null"（C 未設定観点）。
     */
    @Test
    void everyLogTypeEmitsAllExpectedFields(CapturedOutput out) {
        MARKER_LOGGERS.forEach(name -> LoggerFactory.getLogger(name).info(
                StructuredLog.create().put(LogFields.URL, "GET /x").put(LogFields.STATUS, 200).marker(),
                "log for " + name));
        ApplicationLogger.getLogger().info("business log");
        ApplicationLogger.getLogger().error("business error", new RuntimeException("boom"));
        LoggerFactory.getLogger("system.check.Sample").info("system log");

        // (logger, type, subtype[null=無し]) の網羅表
        record Spec(String logger, String type, String subtype) {}
        List<Spec> specs = List.of(
                new Spec(LoggerNames.API_ACCESS,      "trail", null),   // アクセスログ：subtype 無し
                new Spec(LoggerNames.API_ACCESS_JNL,  "app",   "APL"),
                new Spec(LoggerNames.SERVICE_JNL,     "app",   "APL"),
                new Spec(LoggerNames.SQL_JNL,         "app",   "DBCALL"),
                new Spec(LoggerNames.STORAGE_JNL,     "app",   "AWSCALL"),
                new Spec("AWSCALL",                   "app",   "AWSCALL"),
                new Spec(LoggerNames.HTTP_CLIENT_JNL, "app",   "APL"),
                new Spec(LoggerNames.SQS_JNL,         "app",   "AWSCALL"),
                new Spec(LoggerNames.KMS_JNL,         "app",   "AWSCALL"),
                new Spec(LoggerNames.DYNAMODB_JNL,    "app",   "AWSCALL"));

        for (Spec s : specs) {
            JsonNode log = logLineOf(out, s.logger());
            assertEnvelope(log, s.logger(), "INFO", 20000, "log for " + s.logger());

            assertThat(log.path("type").asText()).as(s.logger() + " type").isEqualTo(s.type());
            if (s.subtype() == null) {
                assertThat(log.has("subtype")).as(s.logger() + " subtype 無し").isFalse();
            } else {
                assertThat(log.path("subtype").asText()).as(s.logger() + " subtype").isEqualTo(s.subtype());
            }

            // 発生元（SYSTEM 以外は付与）
            assertThat(log.path("class_name").asText()).as(s.logger() + " class_name")
                    .contains("AllLogTypesLoggingIT");
            assertThat(log.path("method_name").asText()).as(s.logger() + " method_name")
                    .isNotBlank().isNotEqualTo("-");

            // MDC（IT は未設定 → "null"）。ACCESS のみ user/action/source_ip を持ち trace を持たない
            assertThat(log.path("function").asText()).as(s.logger() + " function").isEqualTo("-");
            if (s.logger().equals(LoggerNames.API_ACCESS)) {
                assertThat(log.path("user").asText()).isEqualTo("-");
                assertThat(log.path("action").asText()).isEqualTo("-");
                assertThat(log.path("source_ip").asText()).isEqualTo("-");
                assertThat(log.has("trace")).as("access は trace 無し").isFalse();
            } else {
                assertThat(log.path("trace").asText()).as(s.logger() + " trace").isEqualTo("-");
            }

            // marker（値は文字列化）
            assertThat(log.path("url").asText()).as(s.logger() + " url").isEqualTo("GET /x");
            assertThat(log.path("status").asText()).as(s.logger() + " status").isEqualTo("200");

            // 例外なし → stack_trace は出ない
            assertThat(log.has("stack_trace")).as(s.logger() + " stack_trace 無し").isFalse();
        }

        // 業務ログ（APP）：marker 無し。id/name は環境変数未設定で "null"（C 未設定観点）
        JsonNode app = logLineOf(out, LoggerNames.API_LOG);
        assertEnvelope(app, LoggerNames.API_LOG, "INFO", 20000, "business log");
        assertThat(app.path("id").asText()).as("id 未設定").isEqualTo("-");
        assertThat(app.path("name").asText()).as("name 未設定").isEqualTo("-");
        assertThat(app.path("type").asText()).isEqualTo("app");
        assertThat(app.path("subtype").asText()).isEqualTo("APL");
        assertThat(app.has("url")).as("業務ログは marker 無し").isFalse();
        assertThat(app.has("stack_trace")).isFalse();

        // 業務エラーログ（ERROR）：stack_trace あり
        JsonNode err = logLineOf(out, LoggerNames.ERROR_LOG);
        assertEnvelope(err, LoggerNames.ERROR_LOG, "ERROR", 40000, "business error");
        assertThat(err.path("type").asText()).isEqualTo("monitor");
        assertThat(err.path("subtype").asText()).isEqualTo("APL");
        assertThat(err.path("stack_trace").asText()).contains("RuntimeException").contains("boom");

        // システムログ（SYSTEM）：発生元 provider 無し
        JsonNode sys = logLineOf(out, "system.check.Sample");
        assertEnvelope(sys, "system.check.Sample", "INFO", 20000, "system log");
        assertThat(sys.path("type").asText()).isEqualTo("app");
        assertThat(sys.path("subtype").asText()).isEqualTo("SYSTEM");
        assertThat(sys.has("class_name")).as("SYSTEM は class_name 無し").isFalse();
        assertThat(sys.has("method_name")).isFalse();
    }

    /**
     * マスク・出力長制限が実 encoder 経由で適用されること。
     *
     * 観点：出力時に {@code SanitizingCompositeJsonEncoder} がマスクと出力長制限を適用すること。
     */
    @Test
    void maskingAndLengthLimitApplyThroughEncoder(CapturedOutput out) {
        LoggerFactory.getLogger(LoggerNames.API_ACCESS_JNL).info(
                StructuredLog.create()
                        .put(LogFields.HEADERS, Map.of("Authorization", "Bearer secret-token"))
                        .put(LogFields.BODY,
                                "{\"password\":\"p@ssw0rd\",\"note\":\"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ\"}")
                        .marker(),
                "mask/limit check");

        assertThat(out).contains("\"***\"");                   // マスク適用
        assertThat(out).doesNotContain("p@ssw0rd");            // body の password 値が伏せられた
        assertThat(out).doesNotContain("Bearer secret-token"); // headers の authorization 値が伏せられた
        assertThat(out).contains("(truncated)");               // body が上限超過で制限された
    }

    /**
     * メッセージと stack_trace を最大まで膨らませても、実 encoder を通した1行が 4KB 以内に収まること。
     *
     * 観点：message は encoder（既定 768）、stack_trace は appender（既定 2560）で制限され、行全体が 4KB を超えないこと。
     * 併せて stack_trace の改行が \n エスケープされ1物理行に収まることも確認する（G）。
     */
    @Test
    void errorLineStaysWithin4KbWhenMessageAndStackTraceMaxedOut(CapturedOutput out) {
        RuntimeException deep = new RuntimeException("root");
        for (int i = 0; i < 80; i++) {
            deep = new RuntimeException("layer " + i + " " + "x".repeat(50), deep); // stack_trace を上限超へ
        }
        ApplicationLogger.getLogger().error("ERR4KB-" + "M".repeat(5000), deep);

        String errLine = out.getAll().lines()
                .filter(l -> l.contains("ERR4KB-")) // 先頭の目印は message 制限後も残る
                .findFirst().orElseThrow();

        assertThat(errLine.getBytes(UTF_8).length).as("1行 4KB 以内").isLessThanOrEqualTo(4096);
        assertThat(errLine).contains("(truncated)");     // message が上限超過で制限
        assertThat(errLine).contains("\"stack_trace\""); // stack_trace も出力（1物理行に収まる）
    }

    /**
     * 環境変数 CONTAINER_ID／CONTAINER_NAME が設定されていれば id／name に反映されること（C 設定観点）。
     *
     * <p>{@code ${CONTAINER_ID:--}} は config 解決時に評価されるため、独立した {@link LoggerContext} を
     * 用意し、システムプロパティを設定した状態で encoder を start() して反映を確認する（全体構成に影響しない）。
     */
    @Test
    void idAndNameReflectContainerWhenSet() throws Exception {
        LoggerContext ctx = new LoggerContext();
        ctx.putProperty("CONTAINER_ID", "cid-1");
        ctx.putProperty("CONTAINER_NAME", "cname-1");
        // ${CONTAINER_ID:--} は本番では Joran が config 解決時に substVars で置換する。テストも同じ解決を再現する。
        String pattern = OptionHelper.substVars(
                "{\"id\":\"${CONTAINER_ID:--}\",\"name\":\"${CONTAINER_NAME:--}\"}", ctx);
        // 未設定なら "null" に解決されることも同時に確認（C 未設定観点の機構レベル裏取り）
        assertThat(OptionHelper.substVars("${CONTAINER_ID:--}", new LoggerContext()))
                .as("未設定なら null").isEqualTo("-");

        SanitizingCompositeJsonEncoder encoder = new SanitizingCompositeJsonEncoder();
        encoder.setContext(ctx);
        LoggingEventPatternJsonProvider idName = new LoggingEventPatternJsonProvider();
        idName.setPattern(pattern);
        encoder.getProviders().addProvider(idName);
        encoder.start();

        Logger logger = ctx.getLogger("env-test");
        LoggingEvent event = new LoggingEvent("fqcn", logger, Level.INFO, "x", null, null);
        JsonNode json = MAPPER.readTree(new String(encoder.encode(event), UTF_8));
        assertThat(json.path("id").asText()).as("id=設定値").isEqualTo("cid-1");
        assertThat(json.path("name").asText()).as("name=設定値").isEqualTo("cname-1");
    }
}
