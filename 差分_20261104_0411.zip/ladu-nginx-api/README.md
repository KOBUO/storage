# 電文受付

新POS・SC からのリクエストを、店舗コードとリクエストURIに応じてバックエンドサービスへ振り分けて転送する Nginx。

振分けの定義はデータベースで管理する。サイドカーコンテナが起動時にルーティング情報を取得して共有ボリュームへ出力し、
Nginx はこれを読み込んで振分け定義を生成する。リクエストの受信時に適用期間を判定するため、
適用開始日時を過ぎると、コンテナを再起動せずに転送先が切り替わる。

あわせて、同時接続数の制限とエラー応答の生成を行う。
HTTPS で転送する場合は、転送先のサーバー証明書を検証する。

## 構成

| ディレクトリ | 内容 |
|---|---|
| `docker/nginx/` | Nginx のイメージ（設定ファイルのテンプレート、振分け処理の njs、起動処理） |
| `docker/nginx/certs/` | バックエンドのサーバー証明書の検証に用いるルート証明書 |
| `docker/loader/` | サイドカーのイメージ（ルーティング情報の取得） |
| `docs/` | 設計書 |
| `.gitlab-ci.yml` | パイプライン（ビルド・Nexus への登録・ECR への登録）。Nginx とサイドカーの2イメージ |

設定値はすべて環境変数で与える。一覧と既定値は `docs/電文受付.md` の環境変数の節に記載する。

## パイプライン

`.gitlab-ci.yml` で、コンテナイメージをビルドし Nexus を経由して ECR へ登録する。
pipeline-template の `common-pipeline.yml` を include し、タグ名の判定（`pre:pipeline`）と Nexus へのログイン・ビルド（`.docker-build-base`）を利用する。

| アクション | 実行されるジョブ |
|---|---|
| ブランチへの push／MR | `*-docker-build`（ビルドの確認のみ） |
| タグの作成 | `*-docker-build`、`*-nexus-push`（Nexus へ登録）、`*-ecr-push`（Nexus のイメージを ECR へ登録） |

- Nexus の格納先はタグ名で決まる。`snapshot-1.0.0-build1` の場合は `lpj-docker-snapshot`、`release-1.0.0` の場合は `lpj-docker-release`。
- イメージのタグは、タグ名から `snapshot-`／`release-` を除いたもの（例: `1.0.0-build1`、`1.0.0`）。
- ECR へは Nexus に登録したイメージをそのまま登録し、再ビルドしない。
- ECR のリポジトリ名は `.gitlab-ci.yml` の `.nginx`・`.loader` の `ECR_REPOSITORY` に設定する。
- Nexus のイメージ名は、Nginx がプロジェクト名、サイドカーがプロジェクト名に `-loader` を付けたもの。
