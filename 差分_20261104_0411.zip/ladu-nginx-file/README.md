# ファイルダウンロード

新POS からのファイルダウンロードのリクエストを S3 へ中継し、帯域制限をかけながらクライアントへ転送する Nginx。

リクエストヘッダで指定された帯域制御区分に対応する帯域制限値に従って、クライアントへの転送速度を制限する。
S3 への接続は VPC エンドポイントを経由し、アクセス認可はバケットポリシーで行う。
S3 へは、バケット名をホスト名に含める仮想ホスト形式（`{バケット名}.{S3のエンドポイント}`）で転送する。
Nginx は署名の生成も検証も行わず、中継のみを担う。

あわせて、エラー応答の生成を行う。

## 構成

| ディレクトリ | 内容 |
|---|---|
| `docker/nginx/` | Nginx のイメージ（設定ファイルのテンプレート、中継処理の njs、起動処理） |
| `docs/` | 設計書 |
| `.gitlab-ci.yml` | パイプライン（ビルド・Nexus への登録・ECR への登録） |

設定値はすべて環境変数で与える。一覧と既定値は `docs/ファイルダウンロード.md` の環境変数の節に記載する。

## パイプライン

`.gitlab-ci.yml` で、コンテナイメージをビルドし Nexus を経由して ECR へ登録する。
pipeline-template の `common-pipeline.yml` を include し、タグ名の判定（`pre:pipeline`）と Nexus へのログイン・ビルド（`.docker-build-base`）を利用する。

| アクション | 実行されるジョブ |
|---|---|
| ブランチへの push／MR | `*-docker-build`（ビルドの確認のみ） |
| タグの作成 | `*-docker-build`、`*-nexus-push`（Nexus へ登録）、`*-ecr-push`（Nexus のイメージを ECR へ登録） |

- Nexus の格納先はタグ名で決まる。`snapshot-1.0.0-build1` の場合は `lpj-docker-snapshot`、`release-1.0.0` の場合は `lpj-docker-release`。
- イメージのタグは、タグ名から `snapshot-`／`release-` を除いたもの（例: `1.0.0-build1`、`1.0.0`）。
- ECR へは Nexus に登録したイメージをそのまま登録し、再ビルドしない。
- ECR のリポジトリ名は `.gitlab-ci.yml` の `ECR_REPOSITORY` に設定する。
