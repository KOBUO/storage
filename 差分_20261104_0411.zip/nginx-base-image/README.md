# nginx-base-image

Nginx の実行用ベースイメージ（Amazon Linux 2023 + Nginx + njs）を作成し、Nexus（lpj-docker-base）へ登録するプロジェクトです。

## イメージの内容

| 項目 | 内容 |
|---|---|
| ベースイメージ | `amazonlinux:2023`（sha256 で固定） |
| OS | Amazon Linux 2023 |
| 追加内容 | `nginx`、`nginx-mod-njs`（njs モジュール）、`gettext`（envsubst）、`jq`、`TZ=Asia/Tokyo` |

## バージョン一覧

| イメージのタグ | Amazon Linux | nginx | nginx-mod-njs | ベースイメージの sha256 |
|---|---|---|---|---|
| `2023.12.20261021-custom-nginx` | 2023.12.20261021 | 1.30.5-1.amzn2023.0.1 | 1.0.1-1.amzn2023.0.2 | `c04a1012acc483977f61f7f91c28624a39a621e56a59781319a75dec528be9b6` |

## 構成

```
nginx-base-image/
├── docker/
│   └── Dockerfile
├── .gitlab-ci.yml
└── README.md
```

## パイプラインの動き

pipeline-template（`common-pipeline.yml`）を利用しています。

| アクション | 実行されるジョブ |
|---|---|
| ブランチへの push／MR | `build`（ビルドの確認のみ） |
| タグの作成 | `build`、`nexus-push`（Nexus へ push） |

pipeline-template の `pre:pipeline`（git のタグ名のチェック）は実行しません。

ビルド時に Amazon Linux のリポジトリからパッケージを取得するため、`docker build` にプロキシを指定しています。

## イメージのタグ

イメージは `amazonlinux:<Amazon Linux の版>-custom-nginx` の名前で登録します。タグは `.gitlab-ci.yml` の `IMAGE_TAG` で指定します。

- Amazon Linux の版は、ベースイメージに含まれる `system-release` の版です。
  `docker run --rm amazonlinux@sha256:<sha> rpm -q system-release` で確認できます。
- git のタグは nexus-push を動かすためのもので、イメージのタグにはなりません。git のタグには、イメージのタグと同じ名前を付けます。

## リリース手順

1. 変更をターゲットブランチにマージします。
2. `.gitlab-ci.yml` の `IMAGE_TAG` と、「バージョン一覧」の表を更新します。
3. ターゲットブランチからタグを作成します。

   ```
   git tag 2023.12.20261021-custom-nginx
   git push origin 2023.12.20261021-custom-nginx
   ```

4. パイプラインの `nexus-push` が成功したことを確認します。

## 利用方法

```dockerfile
ARG DOCKER_BASE_REGISTRY=""
FROM ${DOCKER_BASE_REGISTRY}amazonlinux:2023.12.20261021-custom-nginx
```

njs モジュールは `/usr/lib64/nginx/modules/` に配置されます。Nginx の設定ファイルでは絶対パスで読み込んでください。

```nginx
load_module /usr/lib64/nginx/modules/ngx_http_js_module.so;
```

## ベースイメージを更新するとき

`FROM` の sha を変えるときは、`nginx`・`nginx-mod-njs` の版も合わせて見直してください。sha を固定すると、参照するリポジトリの時点も固定されるため、そのイメージで提供されていない版は指定できません。

### 手順

1. 新しいベースイメージで提供されている版を確認します。

   ```
   docker run --rm --platform linux/amd64 amazonlinux@sha256:<新しいsha> \
     dnf list --showduplicates nginx nginx-mod-njs
   ```

2. `docker/Dockerfile` の `FROM` の sha と、`dnf install` の版を書き換えます。`.gitlab-ci.yml` の `IMAGE_TAG` も新しい Amazon Linux の版に変えます。
   - `nginx-mod-njs` は `nginx` と同じ版向けのものを指定してください。組み合わせが違うと、インストール時にエラーになります。
3. 「バージョン一覧」に行を追加し、git のタグを作成します。
