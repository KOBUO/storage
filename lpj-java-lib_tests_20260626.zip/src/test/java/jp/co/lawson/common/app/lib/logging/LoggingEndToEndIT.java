package jp.co.lawson.common.app.lib.logging;

import static java.nio.charset.StandardCharsets.UTF_8;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.LoggerFactory;
import org.springframework.boot.LazyInitializationExcludeFilter;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import org.springframework.context.annotation.Bean;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletResponse;

import jp.co.lawson.common.app.lib.logging.api.ApiAccessLogFilter;
import jp.co.lawson.common.app.lib.logging.constant.LogFields;
import jp.co.lawson.common.app.lib.logging.constant.LoggerNames;
import jp.co.lawson.common.app.lib.logging.sqs.SqsJobArgumentProvider;
import jp.co.lawson.common.app.lib.logging.sqs.SqsReceiveJournalInterceptor;

/**
 * 全ログ種別を、実フィルタ／インターセプタ（実 MDC スコープ）経由で出力する end-to-end 検証。
 * 実 encoder（{@code SanitizingCompositeJsonEncoder}）を通して、種類別の type／subtype・
 * API のヘッダ由来項目（user／action／source_ip）・SQS の JobExecutionId／メッセージID・
 * マスク／出力長制限が反映されることを確認する。
 */
@SpringBootTest(
        classes = LoggingEndToEndIT.TestApp.class,
        webEnvironment = SpringBootTest.WebEnvironment.NONE,
        properties = {
                "cosmo-app.logging.mask.headers.keys=authorization",
                "cosmo-app.logging.mask.body.keys=password",
                "cosmo-app.logging.limits.body=64"
        })
@ExtendWith(OutputCaptureExtension.class)
class LoggingEndToEndIT {

    @SpringBootConfiguration
    @EnableConfigurationProperties(LoggingProperties.class)
    static class TestApp {
        @Bean
        static LazyInitializationExcludeFilter eager() {
            return LazyInitializationExcludeFilter.forBeanTypes(LoggingProperties.class);
        }
    }

    private static void marker(String logger, String msg, Map<String, Object> fields) {
        StructuredLog s = StructuredLog.create();
        fields.forEach(s::put);
        LoggerFactory.getLogger(logger).info(s.marker(), msg);
    }

    /**
     * API／SQS の実フローを通して全ログ種別が統一フォーマットで出力されること。
     *
     * 試験条件
     * ・実 ApiAccessLogFilter を必要ヘッダ付きで、実 SqsReceiveJournalInterceptor を JobID＋メッセージID付きで駆動し、
     * 　各処理中に SQL／サービス／ストレージ／外部／KMS／DynamoDB／業務／業務エラー／システムを出力する。
     * 観点
     * ・各種別の type／subtype、API スコープの user／action／source_ip、SQS スコープの function＝JobExecutionId／trace＝メッセージID、
     * 　マスク（authorization／password→***）・出力長制限（body 64B→...(truncated)）が実出力に反映されること。
     * 想定結果
     * ・全固定ロガーの logger_name が出力され、上記の不変条件をすべて満たすこと。
     */
    @Test
    void emitsEveryLogTypeThroughRealComponents(CapturedOutput out) throws Exception {
        // ===== API リクエスト（実 ApiAccessLogFilter・必要ヘッダ付き）=====
        ApiAccessLogFilter apiFilter = new ApiAccessLogFilter();
        MockHttpServletRequest req = new MockHttpServletRequest("POST", "/api/orders");
        req.setQueryString("id=1");
        req.addHeader("X-User-ID", "user-001");
        req.addHeader("X-Trace-ID", "trace-abc-123");
        req.addHeader("X-Forwarded-For", "203.0.113.5, 10.0.0.1");
        req.addHeader("Authorization", "Bearer secret-token");
        req.setContentType("application/json");
        req.setContent("{\"password\":\"p@ssw0rd\",\"item\":\"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-LONG\"}".getBytes(UTF_8));
        MockHttpServletResponse resp = new MockHttpServletResponse();

        FilterChain chain = (rq, rs) -> {
            marker(LoggerNames.SERVICE_JNL, "サービスジャーナル",
                    Map.of(LogFields.ARGS, "[{\"orderId\":1}]", LogFields.RESULT, "{\"status\":\"OK\"}", LogFields.LATENCY, 8));
            marker(LoggerNames.SQL_JNL, "SELECT * FROM orders WHERE id = ?", Map.of(LogFields.LATENCY, 3));
            marker(LoggerNames.STORAGE_JNL, "ストレージアクセスジャーナル", Map.of(LogFields.LATENCY, 25, LogFields.AWS_REQUEST_ID, "s3-req-1"));
            marker(LoggerNames.HTTP_CLIENT_JNL, "外部アクセスジャーナル",
                    Map.of(LogFields.URL, "GET https://api.example.com/x", LogFields.STATUS, 200, LogFields.LATENCY, 40));
            ApplicationLogger.getLogger().info("業務ログ");
            HttpServletResponse r = (HttpServletResponse) rs;
            r.setStatus(200);
            r.getWriter().write("{\"ok\":true}");
        };
        apiFilter.doFilter(req, resp, chain);

        // ===== SQS ポーリング（実 SqsReceiveJournalInterceptor・JobID＋メッセージID付き）=====
        SqsJobArgumentProvider jobArgs = mock(SqsJobArgumentProvider.class);
        when(jobArgs.getJobExecutionId()).thenReturn("batch-orders-20260626-7f3a");
        SqsReceiveJournalInterceptor sqsInterceptor = new SqsReceiveJournalInterceptor(jobArgs);

        MessageHeaders headers = mock(MessageHeaders.class);
        when(headers.getId()).thenReturn(UUID.fromString("11111111-2222-3333-4444-555555555555"));
        @SuppressWarnings("unchecked")
        Message<Object> message = mock(Message.class);
        when(message.getHeaders()).thenReturn(headers);

        sqsInterceptor.intercept(message);
        marker(LoggerNames.KMS_JNL, "KMSアクセスジャーナル", Map.of(LogFields.LATENCY, 7, LogFields.AWS_REQUEST_ID, "kms-req-1"));
        marker(LoggerNames.DYNAMODB_JNL, "DynamoDBアクセスジャーナル", Map.of(LogFields.LATENCY, 4, LogFields.AWS_REQUEST_ID, "ddb-req-1"));
        ApplicationLogger.getLogger().error("業務エラーログ", new RuntimeException("e2e error"));
        sqsInterceptor.afterProcessing(message, null);

        // ===== システムログ（固定ロガー以外・MDC スコープ外）=====
        LoggerFactory.getLogger("system.E2E.Sample").info("システムログ");

        String log = out.getAll();

        // 全固定ロガーが出力されていること
        for (String name : new String[] {
                LoggerNames.API_ACCESS, LoggerNames.API_ACCESS_JNL, LoggerNames.SERVICE_JNL, LoggerNames.SQL_JNL,
                LoggerNames.STORAGE_JNL, LoggerNames.HTTP_CLIENT_JNL, LoggerNames.SQS_JNL, LoggerNames.KMS_JNL,
                LoggerNames.DYNAMODB_JNL, LoggerNames.API_LOG, LoggerNames.ERROR_LOG }) {
            assertThat(log).as(name).contains("\"logger_name\":\"" + name + "\"");
        }

        // type/subtype の代表
        assertThat(log).contains("\"type\":\"trail\"");      // アクセスログ
        assertThat(log).contains("\"subtype\":\"DBCALL\"");  // SQL
        assertThat(log).contains("\"subtype\":\"AWSCALL\""); // AWS 系
        assertThat(log).contains("\"subtype\":\"SYSTEM\"");  // システム
        assertThat(log).contains("\"type\":\"monitor\"");    // 業務エラー
        assertThat(log).contains("\"stack_trace\"");         // 〃

        // API：ヘッダ由来の MDC（アクセスログ）
        assertThat(log).contains("\"user\":\"user-001\"");
        assertThat(log).contains("\"action\":\"POST /api/orders\"");
        assertThat(log).contains("\"source_ip\":\"203.0.113.5\"");

        // SQS：JobExecutionId（function）／メッセージID（trace）
        assertThat(log).contains("\"function\":\"batch-orders-20260626-7f3a\"");
        assertThat(log).contains("\"trace\":\"11111111-2222-3333-4444-555555555555\"");

        // マスク・出力長制限
        assertThat(log).contains("\"***\"").contains("(truncated)")
                .doesNotContain("Bearer secret-token").doesNotContain("p@ssw0rd");
    }
}
