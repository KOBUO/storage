package jp.co.lawson.common.app.lib.logging.sqs;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.DefaultApplicationArguments;

/**
 * {@link SqsJobArgumentProvider} の単体テスト。
 */
class SqsJobArgumentProviderTest {

    /**
     * 第1引数を JobIdentifier、第2引数を JobExecutionId として取得すること。
     *
     * 試験条件
     * ・非オプション引数を2つ（JOB-A／EXEC-1）渡して生成する。
     * 観点
     * ・第1引数を jobIdentifier、第2引数を jobExecutionId にそのまま採用すること。
     * 想定結果
     * ・jobIdentifier＝JOB-A、jobExecutionId＝EXEC-1 であること。
     */
    @Test
    void resolvesBothFromArguments() {
        SqsJobArgumentProvider p = new SqsJobArgumentProvider(new DefaultApplicationArguments("JOB-A", "EXEC-1"));

        assertThat(p.getJobIdentifier()).isEqualTo("JOB-A");
        assertThat(p.getJobExecutionId()).isEqualTo("EXEC-1");
    }

    /**
     * 第2引数が無い場合、JobIdentifier に UUID を付与して JobExecutionId を採番すること。
     *
     * 試験条件
     * ・非オプション引数を1つ（JOB-A）だけ渡して生成する。
     * 観点
     * ・第2引数が無いとき jobExecutionId を「jobIdentifier + "-" + UUID」で生成すること。
     * 想定結果
     * ・jobIdentifier＝JOB-A、jobExecutionId は「JOB-A-」で始まり接頭辞より長いこと。
     */
    @Test
    void generatesExecutionIdWhenSecondArgAbsent() {
        SqsJobArgumentProvider p = new SqsJobArgumentProvider(new DefaultApplicationArguments("JOB-A"));

        assertThat(p.getJobIdentifier()).isEqualTo("JOB-A");
        assertThat(p.getJobExecutionId()).startsWith("JOB-A-");
        assertThat(p.getJobExecutionId().length()).isGreaterThan("JOB-A-".length());
    }

    /**
     * 第1引数（JobIdentifier）が無い場合、例外を送出すること。
     *
     * 試験条件
     * ・非オプション引数なしで生成する。
     * 観点
     * ・JobIdentifier 未設定を不正として扱うこと。
     * 想定結果
     * ・IllegalArgumentException を送出すること。
     */
    @Test
    void throwsWhenJobIdentifierMissing() {
        assertThatThrownBy(() -> new SqsJobArgumentProvider(new DefaultApplicationArguments()))
                .isInstanceOf(IllegalArgumentException.class);
    }

    /**
     * 第1引数（JobIdentifier）が空白のみの場合、例外を送出すること。
     *
     * 試験条件
     * ・非オプション引数に空白文字のみを渡して生成する。
     * 観点
     * ・空白のみの JobIdentifier を不正として扱うこと。
     * 想定結果
     * ・IllegalArgumentException を送出すること。
     */
    @Test
    void throwsWhenJobIdentifierBlank() {
        assertThatThrownBy(() -> new SqsJobArgumentProvider(new DefaultApplicationArguments(" ")))
                .isInstanceOf(IllegalArgumentException.class);
    }
}
