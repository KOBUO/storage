import org.gradle.api.tasks.testing.logging.TestExceptionFormat

plugins {
    id("org.springframework.boot") version "4.0.6"
    id("java")
    id("jacoco")
}

tasks.withType<JavaCompile> { options.release = 25 }

configurations {
    compileOnly {
        extendsFrom(configurations.annotationProcessor.get())
    }
}

repositories { mavenCentral() }


dependencies {
    val springBootBom = platform("org.springframework.boot:spring-boot-dependencies:4.0.6")
    implementation(springBootBom)
    compileOnly(springBootBom)
    annotationProcessor(springBootBom)
    testImplementation(springBootBom)
    testCompileOnly(springBootBom)
    testAnnotationProcessor(springBootBom)
    implementation("org.springframework.boot:spring-boot-starter")
    compileOnly("org.projectlombok:lombok")
    annotationProcessor("org.projectlombok:lombok")
    runtimeOnly("org.postgresql:postgresql")
    implementation("software.amazon.jdbc:aws-advanced-jdbc-wrapper:4.0.1")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    testImplementation("org.springframework.boot:spring-boot-starter-aspectj")

    implementation("org.springframework.batch:spring-batch-infrastructure")
    implementation("org.mybatis.spring.boot:mybatis-spring-boot-starter:4.0.1")
    implementation("com.fasterxml.jackson.core:jackson-databind")
    implementation("org.springframework.boot:spring-boot-starter-web")

    testImplementation("org.junit.jupiter:junit-jupiter:6.0.3")
    testImplementation("org.junit.jupiter:junit-jupiter-api:6.0.3")
    testImplementation("org.junit.jupiter:junit-jupiter-engine:6.0.3")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jdk8:2.19.2")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.19.2")
    testImplementation("org.dbunit:dbunit:2.8.0")
    testImplementation("commons-io:commons-io:2.2")
    testCompileOnly("org.projectlombok:lombok:1.18.38")
    testAnnotationProcessor("org.projectlombok:lombok:1.18.38")
    implementation("jakarta.validation:jakarta.validation-api:3.0.2")
    implementation("org.hibernate.validator:hibernate-validator:8.0.2.Final")
    implementation("org.springframework.boot:spring-boot-starter-data-jdbc:4.0.6")

    testImplementation("org.hsqldb:hsqldb")
    testRuntimeOnly("org.postgresql:postgresql:42.7.4")
    testImplementation("org.elasticmq:elasticmq-rest-sqs_2.13:1.7.1")
    testImplementation("com.adobe.testing:s3mock-junit5:5.0.0")

    implementation("org.springframework.retry:spring-retry:2.0.13")
    implementation("org.springframework.boot:spring-boot-starter-validation")
    implementation("net.logstash.logback:logstash-logback-encoder:9.0")
}

tasks.withType<JavaCompile> {
    options.compilerArgs.add("-parameters")
}
tasks.named<Test>("test") {
    maxHeapSize = "1024m"
    forkEvery = 50
    useJUnitPlatform()
    testLogging { exceptionFormat = TestExceptionFormat.FULL }
}

jacoco {
    toolVersion = "0.8.14"
}

tasks.jacocoTestReport {
    dependsOn(tasks.test)
    reports {
        xml.required = true
        html.required = true
    }
    classDirectories.setFrom(files(classDirectories.files.map {
        fileTree(it) {
            include("jp/co/lawson/laif/**")
        }
    }))
}
