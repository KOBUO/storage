plugins {
    java
    id("org.springframework.boot") version "4.0.6"
    id("io.spring.dependency-management") version "1.1.7"
}

group = "jp.co.lawson.laif"
version = "0.0.1-SNAPSHOT"

tasks.withType<JavaCompile> {
    options.release = 25
}

repositories {
    mavenCentral()
}

// Mockito を javaagent として読み込む (JDK21+ の動的アタッチ警告対策)
val mockitoAgent = configurations.create("mockitoAgent")

dependencies {
    implementation("org.springframework.boot:spring-boot-starter")
    implementation("org.springframework.boot:spring-boot-starter-validation")
    implementation("org.springframework.boot:spring-boot-starter-aspectj")
    implementation("org.mybatis.spring.boot:mybatis-spring-boot-starter:4.0.1")
    implementation("org.springframework.retry:spring-retry:2.0.13")
    implementation("net.logstash.logback:logstash-logback-encoder:9.0")
    compileOnly("org.projectlombok:lombok")
    annotationProcessor("org.projectlombok:lombok")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
    testRuntimeOnly("org.hsqldb:hsqldb")
    mockitoAgent("org.mockito:mockito-core") { isTransitive = false }
}

tasks.test {
    useJUnitPlatform()
    jvmArgs("-javaagent:${mockitoAgent.asPath}", "-Dfile.encoding=UTF-8")
}
