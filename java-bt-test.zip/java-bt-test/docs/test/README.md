# 単体テスト (LAIF016 配信指示登録処理)

## ファイル

| ファイル | 内容 |
|---|---|
| `UNT-030_LAIF016_観点追記.tsv` | 試験項目書 (UNT-030「テストケース表」) に貼る行。列は A〜W 列と同じ並び。空欄だった行の埋め込みと、設計書・実装観点で追加した行 |
| `UNT-030_LAIF016_事前DBデータ.tsv` | 試験項目書の「事前DBデータ」シートに貼る内容。No (事前01〜11) ごとに 3 テーブルの行と、各行の意図 |
| `UNT-030_LAIF016_想定DBデータ.tsv` | 試験項目書の「想定DBデータ」シートに貼る内容。No (想定01〜12) ごとに 3 テーブルの行、更新/変更なし、その理由、想定ログ |
| `事前DBデータ_想定DBデータ.md` | 上の 2 つを読みやすくしたもの。単体テストのケースと No・環境変数の対応表つき |
| `../../src/test/java/.../DistributeInstructRegisterJobTest.java` | 単体テスト (`@SpringBootTest`) |
| `../../src/test/resources/.../testcases/README.md` | テストケース (case_01〜33) の一覧 |

TSV の「事前DBデータNo」「実施後DBデータNo」には、事前01〜11・想定01〜12 の No を入れている。既存の行の「(正常系のデータ)」は事前01、「(更新ありのデータ)」は想定01、「(更新なしのデータ)」は想定02 にあたる。

## 試験項目書の既存行と単体テストの対応

| 試験項目書のケースNo | 観点 | 単体テスト |
|---|---|---|
| LAIF016-1-1-1-1-1-1〜10 | 環境変数が未設定 | case_26 |
| LAIF016-1-1-1-1-1-11〜20 | 環境変数が空文字 | case_34 |
| LAIF016-1-1-1-1-1-21〜30 | 環境変数が負数 | case_27, case_05 |
| LAIF016-1-1-1-1-1-31〜40 | Integer 下限値超過 | case_29 |
| LAIF016-1-1-1-1-1-41〜50 | Integer 上限値超過 | case_29, case_07 |
| LAIF016-1-1-1-1-1-51〜60 | 数値以外 | case_29, case_06 |
| LAIF016-1-1-1-1-2-1〜10 | 0 値 | case_28 |
| LAIF016-1-1-1-1-2-11〜20 | 正数 | case_01 |
| LAIF016-2-1-1-1-1-1 | 起動引数が未指定 | case_30 |
| LAIF016-2-1-1-1-1-2 | 起動引数が空文字 | case_32 |
| LAIF016-2-1-1-2-1-1 | 起動引数が複数指定 | case_31 |
| LAIF016-2-1-1-2-1-2 | 起動引数が許容値以外 | case_04 |
| 上記以外 (LAIF016-2-1-1-2-2-* 以降) | | TSV の「事前DBデータNo」を参照 |

## カバレッジ (2026-10-01、`./gradlew clean test jacocoTestReport`)

65 テスト (case_29 は 33 通り) すべて成功。対象は `jp.co.lawson.laif` 配下 (社内フレームワークの代用クラスは除く)。lombok の生成コードは `lombok.config` で除外。

| クラス | 行 | 分岐 |
|---|---|---|
| DistributeInstructRegisterJob | 28/28 | 7/8 |
| DistributeInstructRegisterJobPreprocessor | 32/32 | 6/6 |
| DistributeInstructRegisterJobPermissionSetter | 99/99 | 53/53 |
| DistributeInstructRegisterJobDatabaseUpdater | 7/7 | - |
| DistributeConst (AreaCategory / Channel) | 14/14 | - |
| BatchConfiguration | 1/1 | - |
| BatchApplication | 0/10 | 0/2 |
| 合計 | 187/197 | 66/69 |

通せない箇所

| 箇所 | 理由 |
|---|---|
| `BatchApplication` (main / batchAppRun) | `System.exit` を呼ぶため、テストの JVM の中で実行できない |
| `DistributeInstructRegisterJob` 65 行目 `distributeAreaCategory == null` | 起動引数が無い場合は `JobParameterUtils` が `NoJobParameterException` を投げるため、null が届かない |

## 設計書と実装・設定の違い (要判断)

| # | 箇所 | 設計書 | 実装 |
|---|---|---|---|
| 1 | 環境変数チェックのメッセージ | 環境変数（プロパティ）が不正です。 | 環境変数(プロパティ)の設定値が不正です。 |
| 2 | 更新日時 (upd_dt_tm) | バッチの開始日時 | SQL の `CURRENT_TIMESTAMP` (更新した時刻) |
| 3 | 起動引数が未指定 | `JobParameterUtils` が `NoJobParameterException` を投げる | ジョブ側の `distributeAreaCategory == null` のチェックには届かない (不要なコード) |

## 実装で考慮したこと

| 箇所 | 内容 |
|---|---|
| 転送帯域が 0 | 0 で割らないよう、転送帯域が 0 のチャネルは帯域上限判定を行わない (上限未到達として扱う)。`DistributeInstructRegisterJobPermissionSetter#isBandwidthLimitReached` (case_25) |
