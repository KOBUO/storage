# 事前DBデータ・想定DBデータ (LAIF016)

単体テストのケース資材 (testcases/case_xx/input, expected) から作成。内容が同じものは同じ No にまとめている。

## 事前DBデータ

### 事前01 (正常系のデータ)

使用ケース: case_01, case_02, case_03, case_04, case_05, case_06, case_07, case_17, case_18, case_19, case_20, case_21, case_22, case_23, case_26, case_27, case_28, case_29, case_30, case_31, case_32, case_33, case_34

**laif_distribute_status** (配信状況) 5件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 05 | 2 | 0 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信不可。店舗S001の1台目 |
| 2 | S001 | 01 | 02 | 05 | 2 | 0 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信不可。店舗S001の2台目 (同時配信機器数1で上限) |
| 3 | S002 | 01 | 01 | 05 | 3 | 0 | 1 | 3 | SEED | 2026-09-20 10:00:00 | 配信不可。別店舗S002・チャネルC |
| 4 | S003 | 01 | 01 | 05 | 2 | 0 | 1 | 4 | SEED | 2026-09-20 10:00:00 | 配信不可。配信完了テーブルに存在する (処理対象外) |
| 5 | S004 | 01 | 01 | 01 | 2 | 0 | 1 | 5 | SEED | 2026-09-20 10:00:00 | 配信不可。起動引数と別の配信エリア種別01 (処理対象外) |

**laif_distribute_completed** (配信完了) 1件

| distribute_id | distribute_status_kbn | distribute_completed_dt_tm | distribute_stop_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 意図 |
|---|---|---|---|---|---|---|---|---|
| 4 | 07 | 2026-06-09 10:11:07 | 2026-06-09 11:11:07 | 2026-06-09 12:11:07 | DLAIF0100017 | 2026-06-09 13:11:07 | DLAIF0100027 | 配信ID 4 を配信完了済みにする |

**laif_down_equipment** (ダウン機器) 1件

| store_cd | equipment_category | equipment_no | down_equipment_entry_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 意図 |
|---|---|---|---|---|---|---|---|---|
| S009 | 05 | 15 | 2026-06-09 11:12:05 | 2026-06-09 12:12:05 | DLAIF0100035 | 2026-06-09 13:12:05 | DLAIF0100045 | どの配信状況とも一致しないダウン機器 |

### 事前02

使用ケース: case_08

**laif_distribute_status** (配信状況) 4件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 0 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルB (最初に処理する) |
| 2 | S002 | 01 | 01 | 01 | 3 | 0 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルC (2番目に処理する) |
| 3 | S003 | 01 | 01 | 01 | 1 | 0 | 1 | 3 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルA (最後に処理する) |
| 4 | S004 | 01 | 01 | 01 | 1 | 0 | 1 | 4 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルA の2件目 |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


### 事前03

使用ケース: case_09

**laif_distribute_status** (配信状況) 8件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 02 | 2 | 0 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルB の1件目 |
| 2 | S002 | 01 | 01 | 02 | 2 | 0 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルB の2件目 |
| 3 | S003 | 01 | 01 | 02 | 2 | 0 | 1 | 3 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルB の3件目 |
| 4 | S001 | 01 | 01 | 02 | 3 | 0 | 1 | 4 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルC の1件目 |
| 5 | S002 | 01 | 01 | 02 | 3 | 0 | 1 | 5 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルC の2件目 |
| 6 | S001 | 01 | 01 | 02 | 1 | 0 | 1 | 6 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルA の1件目 |
| 7 | S002 | 01 | 01 | 02 | 1 | 0 | 1 | 7 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルA の2件目 |
| 8 | S003 | 01 | 01 | 02 | 1 | 0 | 1 | 8 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルA の3件目 |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


### 事前04

使用ケース: case_10

**laif_distribute_status** (配信状況) 7件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 03 | 2 | 1 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信可。店舗S001 機器01/01 (配信許可中) |
| 2 | S001 | 01 | 01 | 03 | 2 | 1 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信可。ID 1 と同じ機器 (同じ機器は1台として数える) |
| 3 | S001 | 01 | 02 | 03 | 2 | 0 | 1 | 3 | SEED | 2026-09-20 10:00:00 | 配信不可。店舗S001 機器01/02 (配信許可中の機器と別) |
| 4 | S001 | 01 | 01 | 03 | 2 | 0 | 1 | 4 | SEED | 2026-09-20 10:00:00 | 配信不可。店舗S001 機器01/01 (配信許可中の機器と同じ) |
| 5 | S001 | 02 | 03 | 03 | 2 | 0 | 1 | 5 | SEED | 2026-09-20 10:00:00 | 配信不可。店舗S001 機器02/03 (機器種別が違う) |
| 6 | S001 | 01 | 04 | 03 | 2 | 0 | 1 | 6 | SEED | 2026-09-20 10:00:00 | 配信不可。店舗S001 機器01/04 |
| 7 | S002 | 01 | 01 | 03 | 2 | 0 | 1 | 7 | SEED | 2026-09-20 10:00:00 | 配信不可。別店舗S002 |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


### 事前05

使用ケース: case_11

**laif_distribute_status** (配信状況) 4件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 04 | 1 | 0 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルA |
| 2 | S001 | 01 | 01 | 04 | 3 | 0 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルC の1台目 |
| 3 | S001 | 01 | 02 | 04 | 3 | 0 | 1 | 3 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルC の2台目 (同じ店舗) |
| 4 | S001 | 01 | 03 | 04 | 2 | 1 | 1 | 4 | SEED | 2026-09-20 10:00:00 | 配信可。同じ店舗のチャネルB (配信許可中) |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


### 事前06

使用ケース: case_12

**laif_distribute_status** (配信状況) 8件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 1 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信可。ダウン機器と店舗・機器種別・機器番号がすべて一致 |
| 2 | S001 | 01 | 02 | 01 | 2 | 1 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信可。ダウン機器と機器番号だけ違う |
| 3 | S009 | 01 | 01 | 01 | 2 | 1 | 1 | 3 | SEED | 2026-09-20 10:00:00 | 配信可。ダウン機器と店舗コードだけ違う (別店舗S009) |
| 4 | S001 | 02 | 01 | 01 | 2 | 1 | 1 | 4 | SEED | 2026-09-20 10:00:00 | 配信可。ダウン機器と機器種別だけ違う |
| 5 | S001 | 01 | 01 | 01 | 2 | 0 | 1 | 6 | SEED | 2026-09-20 10:00:00 | 配信不可。ダウン機器と一致 (配信順6) |
| 6 | S001 | 01 | 05 | 01 | 2 | 0 | 1 | 5 | SEED | 2026-09-20 10:00:00 | 配信不可。店舗S001 機器01/05 (配信順5) |
| 7 | S001 | 03 | 01 | 01 | 2 | 0 | 1 | 7 | SEED | 2026-09-20 10:00:00 | 配信不可。ダウン機器と機器種別だけ違う |
| 8 | S008 | 01 | 01 | 01 | 2 | 0 | 1 | 8 | SEED | 2026-09-20 10:00:00 | 配信不可。ダウン機器と店舗コードだけ違う (別店舗S008) |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 2件

| store_cd | equipment_category | equipment_no | down_equipment_entry_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 意図 |
|---|---|---|---|---|---|---|---|---|
| S001 | 01 | 01 | 2026-06-09 11:12:05 | 2026-06-09 12:12:05 | DLAIF0100035 | 2026-06-09 13:12:05 | DLAIF0100045 | ダウン中の機器 |
| S007 | 01 | 01 | 2026-06-09 11:12:05 | 2026-06-09 12:12:05 | DLAIF0100035 | 2026-06-09 13:12:05 | DLAIF0100045 | どの配信状況とも一致しないダウン機器 (n件にするため) |

### 事前07

使用ケース: case_13

**laif_distribute_status** (配信状況) 4件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 05 | 2 | 1 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信可。店舗S001 機器01/01 |
| 2 | S001 | 01 | 01 | 05 | 2 | 1 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信可。ID 1 と同じ機器の別レコード |
| 3 | S001 | 01 | 02 | 05 | 2 | 0 | 1 | 3 | SEED | 2026-09-20 10:00:00 | 配信不可。店舗S001 |
| 4 | S002 | 01 | 01 | 05 | 2 | 0 | 1 | 4 | SEED | 2026-09-20 10:00:00 | 配信不可。別店舗S002 |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


### 事前08

使用ケース: case_14

**laif_distribute_status** (配信状況) 2件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 1 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信可 (配信不可の配信状況が無い) |
| 2 | S002 | 01 | 01 | 01 | 3 | 1 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信可。配信完了テーブルに存在する (処理対象外) |

**laif_distribute_completed** (配信完了) 1件

| distribute_id | distribute_status_kbn | distribute_completed_dt_tm | distribute_stop_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 意図 |
|---|---|---|---|---|---|---|---|---|
| 2 | 07 | 2026-06-09 10:11:07 | 2026-06-09 11:11:07 | 2026-06-09 12:11:07 | DLAIF0100017 | 2026-06-09 13:11:07 | DLAIF0100027 | 配信ID 2 を配信完了済みにする |

**laif_down_equipment** (ダウン機器) 0件


### 事前09

使用ケース: case_15

**laif_distribute_status** (配信状況) 2件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 0 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信不可。配信完了テーブルに存在する (処理対象外) |
| 2 | S002 | 01 | 01 | 02 | 2 | 0 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信不可。起動引数と別の配信エリア種別02 (処理対象外) |

**laif_distribute_completed** (配信完了) 1件

| distribute_id | distribute_status_kbn | distribute_completed_dt_tm | distribute_stop_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 意図 |
|---|---|---|---|---|---|---|---|---|
| 1 | 07 | 2026-06-09 10:11:07 | 2026-06-09 11:11:07 | 2026-06-09 12:11:07 | DLAIF0100017 | 2026-06-09 13:11:07 | DLAIF0100027 | 配信ID 1 を配信完了済みにする |

**laif_down_equipment** (ダウン機器) 0件


### 事前10

使用ケース: case_16

**laif_distribute_status** (配信状況) 3件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 0 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信不可。配信優先区分1・配信順1 |
| 2 | S001 | 01 | 02 | 01 | 2 | 0 | 2 | 5 | SEED | 2026-09-20 10:00:00 | 配信不可。配信優先区分2・配信順5 |
| 3 | S001 | 01 | 03 | 01 | 2 | 0 | 2 | 3 | SEED | 2026-09-20 10:00:00 | 配信不可。配信優先区分2・配信順3 |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


### 事前11

使用ケース: case_25

**laif_distribute_status** (配信状況) 2件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | upd_dt_tm | 意図 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 0 | 1 | 1 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルB (転送帯域0) |
| 2 | S002 | 01 | 01 | 01 | 3 | 0 | 1 | 2 | SEED | 2026-09-20 10:00:00 | 配信不可。チャネルC (転送帯域10) |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


## 想定DBデータ

### 想定01 (更新ありのデータ)

使用ケース: case_01, case_02, case_18

**laif_distribute_status** (配信状況) 5件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 05 | 2 | 1 | 1 | 1 | DLAIF0100001 | 更新 | 店舗S001 の1台目。低速回線店の同時配信機器数(1)未満 |
| 2 | S001 | 01 | 02 | 05 | 2 | 0 | 1 | 2 | SEED | 変更なし | 店舗S001 が同時配信機器数(1)に達したため許可しない |
| 3 | S002 | 01 | 01 | 05 | 3 | 1 | 1 | 3 | DLAIF0100001 | 更新 | 店舗S002 の1台目 |
| 4 | S003 | 01 | 01 | 05 | 2 | 0 | 1 | 4 | SEED | 変更なし | 配信完了済みのため処理対象外 |
| 5 | S004 | 01 | 01 | 01 | 2 | 0 | 1 | 5 | SEED | 変更なし | 別エリアのため処理対象外 |

**laif_distribute_completed** (配信完了) 1件

| distribute_id | distribute_status_kbn | distribute_completed_dt_tm | distribute_stop_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 07 | 2026-06-09 10:11:07 | 2026-06-09 11:11:07 | 2026-06-09 12:11:07 | DLAIF0100017 | 2026-06-09 13:11:07 | DLAIF0100027 | 変更なし |  |

**laif_down_equipment** (ダウン機器) 1件

| store_cd | equipment_category | equipment_no | down_equipment_entry_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|
| S009 | 05 | 15 | 2026-06-09 11:12:05 | 2026-06-09 12:12:05 | DLAIF0100035 | 2026-06-09 13:12:05 | DLAIF0100045 | 変更なし |  |

**想定ログ**: 配信状況テーブルを2件更新しました。

### 想定02 (更新なしのデータ)

使用ケース: case_03, case_04, case_05, case_06, case_07, case_17, case_19, case_20, case_21, case_22, case_23, case_26, case_27, case_28, case_29, case_30, case_31, case_32, case_33, case_34

**laif_distribute_status** (配信状況) 5件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 05 | 2 | 0 | 1 | 1 | SEED | 変更なし |  |
| 2 | S001 | 01 | 02 | 05 | 2 | 0 | 1 | 2 | SEED | 変更なし |  |
| 3 | S002 | 01 | 01 | 05 | 3 | 0 | 1 | 3 | SEED | 変更なし |  |
| 4 | S003 | 01 | 01 | 05 | 2 | 0 | 1 | 4 | SEED | 変更なし |  |
| 5 | S004 | 01 | 01 | 01 | 2 | 0 | 1 | 5 | SEED | 変更なし |  |

**laif_distribute_completed** (配信完了) 1件

| distribute_id | distribute_status_kbn | distribute_completed_dt_tm | distribute_stop_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|
| 4 | 07 | 2026-06-09 10:11:07 | 2026-06-09 11:11:07 | 2026-06-09 12:11:07 | DLAIF0100017 | 2026-06-09 13:11:07 | DLAIF0100027 | 変更なし |  |

**laif_down_equipment** (ダウン機器) 1件

| store_cd | equipment_category | equipment_no | down_equipment_entry_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|
| S009 | 05 | 15 | 2026-06-09 11:12:05 | 2026-06-09 12:12:05 | DLAIF0100035 | 2026-06-09 13:12:05 | DLAIF0100045 | 変更なし |  |

**想定ログ**: 更新件数のログは出力されない

upd_dt_tm は比較対象外 (実行時刻が入るため)。

### 想定03

使用ケース: case_08

**laif_distribute_status** (配信状況) 4件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 1 | 1 | 1 | DLAIF0100001 | 更新 | チャネルBを最初に処理。残配信可能数 (25-0)/10=2 |
| 2 | S002 | 01 | 01 | 01 | 3 | 1 | 1 | 2 | DLAIF0100001 | 更新 | 残配信可能数 (25-10)/10=1 (端数切り捨て) |
| 3 | S003 | 01 | 01 | 01 | 1 | 0 | 1 | 3 | SEED | 変更なし | 残配信可能数 (25-20)/10=0 で全体の帯域上限に到達。チャネルAを打ち切る |
| 4 | S004 | 01 | 01 | 01 | 1 | 0 | 1 | 4 | SEED | 変更なし | チャネルAを打ち切ったため判定しない |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 配信状況テーブルを2件更新しました。

### 想定04

使用ケース: case_09

**laif_distribute_status** (配信状況) 8件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 02 | 2 | 1 | 1 | 1 | DLAIF0100001 | 更新 | チャネルBの残配信可能数 (15-0)/10=1 |
| 2 | S002 | 01 | 01 | 02 | 2 | 0 | 1 | 2 | SEED | 変更なし | チャネルBの残配信可能数 (15-10)/10=0 で上限に到達。チャネルBを打ち切る |
| 3 | S003 | 01 | 01 | 02 | 2 | 0 | 1 | 3 | SEED | 変更なし | チャネルBを打ち切ったため判定しない |
| 4 | S001 | 01 | 01 | 02 | 3 | 1 | 1 | 4 | DLAIF0100001 | 更新 | チャネルCの残配信可能数 (15-0)/10=1 |
| 5 | S002 | 01 | 01 | 02 | 3 | 0 | 1 | 5 | SEED | 変更なし | チャネルCの帯域上限に到達。チャネルCを打ち切る |
| 6 | S001 | 01 | 01 | 02 | 1 | 1 | 1 | 6 | DLAIF0100001 | 更新 | チャネルAはチャネル別の帯域上限を判定しない |
| 7 | S002 | 01 | 01 | 02 | 1 | 1 | 1 | 7 | DLAIF0100001 | 更新 | 同上 |
| 8 | S003 | 01 | 01 | 02 | 1 | 1 | 1 | 8 | DLAIF0100001 | 更新 | 同上 |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 配信状況テーブルを5件更新しました。

### 想定05

使用ケース: case_10

**laif_distribute_status** (配信状況) 7件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 03 | 2 | 1 | 1 | 1 | SEED | 変更なし | 配信許可中 (変更なし) |
| 2 | S001 | 01 | 01 | 03 | 2 | 1 | 1 | 2 | SEED | 変更なし | 配信許可中 (変更なし) |
| 3 | S001 | 01 | 02 | 03 | 2 | 1 | 1 | 3 | DLAIF0100001 | 更新 | 店舗の配信許可中機器数1 < 3。使用中帯域 10→20 |
| 4 | S001 | 01 | 01 | 03 | 2 | 1 | 1 | 4 | DLAIF0100001 | 更新 | 機器数2 < 3。配信許可中の同じ機器なので使用中帯域は加算しない (20のまま) |
| 5 | S001 | 02 | 03 | 03 | 2 | 1 | 1 | 5 | DLAIF0100001 | 更新 | 機器数2 < 3。使用中帯域 20→30 |
| 6 | S001 | 01 | 04 | 03 | 2 | 0 | 1 | 6 | SEED | 変更なし | 機器数3 で同時配信機器数(3)に到達 |
| 7 | S002 | 01 | 01 | 03 | 2 | 1 | 1 | 7 | DLAIF0100001 | 更新 | 別店舗。チャネルBの残配信可能数 (40-30)/10=1。ID 4 で加算していれば0で許可されない |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 配信状況テーブルを4件更新しました。

### 想定06

使用ケース: case_11

**laif_distribute_status** (配信状況) 4件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 04 | 1 | 0 | 1 | 1 | SEED | 変更なし | チャネルAの同時配信機器数が0 |
| 2 | S001 | 01 | 01 | 04 | 3 | 1 | 1 | 2 | DLAIF0100001 | 更新 | チャネルCの機器数0 < 1。チャネルBの配信許可中(ID 4)は数えない |
| 3 | S001 | 01 | 02 | 04 | 3 | 0 | 1 | 3 | SEED | 変更なし | チャネルCの機器数1 で同時配信機器数(1)に到達 |
| 4 | S001 | 01 | 03 | 04 | 2 | 1 | 1 | 4 | SEED | 変更なし | 配信許可中 (変更なし) |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 配信状況テーブルを1件更新しました。

### 想定07

使用ケース: case_12

**laif_distribute_status** (配信状況) 8件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 1 | 1 | 1 | SEED | 変更なし | 配信許可中 (変更なし)。ダウン機器のため配信許可中の台数に数えない |
| 2 | S001 | 01 | 02 | 01 | 2 | 1 | 1 | 2 | SEED | 変更なし | 配信許可中 (変更なし) |
| 3 | S009 | 01 | 01 | 01 | 2 | 1 | 1 | 3 | SEED | 変更なし | 配信許可中 (変更なし) |
| 4 | S001 | 02 | 01 | 01 | 2 | 1 | 1 | 4 | SEED | 変更なし | 配信許可中 (変更なし) |
| 5 | S001 | 01 | 01 | 01 | 2 | 1 | 1 | 6 | DLAIF0100001 | 更新 | ダウン機器のため、店舗の上限(3台)に達していても許可 |
| 6 | S001 | 01 | 05 | 01 | 2 | 1 | 1 | 5 | DLAIF0100001 | 更新 | 店舗S001 の配信許可中機器数2 (ID 2, 4) < 3 |
| 7 | S001 | 03 | 01 | 01 | 2 | 0 | 1 | 7 | SEED | 変更なし | ダウン機器ではなく、店舗S001 が上限(3台)に到達 |
| 8 | S008 | 01 | 01 | 01 | 2 | 1 | 1 | 8 | DLAIF0100001 | 更新 | ダウン機器ではない。別店舗S008 の1台目 |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 2件

| store_cd | equipment_category | equipment_no | down_equipment_entry_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|
| S001 | 01 | 01 | 2026-06-09 11:12:05 | 2026-06-09 12:12:05 | DLAIF0100035 | 2026-06-09 13:12:05 | DLAIF0100045 | 変更なし |  |
| S007 | 01 | 01 | 2026-06-09 11:12:05 | 2026-06-09 12:12:05 | DLAIF0100035 | 2026-06-09 13:12:05 | DLAIF0100045 | 変更なし |  |

**想定ログ**: 配信状況テーブルを3件更新しました。

### 想定08

使用ケース: case_13

**laif_distribute_status** (配信状況) 4件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 05 | 2 | 1 | 1 | 1 | SEED | 変更なし | 配信許可中 (変更なし) |
| 2 | S001 | 01 | 01 | 05 | 2 | 1 | 1 | 2 | SEED | 変更なし | 配信許可中 (変更なし) |
| 3 | S001 | 01 | 02 | 05 | 2 | 0 | 1 | 3 | SEED | 変更なし | 低速回線店はレコード単位で数えるため2台。同時配信機器数(2)に到達 |
| 4 | S002 | 01 | 01 | 05 | 2 | 1 | 1 | 4 | DLAIF0100001 | 更新 | 別店舗の1台目。全体の帯域上限0でも低速回線店は帯域を判定しない |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 配信状況テーブルを1件更新しました。

### 想定09

使用ケース: case_14

**laif_distribute_status** (配信状況) 2件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 1 | 1 | 1 | SEED | 変更なし |  |
| 2 | S002 | 01 | 01 | 01 | 3 | 1 | 1 | 2 | SEED | 変更なし |  |

**laif_distribute_completed** (配信完了) 1件

| distribute_id | distribute_status_kbn | distribute_completed_dt_tm | distribute_stop_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|
| 2 | 07 | 2026-06-09 10:11:07 | 2026-06-09 11:11:07 | 2026-06-09 12:11:07 | DLAIF0100017 | 2026-06-09 13:11:07 | DLAIF0100027 | 変更なし |  |

**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 更新件数のログは出力されない

### 想定10

使用ケース: case_15

**laif_distribute_status** (配信状況) 2件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 0 | 1 | 1 | SEED | 変更なし |  |
| 2 | S002 | 01 | 01 | 02 | 2 | 0 | 1 | 2 | SEED | 変更なし |  |

**laif_distribute_completed** (配信完了) 1件

| distribute_id | distribute_status_kbn | distribute_completed_dt_tm | distribute_stop_dt_tm | entry_dt_tm | creator_id | upd_dt_tm | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 07 | 2026-06-09 10:11:07 | 2026-06-09 11:11:07 | 2026-06-09 12:11:07 | DLAIF0100017 | 2026-06-09 13:11:07 | DLAIF0100027 | 変更なし |  |

**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 更新件数のログは出力されない

### 想定11

使用ケース: case_16

**laif_distribute_status** (配信状況) 3件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 0 | 1 | 1 | SEED | 変更なし | 店舗S001 が同時配信機器数(1)に到達 |
| 2 | S001 | 01 | 02 | 01 | 2 | 0 | 2 | 5 | SEED | 変更なし | 店舗S001 が同時配信機器数(1)に到達 |
| 3 | S001 | 01 | 03 | 01 | 2 | 1 | 2 | 3 | DLAIF0100001 | 更新 | 配信優先区分2・配信順3 が最初に処理される |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 配信状況テーブルを1件更新しました。

### 想定12

使用ケース: case_25

**laif_distribute_status** (配信状況) 2件

| distribute_id | store_cd | equipment_category | equipment_no | distribute_area_category | distribute_channel | distribute_availability_fg | distribute_priority_kbn | distribute_order | updater_id | 結果 | 理由 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | S001 | 01 | 01 | 01 | 2 | 1 | 1 | 1 | DLAIF0100001 | 更新 | 転送帯域0のチャネルは帯域上限を判定しない |
| 2 | S002 | 01 | 01 | 01 | 3 | 0 | 1 | 2 | SEED | 変更なし | 全体の帯域上限0のため許可しない |

**laif_distribute_completed** (配信完了) 0件


**laif_down_equipment** (ダウン機器) 0件


**想定ログ**: 配信状況テーブルを1件更新しました。

## 単体テストのケースと No の対応

| ケース | 事前DBデータNo | 想定DBデータNo | 環境変数 (.env) |
|---|---|---|---|
| case_01 | 事前01 | 想定01 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_02 | 事前01 | 想定01 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_03 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_04 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_05 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=-1<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_06 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=abc<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_07 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=2147483648<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_08 | 事前02 | 想定03 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=25<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_09 | 事前03 | 想定04 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=15<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=15<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_10 | 事前04 | 想定05 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=40<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=3<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_11 | 事前05 | 想定06 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=0<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_12 | 事前06 | 想定07 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=3<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=9<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_13 | 事前07 | 想定08 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=0<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=0<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=2<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_14 | 事前08 | 想定09 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_15 | 事前09 | 想定10 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_16 | 事前10 | 想定11 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_17 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_18 | 事前01 | 想定01 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_19 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_20 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_21 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_22 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_23 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_25 | 事前11 | 想定12 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=0<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=0<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=0<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_26 | 事前01 | 想定02 | (なし) |
| case_27 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=-1<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=-1<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=-1<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=-1<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=-1<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=-1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=-1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=-1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=-1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=-1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=-1 |
| case_28 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=0<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=0<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=0<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=0<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=0<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=0<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=0<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=0<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=0<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=0<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=0 |
| case_29 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_30 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_31 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_32 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_33 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=1000<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=500<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=500<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=10<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=10<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=1<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=1<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD=24 |
| case_34 | 事前01 | 想定02 | ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL=<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B=<br>ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C=<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A=<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B=<br>ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C=<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A=<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B=<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C=<br>ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED=<br>ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD= |

想定DBデータの laif_distribute_status は upd_dt_tm を比較しない (実行時刻が入るため)。期待値 CSV にも upd_dt_tm は書いていない。
