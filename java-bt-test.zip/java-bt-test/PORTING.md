# テスト基盤の移植手順

常駐バッチの「起動 → 処理 → 停止」をテストする一式を、別プロジェクトへ持っていく手順。
検証環境: Spring Boot 4.0.6 / JDK 25 / Gradle 9.7 / mybatis-spring-boot-starter 4.0.1 / logstash-logback-encoder 9.0 / H2。

---

## 1. 必要な依存 (build.gradle)

バージョンは Spring Boot の BOM に任せる。JSONAssert は `spring-boot-starter-test` に含まれる。

```groovy
// Mockito を javaagent として読み込むための構成 (JDK 21 以降で必要)
configurations {
    mockitoAgent
}

dependencies {
    testImplementation 'org.springframework.boot:spring-boot-starter-test'
    testRuntimeOnly 'com.h2database:h2'                       // テスト用 DB。本物の DB を使うなら不要

    mockitoAgent('org.mockito:mockito-core') { transitive = false }
}

tasks.named('test') {
    useJUnitPlatform()
    jvmArgs "-javaagent:${configurations.mockitoAgent.asPath}",
            '-Dnet.bytebuddy.experimental=true',
            '-Dfile.encoding=UTF-8'
}
```

---

## 2. 完全コピーするもの

`SettlementBatchTest.java` 内の 2 クラス。中身は触らない。

| クラス | 役割 |
|---|---|
| `JsonLogCapture` | System.out を差し替えて、標準出力に出た JSON ログを取り込む |
| `DbFaults` | `faults.csv` のルールに従って DB アクセス例外を注入する (SqlSessionTemplate の spy) |

---

## 3. 実装に合わせて修正するもの

**`BatchTestSupport`** — ジョブのクラスとログ対象。

```java
@MockitoSpyBean
protected SettlementJob job;        // ← 移植先のジョブ (ループと 1 サイクル分の処理を持つクラス)

logs = JsonLogCapture.start("com.example.batch.");   // 取り込むロガーの接頭辞
```

ジョブの 1 サイクル分のメソッド (サンプルでは `protected int execute(...)`) を spy で横取りするため、
**テストクラスはジョブと同じパッケージに置く** (protected を参照するため)。

### 常駐ループの扱い (`runJob`)

検証したいのは「ジョブ 1 回分の処理結果 (DB とログ)」で、ループが何周回るかではない。

`@SpringBootTest` は起動時に `ApplicationRunner` を実行する (`@BeforeAll` の後、`@BeforeEach` の前)。
そのままだとテストデータを入れる前にジョブが動いてしまうので、テストでは `batch.auto-startup=false` で
実行契機の Bean を無効にし、データを入れてから**本番と同じ実行契機をテストから呼ぶ**。
ジョブは `@MockitoSpyBean` にしておき、1 サイクル実行された時点で停止させる (= 常駐にしない)。

```java
doAnswer(invocation -> {
    try {
        return invocation.callRealMethod();   // 本物の処理をそのまま実行 (DB アクセスも本物)
    } finally {
        job.stop();                           // 実行されたら停止 → 2 周目に入らない
    }
}).when(job).execute(anyString(), any(LocalDate.class));

BatchRunner runner = new BatchRunner(job);
runner.run(applicationArguments);   // 本番と同じ入口
runner.shutdown();                  // ループが終わるまで待つ
verify(job, times(1)).execute(anyString(), any(LocalDate.class));   // 1 回だけ実行されたこと
```

差し替えているのは実行の**タイミングだけ**で、処理内容は本物のまま。時間や DB 件数で待つ必要もない。

**`TestCaseResources`** — 定数 2 つ (`MASKED_LOG_FIELDS` は通常そのまま)。

```java
static final Set<String> IGNORED_DB_COLUMNS = Set.of("updated_at", "settled_at");   // 実行ごとに変わるカラム
private static final Map<String, String> ORDER_BY = Map.of("orders", "id", "settlements", "order_id");
```

**`src/test/resources/application-test.yml`**

```yaml
spring:
  datasource:
    url: jdbc:h2:mem:batchdb;MODE=PostgreSQL;DATABASE_TO_LOWER=TRUE;DB_CLOSE_DELAY=-1
    username: sa
    password: ""
batch:
  auto-startup: false   # テストではデータ投入後にテスト自身が起動する
  poll-interval: 200ms
```

**`logback-spring.xml`** — JSON ログが標準出力に出ること。非同期 appender はテストでは使わない (ログが欠ける)。

**対象アプリ側の前提** — 満たしていなければ実装を直す。

- `start()` / `stop()` が多重呼び出しで安全
- `stop()` が処理中の 1 件の完了を待ってから戻る
- 自動起動を設定で切れる (例: 実行契機の `ApplicationRunner` に `@ConditionalOnProperty`)
- 1 サイクル分の処理がメソッドとして分かれている (ループ用メソッドがそれを呼ぶ構造)

---

## 4. テストデータの置き場所

テスト資材は**テストクラスと同じパッケージ配下**に置く (ジョブごとに分かれる)。

```
src/main/java/com/example/batch/jobs/xxxxxxxx1/SettlementJob.java   … ジョブ (ループ + execute)
src/test/java/com/example/batch/jobs/xxxxxxxx1/SettlementBatchTest.java
src/test/resources/com/example/batch/jobs/xxxxxxxx1/
├─ ddl/{テーブル名}.sql          … DROP TABLE IF EXISTS → CREATE TABLE。実行はファイル名順
└─ testcases/case_01/
    ├─ input/{テーブル名}.csv     … 投入データ (1 行目 = カラム名)
    ├─ expected/{テーブル名}.csv  … 実行後の期待値 (IGNORED_DB_COLUMNS は書かない)
    ├─ expected/log.json         … 期待するログ (含まれていればよい。全件書く必要はない)
    └─ faults.csv                … 任意。DB 例外の注入ルール
```

参照先は `getClass().getPackageName()` から解決するので、パッケージを変えてもコードの修正は不要。

- CSV: 空欄は NULL。日付は `2026-09-21`、小数は桁数込み (`0.10`)。行・カラムの過不足は不一致。
  読み込みは H2 の `CSVREAD` を使う (CSV ライブラリは不要。テスト用 DB が H2 でない場合はここだけ差し替える)。
- ログ: 書いたログ・書いた項目だけ照合する (順序は保つ)。毎回変わる値は `"***"` と書けば存在チェックになる。丸ごと固定したい場合は `assertLogExactly`。
- `faults.csv`: `statement,params,fail_times,exception,message`
  例) `OrderMapper.insertSettlement,,2,QueryTimeoutException,simulated timeout`
  ※ `@Retryable` を Mapper に付けている場合、失敗回数が実行回数未満だとリトライで回復する。

期待値ファイルは、空 (`[]` やヘッダーのみ) で作って一度落とすと、失敗メッセージに実際の結果が CSV / JSON で出るので、それを貼る。

---

## 5. Spring Boot 3.x へ移植する場合の読み替え

| 項目 | Boot 4.0.6 | Boot 3.x |
|---|---|---|
| リトライ | `org.springframework.resilience.annotation.@Retryable(includes=…, maxRetries=2)` + `@EnableResilientMethods` | spring-retry の `@Retryable(retryFor=…, maxAttempts=3, backoff=@Backoff(...))` + `@EnableRetry` (要 `spring-retry`, `spring-boot-starter-aop`) |
| Jackson | 3 系 (`tools.jackson`)。例外は非チェック | 2 系 (`com.fasterxml.jackson`)。`IOException` の catch が必要 |
| JSON ログ | logstash-logback-encoder 9.0 | 8.1 |
| spy | `@MockitoSpyBean` | Boot 3.4 未満は `@SpyBean` |

DB アクセスが MyBatis でない場合、`DbFaults` は例外を差し込む位置を変える必要がある (他のクラスはそのまま使える)。
