# 作業再開メモ

> **2026-09-29 更新: サンプルを移植先 (laif-daemon-bt) の構成に作り替え中。以下の旧構成の記述より、この節を優先する。**
> - 本番コードは移植先の文字起こし (パッケージ jp.co.lawson.laif.bt.daemon, spring-retry, @Select, lombok)。
>   社内フレームワーク (jp.co.nri.*, jp.co.lawson.common.*) は jar が無いので、使う部分だけの代用クラスを src/main/java に置いた。
> - テスト: src/test/java/jp/.../jobs/job/dlaif0100001/DistributeInstructRegisterJobTest.java
> - 現状: 5 ケース全て成功 (HSQLDB)。更新 SQL は IN (...) + CURRENT_TIMESTAMP の汎用 SQL に変更。
>   DistributeProperties は @Validated を外し入れ子に @Valid (検証は runJob だけで行う)。
>   テスト基盤の .env のプロパティソース名を "case-systemEnvironment" に修正 (環境変数名の読み替えを効かせるため)。
> - 未決: 移植先でリトライが 1 回しか動かない件。サンプル (同じコード) では動くので、差は社内フレームワークの本物の jar。
> - 作り替え前の状態は scratchpad にバックアップ (セッション限り)。

最終確認: `./gradlew clean test` で **5 ケース全て成功**（HSQLDB）。

## 実行方法

```bash
cd /Users/kobuo/workspace/java-bt-test
JAVA_HOME=/opt/homebrew/opt/openjdk@26 ./gradlew clean test    # 約 10 秒 (初回は依存の取得で長い)
```

- システム既定の `java` は無いので `JAVA_HOME` の指定が必須。
- **ケースのフォルダを増減・改名したら `clean` が必要**（`build/resources/test` に旧資材が残り、古いデータでテストが走る）。
- ビルドは Gradle Wrapper 9.7.1 (build.gradle.kts)。Maven の pom.xml / mvnw は削除済み。`target/` は VS Code が作るもので無関係。

## 現在の構成

環境: Spring Boot 4.0.6 / JDK 25 (ローカルは 26 でビルド) / mybatis-spring-boot-starter 4.0.1 /
logstash-logback-encoder 9.0 / テスト DB は HSQLDB / ビルドは Gradle。

### 本番コード (8 ファイル)

```
com/example/batch/
├─ BatchApplication.java          … main で SpringApplication.exit の終了コードを返す
├─ JobContext.java                … 起動引数と結果 (jobName / distributeAreaCategory / exitCode)
├─ config/BatchProperties.java    … batch.* (pollInterval, chunkSize, taxRate)
├─ domain/{Order,Settlement}.java
├─ repository/OrderMapper.java    … SQL は @Select 等 (XML なし)。spring-retry の @Retryable(retryFor=DataAccessException, maxAttempts=3) をメソッド単位に
├─ service/SettlementService.java … @Transactional。例外は投げる (ロールバックさせる)
└─ jobs/xxxxxxxx1/SettlementJob.java
     implements ApplicationRunner, ExitCodeGenerator
     run()      … 起動契機。runJob を呼び、例外を捕まえてログ + 異常終了コード
     runJob()   … 起動引数と設定を検証 (不正なら例外) → 停止までループ
     execute()  … protected。1 サイクル分の処理
     stop()     … 停止指示。@PreDestroy shutdown() から SIGTERM 時に呼ばれる
```

### テストコード (1 ファイル)

`src/test/java/com/example/batch/jobs/xxxxxxxx1/SettlementBatchTest.java`

| クラス | 役割 |
|---|---|
| `@BatchCase` | テストクラスにケース名を明示 (`@BatchCase("case_01")`) |
| `@InjectFault` | 例外注入の指定 (`target` / `method` / `args` / `times` / `exception` / `message`) |
| `CaseSetupExtension` | **Spring 起動前**に DDL・データ投入・ログ取り込み開始 (JUnit の BeforeAllCallback) |
| `CaseContextInitializer` | refresh 前に `.env` を環境変数として反映し、アスペクトと spy を登録 |
| `OneCycleJobPostProcessor` | ジョブを spy にして execute を横取りし、1 サイクルで停止 (自己呼び出しのため AOP 不可) |
| `JobAspect` | サービス・Mapper の呼び出しを AOP で横取り。例外注入と呼び出し記録 |
| `TestDatabase` | SQL ファイル実行 / CSV から INSERT (カラム型に変換) / 結果取得 |
| `TestCaseResources` | ケース資材の読み込みと突合 (DB・ログ) |
| `JsonLogCapture` | System.out / System.err を差し替えて JSON ログを取り込む |

### テスト資材

```
src/test/resources/
├─ application-test.yml                         … DB 接続 (jdbc:hsqldb:mem:batchdb)
└─ com/example/batch/jobs/xxxxxxxx1/
    ├─ ddl/{orders,settlements}.sql             … DROP + CREATE
    └─ testcases/case_01〜case_05/
        ├─ .env                                 … 環境変数 (必須)
        ├─ input/{テーブル}.csv
        └─ expected/{テーブル}.csv, log.json
```

| ケース | 内容 |
|---|---|
| case_01 | 正常系 |
| case_02 | DB エラー 2 回 → リトライで成功 |
| case_03 | DB エラー 3 回 → リトライ超過、ロールバックして中断 |
| case_04 | 起動引数のバリデーションエラー (runJob が例外) |
| case_05 | 環境変数のバリデーションエラー (runJob が例外) |

## 未対応 (次にやること)

1. **`PORTING.md` が旧構成のまま**。現構成 (HSQLDB・`@BatchCase`・`@InjectFault`・起動時実行) に全面的に書き直す。
2. **CSV パーサの方針決め**。現在は自前の簡易実装で、**引用符とカンマを含む値に未対応**。
   実データに必要なら `tools.jackson.dataformat:jackson-dataformat-csv` に戻す。
3. **Gradle 側のタイムアウト**。`tasks.named('test') { timeout = Duration.ofMinutes(10) }` を入れるか決める
   (JUnit の宣言的タイムアウトと surefire の forkedProcessTimeout は、このハングには効かないことを実測済み)。
4. **`JobAspect` の記録機能**を残すか。呼び出し回数が多いジョブでは `calls()` が膨らむ。
5. 移植先 (HSQLDB) で残っている `object not found` の原因確認。`afterAll` の null チェックを入れたので、
   隠れていた本当のエラーが見えるはず。

## 決まっている方針 (蒸し返さない)

- 起動時実行が前提。テストメソッドは**検証だけ**（`runJob()` をテストから呼ぶのはバリデーションのケースのみ）。
- 本番コードにテスト用の分岐を入れない（`batch.auto-startup` は廃止済み）。
- 外部ファイルはケース資材のみ。`META-INF/spring.factories` などの登録ファイルは使わない。
- Javadoc は原則 1 文。未使用 import・警告は毎回掃除する。
- ログの突合は**包含チェック**（書いたログ・書いた項目だけ照合）。`"***"` はワイルドカード。
- DB の突合は**行順を問わない**。時刻カラムは `IGNORED_DB_COLUMNS` で除外。

## 既知の注意点

- CSV は引用符で囲まない（値の一部になる）。カンマを含む値も不可。
- 日時は `2026-09-20 10:00:00` / `2026-09-20T10:00:00` どちらでも可（内部で揃える）。
- 小数は桁数込みで書く（`DECIMAL(10,2)` なら `1000.00`）。
- HSQLDB は識別子を大文字に正規化する。カラム型の取得は大文字・小文字の両方で探している。
