package jp.co.lawson.laif.bt.daemon.jobs.job.dlaif0100001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.UncheckedIOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.SystemEnvironmentPropertySource;
import javax.sql.DataSource;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;

import jp.co.lawson.laif.bt.daemon.jobs.mapper.DownEquipmentMapper;
import jp.co.nri.xpalette.batch.core.exception.JobStartFailedException;
import jp.co.nri.xpalette.batch.core.runner.JobContext;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.SerializationFeature;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ObjectNode;


/**
 * 配信指示登録ジョブのテスト. 1 ケース 1 クラスで、起動引数はクラスに明示し、環境変数はケースの .env に置く.
 *
 * <p>ジョブはアプリケーション起動と同時に実行されるので、テストメソッドは結果を検証するだけ.
 */
class DistributeInstructRegisterJobTest {

    @Nested
    @DisplayName("case_01: 配信不可の配信状況を、店舗の同時配信上限まで配信可能にする (正常系)")
    @BatchCase("case_01")
    @SpringBootTest(args = {"DLAIF0100001", "--distribute_area_category=05"})
    class Case01 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.lastFailure()).as("例外は発生しない").isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_02: DB エラーが 2 回でも、リトライで成功する (正常系)")
    @BatchCase("case_02")
    @SpringBootTest(args = {"DLAIF0100001", "--distribute_area_category=05"})
    @InjectFault(target = DownEquipmentMapper.class, method = "findAll", times = "2",
            exception = QueryTimeoutException.class, message = "simulated timeout")
    class Case02 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).as("2 回失敗させている").isEqualTo(2);
            assertThat(aspect.calls()).as("3 回目で成功している").contains("findAll");
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_03: DB エラーが 3 回でリトライを使い切り、中断する (異常系)")
    @BatchCase("case_03")
    @SpringBootTest(args = {"DLAIF0100001", "--distribute_area_category=05"})
    @InjectFault(target = DownEquipmentMapper.class, method = "findAll", times = "3",
            exception = QueryTimeoutException.class, message = "simulated timeout")
    class Case03 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).as("初回 + リトライ 2 回").isEqualTo(3);
            assertThat(aspect.lastFailure())
                    .isInstanceOf(QueryTimeoutException.class)
                    .hasMessage("simulated timeout");
            testCase.assertDatabase(testDb); // 更新されていないこと
        }
    }

    @Nested
    @DisplayName("case_04: 起動引数が不正なら例外になる (バリデーション)")
    @BatchCase("case_04")
    @SpringBootTest(args = {"DLAIF0100001", "--distribute_area_category=99"})
    class Case04 extends BatchTestSupport {

        @Test
        void test() {
            assertThatThrownBy(() -> job.runJob(new JobContext(applicationArguments)))
                    .isInstanceOf(JobStartFailedException.class)
                    .hasMessage("起動引数が不正です。--distribute_area_category=99");
            testCase.assertDatabase(testDb); // ジョブが動いていないこと
        }
    }

    @Nested
    @DisplayName("case_05: 環境変数が不正なら例外になる (バリデーション)")
    @BatchCase("case_05")
    @SpringBootTest(args = {"DLAIF0100001", "--distribute_area_category=05"})
    class Case05 extends BatchTestSupport {

        @Test
        void test() {
            assertThatThrownBy(() -> job.runJob(new JobContext(applicationArguments)))
                    .isInstanceOf(JobStartFailedException.class)
                    .hasMessageStartingWith("環境変数の設定値が不正です。")
                    .hasMessageContaining("bandwidth.overall=0");
            testCase.assertDatabase(testDb); // ジョブが動いていないこと
        }
    }

    /**
     * DB アクセスに例外を注入する (テストクラスに付ける).
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.TYPE)
    public @interface InjectFault {

        /**
         * 例外を投げる対象の Mapper.
         */
        Class<?> target();

        /**
         * 例外を投げる対象のメソッド名.
         */
        String method();

        /**
         * 引数での絞り込み (任意). 引数の文字列表現に、ここに書いた文字列がすべて含まれる呼び出しだけ失敗させる.
         * 例: args = {"DONE"} なら、どの引数かに関わらず "DONE" を含む呼び出しが対象.
         */
        String[] args() default {};

        /**
         * 最初の何回を失敗させるか. "*" は毎回.
         */
        String times() default "*";

        /**
         * 投げる例外.
         */
        Class<? extends RuntimeException> exception();

        /**
         * 例外メッセージ.
         */
        String message() default "injected by test";
    }

    /**
     * このテストクラスが検証するケース (testcases/{ケース名}/ を使う).
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.TYPE)
    public @interface BatchCase {

        /**
         * ケース名 (例: "case_01").
         */
        String value();
    }

    /**
     * アプリ起動前に、ケースの .env を環境変数として積み、テスト用の仕掛け (アスペクト・spy) を登録する.
     *
     * <p>ケース名はテストクラスの @BatchCase から決まる. コンテキスト生成前に
     * {@link CaseSetupExtension} が設定するので、ここではそれを参照する.
     */
    public static class CaseContextInitializer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext context) {
            TestCaseResources testCase = BatchTestSupport.testCase;
            Map<String, Object> variables = testCase.environment();
            context.getEnvironment()
                    .getPropertySources()
                    // 名前が "-systemEnvironment" で終わると、OS の環境変数と同じ読み替え (FOO_BAR → foo.bar) が効く
                    .addFirst(new SystemEnvironmentPropertySource("case-systemEnvironment", variables));

            // 起動と同時にジョブが走るので、仕掛けはこの時点で用意する
            BeanDefinitionRegistry registry = (BeanDefinitionRegistry) context.getBeanFactory();
            registry.registerBeanDefinition("jobAspect", BeanDefinitionBuilder
                    .genericBeanDefinition(JobAspect.class)
                    .addConstructorArgValue(BatchTestSupport.fault)
                    .getBeanDefinition());
            registry.registerBeanDefinition("oneCycleJobPostProcessor", BeanDefinitionBuilder
                    .genericBeanDefinition(OneCycleJobPostProcessor.class)
                    .getBeanDefinition());
        }
    }

    /**
     * 注入ルール (@InjectFault の内容).
     */
    public record Fault(Class<?> target, String method, List<String> args, String times,
            Class<? extends RuntimeException> exception, String message) {

        static Fault of(InjectFault annotation) {
            if (Modifier.isAbstract(annotation.exception().getModifiers())) {
                throw new IllegalArgumentException("@InjectFault の exception に抽象クラスは指定できない"
                        + " (QueryTimeoutException などの具象クラスを指定する): " + annotation.exception().getName());
            }
            return new Fault(annotation.target(), annotation.method(), List.of(annotation.args()),
                    annotation.times(), annotation.exception(), annotation.message());
        }

        boolean matches(Object actualTarget, String method, Object[] actualArgs) {
            // 宣言元ではなく呼び出し先で判定する (親インターフェースで宣言されたメソッドも対象にするため)
            if (!target.isInstance(actualTarget) || !this.method.equals(method)) {
                return false;
            }
            String values = Stream.of(actualArgs).map(String::valueOf).collect(Collectors.joining(", "));
            return args.stream().allMatch(values::contains); // 部分一致 (リストや任意の型でも書ける)
        }

        boolean remains(int injected) {
            return "*".equals(times) || injected < Integer.parseInt(times);
        }

        RuntimeException newException() {
            try {
                return exception.getConstructor(String.class).newInstance(message);
            } catch (ReflectiveOperationException e) {
                throw new IllegalArgumentException("例外が生成できない: " + exception, e);
            }
        }
    }

    /**
     * アプリ起動より前 (コンテキスト生成前) に、ケースのデータ投入とログ取り込みを行う.
     */
    public static class CaseSetupExtension implements BeforeAllCallback, AfterAllCallback {

        /**
         * Spring 起動前に DB を使うため、アプリと同じ接続先を application-test.yml から読む.
         */
        private static DataSource testDataSource() {
            try {
                PropertySource<?> properties = new YamlPropertySourceLoader()
                        .load("application-test", new ClassPathResource("application-test.yml"))
                        .getFirst();
                // suppressClose=true: 接続を閉じない = インメモリ DB を生かし続ける
                return new SingleConnectionDataSource(
                        String.valueOf(properties.getProperty("spring.datasource.url")),
                        String.valueOf(properties.getProperty("spring.datasource.username")),
                        String.valueOf(properties.getProperty("spring.datasource.password")),
                        true);
            } catch (IOException e) {
                throw new UncheckedIOException("application-test.yml が読めない", e);
            }
        }

        @Override
        public void beforeAll(ExtensionContext context) {
            Class<?> testClass = context.getRequiredTestClass();
            BatchCase batchCase = AnnotatedElementUtils.findMergedAnnotation(testClass, BatchCase.class);
            if (batchCase == null) {
                throw new IllegalStateException("テストクラスに @BatchCase を付けること: " + testClass.getSimpleName());
            }
            InjectFault injectFault = AnnotatedElementUtils.findMergedAnnotation(testClass, InjectFault.class);

            // ジョブはコンテキスト起動と同時に走るので、その前にすべて準備する
            BatchTestSupport.fault = injectFault == null ? null : Fault.of(injectFault);
            BatchTestSupport.testDb = new TestDatabase(new JdbcTemplate(testDataSource()));
            BatchTestSupport.testCase = new TestCaseResources(testClass.getPackageName(), batchCase.value());
            BatchTestSupport.testCase.setUpDatabase(BatchTestSupport.testDb);
            BatchTestSupport.logs = JsonLogCapture.start("jp.co.lawson.laif.bt.daemon.");
        }

        @Override
        public void afterAll(ExtensionContext context) {
            if (BatchTestSupport.logs != null) { // 準備中に失敗した場合は未取得
                BatchTestSupport.logs.detach();
            }
        }
    }

    /**
     * ジョブを spy に差し替え、execute が呼ばれたら停止を指示する (常駐にしない).
     *
     * <p>execute は runJob からの自己呼び出しなので Spring AOP では捕まえられない.
     * spy はクラス自体を書き換える方式なので捕まえられる.
     * 起動と同時にジョブが走るため、Bean 生成時 (実行契機より前) に仕込む.
     */
    public static class OneCycleJobPostProcessor implements BeanPostProcessor {

        @Override
        public Object postProcessAfterInitialization(Object bean, String beanName) {
            if (!(bean instanceof DistributeInstructRegisterJob job)) {
                return bean;
            }
            // @MockitoSpyBean で既に spy 化されていればそれを使う
            DistributeInstructRegisterJob spy = MockUtil.isMock(job) ? job : Mockito.spy(job);
            Mockito.doAnswer(invocation -> {
                spy.stop(); // 実行中のサイクルを終えたらループを抜ける = 常駐にしない
                return invocation.callRealMethod();
            }).when(spy).execute(ArgumentMatchers.any(JobContext.class));
            return spy;
        }
    }

    /**
     * テスト用アスペクト. @InjectFault に従って例外を注入し、呼び出しを記録する (停止は OneCycleJobPostProcessor が担当).
     */
    @Aspect
    @Order(Ordered.LOWEST_PRECEDENCE) // リトライ (@Retryable) より内側にする
    public static class JobAspect {

        private final Fault fault;
        private final List<String> calls = new CopyOnWriteArrayList<>();
        private final AtomicInteger injected = new AtomicInteger();

        private Throwable lastFailure;

        public JobAspect(Fault fault) {
            this.fault = fault;
        }

        /**
         * Mapper の呼び出しを横取りする.
         */
        @Around("execution(* jp.co.lawson.laif.bt.daemon.jobs.mapper..*.*(..))")
        public Object intercept(ProceedingJoinPoint joinPoint) throws Throwable {
            String method = joinPoint.getSignature().getName();
            try {
                // @InjectFault に従って例外を投げる
                failIfConfigured(joinPoint.getTarget(), method, joinPoint.getArgs());
                Object result = joinPoint.proceed();
                calls.add(method);
                return result;
            } catch (Throwable e) {
                calls.add(method + ":" + e.getClass().getSimpleName());
                lastFailure = e;
                throw e;
            }
        }

        /**
         * @InjectFault に一致する呼び出しで例外を投げる.
         */
        private void failIfConfigured(Object target, String method, Object[] args) {
            if (fault == null || !fault.matches(target, method, args) || !fault.remains(injected.get())) {
                return;
            }
            injected.incrementAndGet();
            throw fault.newException();
        }

        /**
         * 記録された呼び出し (メソッド名. 例外が出たものは "メソッド名:例外クラス名").
         */
        public List<String> calls() {
            return List.copyOf(calls);
        }

        /**
         * 注入した例外の回数.
         */
        public int injectedCount() {
            return injected.get();
        }

        /**
         * 最後に発生した例外 (無ければ null).
         */
        public Throwable lastFailure() {
            return lastFailure;
        }
    }

    // =====================================================================================
    // 以下、テスト用のサポートクラス
    // =====================================================================================

    /**
     * 各 @Nested テストクラスの共通処理 (DB 準備・ログ取り込み・ワーカーの起動と停止).
     */
    @ActiveProfiles("test")
    @ExtendWith(CaseSetupExtension.class)
    @ContextConfiguration(initializers = CaseContextInitializer.class)
    @DirtiesContext(classMode = ClassMode.AFTER_CLASS) // ケースごとに起動し直す
    abstract static class BatchTestSupport {

        /**
         * このケースの例外注入ルール (@InjectFault. 無ければ null)
         */
        static Fault fault;

        protected static TestDatabase testDb;

        /**
         * 検証対象のジョブ. 実行されたことを検証するため spy にしている
         */
        @MockitoSpyBean
        protected DistributeInstructRegisterJob job;

        /**
         * @SpringBootTest(args = ...) で渡した起動引数
         */
        @Autowired
        protected ApplicationArguments applicationArguments;

        /**
         * このテストのケース資材 (@BeforeEach で準備される)
         */
        protected static TestCaseResources testCase;

        protected static JsonLogCapture logs;

        /**
         * ケースのテストにだけ登録されるアスペクト (起動失敗テストでは null)
         */
        @Autowired(required = false)
        protected JobAspect aspect;


    }

    /**
     * テスト用の DB 操作 (SQL ファイルの実行と、CSV から組み立てた INSERT 文で行う).
     */
    static final class TestDatabase {

        private final JdbcTemplate jdbc;

        TestDatabase(JdbcTemplate jdbc) {
            this.jdbc = jdbc;
        }

        /**
         * .sql ファイルをそのまま実行する (";" 区切り、"--" コメント可)
         */
        void runScript(Resource script) {
            ResourceDatabasePopulator populator = new ResourceDatabasePopulator(script);
            populator.setSeparator(";");
            populator.execute(jdbc.getDataSource());
        }

        /**
         * CSV のヘッダーからカラムを決めて INSERT 文を組み立て、全行を投入する.
         * CSV の値は文字列なので、テーブルのカラム型に合わせて変換する.
         */
        void insert(String table, List<Map<String, String>> rows) {
            if (rows.isEmpty()) {
                return;
            }
            List<String> columns = List.copyOf(rows.getFirst().keySet());
            Map<String, Integer> types = columnTypes(table);
            String sql = "INSERT INTO %s (%s) VALUES (%s)".formatted(table, String.join(", ", columns),
                    columns.stream().map(column -> "?").collect(Collectors.joining(", ")));
            List<Object[]> values = rows.stream()
                    .map(row -> columns.stream()
                            .map(column -> toColumnValue(row.get(column), types.get(column)))
                            .toArray())
                    .toList();
            jdbc.batchUpdate(sql, values);
        }

        /**
         * テーブルのカラム名 (小文字) → java.sql.Types
         */
        private Map<String, Integer> columnTypes(String table) {
            return jdbc.execute((Connection connection) -> {
                Map<String, Integer> types = new LinkedHashMap<>();
                // 引用符なしの識別子は DB により大文字・小文字が変わるので、両方で探す
                for (String name : List.of(table.toUpperCase(), table.toLowerCase())) {
                    try (ResultSet columns = connection.getMetaData().getColumns(null, null, name, null)) {
                        while (columns.next()) {
                            types.put(columns.getString("COLUMN_NAME").toLowerCase(), columns.getInt("DATA_TYPE"));
                        }
                    }
                    if (!types.isEmpty()) {
                        return types;
                    }
                }
                throw new IllegalStateException("テーブルが見つからない: " + table);
            });
        }

        /**
         * CSV の文字列を、カラム型に合わせた値にする (空欄は NULL)
         */
        private static Object toColumnValue(String value, Integer sqlType) {
            if (value == null || value.isEmpty()) {
                return null;
            }
            if (sqlType == null) {
                return value;
            }
            return switch (sqlType) {
                case Types.TINYINT, Types.SMALLINT, Types.INTEGER, Types.BIGINT -> Long.valueOf(value);
                case Types.DECIMAL, Types.NUMERIC, Types.REAL, Types.FLOAT, Types.DOUBLE -> new BigDecimal(value);
                case Types.BOOLEAN, Types.BIT -> Boolean.valueOf(value);
                case Types.DATE -> LocalDate.parse(value);
                case Types.TIME -> LocalTime.parse(value);
                case Types.TIMESTAMP, Types.TIMESTAMP_WITH_TIMEZONE ->
                        LocalDateTime.parse(value.replace(' ', 'T'));
                default -> value;
            };
        }

        /**
         * ヘッダー付き CSV を読む. 空欄は "" (引用符やカンマを含む値には未対応)
         */
        static List<Map<String, String>> readCsv(Resource csv) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(csv.getInputStream(), StandardCharsets.UTF_8))) {
                List<String> lines = reader.lines().filter(line -> !line.isBlank()).toList();
                List<String> columns = Stream.of(lines.getFirst().split(",", -1)).map(String::strip).toList();
                return lines.stream().skip(1).map(line -> {
                    String[] values = line.split(",", -1);
                    Map<String, String> row = new LinkedHashMap<>();
                    for (int i = 0; i < columns.size(); i++) {
                        row.put(columns.get(i), i < values.length ? values[i].strip() : "");
                    }
                    return row;
                }).toList();
            } catch (IOException e) {
                throw new UncheckedIOException("CSV が読めない: " + csv.getDescription(), e);
            }
        }

        /**
         * 結果の突合用. カラム順は SELECT * の順 (行順は比較しないので ORDER BY は付けない)
         */
        List<Map<String, Object>> selectAll(String table) {
            return jdbc.queryForList("SELECT * FROM " + table);
        }
    }

    /**
     * 標準出力・標準エラーに実際に書き出された JSON ログを取り込む (元の出力先にもそのまま流す).
     */
    static final class JsonLogCapture {

        private final PrintStream originalOut;
        private final PrintStream originalErr;
        private final ByteArrayOutputStream captured = new ByteArrayOutputStream();
        private final String loggerPrefix;

        private JsonLogCapture(PrintStream originalOut, PrintStream originalErr, String loggerPrefix) {
            this.originalOut = originalOut;
            this.originalErr = originalErr;
            this.loggerPrefix = loggerPrefix;
        }

        /**
         * @param loggerPrefix 取り出す対象のロガー名の接頭辞. 空文字なら全件
         */
        static JsonLogCapture start(String loggerPrefix) {
            // appender の出力先が標準エラーの場合もあるので、両方を取り込む
            JsonLogCapture capture = new JsonLogCapture(System.out, System.err, loggerPrefix);
            System.setOut(tee(System.out, capture.captured));
            System.setErr(tee(System.err, capture.captured));
            return capture;
        }

        private static PrintStream tee(OutputStream original, OutputStream capture) {
            return new PrintStream(new TeeOutputStream(original, capture), true, StandardCharsets.UTF_8);
        }

        /**
         * 取り込みを終了して出力先を元に戻す. テストごとに必ず呼ぶこと.
         */
        void detach() {
            System.out.flush();
            System.err.flush();
            System.setOut(originalOut);
            System.setErr(originalErr);
        }

        /**
         * 標準出力に出た JSON ログ (1 要素 = 1 行). JSON 以外の行と対象外のロガーの行は除く.
         */
        List<String> lines() {
            return captured.toString(StandardCharsets.UTF_8).lines()
                    .map(String::strip)
                    .filter(line -> line.startsWith("{"))
                    .filter(this::isTargetLogger)
                    .toList();
        }

        private boolean isTargetLogger(String jsonLine) {
            try {
                return TestCaseResources.MAPPER.readTree(jsonLine).path("logger_name").asString("")
                        .startsWith(loggerPrefix);
            } catch (JacksonException e) {
                return false; // JSON として読めない行は対象外
            }
        }

        /**
         * 書き込みを元の標準出力と取り込み用バッファの両方へ流す.
         */
        private static final class TeeOutputStream extends OutputStream {

            private final OutputStream first;
            private final OutputStream second;

            private TeeOutputStream(OutputStream first, OutputStream second) {
                this.first = first;
                this.second = second;
            }

            @Override
            public synchronized void write(int b) throws IOException {
                first.write(b);
                second.write(b);
            }

            @Override
            public synchronized void write(byte[] b, int off, int len) throws IOException {
                first.write(b, off, len);
                second.write(b, off, len);
            }

            @Override
            public void flush() throws IOException {
                first.flush();
                second.flush();
            }
        }
    }

    /**
     * テストクラスと同じパッケージ配下のテスト資材を扱う.
     *
     * <pre>
     * {パッケージ}/ddl/{テーブル名}.sql   … 共通の DDL (DROP → CREATE). ケース配下に同名ファイルを置くと優先
     * {パッケージ}/testcases/{ケース名}/
     *   input/{テーブル名}.csv      … 投入データ (1 行目 = ヘッダー. 空欄は NULL)
     *   expected/{テーブル名}.csv   … 実行後の期待値 (IGNORED_DB_COLUMNS は書かない)
     *   expected/log.json          … 期待するログ (MASKED_LOG_FIELDS は "***" と書く)
     *   .env                       … このケースの環境変数 (必須. 空でもよい)
     * </pre>
     */
    static final class TestCaseResources {

        /**
         * 期待値ログのワイルドカード. "***" だけなら値は問わず項目の存在のみ、
         * "***xxx***" のように書くと値に xxx が (複数あればその順で) 含まれることを確認する.
         */
        static final String MASK = "***";

        /**
         * 実行のたびに変わるカラム
         */
        static final Set<String> IGNORED_DB_COLUMNS = Set.of("upd_dt_tm");

        static final ObjectMapper MAPPER = JsonMapper.builder()
                .enable(SerializationFeature.INDENT_OUTPUT)
                .build();
        private static final PathMatchingResourcePatternResolver RESOLVER = new PathMatchingResourcePatternResolver();

        private final String basePath;
        private final String caseName;

        TestCaseResources(String packageName, String caseName) {
            this.basePath = packageName.replace('.', '/');
            this.caseName = caseName;
        }

        /**
         * DDL でテーブルを作り直して input/*.csv を投入する
         */
        void setUpDatabase(TestDatabase db) {
            // 各 DDL ファイルが DROP TABLE IF EXISTS → CREATE TABLE を持つ (実行順はファイル名順)
            ddlResources().values().forEach(db::runScript);
            for (Resource resource : resources("input/*.csv")) {
                db.insert(tableName(resource), db.readCsv(resource));
            }
        }

        /**
         * .env を読む. ケースごとに必ず置く (空でもよい).
         */
        Map<String, Object> environment() {
            Map<String, Object> variables = new LinkedHashMap<>();
            for (String line : read(resource(".env")).lines().map(String::strip).toList()) {
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                String[] keyValue = line.split("=", 2);
                variables.put(keyValue[0].strip(), keyValue.length > 1 ? keyValue[1].strip() : "");
            }
            return variables;
        }

        /**
         * expected/{テーブル名}.csv と DB の内容を突合する (行の順序・カラムの過不足も NG)
         */
        void assertDatabase(TestDatabase db) {
            List<Resource> expectedTables = resources("expected/*.csv");
            if (expectedTables.isEmpty()) {
                throw new IllegalStateException("no expected table files for case: " + caseName);
            }
            for (Resource resource : expectedTables) {
                String table = tableName(resource);
                List<Map<String, String>> actual = db.selectAll(table).stream()
                        .map(TestCaseResources::normalizeRow)
                        .toList();
                List<Map<String, String>> expected = db.readCsv(resource).stream()
                        .map(TestCaseResources::canonicalRow)
                        .toList();
                // DB の行順は保証されないので、順序は問わず件数と内容で比較する
                assertThat(actual)
                        .as("[%s] table [%s] mismatch.%nexpected:%n%s%nactual:%n%s",
                                caseName, table, toCsv(expected), toCsv(actual))
                        .containsExactlyInAnyOrderElementsOf(expected);
            }
        }

        /**
         * expected/log.json のログが、出力されたログに順番どおり含まれていることを確認する (書いた項目だけ照合).
         */
        void assertLogContains(List<String> jsonLines) {
            List<ObjectNode> actual = parseLogs(jsonLines);
            int from = 0;
            for (JsonNode expected : MAPPER.readTree(read(resource("expected/log.json")))) {
                int found = indexOfMatch(actual, (ObjectNode) expected, from);
                if (found < 0) {
                    throw new AssertionError("[" + caseName + "] expected log not found"
                            + (from > 0 ? " (after the previous one)" : "") + ":\n" + toJson(expected)
                            + "\nactual:\n" + toJson(actual) + "\n");
                }
                from = found + 1; // 同じログ行を 2 回使わない (順序も検証される)
            }
        }

        /**
         * 出力されたログが expected/log.json と完全一致することを確認する (並び・項目とも過不足なし).
         */
        void assertLogExactly(List<String> jsonLines) {
            List<ObjectNode> actual = parseLogs(jsonLines);
            JsonNode expected = MAPPER.readTree(read(resource("expected/log.json")));
            boolean sameSize = expected.size() == actual.size();
            for (int i = 0; sameSize && i < actual.size(); i++) {
                ObjectNode log = actual.get(i);
                ObjectNode want = (ObjectNode) expected.get(i);
                // 項目の過不足が無く、かつ値が一致すること
                if (!want.propertyNames().equals(log.propertyNames()) || !matches(want, log)) {
                    sameSize = false;
                }
            }
            if (!sameSize) {
                throw new AssertionError("[" + caseName + "] log mismatch.\nexpected:\n" + toJson(expected)
                        + "\nactual:\n" + toJson(actual) + "\n");
            }
        }

        /**
         * 出力された JSON ログを読み、実行のたびに変わる項目の値を MASK に置き換える.
         */
        private static List<ObjectNode> parseLogs(List<String> jsonLines) {
            List<ObjectNode> logs = new ArrayList<>();
            for (String line : jsonLines) {
                try {
                    logs.add((ObjectNode) MAPPER.readTree(line));
                } catch (JacksonException e) {
                    throw new IllegalStateException("not a JSON log line: " + line, e);
                }
            }
            return logs;
        }

        /**
         * from 番目以降で、期待値に書かれた項目をすべて満たす最初のログの位置 (無ければ -1).
         */
        private static int indexOfMatch(List<ObjectNode> actual, ObjectNode expected, int from) {
            for (int i = from; i < actual.size(); i++) {
                if (matches(expected, actual.get(i))) {
                    return i;
                }
            }
            return -1;
        }

        /**
         * 期待値に書かれた項目がすべて一致するか.
         */
        private static boolean matches(ObjectNode expected, ObjectNode log) {
            return expected.properties().stream()
                    .allMatch(field -> valueMatches(field.getValue(), log.get(field.getKey())));
        }

        /**
         * 期待値に "***" があれば部分一致 (順序つき)、無ければ完全一致.
         */
        private static boolean valueMatches(JsonNode expected, JsonNode actual) {
            if (actual == null) {
                return false;
            }
            if (!expected.isString() || !expected.stringValue().contains(MASK)) {
                return expected.equals(actual);
            }
            String text = actual.isString() ? actual.stringValue() : actual.toString();
            int from = 0;
            for (String part : expected.stringValue().split("\\*\\*\\*", -1)) {
                if (part.isEmpty()) {
                    continue;
                }
                int found = text.indexOf(part, from);
                if (found < 0) {
                    return false;
                }
                from = found + part.length(); // 順序も見る
            }
            return true;
        }

        /**
         * 日時の表記ゆれ ("2026-09-21T10:00:00" と "2026-09-21 10:00:00"、末尾の .0) を揃える
         */
        private static final Pattern DATE_TIME =
                Pattern.compile("(\\d{4}-\\d{2}-\\d{2})[T ](\\d{2}:\\d{2}:\\d{2})(\\.\\d+)?");

        /**
         * 比較のために値を正規化する (日時は "yyyy-MM-dd HH:mm:ss" に揃える)
         */
        private static String canonical(String value) {
            Matcher matcher = DATE_TIME.matcher(value);
            if (!matcher.matches()) {
                return value;
            }
            String fraction = matcher.group(3) == null ? "" : matcher.group(3).replaceAll("0+$", "");
            return matcher.group(1) + " " + matcher.group(2) + (".".equals(fraction) ? "" : fraction);
        }

        /**
         * DB の 1 行を CSV と比較できる文字列の Map にする
         */
        private static Map<String, String> normalizeRow(Map<String, Object> row) {
            Map<String, String> normalized = new LinkedHashMap<>();
            row.forEach((column, value) -> {
                String key = column.toLowerCase();
                if (IGNORED_DB_COLUMNS.contains(key)) {
                    return;
                }
                normalized.put(key, switch (value) {
                    case null -> "";
                    case Date d -> d.toLocalDate().toString();
                    case Timestamp t -> canonical(t.toLocalDateTime().toString());
                    case BigDecimal b -> b.toPlainString();
                    default -> canonical(value.toString());
                });
            });
            return normalized;
        }

        /**
         * ファイル名 → DDL. 共通の ddl/*.sql に、ケース固有の testcases/{ケース名}/ddl/*.sql を同名で上書きする.
         * 実行順はファイル名順 (外部キーがある場合は 01_ などの接頭辞で順序を決める).
         */
        private Map<String, Resource> ddlResources() {
            Map<String, Resource> ddls = new TreeMap<>();
            try {
                for (Resource resource : RESOLVER.getResources("classpath*:" + basePath + "/ddl/*.sql")) {
                    ddls.put(resource.getFilename(), resource);
                }
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
            resources("ddl/*.sql").forEach(resource -> ddls.put(resource.getFilename(), resource));
            if (ddls.isEmpty()) {
                throw new IllegalStateException("no DDL files found under classpath:ddl/");
            }
            return ddls;
        }

        /**
         * ケースフォルダ配下のリソースをファイル名順で取得する (無ければ空).
         */
        /**
         * 期待値 CSV の 1 行を、実際の値と同じ表記に揃える
         */
        private static Map<String, String> canonicalRow(Map<String, String> row) {
            Map<String, String> canonical = new LinkedHashMap<>();
            row.forEach((column, value) -> canonical.put(column, canonical(value)));
            return canonical;
        }

        private List<Resource> resources(String pattern) {
            try {
                List<Resource> list = new ArrayList<>(List.of(
                        RESOLVER.getResources("classpath*:" + basePath + "/testcases/" + caseName + "/" + pattern)));
                list.sort(Comparator.comparing(r -> String.valueOf(r.getFilename())));
                return list;
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }

        /**
         * ケースフォルダ配下の 1 ファイルを取得する (無ければ例外).
         */
        private Resource resource(String path) {
            Resource resource = RESOLVER.getResource("classpath:" + basePath + "/testcases/" + caseName + "/" + path);
            if (!resource.exists()) {
                throw new IllegalStateException("resource not found: " + resource.getDescription());
            }
            return resource;
        }

        /**
         * CSV のファイル名 = テーブル名.
         */
        private static String tableName(Resource resource) {
            return resource.getFilename().replaceFirst("\\.csv$", "");
        }

        /**
         * 失敗時にそのまま期待値ファイルへ貼れる形で出す
         */
        private static String toCsv(List<Map<String, String>> rows) {
            if (rows.isEmpty()) {
                return "(no rows)";
            }
            StringBuilder csv = new StringBuilder(String.join(",", rows.getFirst().keySet())).append("\n");
            rows.forEach(row -> csv.append(String.join(",", row.values())).append("\n"));
            return csv.toString();
        }

        /**
         * ファイルを文字列として読む (期待値 JSON 用).
         */
        private static String read(Resource resource) {
            try (InputStream in = resource.getInputStream()) {
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }

        /**
         * 比較・表示用に JSON 文字列へ変換する.
         */
        private static String toJson(Object value) {
            return MAPPER.writeValueAsString(value);
        }
    }
}
