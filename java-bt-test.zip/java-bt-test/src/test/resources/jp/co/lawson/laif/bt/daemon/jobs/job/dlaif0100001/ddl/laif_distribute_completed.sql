-- 配信完了
DROP TABLE IF EXISTS laif_distribute_completed;

CREATE TABLE laif_distribute_completed (
    distribute_id BIGINT NOT NULL PRIMARY KEY
);
