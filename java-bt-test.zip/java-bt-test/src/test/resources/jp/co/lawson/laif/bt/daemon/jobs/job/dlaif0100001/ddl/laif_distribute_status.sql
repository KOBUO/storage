DROP TABLE IF EXISTS laif_distribute_status;

CREATE TABLE laif_distribute_status (
    distribute_id              BIGINT      NOT NULL PRIMARY KEY,
    store_cd                   VARCHAR(10) NOT NULL,
    equipment_category         VARCHAR(2)  NOT NULL,
    equipment_no               VARCHAR(10) NOT NULL,
    distribute_area_category   VARCHAR(2)  NOT NULL,
    distribute_channel         VARCHAR(1)  NOT NULL,
    distribute_availability_fg VARCHAR(1)  NOT NULL,
    distribute_priority_kbn    VARCHAR(1)  NOT NULL,
    distribute_order           INTEGER     NOT NULL,
    updater_id                 VARCHAR(20),
    upd_dt_tm                  TIMESTAMP
);
