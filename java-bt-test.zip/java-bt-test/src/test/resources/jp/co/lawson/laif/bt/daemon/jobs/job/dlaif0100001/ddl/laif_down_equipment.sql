-- ダウン機器
DROP TABLE IF EXISTS laif_down_equipment;

CREATE TABLE laif_down_equipment (
    store_cd           VARCHAR(10) NOT NULL,
    equipment_category VARCHAR(2)  NOT NULL,
    equipment_no       VARCHAR(10) NOT NULL
);
