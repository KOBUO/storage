package jp.co.lawson.laif.bt.daemon.jobs.job.dlaif0100001;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import jp.co.lawson.common.app.lib.logging.ApplicationLogger;
import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeConst.AreaCategory;
import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeProperties;
import jp.co.lawson.laif.bt.daemon.jobs.dto.DistributeInstructRegisterJobPreprocessorResult;
import jp.co.lawson.laif.bt.daemon.jobs.jobstep.dlaif0100001.DistributeInstructRegisterJobDatabaseUpdater;
import jp.co.lawson.laif.bt.daemon.jobs.jobstep.dlaif0100001.DistributeInstructRegisterJobPermissionSetter;
import jp.co.lawson.laif.bt.daemon.jobs.jobstep.dlaif0100001.DistributeInstructRegisterJobPreprocessor;
import jp.co.nri.cortixa.batch.daemon.job.DaemonJob;
import jp.co.nri.xpalette.batch.core.exception.JobStartFailedException;
import jp.co.nri.xpalette.batch.core.result.JobExecutionResult;
import jp.co.nri.xpalette.batch.core.runner.JobContext;
import jp.co.nri.xpalette.batch.core.runner.JobIdentifier;
import jp.co.nri.xpalette.batch.core.util.JobParameterUtils;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 配信指示登録処理のジョブクラス
 */
@JobIdentifier("DLAIF0100001")
@RequiredArgsConstructor
public class DistributeInstructRegisterJob extends DaemonJob {

    private static final ApplicationLogger LOGGER = ApplicationLogger.getLogger();

    private final Validator validator;
    private final DistributeProperties properties;
    private final DistributeInstructRegisterJobPreprocessor preprocessor;
    private final DistributeInstructRegisterJobPermissionSetter permissionSetter;
    private final DistributeInstructRegisterJobDatabaseUpdater databaseUpdater;

    /**
     * {@inheritDoc}
     *
     * <p>
     * ジョブ実行前に起動引数の妥当性を検証する。
     * </p>
     */
    @Override
    public JobExecutionResult runJob(JobContext jobContext) {
        // プロパティ(環境変数)チェック
        Set<ConstraintViolation<DistributeProperties>> violations = this.validator.validate(properties);
        if (!violations.isEmpty()) {
            String details = violations.stream()
                    .map(v -> String.format(
                            "%s(%s=%s)",
                            v.getMessage(),
                            v.getPropertyPath(),
                            v.getInvalidValue()))
                    .sorted()
                    .collect(Collectors.joining(", "));
            throw new JobStartFailedException("環境変数の設定値が不正です。" + details);
        }
        // 起動引数チェック(配信エリア種別)
        String distributeAreaCategory = JobParameterUtils.getJobParameter(
                "distribute_area_category", jobContext);
        if (distributeAreaCategory == null
                || Arrays.stream(AreaCategory.values())
                .noneMatch(area -> area.getCode().equals(distributeAreaCategory))) {
            // 配信エリア種別が未指定または定義外の場合
            throw new JobStartFailedException(
                    "起動引数が不正です。--distribute_area_category="
                            + distributeAreaCategory);
        }
        return super.runJob(jobContext);
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * 配信指示登録処理を実行する。
     * </p>
     */
    @Override
    protected JobExecutionResult execute(JobContext jobContext) {
        // バッチ引数より、配信エリア種別を取得
        String distributeAreaCategory = JobParameterUtils.getJobParameter(
                "distribute_area_category", jobContext);
        // 事前処理を実行
        DistributeInstructRegisterJobPreprocessorResult preprocessorResult = preprocessor
                .preprocess(distributeAreaCategory);
        // 配信許可設定処理を実行
        List<Long> permittedDistributeIdList = permissionSetter.getPermittedDistributeIds(
                distributeAreaCategory,
                preprocessorResult.downEquipmentList(),
                preprocessorResult.permittedDistributeStatusMap(),
                preprocessorResult.distributePermissionSettingTargetMap());
        // 配信許可対象が存在する場合、DB更新処理を実行
        if (!permittedDistributeIdList.isEmpty()) {
            int updateCount = this.databaseUpdater.update(permittedDistributeIdList);
            LOGGER.info("配信状況テーブルを" + updateCount + "件更新しました。");
        }
        return jobContext.getJobExecutionResult();
    }
}
