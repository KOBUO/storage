package jp.co.lawson.laif.bt.daemon.jobs.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DistributeStatus;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.annotation.Retryable;

/**
 * 配信状況テーブル用のマッパーインターフェース。
 */
@Mapper
public interface DistributeStatusMapper {

    /**
     * 指定された配信エリア種別に該当する未完了の配信状況レコードを取得する。
     *
     * @param distributeAreaCategory 配信エリア種別
     * @return 配信対象の配信状況レコード
     */
    @Retryable(retryFor = DataAccessException.class, maxAttempts = 3)
    @Select("""
            SELECT
              ds.distribute_id,
              ds.store_cd,
              ds.equipment_category,
              ds.equipment_no,
              ds.distribute_availability_fg,
              ds.distribute_channel
            FROM
              laif_distribute_status AS ds
            LEFT JOIN
              laif_distribute_completed AS dc
            ON
              ds.distribute_id = dc.distribute_id
            WHERE
              ds.distribute_area_category = #{distributeAreaCategory}
             AND
              dc.distribute_id IS NULL
            ORDER BY
              ds.distribute_priority_kbn DESC,
              ds.distribute_order ASC
            """)
    List<DistributeStatus> findByDistributeAreaCategory(String distributeAreaCategory);

    /**
     * 配信可否を配信可能に更新する。
     *
     * @param distributeIdList 配信IDリスト
     * @return 更新件数
     */
    @Update("""
            <script>
            UPDATE
              laif_distribute_status
            SET
              distribute_availability_fg = '1',
              updater_id = 'DLAIF0100001',
              upd_dt_tm = CURRENT_TIMESTAMP
            WHERE
              distribute_id IN
                <foreach collection="distributeIdList" item="distributeId" open="(" separator="," close=")">
                  #{distributeId}
                </foreach>
            </script>
            """)
    int updateDistributeAvailabilityToPossible(List<Long> distributeIdList);
}
