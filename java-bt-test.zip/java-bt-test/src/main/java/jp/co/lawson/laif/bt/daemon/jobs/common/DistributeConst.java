package jp.co.lawson.laif.bt.daemon.jobs.common;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.jspecify.annotations.NonNull;

import java.util.Arrays;

/**
 * 配信処理で共通して使用する定数を定義するクラス
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DistributeConst {

    /**
     * 配信エリア種別
     */
    @Getter
    @AllArgsConstructor
    public enum AreaCategory {
        EAST_1("01"), // 東1
        EAST_2("02"), // 東2
        WEST_1("03"), // 西1
        WEST_2("04"), // 西2
        LOW_SPEED("05"); // 低速

        private final String code;

        /**
         * 指定されたコードと一致するか判定する。
         *
         * @param code 配信エリア種別コード
         * @return 一致する場合 true
         */
        public boolean matchOf(String code) {
            return this.code.equals(code);
        }
    }

    /**
     * 配信チャネル
     */
    @Getter
    @AllArgsConstructor
    public enum Channel {
        A("1"), // チャネルA
        B("2"), // チャネルB
        C("3"); // チャネルC

        private final String code;

        /**
         * 指定されたコードに対応する配信チャネルを取得する。
         *
         * @param code 配信チャネルコード
         * @return 配信チャネル
         * @throws java.util.NoSuchElementException 対象する配信チャネルが存在しない場合
         */
        public static @NonNull Channel codeOf(String code) {
            return Arrays.stream(values())
                    .filter(channel -> channel.getCode().equals(code))
                    .findFirst().orElseThrow();
        }
    }
}
