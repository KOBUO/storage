package jp.co.lawson.laif.bt.daemon.jobs.dto;

import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeConst.Channel;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DistributeStatus;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DownEquipment;

import java.util.List;
import java.util.Map;

/**
 * 配信指示登録ジョブの事前処理結果クラス
 *
 * @param downEquipmentList                    ダウン機器リスト
 * @param permittedDistributeStatusMap         配信チャネル・店舗別配信許可中配信状況マップ
 * @param distributePermissionSettingTargetMap 配信チャネル別配信許可設定処理対象マップ
 */
public record DistributeInstructRegisterJobPreprocessorResult(
        List<DownEquipment> downEquipmentList,
        Map<Channel, Map<String, List<DistributeStatus>>> permittedDistributeStatusMap,
        Map<Channel, List<DistributeStatus>> distributePermissionSettingTargetMap) {
}
