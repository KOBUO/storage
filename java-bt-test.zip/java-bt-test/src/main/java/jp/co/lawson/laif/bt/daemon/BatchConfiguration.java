package jp.co.lawson.laif.bt.daemon;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.SchedulingConfiguration;

/**
 * CortixaSimpleBatchで共通利用されるBeanの定義
 */
@Configuration(proxyBeanMethods = false)
@Import({ SchedulingConfiguration.class })
public class BatchConfiguration {
}
