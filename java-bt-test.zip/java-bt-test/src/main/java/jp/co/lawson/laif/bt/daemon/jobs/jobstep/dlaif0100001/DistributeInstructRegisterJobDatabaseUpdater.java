package jp.co.lawson.laif.bt.daemon.jobs.jobstep.dlaif0100001;

import jp.co.lawson.laif.bt.daemon.jobs.mapper.DistributeStatusMapper;
import jp.co.nri.cortixa.batch.core.runner.JobStep;
import jp.co.nri.xpalette.batch.core.exception.JobExecFailedException;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 配信指示登録ジョブのDB更新処理を行うクラス。
 */
@Component
@RequiredArgsConstructor
public class DistributeInstructRegisterJobDatabaseUpdater {

    private final DistributeStatusMapper distributeStatusMapper;

    /**
     * 配信許可対象について、配信状況テーブルの配信可否を配信可能に更新する。
     *
     * @param permittedDistributeIdList 配信許可設定済み配信IDリスト
     * @return 更新件数
     */
    @JobStep
    @Transactional
    public int update(List<Long> permittedDistributeIdList) {
        try {
            // 配信状況テーブルの配信可否を配信可能に更新
            return this.distributeStatusMapper.updateDistributeAvailabilityToPossible(permittedDistributeIdList);
        } catch (DataAccessException e) {
            String msg = "DB処理でエラーが発生しました。DB処理：配信状況更新";
            throw new JobExecFailedException(msg, e);
        } catch (Exception e) {
            String msg = "予期せぬ以下の例外が発生しました。Exception={0}" + e.getClass().getSimpleName();
            throw new JobExecFailedException(msg, e);
        }
    }
}
