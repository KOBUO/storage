package jp.co.lawson.laif.bt.daemon;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ConfigurableApplicationContext;
import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeProperties;
import org.springframework.retry.annotation.EnableRetry;

/**
 * バッチアプリケーションのエントリポイント。
 */
@SpringBootApplication
@EnableConfigurationProperties({ DistributeProperties.class })
@EnableRetry
public class BatchApplication {

    public static void main(String[] args) {
        final int exitCode = batchAppRun(args);
        System.exit(exitCode);
    }

    /**
     * Spring Boot アプリケーションを起動し、終了コードを取得する。
     *
     * @param args 起動引数
     * @return 終了コード
     */
    private static int batchAppRun(final String... args) {
        final SpringApplication app = new SpringApplication(BatchApplication.class);
        app.setBannerMode(Banner.Mode.OFF);

        ConfigurableApplicationContext appContext = app.run(args);
        if (!appContext.isActive()) {
            return 0;
        }

        return SpringApplication.exit(appContext);
    }
}
