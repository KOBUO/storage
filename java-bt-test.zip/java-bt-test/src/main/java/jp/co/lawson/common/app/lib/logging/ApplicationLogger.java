package jp.co.lawson.common.app.lib.logging;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 社内共通ライブラリの代用 (本物は jar). 呼び出し元クラス名のロガーに出力する.
 */
public final class ApplicationLogger {

    private final Logger logger;

    private ApplicationLogger(Logger logger) {
        this.logger = logger;
    }

    /**
     * 呼び出し元クラスのロガーを返す.
     */
    public static ApplicationLogger getLogger() {
        Class<?> caller = StackWalker.getInstance(StackWalker.Option.RETAIN_CLASS_REFERENCE).getCallerClass();
        return new ApplicationLogger(LoggerFactory.getLogger(caller));
    }

    /**
     * INFO ログを出力する.
     */
    public void info(String message) {
        logger.info(message);
    }

    /**
     * ERROR ログを出力する.
     */
    public void error(String message, Throwable cause) {
        logger.error(message, cause);
    }
}
