package jp.co.lawson.laif.bt.daemon.jobs.mapper;

import jp.co.lawson.laif.bt.daemon.jobs.entity.DownEquipment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.dao.DataAccessException;
import org.springframework.retry.annotation.Retryable;

import java.util.List;

/**
 * ダウン機器テーブル用のマッパーインターフェース
 */
@Mapper
public interface DownEquipmentMapper {

    /**
     * ダウン機器テーブルから全件を取得する
     *
     * @return ダウン機器リスト
     */
    @Retryable(retryFor = DataAccessException.class, maxAttempts = 3)
    @Select("""
            SELECT
              store_cd,
              equipment_category,
              equipment_no
            FROM
              laif_down_equipment
            """)
    List<DownEquipment> findAll();
}
