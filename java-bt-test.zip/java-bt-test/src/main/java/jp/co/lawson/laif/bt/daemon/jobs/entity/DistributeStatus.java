package jp.co.lawson.laif.bt.daemon.jobs.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 配信状況を保持するエンティティクラス。
 */
@Data
@NoArgsConstructor
public class DistributeStatus {

    /**
     * 配信ID
     */
    private Long distributeId;

    /**
     * 店舗コード
     */
    private String storeCd;

    /**
     * 機器種別
     */
    private String equipmentCategory;

    /**
     * 機器番号
     */
    private String equipmentNo;

    /**
     * 配信可否FG
     */
    private String distributeAvailabilityFg;

    /**
     * 配信チャネル
     */
    private String distributeChannel;
}
