package jp.co.lawson.laif.bt.daemon.jobs.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * ダウン機器を保持するエンティティクラス。
 */
@Data
@NoArgsConstructor
public class DownEquipment {

    /**
     * 店舗コード
     */
    private String storeCd;
    /**
     * 機器種別
     */
    private String equipmentCategory;
    /**
     * 機器番号
     */
    private String equipmentNo;
}
