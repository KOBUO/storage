package jp.co.nri.xpalette.batch.core.runner;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import org.springframework.stereotype.Component;

/**
 * 社内フレームワークの代用 (本物は jar). ジョブ ID を付け、ジョブを Bean として登録する.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Component
public @interface JobIdentifier {

    /**
     * ジョブ ID.
     */
    String value();
}
