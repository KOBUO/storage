package jp.co.nri.xpalette.batch.core.exception;

/**
 * 社内フレームワークの代用.
 */
public class DuplicateJobParameterException extends RuntimeException {

    public DuplicateJobParameterException(String message) {
        super(message);
    }
}
