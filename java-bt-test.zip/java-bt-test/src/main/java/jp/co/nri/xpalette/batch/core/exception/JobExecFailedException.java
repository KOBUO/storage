package jp.co.nri.xpalette.batch.core.exception;

/**
 * 社内フレームワークの代用.
 */
public class JobExecFailedException extends RuntimeException {

    public JobExecFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}
