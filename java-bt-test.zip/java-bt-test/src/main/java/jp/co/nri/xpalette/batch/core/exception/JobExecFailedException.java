package jp.co.nri.xpalette.batch.core.exception;

/**
 * 社内フレームワークの代用 (本物は jar). ジョブの実行に失敗した.
 */
public class JobExecFailedException extends RuntimeException {

    public JobExecFailedException(String message, Throwable cause) {
        super(message, cause);
    }
}
