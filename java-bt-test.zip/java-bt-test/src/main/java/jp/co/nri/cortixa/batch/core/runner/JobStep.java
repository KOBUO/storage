package jp.co.nri.cortixa.batch.core.runner;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 社内フレームワークの代用 (本物は jar). ジョブステップの目印で、この代用には動作はない.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface JobStep {
}
