package jp.co.nri.xpalette.batch.core.exception;

/**
 * 社内フレームワークの代用.
 */
public class NoJobParameterException extends RuntimeException {

    public NoJobParameterException(String message) {
        super(message);
    }
}
