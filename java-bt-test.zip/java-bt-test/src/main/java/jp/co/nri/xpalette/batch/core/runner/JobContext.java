package jp.co.nri.xpalette.batch.core.runner;

import org.springframework.boot.ApplicationArguments;

import jp.co.nri.xpalette.batch.core.result.JobExecutionResult;

/**
 * 社内フレームワークの代用 (本物は jar). 起動引数と実行結果を持つ.
 */
public class JobContext {

    private final ApplicationArguments arguments;
    private final JobExecutionResult jobExecutionResult = new JobExecutionResult();

    public JobContext(ApplicationArguments arguments) {
        this.arguments = arguments;
    }

    /**
     * 起動引数.
     */
    public ApplicationArguments getArguments() {
        return arguments;
    }

    /**
     * 実行結果.
     */
    public JobExecutionResult getJobExecutionResult() {
        return jobExecutionResult;
    }
}
