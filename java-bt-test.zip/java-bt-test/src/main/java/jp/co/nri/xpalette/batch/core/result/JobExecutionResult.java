package jp.co.nri.xpalette.batch.core.result;

/**
 * 社内フレームワークの代用 (本物は jar). ジョブの終了コードを持つ.
 */
public class JobExecutionResult {

    private int exitCode;

    /**
     * 終了コード. 0 は正常終了.
     */
    public int getExitCode() {
        return exitCode;
    }

    /**
     * 異常終了として記録する.
     */
    public void fail() {
        exitCode = 1;
    }
}
