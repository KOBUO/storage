package jp.co.nri.xpalette.batch.core.result;

/**
 * 社内フレームワークの代用.
 */
public class JobExecutionResult {

    private int exitCode;

    /**
     * 終了コード.
     */
    public int getExitCode() {
        return exitCode;
    }

    /**
     * 異常終了として記録する.
     */
    public void fail() {
        exitCode = 1;
    }
}
