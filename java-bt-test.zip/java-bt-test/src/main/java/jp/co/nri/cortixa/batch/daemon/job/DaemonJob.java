package jp.co.nri.cortixa.batch.daemon.job;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.ExitCodeGenerator;

import jakarta.annotation.PreDestroy;
import jp.co.nri.xpalette.batch.core.result.JobExecutionResult;
import jp.co.nri.xpalette.batch.core.runner.JobContext;

/**
 * 社内フレームワークの代用 (本物は jar). 起動時に {@link #runJob} を呼び、停止されるまで {@link #execute} を繰り返す.
 */
public abstract class DaemonJob implements ApplicationRunner, ExitCodeGenerator {

    private static final Logger log = LoggerFactory.getLogger(DaemonJob.class);
    private static final Duration POLL_INTERVAL = Duration.ofSeconds(5);

    private final Object monitor = new Object();
    private volatile boolean running;
    private JobContext jobContext;

    @Override
    public void run(ApplicationArguments args) {
        jobContext = new JobContext(args);
        try {
            runJob(jobContext);
        } catch (RuntimeException e) {
            log.error("job aborted", e);
            jobContext.getJobExecutionResult().fail();
        }
    }

    @Override
    public int getExitCode() {
        return jobContext == null ? 0 : jobContext.getJobExecutionResult().getExitCode();
    }

    /**
     * 停止されるまで {@link #execute} を繰り返す.
     */
    public JobExecutionResult runJob(JobContext jobContext) {
        running = true;
        while (running) {
            execute(jobContext);
            waitForNextPoll();
        }
        return jobContext.getJobExecutionResult();
    }

    /**
     * 1 サイクル分の処理.
     */
    protected abstract JobExecutionResult execute(JobContext jobContext);

    /**
     * 停止を指示する (実行中の {@link #execute} は最後まで実行される).
     */
    public void stop() {
        synchronized (monitor) {
            running = false;
            monitor.notifyAll();
        }
    }

    @PreDestroy
    void shutdown() {
        stop();
    }

    private void waitForNextPoll() {
        synchronized (monitor) {
            if (!running) {
                return;
            }
            try {
                monitor.wait(POLL_INTERVAL.toMillis());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                running = false;
            }
        }
    }
}
