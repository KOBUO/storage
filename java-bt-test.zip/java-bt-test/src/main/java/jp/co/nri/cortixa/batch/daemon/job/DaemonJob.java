package jp.co.nri.cortixa.batch.daemon.job;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.ExitCodeGenerator;

import jakarta.annotation.PreDestroy;
import jp.co.nri.xpalette.batch.core.result.JobExecutionResult;
import jp.co.nri.xpalette.batch.core.runner.JobContext;

/**
 * 社内フレームワークの代用.
 */
public abstract class DaemonJob implements ApplicationRunner, ExitCodeGenerator {

    private static final Logger log = LoggerFactory.getLogger(DaemonJob.class);
    private static final Duration POLL_INTERVAL = Duration.ofSeconds(5);

    private final Object monitor = new Object();
    private volatile boolean running;
    private volatile Thread worker;
    private JobContext jobContext;

    @Override
    public void run(ApplicationArguments args) {
        jobContext = new JobContext(args);
        try {
            runJob(jobContext);
        } catch (RuntimeException e) {
            log.error("job aborted", e);
            jobContext.getJobExecutionResult().fail();
        }
    }

    @Override
    public int getExitCode() {
        return jobContext == null ? 0 : jobContext.getJobExecutionResult().getExitCode();
    }

    /**
     * 停止されるまで {@link #execute} を繰り返す.
     */
    public JobExecutionResult runJob(JobContext jobContext) {
        running = true;
        worker = Thread.currentThread();
        while (running) {
            execute(jobContext);
            waitForNextPoll();
        }
        return jobContext.getJobExecutionResult();
    }

    /**
     * 1 サイクル分の処理.
     */
    protected abstract JobExecutionResult execute(JobContext jobContext);

    /**
     * 停止を指示する.
     */
    public void requestStop() {
        synchronized (monitor) {
            running = false;
            monitor.notifyAll();
        }
        Thread target = worker;
        if (target != null) {
            target.interrupt();
        }
    }

    @PreDestroy
    void shutdown() {
        requestStop();
    }

    private void waitForNextPoll() {
        synchronized (monitor) {
            if (!running) {
                return;
            }
            try {
                monitor.wait(POLL_INTERVAL.toMillis());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                running = false;
            }
        }
    }
}
