package jp.co.nri.xpalette.batch.core.exception;

/**
 * 社内フレームワークの代用 (本物は jar). ジョブの開始に失敗した.
 */
public class JobStartFailedException extends RuntimeException {

    public JobStartFailedException(String message) {
        super(message);
    }
}
