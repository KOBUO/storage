package jp.co.nri.xpalette.batch.core.exception;

/**
 * 社内フレームワークの代用.
 */
public class JobStartFailedException extends RuntimeException {

    public JobStartFailedException(String message) {
        super(message);
    }
}
