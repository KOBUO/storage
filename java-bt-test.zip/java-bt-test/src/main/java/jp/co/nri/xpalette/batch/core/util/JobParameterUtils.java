package jp.co.nri.xpalette.batch.core.util;

import java.util.List;

import jp.co.nri.xpalette.batch.core.runner.JobContext;

/**
 * 社内フレームワークの代用 (本物は jar). 起動引数 (--name=value) を取り出す.
 */
public final class JobParameterUtils {

    private JobParameterUtils() {
    }

    /**
     * 起動引数の値 (指定が無ければ null).
     */
    public static String getJobParameter(String name, JobContext jobContext) {
        List<String> values = jobContext.getArguments().getOptionValues(name);
        return values == null || values.isEmpty() ? null : values.getFirst();
    }
}
