package jp.co.nri.xpalette.batch.core.util;

import java.util.List;

import jp.co.nri.xpalette.batch.core.exception.DuplicateJobParameterException;
import jp.co.nri.xpalette.batch.core.exception.NoJobParameterException;
import jp.co.nri.xpalette.batch.core.runner.JobContext;

/**
 * 社内フレームワークの代用.
 */
public final class JobParameterUtils {

    private JobParameterUtils() {
    }

    /**
     * 起動引数の値.
     */
    public static String getJobParameter(String name, JobContext jobContext) {
        List<String> values = jobContext.getArguments().getOptionValues(name);
        if (values == null || values.isEmpty()) {
            throw new NoJobParameterException("job parameter is not specified: --" + name);
        }
        if (values.size() > 1) {
            throw new DuplicateJobParameterException("job parameter is duplicated: --" + name);
        }
        return values.getFirst();
    }
}
