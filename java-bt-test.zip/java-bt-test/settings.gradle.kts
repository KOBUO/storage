rootProject.name = "laif-daemon-bt"
