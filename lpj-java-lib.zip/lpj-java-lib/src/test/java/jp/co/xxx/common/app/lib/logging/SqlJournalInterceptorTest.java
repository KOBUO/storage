package jp.co.xxx.common.app.lib.logging;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.List;

import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Invocation;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.read.ListAppender;

/**
 * {@link SqlJournalInterceptor} の単体テスト。
 */
class SqlJournalInterceptorTest {

    /** テスト対象（全 SQL 出力モード）。状態を持たないため全テストで共有する。 */
    private static final SqlJournalInterceptor TARGET = new SqlJournalInterceptor(false);

    /** テスト対象（例外時のみ出力モード）。 */
    private static final SqlJournalInterceptor TARGET_ERROR_ONLY = new SqlJournalInterceptor(true);

    /** SQLジャーナルロガーに付け替える、出力イベント捕捉用 appender。 */
    private ListAppender<ILoggingEvent> appender;
    private Logger sqlLogger;

    @BeforeEach
    void attachAppender() {
        sqlLogger = (Logger) org.slf4j.LoggerFactory.getLogger(LoggerNames.SQL_JNL);
        appender = new ListAppender<>();
        appender.start();
        sqlLogger.addAppender(appender);
        sqlLogger.setLevel(Level.INFO);
        sqlLogger.setAdditive(false); // ルートへの伝播を止めてテスト出力を汚さない
    }

    @AfterEach
    void detachAppender() {
        sqlLogger.detachAppender(appender);
        sqlLogger.setAdditive(true);
    }

    /**
     * 指定 SQL・引数で {@link Invocation} を組み立てる。
     * {@code args[0]} を {@link MappedStatement} とみなす。
     *
     * @param sql {@code getBoundSql().getSql()} が返す SQL（{@code null} 可）
     * @param args インターセプト対象メソッドの引数（先頭が MappedStatement）
     * @return モック化した {@link Invocation}
     */
    private static Invocation invocationWith(String sql, Object[] args) {
        BoundSql boundSql = mock(BoundSql.class);
        when(boundSql.getSql()).thenReturn(sql);
        when(((MappedStatement) args[0]).getBoundSql(any())).thenReturn(boundSql);
        Invocation invocation = mock(Invocation.class);
        when(invocation.getArgs()).thenReturn(args);
        return invocation;
    }

    /** 直近に捕捉したログイベント。 */
    private ILoggingEvent lastEvent() {
        return appender.list.get(appender.list.size() - 1);
    }

    /**
     * 成功時、整形した実行 SQL を INFO・marker（処理時間）付きで出力すること。
     *
     * 試験条件
     * ・proceed() が正常終了する。SQL に改行・連続空白を含む。
     * 観点ポイント
     * ・SQL の連続空白を1スペースに畳み、message は実行 SQL のみ（件数等は付けない）。
     * 想定結果
     * ・INFO で message が「SELECT * FROM t」。marker（latency）が付く。
     */
    @Test
    void successLogsNormalizedSqlAtInfo() throws Throwable {
        Invocation invocation = invocationWith("SELECT *\n  FROM t", new Object[] {mock(MappedStatement.class), null});
        when(invocation.proceed()).thenReturn(List.of("a", "b"));

        TARGET.intercept(invocation);

        assertThat(lastEvent().getLevel()).isEqualTo(Level.INFO);
        assertThat(lastEvent().getFormattedMessage()).isEqualTo("SELECT * FROM t");
        assertThat(lastEvent().getMarkerList()).isNotEmpty();
    }

    /**
     * 実行例外時、実行 SQL を ERROR・例外付きで出力し、例外をそのまま再スローすること。
     *
     * 試験条件
     * ・proceed() が例外を投げる。
     * 観点ポイント
     * ・例外時は message に実行 SQL、例外を付けて ERROR 出力し、同じ例外を再スローする（stack_trace は appender）。
     * 想定結果
     * ・ERROR で message「UPDATE t」・スタックトレース付き。投げた例外がそのまま伝播する。
     */
    @Test
    void failureLogsSqlAndRethrows() throws Throwable {
        Invocation invocation = invocationWith("UPDATE t", new Object[] {mock(MappedStatement.class), null});
        RuntimeException boom = new RuntimeException("boom");
        when(invocation.proceed()).thenThrow(boom);

        assertThatThrownBy(() -> TARGET.intercept(invocation)).isSameAs(boom);

        assertThat(lastEvent().getLevel()).isEqualTo(Level.ERROR);
        assertThat(lastEvent().getFormattedMessage()).isEqualTo("UPDATE t");
        assertThat(lastEvent().getThrowableProxy()).isNotNull();
    }

    /**
     * SQL が取得できない（null）場合も落ちず出力すること。
     *
     * 試験条件
     * ・getBoundSql().getSql() が null を返す。
     * 観点ポイント
     * ・SQL が null でも整形でぬるぽにならず、message は null とする。
     * 想定結果
     * ・INFO で message が空（SQL=null）。
     */
    @Test
    void nullSqlIsHandled() throws Throwable {
        Invocation invocation = invocationWith(null, new Object[] {mock(MappedStatement.class), null});
        when(invocation.proceed()).thenReturn(List.of("only"));

        TARGET.intercept(invocation);

        assertThat(lastEvent().getFormattedMessage()).isNull();
    }

    /**
     * 引数がパラメータを含まない（要素1つ）場合も、パラメータ null として動くこと。
     *
     * 試験条件
     * ・args が MappedStatement 1要素のみ（パラメータ無し）。
     * 観点ポイント
     * ・args の要素数が1なら、SQL 取得のパラメータを null として扱う。
     * 想定結果
     * ・message が「SELECT 9」。
     */
    @Test
    void singleArgUsesNullParameter() throws Throwable {
        Invocation invocation = invocationWith("SELECT 9", new Object[] {mock(MappedStatement.class)});
        when(invocation.proceed()).thenReturn(List.of("x"));

        TARGET.intercept(invocation);

        assertThat(lastEvent().getFormattedMessage()).isEqualTo("SELECT 9");
    }

    /**
     * 例外時のみモードで成功した場合、ログを出力しないこと。
     *
     * 試験条件
     * ・errorOnly=true のインターセプターで proceed() が正常終了する。
     * 観点ポイント
     * ・例外時のみモードでは、成功時の INFO 出力を行わない。
     * 想定結果
     * ・ログイベントが1件も出ない。
     */
    @Test
    void errorOnlyModeSkipsSuccessLog() throws Throwable {
        Invocation invocation = invocationWith("SELECT 1", new Object[] {mock(MappedStatement.class), null});
        when(invocation.proceed()).thenReturn(List.of("a"));

        TARGET_ERROR_ONLY.intercept(invocation);

        assertThat(appender.list).isEmpty();
    }

    /**
     * 例外時のみモードで例外が発生した場合、ERROR で出力し再スローすること。
     *
     * 試験条件
     * ・errorOnly=true のインターセプターで proceed() が例外を投げる。
     * 観点ポイント
     * ・例外時のみモードでも、例外時は通常どおり ERROR 出力し例外を再スローする。
     * 想定結果
     * ・ERROR で message「UPDATE t」。投げた例外がそのまま伝播する。
     */
    @Test
    void errorOnlyModeStillLogsOnFailure() throws Throwable {
        Invocation invocation = invocationWith("UPDATE t", new Object[] {mock(MappedStatement.class), null});
        RuntimeException boom = new RuntimeException("boom");
        when(invocation.proceed()).thenThrow(boom);

        assertThatThrownBy(() -> TARGET_ERROR_ONLY.intercept(invocation)).isSameAs(boom);

        assertThat(lastEvent().getLevel()).isEqualTo(Level.ERROR);
        assertThat(lastEvent().getFormattedMessage()).isEqualTo("UPDATE t");
    }
}
