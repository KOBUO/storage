package jp.co.xxx.common.app.lib.logging.logback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.StringWriter;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * {@link ClassMethodJsonProvider} の単体テスト。
 */
class ClassMethodJsonProviderTest {

    /**
     * テスト対象。
     */
    private static final ClassMethodJsonProvider TARGET = new ClassMethodJsonProvider();

    /**
     * 呼び出し元スタックの1フレームを組み立てる。
     *
     * @param className フレームのクラス FQCN
     * @param method フレームのメソッド名
     * @return ファイル名・行番号を持たない {@link StackTraceElement}
     */
    private static StackTraceElement frame(String className, String method) {
        return new StackTraceElement(className, method, null, 0);
    }

    /**
     * 呼び出し元スタックを差し込んでテスト対象に1イベント分を出力させる。
     *
     * @param caller 呼び出し元スタック（{@code null} 可＝取得不可を再現）
     * @return 出力された JSON 文字列
     * @throws Exception JSON 生成時の入出力例外
     */
    private String render(StackTraceElement[] caller) throws Exception {
        StringWriter writer = new StringWriter();
        try (JsonGenerator g = new JsonFactory().createGenerator(writer)) {
            g.writeStartObject();
            ILoggingEvent event = mock(ILoggingEvent.class);
            when(event.getCallerData()).thenReturn(caller);
            TARGET.writeTo(g, event);
            g.writeEndObject();
        }
        return writer.toString();
    }

    /**
     * 中継クラスがある場合、それを除外して業務クラスを発生元とすること。
     *
     * 試験条件
     * ・スタック先頭が中継クラス ApplicationLogger、直下に業務クラス OrderService。
     * 観点ポイント
     * ・ApplicationLogger を中継クラスとして飛ばし、直下のフレームを発生元に選ぶ。
     * 想定結果
     * ・class_name=com.example.app.OrderService / method_name=save を出力する。
     */
    @Test
    void skipsLibFacadeAndPicksBusinessClass() throws Exception {
        String json = render(new StackTraceElement[] {
                frame("jp.co.xxx.common.app.lib.logging.ApplicationLogger", "info"),
                frame("com.example.app.OrderService", "save"),
                frame("com.example.app.OrderController", "create"),
        });
        assertThat(json).contains("\"class_name\":\"com.example.app.OrderService\"", "\"method_name\":\"save\"");
    }

    /**
     * 中継クラスが連続する場合、全て除外すること。
     *
     * 試験条件
     * ・スタック先頭から ApLogger → JournalLogger（いずれも既存中継）→ 業務クラス PaymentService の順。
     * 観点ポイント
     * ・既存システムの中継クラスを除外対象とし、連続する2フレームを両方とも飛ばす。
     * 想定結果
     * ・class_name=com.example.app.PaymentService / method_name=charge を出力する。
     */
    @Test
    void skipsExistingSystemFacades() throws Exception {
        String json = render(new StackTraceElement[] {
                frame("jp.co.xxx.xxx.app.lib.logging.ApLogger", "info"),
                frame("jp.co.xxx.xxx.app.lib.logging.JournalLogger", "write"),
                frame("com.example.app.PaymentService", "charge"),
        });
        assertThat(json).contains("\"class_name\":\"com.example.app.PaymentService\"", "\"method_name\":\"charge\"");
    }

    /**
     * 中継クラスが無い場合、先頭フレームを発生元とすること。
     *
     * 試験条件
     * ・スタックが業務クラス PlainService の1フレームのみ（中継クラスなし）。
     * 観点ポイント
     * ・除外対象が無ければ先頭（直近の呼び出し元）をそのまま採用する。
     * 想定結果
     * ・class_name=com.example.app.PlainService / method_name=run を出力する。
     */
    @Test
    void picksTopFrameWhenNoFacade() throws Exception {
        String json = render(new StackTraceElement[] {
                frame("com.example.app.PlainService", "run"),
        });
        assertThat(json).contains("\"class_name\":\"com.example.app.PlainService\"", "\"method_name\":\"run\"");
    }

    /**
     * 発生元が見つからない場合、"null" が出力されること。
     *
     * 試験条件
     * ・スタックが中継クラス ApplicationLogger の1フレームのみ。
     * 観点ポイント
     * ・全フレームが中継クラスで発生元が無いとき、キーは出力しつつ値を文字列 "null" にする。
     * 想定結果
     * ・class_name / method_name とも値が "null"。
     */
    @Test
    void writesNullWhenOnlyFacadeFrames() throws Exception {
        String json = render(new StackTraceElement[] {
                frame("jp.co.xxx.common.app.lib.logging.ApplicationLogger", "info"),
        });
        assertThat(json).contains("\"class_name\":\"null\"", "\"method_name\":\"null\"");
    }

    /**
     * 呼び出し元スタックが取得できない場合、"null" が出力されること。
     *
     * 試験条件
     * ・getCallerData() が null を返す。
     * 観点ポイント
     * ・null でも例外を投げず、キーは出力しつつ値を文字列 "null" にする。
     * 想定結果
     * ・class_name / method_name とも値が "null"。
     */
    @Test
    void writesNullWhenCallerDataAbsent() throws Exception {
        assertThat(render(null)).contains("\"class_name\":\"null\"", "\"method_name\":\"null\"");
    }
}
