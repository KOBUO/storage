package jp.co.xxx.common.app.lib.logging.mask;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import net.logstash.logback.composite.loggingevent.LogstashMarkersJsonProvider;
import net.logstash.logback.composite.loggingevent.MessageJsonProvider;
import net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder;
import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;
import net.logstash.logback.mask.MaskingJsonGeneratorDecorator;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggingEvent;

/**
 * appender の {@code <jsonGeneratorDecorator>} に差した {@link LogMasker}（マスク）と {@link LogLengthLimiter}（切詰）が、
 * encoder 書き出し時に「マスク→切詰」の順で効くことを実機相当で確認する。呼び出し側処理は介さない。
 *
 * <p>valueMasker は登録順に直列適用される（{@link LogMasker} → {@link LogLengthLimiter}）。
 */
class MaskingDecoratorTest {

    @BeforeEach
    void installRules() {
        // yml 相当：ヘッダ authorization / body キー password / 値パターン=メール。上限は既定なし。
        LogMasker.install(
                Set.of("authorization"),
                List.of("password"),
                List.of(Pattern.compile("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}")));
        LogLengthLimiter.install(Map.of());
    }

    private String encode(LogstashMarker marker) {
        LoggerContext context = new LoggerContext();

        MaskingJsonGeneratorDecorator decorator = new MaskingJsonGeneratorDecorator();
        decorator.addValueMasker(new LogMasker());        // ① マスク（先）
        decorator.addValueMasker(new LogLengthLimiter());  // ② 切詰（後）
        decorator.addFieldMasker(new LogMasker());         // ヘッダ名マスク
        decorator.start();

        LoggingEventCompositeJsonEncoder encoder = new LoggingEventCompositeJsonEncoder();
        encoder.setContext(context);
        encoder.getProviders().addProvider(new MessageJsonProvider());
        encoder.getProviders().addProvider(new LogstashMarkersJsonProvider());
        encoder.setJsonGeneratorDecorator(decorator);
        encoder.start();

        Logger logger = context.getLogger("test");
        LoggingEvent event = new LoggingEvent("fqcn", logger, Level.INFO, "msg", null, null);
        event.addMarker(marker);
        return new String(encoder.encode(event), StandardCharsets.UTF_8);
    }

    @Test
    void masksHeaderValueUnderHeadersObject() {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("Authorization", "Bearer secret");
        headers.put("Accept", "*/*");
        String out = encode(Markers.appendEntries(new LinkedHashMap<>(Map.of("headers", headers))));
        assertThat(out).contains("\"Authorization\":\"***\"");   // 対象ヘッダは値ごと
        assertThat(out).contains("\"Accept\":\"*/*\"");          // 対象外は素通し
        assertThat(out).doesNotContain("Bearer secret");
    }

    @Test
    void doesNotMaskSameNameFieldOutsideHeaders() {
        // headers 直下でない同名フィールドは誤爆しない（親が headers の時のみ）
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("authorization", "top-level-not-a-header");
        String out = encode(Markers.appendEntries(fields));
        assertThat(out).contains("\"authorization\":\"top-level-not-a-header\"");
    }

    @Test
    void truncatesHeaderValueAtDecorator() {
        // headers 値も decorator で切詰（全ログ種類一律）。親が headers の値に headers 上限を適用
        LogMasker.install(Set.of(), List.of(), List.of());
        LogLengthLimiter.install(Map.of("headers", 20));
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("X-Custom", "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"); // 36B > 20B
        String out = encode(Markers.appendEntries(new LinkedHashMap<>(Map.of("headers", headers))));
        assertThat(out).contains("...(truncated)");
        assertThat(out).doesNotContain("UVWXYZ");
    }

    @Test
    void truncatesMessageField() {
        // message も decorator で切詰（MessageJsonProvider 経由でも getCurrentName()="message" で効く）
        LogMasker.install(Set.of(), List.of(), List.of());
        LogLengthLimiter.install(Map.of("message", 2));
        String out = encode(Markers.appendEntries(new LinkedHashMap<>())); // event message="msg"
        assertThat(out).contains("\"message\":\"ms\"");  // 3B→2B 素切り（上限<サフィックス長）
    }

    @Test
    void masksThenTruncatesInOrder() {
        // マスク→切詰の順：先にマスクされた値に対して切詰が掛かる
        LogMasker.install(Set.of(), List.of(), List.of());
        LogLengthLimiter.install(Map.of("body", 20));
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("body", "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"); // 36B > 20B
        String out = encode(Markers.appendEntries(fields));
        assertThat(out).contains("...(truncated)");
        assertThat(out).doesNotContain("UVWXYZ");
    }

    @Test
    void masksBodyStringKeysAndValuePatterns() {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("body", "{\"password\":\"p@ss\",\"id\":\"1\"}");
        fields.put("memo", "連絡先 taro@example.com まで");
        String out = encode(Markers.appendEntries(fields));
        assertThat(out).doesNotContain("p@ss");              // body 内キー password の値
        assertThat(out).doesNotContain("taro@example.com");  // 値パターン（メール）
        assertThat(out).contains("***").contains("\\\"id\\\":\\\"1\\\""); // 対象外はそのまま
    }
}
