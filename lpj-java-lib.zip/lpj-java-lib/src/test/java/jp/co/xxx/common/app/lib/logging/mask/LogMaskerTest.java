package jp.co.xxx.common.app.lib.logging.mask;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Test;

import jp.co.xxx.common.app.lib.logging.LoggingProperties;

/**
 * マスキング（{@link LogMasker}）と出力長制限（{@link LogLengthLimiter}）の静的・純粋ロジック、
 * および {@link LoggingProperties#install()} による yml→静的フィールド橋渡しを検証する。
 */
class LogMaskerTest {

    @Test
    void masksConfiguredHeadersCaseInsensitively() {
        Map<String, String> out = LogMasker.maskHeaders(
                Map.of("Authorization", "Bearer x", "Accept", "*/*"), Set.of("authorization", "cookie"));
        assertThat(out.get("Authorization")).isEqualTo("***");
        assertThat(out.get("Accept")).isEqualTo("*/*");
    }

    @Test
    void masksJsonBodyKeys() {
        String out = LogMasker.maskKeys(
                "{\"id\":\"1\",\"password\":\"p@ss\",\"token\":\"abc\"}", List.of("password", "token"), List.of());
        assertThat(out).contains("\"password\":\"***\"").contains("\"token\":\"***\"").contains("\"id\":\"1\"");
    }

    @Test
    void masksNonStringJsonValues() {
        // 数値/真偽 の値もマスクされる（従来は文字列値しか伏せられず漏れていた）。
        String out = LogMasker.maskKeys(
                "{\"id\":1,\"password\":12345,\"token\":true,\"note\":\"x\"}", List.of("password", "token"), List.of());
        assertThat(out)
                .contains("\"password\":***")
                .contains("\"token\":***")
                .contains("\"id\":1")        // マスク対象外キーはそのまま
                .contains("\"note\":\"x\"");
    }

    @Test
    void appliesValuePatterns() {
        // 値パターン（opt-in）。メールアドレスを正規表現で伏せる。
        String out = LogMasker.maskKeys("{\"memo\":\"連絡先 taro@example.com まで\"}",
                List.of("password"), List.of(Pattern.compile("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}")));
        assertThat(out).contains("連絡先 *** まで").doesNotContain("taro@example.com");
    }

    @Test
    void valuePatternsDisabledWhenEmpty() {
        // パターン未指定なら本文の値はそのまま＝誤爆しない。
        assertThat(LogMasker.maskKeys("{\"memo\":\"taro@example.com\"}", List.of("password"), List.of()))
                .contains("taro@example.com");
    }

    @Test
    void masksUrlQueryValues() {
        assertThat(LogMasker.maskUrlKeys("GET /login?token=secret&id=1", List.of("token")))
                .isEqualTo("GET /login?token=***&id=1");
    }

    @Test
    void masksPiiKeyValueText() {
        assertThat(LogMasker.maskKeys("login password=secret done", List.of("password"), List.of()))
                .contains("password=***").doesNotContain("secret");
    }

    @Test
    void truncatesOverMaxBytes() {
        String out = LogLengthLimiter.truncate("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 40);
        assertThat(out).endsWith("(truncated)").startsWith("0123456789");
        assertThat(out.getBytes(StandardCharsets.UTF_8).length).isLessThanOrEqualTo(40);
    }

    @Test
    void truncatesByByteNotCharForMultibyte() {
        // 日本語(UTF-8 3byte)。文字数でなくバイトで切れること（境界で割れない）。
        String out = LogLengthLimiter.truncate("あ".repeat(30), 40); // 90byte > 40
        assertThat(out).endsWith("(truncated)");
        assertThat(out.getBytes(StandardCharsets.UTF_8).length).isLessThanOrEqualTo(40);
    }

    @Test
    void nullSafe() {
        assertThat(LogMasker.maskHeaders(null, Set.of())).isNull();
        assertThat(LogMasker.maskKeys(null, List.of(), List.of())).isNull();
        assertThat(LogMasker.maskUrlKeys(null, List.of())).isNull();
        assertThat(LogLengthLimiter.truncate(null, 10)).isNull();
    }

    @Test
    void installPublishesYmlRulesAndLimitsToStatics() {
        // yml(LoggingProperties)→ LogMasker / LogLengthLimiter の静的フィールドへの橋渡し。
        LoggingProperties props = new LoggingProperties();
        props.getMask().setHeaderNames(List.of("Authorization"));
        props.getMask().setBodyKeys(List.of("password"));
        props.install();
        assertThat(LogMasker.headerLower()).contains("authorization"); // 小文字化して公開
        assertThat(LogMasker.bodyKeys()).contains("password");
        assertThat(LogLengthLimiter.limitFor("message")).isEqualTo(768); // limits 既定値
        assertThat(LogLengthLimiter.limitFor("body")).isEqualTo(1024);
    }
}
