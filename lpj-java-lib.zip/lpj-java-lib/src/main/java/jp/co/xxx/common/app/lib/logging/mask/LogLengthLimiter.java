package jp.co.xxx.common.app.lib.logging.mask;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import com.fasterxml.jackson.core.JsonStreamContext;

import net.logstash.logback.mask.ValueMasker;

import jp.co.xxx.common.app.lib.logging.LogFields;

/**
 * 出力長制限部品（appender 層）。logstash の {@link ValueMasker} として、各文字列値を yml 由来の
 * フィールド別バイト上限で切り詰める。ログ1行を 4KB 以内に収めるための部品。
 *
 * <p><b>マスキング（{@link LogMasker}）の後に動く前提</b>。{@code MaskingJsonGeneratorDecorator} は valueMasker を
 * 登録順に直列適用するため、{@code <valueMasker>} を「{@link LogMasker} → 本クラス」の順に並べる。受け取る値は
 * 既にマスク済みなので構造を壊さず安全に切れる（先に切るとマスク漏れの恐れ）。マスキングは本クラスを知らない＝
 * 依存は出力長制限→マスキングの一方向（実体は decorator の直列適用で担保）。
 *
 * <p>logback が config 時に no-arg で生成するため、上限は {@link jp.co.xxx.common.app.lib.logging.LoggingProperties} が
 * 起動時に静的フィールドへ {@link #install} する。未登録フィールドは切らない。
 */
public class LogLengthLimiter implements ValueMasker {

    private static final String TRUNCATED_SUFFIX = "...(truncated)";

    /** フィールド名 → UTF-8 バイト上限。未登録は切詰対象外。 */
    private static volatile Map<String, Integer> limits = Map.of();

    /** 起動時に yml 由来の上限を充填する。 */
    public static void install(Map<String, Integer> fieldLimits) {
        limits = Map.copyOf(fieldLimits);
    }

    /** フィールド名に対応する UTF-8 バイト上限。未登録・null は {@code -1}（対象外）。 */
    public static int limitFor(String fieldName) {
        if (fieldName == null) {
            return -1;
        }
        Integer v = limits.get(fieldName);
        return v == null ? -1 : v;
    }

    @Override
    public Object mask(JsonStreamContext context, Object value) {
        if (value instanceof CharSequence cs) {
            String s = cs.toString();
            int limit = limitFor(context);
            if (limit > 0) {
                String truncated = truncate(s, limit);
                if (!s.equals(truncated)) {
                    return truncated;
                }
            }
        }
        return null;
    }

    /**
     * 書き出し中フィールドに適用する上限。フィールド名に直接上限があればそれ。無ければ
     * {@code headers} オブジェクト直下の値かを親 context で判定し headers 上限を適用する
     * （ヘッダは項目名がログ種類で異なるため、親が {@code headers} かどうかで一律に扱う）。
     */
    private static int limitFor(JsonStreamContext context) {
        if (context == null) {
            return -1;
        }
        int byName = limitFor(context.getCurrentName());
        if (byName > 0) {
            return byName;
        }
        JsonStreamContext parent = context.getParent();
        if (parent != null && LogFields.HEADERS.equals(parent.getCurrentName())) {
            return limitFor(LogFields.HEADERS); // headers 直下の値
        }
        return -1;
    }

    /**
     * 最大<b>バイト数</b>(UTF-8)で切り詰める。超過時は切り詰め後に {@code ...(truncated)} を付け、
     * サフィックス込みで max バイト以内に収める（マルチバイト文字はコードポイント境界で切る）。
     */
    public static String truncate(String s, int maxBytes) {
        if (s == null) {
            return null;
        }
        if (s.getBytes(StandardCharsets.UTF_8).length <= maxBytes) {
            return s;
        }
        int suffixBytes = TRUNCATED_SUFFIX.getBytes(StandardCharsets.UTF_8).length;
        // max がサフィックス長以下なら、サフィックスを付けず本文を max バイトまで素切り（出力が max を超えないように）。
        boolean withSuffix = maxBytes > suffixBytes;
        int budget = withSuffix ? maxBytes - suffixBytes : maxBytes;
        StringBuilder sb = new StringBuilder();
        int used = 0;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            int bw = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8).length;
            if (used + bw > budget) {
                break;
            }
            sb.appendCodePoint(cp);
            used += bw;
            i += Character.charCount(cp);
        }
        return withSuffix ? sb + TRUNCATED_SUFFIX : sb.toString();
    }
}
