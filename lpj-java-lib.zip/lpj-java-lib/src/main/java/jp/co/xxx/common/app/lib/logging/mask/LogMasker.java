package jp.co.xxx.common.app.lib.logging.mask;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.fasterxml.jackson.core.JsonStreamContext;

import net.logstash.logback.mask.FieldMasker;
import net.logstash.logback.mask.ValueMasker;

import jp.co.xxx.common.app.lib.logging.LogFields;

/**
 * マスキング部品（appender 層）。logstash の {@link ValueMasker}（値）と {@link FieldMasker}（ヘッダ名）の
 * 両口を1クラスで実装し、yml 由来の規則で JSON 書き出し時に機密を {@code ***} へ伏せる（全ロガー横断）。
 *
 * <p>出力長制限（{@link LogLengthLimiter}）とは独立。{@code MaskingJsonGeneratorDecorator} は valueMasker を
 * 登録順に直列適用するため、{@code <valueMasker>} を「本クラス → {@link LogLengthLimiter}」の順に並べることで
 * 「マスク→切詰」が成立する（本クラスは切詰を知らない）。
 *
 * <p>logback が config 時に no-arg で生成するため Bean を DI できない。規則は
 * {@link jp.co.xxx.common.app.lib.logging.LoggingProperties} が起動時に静的フィールドへ {@link #install} する
 * （masker は実行時に静的参照）。{@code install} 前＝既定は空＝何も伏せない。
 */
public class LogMasker implements ValueMasker, FieldMasker {

    /** マスク後の値。 */
    public static final String MASK = "***";

    private static volatile Set<String> headerLower = Set.of();
    private static volatile List<String> bodyKeys = List.of();
    private static volatile List<Pattern> bodyPatterns = List.of();

    /** 起動時に yml 由来の規則を充填する。 */
    public static void install(Set<String> headerLowerNames, List<String> keys, List<Pattern> patterns) {
        headerLower = Set.copyOf(headerLowerNames);
        bodyKeys = List.copyOf(keys);
        bodyPatterns = List.copyOf(patterns);
    }

    /** マスク対象ヘッダー名（小文字）。 */
    public static Set<String> headerLower() {
        return headerLower;
    }

    /** マスク対象ボディ/引数キー。 */
    public static List<String> bodyKeys() {
        return bodyKeys;
    }

    /** 値パターン（事前コンパイル済み）。 */
    public static List<Pattern> bodyPatterns() {
        return bodyPatterns;
    }

    /** 値マスク：全文字列値にキー名／値パターンマスクを適用（無変化は null で素通し）。 */
    @Override
    public Object mask(JsonStreamContext context, Object value) {
        if (value instanceof CharSequence cs) {
            String original = cs.toString();
            String masked = maskKeys(original, bodyKeys, bodyPatterns);
            if (!original.equals(masked)) {
                return masked;
            }
        }
        return null;
    }

    /** ヘッダ名マスク：{@code headers} オブジェクト直下の、yml 指定ヘッダー名の値を伏せる。 */
    @Override
    public Object mask(JsonStreamContext context) {
        String name = context.getCurrentName();
        if (name == null) {
            return null;
        }
        JsonStreamContext parent = context.getParent();
        if (parent == null || !LogFields.HEADERS.equals(parent.getCurrentName())) {
            return null; // headers 直下以外は対象外（MDC 等の同名フィールド誤爆を防ぐ）
        }
        if (headerLower.contains(name.toLowerCase(Locale.ROOT))) {
            return MASK;
        }
        return null;
    }

    // ---- 純粋・静的ロジック（テストが直接利用する） ----

    /** マスク対象ヘッダー（小文字集合）を値ごと伏せる。 */
    static Map<String, String> maskHeaders(Map<String, String> headers, Set<String> maskLower) {
        if (headers == null) {
            return null;
        }
        Map<String, String> out = new LinkedHashMap<>();
        headers.forEach((k, v) -> out.put(k, maskLower.contains(k.toLowerCase(Locale.ROOT)) ? MASK : v));
        return out;
    }

    /** テキストへ (1)キー名ベース (2)値パターンベース のマスクを適用する。 */
    static String maskKeys(String text, List<String> keys, List<Pattern> patterns) {
        if (text == null) {
            return null;
        }
        String masked = text;
        // (1) キー名ベース（キー名は大小文字を無視＝(?i)）
        for (String key : keys) {
            String q = Pattern.quote(key);
            // "key":"value"（文字列値。エスケープ \" を含む値も末尾まで）
            masked = masked.replaceAll("(?i)(\"" + q + "\"\\s*:\\s*\")(?:\\\\.|[^\"\\\\])*(\")", "$1" + MASK + "$2");
            // "key":123 / true / false / null（非文字列の**スカラ**値のみ。オブジェクト/配列値は対象外＝JSON を壊さない）
            masked = masked.replaceAll("(?i)(\"" + q + "\"\\s*:\\s*)(?:-?\\d[\\d.eE+-]*|true|false|null)", "$1" + MASK);
            // key=value（クエリ/フォーム/フリーテキスト形式）
            masked = masked.replaceAll("(?i)(" + q + "\\s*=\\s*)[^,&;\\s)}]+", "$1" + MASK);
        }
        // (2) 値パターンベース
        for (Pattern p : patterns) {
            masked = p.matcher(masked).replaceAll(Matcher.quoteReplacement(MASK));
        }
        return masked;
    }

    /** URL クエリ（?key=value / &key=value）のマスク対象キーの値を伏せる。 */
    static String maskUrlKeys(String url, List<String> keys) {
        if (url == null) {
            return null;
        }
        String masked = url;
        for (String key : keys) {
            masked = masked.replaceAll("([?&]" + Pattern.quote(key) + "=)[^&\\s]*", "$1" + MASK);
        }
        return masked;
    }
}
