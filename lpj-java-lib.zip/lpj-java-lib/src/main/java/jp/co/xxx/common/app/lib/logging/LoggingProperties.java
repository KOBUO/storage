package jp.co.xxx.common.app.lib.logging;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.logging.mask.LogLengthLimiter;
import jp.co.xxx.common.app.lib.logging.mask.LogMasker;

import jakarta.annotation.PostConstruct;

/**
 * ログ部品の設定保持部品。application.yml の {@code cosmo-app.logging.*} をバインドし、起動時に
 * マスキング／出力長制限の各部品へ規則・上限を渡す。
 *
 * <ul>
 *   <li>{@code mask.*} … マスク対象（header名/body-key/値パターン）。「指定したものだけマスク」＝<b>既定は空</b>。</li>
 *   <li>{@code limits.*} … フィールド別の出力長上限（UTF-8 バイト）。1行を 4KB 以内に収めるための値。
 *       未指定時は各フィールドのデフォルトで動く。</li>
 * </ul>
 *
 * <p>logback の masker（{@link LogMasker}／{@link LogLengthLimiter}）は config 時に no-arg 生成され Bean を
 * DI できないため、{@link #install()} で各クラスの静的フィールドへ充填する（masker は実行時に静的参照）。
 */
@Component
@ConfigurationProperties(prefix = "cosmo-app.logging")
public class LoggingProperties {

    private final Mask mask = new Mask();
    private final Limits limits = new Limits();

    public Mask getMask() {
        return mask;
    }

    public Limits getLimits() {
        return limits;
    }

    /**
     * 起動時に yml 由来の規則・上限を {@link LogMasker}／{@link LogLengthLimiter} の静的フィールドへ充填する。
     * Spring がライフサイクルで呼ぶ（テストの素の new では発火しないため、テストは本メソッドを直接呼ぶ）。
     */
    @PostConstruct
    public void install() {
        Set<String> headerLower = mask.getHeaderNames().stream()
                .map(s -> s.toLowerCase(Locale.ROOT)).collect(Collectors.toSet());
        List<Pattern> patterns = mask.getBodyPatterns().stream().map(Pattern::compile).toList();
        LogMasker.install(headerLower, List.copyOf(mask.getBodyKeys()), patterns);

        Map<String, Integer> fieldLimits = new LinkedHashMap<>();
        fieldLimits.put("message", limits.getMessage());
        fieldLimits.put("body", limits.getBody());
        fieldLimits.put("result", limits.getResult());
        fieldLimits.put("args", limits.getResult()); // args は result と同上限
        fieldLimits.put(LogFields.HEADERS, limits.getHeaders());
        LogLengthLimiter.install(fieldLimits);
    }

    /** マスク対象（{@code cosmo-app.logging.mask.*}）。既定は空＝何もマスクしない。 */
    public static class Mask {

        /** マスク対象ヘッダー名（小文字比較）。 */
        private List<String> headerNames = new ArrayList<>();
        /** マスク対象ボディ/引数キー（値を {@code ***} に）。 */
        private List<String> bodyKeys = new ArrayList<>();
        /** 値パターンマスク（正規表現）。キーに紐づかない PII を本文から伏せる opt-in。既定は空。 */
        private List<String> bodyPatterns = new ArrayList<>();

        public List<String> getHeaderNames() {
            return headerNames;
        }

        public void setHeaderNames(List<String> headerNames) {
            this.headerNames = headerNames;
        }

        public List<String> getBodyKeys() {
            return bodyKeys;
        }

        public void setBodyKeys(List<String> bodyKeys) {
            this.bodyKeys = bodyKeys;
        }

        public List<String> getBodyPatterns() {
            return bodyPatterns;
        }

        public void setBodyPatterns(List<String> bodyPatterns) {
            this.bodyPatterns = bodyPatterns;
        }
    }

    /**
     * フィールド別の出力長上限（UTF-8 バイト、{@code cosmo-app.logging.limits.*}）。
     * デフォルトはエンベロープ約 700B を見込み、種類別の最悪合計が 4096B 以内になるよう配分している
     * （{@code stack_trace} と {@code body}/{@code result}/{@code headers} は同一行に共存しないため和で 4KB を保証）。
     */
    public static class Limits {

        /** {@code message} 上限。マスク後にマスカ層で切詰。 */
        private int message = 768;
        /** {@code body} 上限。マスク後にマスカ層で切詰。 */
        private int body = 1024;
        /** {@code result}/{@code args} 上限。マスク後にマスカ層で切詰。 */
        private int result = 1024;
        /** {@code headers} 上限。マーカー生成時（フィルタ層）に切詰。 */
        private int headers = 512;
        /** {@code stack_trace} 上限。{@code ShortenedThrowableConverter} の {@code maxLength} へ注入。 */
        private int stackTrace = 2560;

        public int getMessage() {
            return message;
        }

        public void setMessage(int message) {
            this.message = message;
        }

        public int getBody() {
            return body;
        }

        public void setBody(int body) {
            this.body = body;
        }

        public int getResult() {
            return result;
        }

        public void setResult(int result) {
            this.result = result;
        }

        public int getHeaders() {
            return headers;
        }

        public void setHeaders(int headers) {
            this.headers = headers;
        }

        public int getStackTrace() {
            return stackTrace;
        }

        public void setStackTrace(int stackTrace) {
            this.stackTrace = stackTrace;
        }
    }
}
