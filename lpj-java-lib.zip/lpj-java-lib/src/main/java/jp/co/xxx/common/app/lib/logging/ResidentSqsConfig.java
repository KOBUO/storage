package jp.co.xxx.common.app.lib.logging;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.awspring.cloud.sqs.config.SqsMessageListenerContainerFactory;

import software.amazon.awssdk.services.sqs.SqsAsyncClient;

/**
 * 常駐バッチ（@SqsListener）のリスナーコンテナファクトリを上書きし、
 * 共通の {@link SqsReceiveJournalInterceptor} を全リスナーに適用する。
 *
 * <p>既定の {@code defaultSqsListenerContainerFactory} を置き換える（@SqsListener が既定で使う Bean 名）。
 * {@code SqsAsyncClient} は Spring Cloud AWS の自動構成（ローカルは ElasticMQ エンドポイント）をそのまま使う。
 *
 * <p>有効/無効は **ライブラリ固有プロパティ `cosmo-app.logging.sqs.enabled`**（既定 false／opt-in）で制御。
 * アプリの `app.mode` 規約には依存しない（＝ライブラリとして自己完結）。@SqsListener が無ければ
 * このファクトリは生成されるだけで何も起動しない。
 *
 * <p><b>注意</b>: アプリ側が独自に {@code SqsMessageListenerContainerFactory} を定義すると本ファクトリが
 * 置き換わり {@link SqsReceiveJournalInterceptor} が登録されず受信ログが出なくなる。その場合は自作ファクトリ
 * にも {@code SqsReceiveJournalInterceptor}（Bean）を {@code messageInterceptor(...)} で追加すること。
 */
@Configuration
@ConditionalOnProperty(prefix = "cosmo-app.logging.sqs", name = "enabled", havingValue = "true", matchIfMissing = false)
public class ResidentSqsConfig {

    // 既存(ブラックボックス)部品が独自にファクトリを定義していれば、そちらに譲る（競合回避）。
    // その場合、ジャーナル interceptor は既存ファクトリ側で messageInterceptor(...) 追加が必要。
    @Bean
    @ConditionalOnMissingBean(SqsMessageListenerContainerFactory.class)
    SqsMessageListenerContainerFactory<Object> defaultSqsListenerContainerFactory(
            SqsAsyncClient sqsAsyncClient, SqsReceiveJournalInterceptor interceptor) {
        return SqsMessageListenerContainerFactory.<Object>builder()
                .sqsAsyncClient(sqsAsyncClient)
                .messageInterceptor(interceptor)
                .build();
    }
}
