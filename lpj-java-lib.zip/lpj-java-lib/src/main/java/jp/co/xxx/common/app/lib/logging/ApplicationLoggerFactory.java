package jp.co.xxx.common.app.lib.logging;

/**
 * {@link ApplicationLogger} の取得口（slf4j の {@code LoggerFactory} に倣った作法）。
 *
 * <pre>{@code
 * private static final ApplicationLogger log = ApplicationLoggerFactory.getLogger();
 * log.info("...");
 * }</pre>
 *
 * <p>{@link ApplicationLogger} は状態を持たず（マスク・最大長は appender 層）、出力先は固定ロガー名
 * （API_LOG/ERROR_LOG）なので呼び出し元ごとに差が無い。よって <b>常に同一インスタンス（シングルトン）</b>を返す。
 * slf4j と違いクラス別インスタンスは不要（class_name/method_name は ClassMethodJsonProvider が呼び出し元スタックから付与）。
 * DI を介さないため、コンポーネント・非コンポーネントを問わずどこからでも取得できる。
 */
public final class ApplicationLoggerFactory {

    private static final ApplicationLogger INSTANCE = new ApplicationLogger();

    private ApplicationLoggerFactory() {
    }

    /** 共有の {@link ApplicationLogger}（シングルトン）を返す。 */
    public static ApplicationLogger getLogger() {
        return INSTANCE;
    }
}
