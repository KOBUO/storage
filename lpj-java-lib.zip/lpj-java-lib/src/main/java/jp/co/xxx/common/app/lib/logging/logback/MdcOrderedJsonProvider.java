package jp.co.xxx.common.app.lib.logging.logback;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * MDC 項目を出力するプロバイダークラス。
 * appender 定義で列挙した順・項目名で出力し、列挙したキー以外は出力しない。
 */
public class MdcOrderedJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    // appender 定義の列挙順を保持する出力エントリのリスト（[0]=MDC取得キー / [1]=出力名）
    private volatile List<String[]> entries = List.of();

    /**
     * 出力エントリを1件追加する。
     * {@code <includeMdcKeyName>name</includeMdcKeyName>}：取得キー＝出力名。
     *
     * @param name MDC 取得キー兼出力名（{@code null}・空白は無視）
     */
    public void addIncludeMdcKeyName(String name) {
        if (name != null && !name.isBlank()) {
            String n = name.trim();
            append(new String[] {n, n});
        }
    }

    /**
     * 出力エントリを1件追加する。
     * {@code <entry>取得キー:出力名</entry>}：取得キーと出力名を分離。
     * {@code :} 無しは取得キー＝出力名として扱う。
     *
     * @param spec 「取得キー:出力名」形式の指定（{@code null}・空白は無視）
     */
    public void addEntry(String spec) {
        if (spec == null || spec.isBlank()) {
            return;
        }
        int i = spec.indexOf(':');
        if (i < 0) {
            addIncludeMdcKeyName(spec);
        } else {
            append(new String[] {spec.substring(0, i).trim(), spec.substring(i + 1).trim()});
        }
    }

    /**
     * エントリを1件追加する。
     * 出力スレッドと安全に共有するため、リストを作り直して入れ替える。
     *
     * @param entry [0]=取得キー / [1]=出力名 の2要素配列
     */
    private void append(String[] entry) {
        List<String[]> next = new ArrayList<>(entries);
        next.add(entry);
        entries = List.copyOf(next);
    }

    /**
     * 列挙したエントリの順に、MDC 値を出力名で JSON へ書き出す。
     * 値が無ければ "null" を出力する。
     *
     * @param generator 出力先の JSON ジェネレータ
     * @param event ログイベント（MDC の取得元）
     */
    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        Map<String, String> mdc = event.getMDCPropertyMap();
        for (String[] e : entries) {
            String value = mdc.get(e[0]);
            generator.writeStringField(e[1], value != null ? value : "null");
        }
    }
}
