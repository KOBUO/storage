package jp.co.xxx.common.app.lib.logging.logback;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

import jp.co.xxx.common.app.lib.logging.LogFields;

/**
 * ログ発生元の クラス名 / メソッド名 を出力するプロバイダークラス。
 * 呼び出し元スタックから中継クラス（{@code SKIP_FACADE_PREFIXES}）を除外し、最初の業務クラスを発生元とする。
 */
public class ClassMethodJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    // 発生元判定で除外する中継クラスのリスト
    private static final List<String> SKIP_FACADE_PREFIXES = List.of(
            "jp.co.xxx.common.app.lib.logging.ApplicationLogger",
            "jp.co.xxx.xxx.app.lib.logging.JournalLogger",
            "jp.co.xxx.xxx.app.lib.logging.ApLogger"
        );

    /**
     * 発生元の クラス名 / メソッド名 を JSON に書き出す。
     * 取得できなければ、クラス名 / メソッド名の値に "null" を設定する。
     *
     * @param generator 出力先の JSON ジェネレータ
     * @param event ログイベント（呼び出し元スタックの取得元）
     */
    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        StackTraceElement target = findTargetFrame(event.getCallerData());
        generator.writeStringField(LogFields.CLASS_NAME, target != null ? target.getClassName() : "null");
        generator.writeStringField(LogFields.METHOD_NAME, target != null ? target.getMethodName() : "null");
    }

    /**
     * 呼び出し元スタックから発生元のフレームを探す。
     * 先頭から順に見て、中継クラス（{@link #SKIP_FACADE_PREFIXES}）を除外し、最初に現れた業務クラスを発生元とする。
     *
     * @param caller {@link org.slf4j.Logger} を呼び出した側のスタックフレーム（先頭が直近の呼び出し元）
     * @return 中継クラスでない最初のフレーム＝発生元。見つからなければ {@code null}
     */
    private static StackTraceElement findTargetFrame(StackTraceElement[] caller) {
        if (caller == null) {
            return null;
        }
        for (StackTraceElement e : caller) {
            if (!isFacade(e.getClassName())) {
                return e;
            }
        }
        return null;
    }

    /**
     * 除外する中継クラスかを判定する。
     *
     * @param className 判定するクラスの FQCN
     * @return {@link #SKIP_FACADE_PREFIXES} のいずれかの接頭辞で始まれば {@code true}
     */
    private static boolean isFacade(String className) {
        for (String prefix : SKIP_FACADE_PREFIXES) {
            if (className.startsWith(prefix)) {
                return true;
            }
        }
        return false;
    }
}
