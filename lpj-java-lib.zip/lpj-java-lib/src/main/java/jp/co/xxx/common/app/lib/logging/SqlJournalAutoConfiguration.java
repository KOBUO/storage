package jp.co.xxx.common.app.lib.logging;

import org.mybatis.spring.boot.autoconfigure.ConfigurationCustomizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * {@link SqlJournalInterceptor} の自動設定。
 * {@code cosmo-app.logging.sql.enabled=true} のとき、本インターセプターを MyBatis に登録する。
 * {@code cosmo-app.logging.sql.error-only=true} なら例外時のみ出力する（既定は全 SQL）。
 */
@Configuration
@ConditionalOnProperty(prefix = "cosmo-app.logging.sql", name = "enabled", havingValue = "true", matchIfMissing = false)
public class SqlJournalAutoConfiguration {

    /**
     * SQLジャーナルログのインターセプターを MyBatis の設定へ登録する。
     * 起動時に呼ばれ、{@link SqlJournalInterceptor} を追加する。
     *
     * @param errorOnly {@code cosmo-app.logging.sql.error-only}（既定 false＝全 SQL を出力）
     * @return {@link ConfigurationCustomizer}
     */
    @Bean
    ConfigurationCustomizer sqlJournalConfigurationCustomizer(
            @Value("${cosmo-app.logging.sql.error-only:false}") boolean errorOnly) {
        return configuration -> configuration.addInterceptor(new SqlJournalInterceptor(errorOnly));
    }
}
