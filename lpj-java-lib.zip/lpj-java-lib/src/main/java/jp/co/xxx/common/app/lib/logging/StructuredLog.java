package jp.co.xxx.common.app.lib.logging;

import java.util.LinkedHashMap;
import java.util.Map;

import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;

/**
 * ログ出力1回ぶんの「その場で設定する項目」を組み立てるビルダー。
 *
 * <pre>{@code
 * logger.info(StructuredLog.create()
 *         .put(LogFields.URL, url)
 *         .put(LogFields.STATUS, status)
 *         .marker(), "message");
 * }</pre>
 *
 * 値の表現は統一方針に従う：
 * <ul>
 *   <li>数値は出力で文字列にする（{@code "latency":"43"}）。JSON の数値型は使わない。</li>
 *   <li>{@link #put} は値が無ければその項目を出力しない（持たないログ種類では自然に欠落）。</li>
 *   <li>{@link #putNullable} は値が無ければ文字列 {@code "null"} を出力する（{@code "status":"null"}）。</li>
 * </ul>
 * type / subtype は Marker では持たせず、各 appender が固定値（pattern provider）で付与する。
 */
public final class StructuredLog {

    /** 値なしを表す統一プレースホルダ（JSON null ではなく文字列）。 */
    public static final String NULL = "null";

    private final Map<String, Object> fields = new LinkedHashMap<>();

    private StructuredLog() {
    }

    public static StructuredLog create() {
        return new StructuredLog();
    }

    public StructuredLog put(String key, Object value) {
        if (value != null) {
            fields.put(key, normalize(value));
        }
        return this;
    }

    /**
     * 値が無くてもキーを出力する。値なしは文字列 {@code "null"}（{@code "key":"null"}）。
     * 前後ペア（要求/応答・開始/終了）で項目セットを揃え、片側にしか値が無い項目を
     * もう一方では {@code "null"} として出力するために使う。
     */
    public StructuredLog putNullable(String key, Object value) {
        fields.put(key, value == null ? NULL : normalize(value));
        return this;
    }

    /** 数値・真偽値は文字列化（JSON の数値型／真偽型を使わない統一方針）。Map/配列/文字列等はそのまま。 */
    private static Object normalize(Object value) {
        return (value instanceof Number || value instanceof Boolean) ? value.toString() : value;
    }

    public LogstashMarker marker() {
        return Markers.appendEntries(fields);
    }
}
