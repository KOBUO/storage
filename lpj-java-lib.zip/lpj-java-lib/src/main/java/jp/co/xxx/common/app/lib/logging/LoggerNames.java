package jp.co.xxx.common.app.lib.logging;

/**
 * ログ種類ごとの固定ロガー名。
 * Javaクラス名ではなく、logback.xml の appender 振り分けキーとして使う。
 */
public final class LoggerNames {

    /** アクセスログ：アプリ側のサマリ（誰が/どこへ/結果）。 */
    public static final String API_ACCESS = "SPRINGBOOT_API_ACCESS_LOG";
    /** アクセスジャーナルログ：要求/応答の詳細（headers/body）。 */
    public static final String API_ACCESS_JNL = "SPRINGBOOT_API_ACCESS_JNL_LOG";
    public static final String SERVICE_JNL = "SPRINGBOOT_SERVICE_JNL_LOG";
    /** ストレージアクセスジャーナル(AWSCALL)。 */
    public static final String STORAGE_JNL = "SPRINGBOOT_STORAGE_JNL_LOG";
    /** ストレージアクセスジャーナルの別ロガー名。`SPRINGBOOT_STORAGE_JNL_LOG` と同じ STORAGE appender・subtype(AWSCALL) で扱う。 */
    public static final String AWSCALL = "AWSCALL";
    public static final String HTTP_CLIENT_JNL = "SPRINGBOOT_HTTP_CLIENT_JNL_LOG";
    public static final String SQS_JNL = "SPRINGBOOT_SQS_JNL_LOG";
    /** SQLジャーナルログ。 */
    public static final String SQL_JNL = "SPRINGBOOT_SQL_JNL_LOG";
    /** KMSアクセスジャーナルログ(AWSCALL)。 */
    public static final String KMS_JNL = "SPRINGBOOT_KMS_JNL_LOG";
    /** DynamoDBアクセスジャーナルログ(AWSCALL)。 */
    public static final String DYNAMODB_JNL = "SPRINGBOOT_DYNAMODB_JNL_LOG";
    public static final String API_LOG = "SPRINGBOOT_API_LOG";
    public static final String ERROR_LOG = "SPRINGBOOT_ERROR_LOG";

    private LoggerNames() {
    }
}
