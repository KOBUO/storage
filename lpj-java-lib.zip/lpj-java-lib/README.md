# lpj-java-lib — 共通ログ出力ライブラリ（ドロップイン）

Spring Boot 4 / Spring Cloud AWS 4 系アプリ向けの **構造化ログ出力部品**一式。
依存追加＋コンポーネントスキャンに含めるだけで、アクセス/ジャーナル/業務/システムの各ログが
JSON で自動出力される「ドロップイン」設計。実装パッケージは `jp.co.xxx.common.app.lib.logging`
（`xxx` は顧客名の仮置き。合流時に実値へ置換する → 下記「2. パッケージ名の置換」）。

> **このリポジトリの位置づけ**: 単体の Gradle サブプロジェクトとして実装・検証済み。
> 最終的には **既存の共通ライブラリ（別リポジトリ）へ本ソースをドロップインで合流**させる
> （統合方針 = B）。本 README はその合流手順書を兼ねる。

---

## 1. 合流するファイル一覧（コピー対象）

> **2026-06-23 改訂**：lib は **ログ部品のみ**に整理（接続部品＝AWSアクセス/外部HTTP/バッチ起点は検証アプリへ移設、S3/SQL は logback定義のみ存置）。パッケージは `jp.co.xxx.common.app.lib.logging`、独自プロパティは `cosmo-app.*`、出力値は全て文字列（値なし"null"）、`trace_id`→`trace`。詳細は ルート `ログ設計書_ベース.md` 第3部。

| 区分 | パス | 必須 |
|---|---|---|
| 実装（ログ部品のみ） | `src/main/java/jp/co/xxx/common/app/lib/log/**` | ✅ |
| ログ設定 | `src/main/resources/logback-spring.xml` | ✅ |
| ログ設定 | `src/main/resources/logback/appender-*.xml`（12種） | ✅ |
| テスト | `src/test/java/**` | 推奨 |

`build/` は生成物なのでコピー不要。`logback-spring.xml` は `<include resource="logback/appender-*.xml"/>`
でクラスパス相対 include しているため、**`logback/` 配下を同じ相対位置に置けばそのまま動く**。

### パッケージ構成（実装＝ログ部品のみ）
```
jp.co.xxx.common.app.lib.logging
├─ ApplicationLogger / StructuredLog                         … 共通基盤
├─ LogFields / LoggerNames / MdcKeys             … 定数・列挙
├─ LoggingProperties                                         … @ConfigurationProperties(cosmo-app.logging.custom.* マスク対象)
├─ logback.{MdcOrdered,TypeSubtype,CallerData}JsonProvider … logback JSON provider（xml から FQCN 参照。CallerData=class_name/method_name）
│   ※ id/name は appender XML で環境変数 `${CONTAINER_ID:-null}` / `${CONTAINER_NAME:-null}` を直接参照（専用 provider 廃止）
├─ logback.TruncatingMessageConverter                         … message を UTF-8 byte 切詰（%truncMsg{N}・appender層）
├─ mask.LogMaskingService                                     … マスク規則エンジン（静的 maskKeys/truncate）＋yml→LogMaskRules 橋渡し
├─ mask.{LogMaskRules,ConfiguredValueMasker,ConfiguredHeaderFieldMasker} … appender層マスク（decorator に差す masker＋静的ホルダー）
├─ ApiAccessLogFilter                                         … アクセスログ/ジャーナル(サマリ/要求/応答)
└─ {ResidentSqsConfig,SqsReceiveJournalInterceptor}           … 常駐SQS(メッセージ受信ジャーナル・opt-in)
```
> 接続部品（`web.*` 外部HTTP / `aws.{Kms,DynamoDb,Sqs}AccessService` / `scope.batch.BatchLogScope`）は
> 検証アプリ(tranning `com.example.cosmolog.*`)へ移設済み。本番では既存部品が担う。
> `mybatis.SqlJournalInterceptor`（SQL）・S3 出力部品は廃止（logback定義のみ存置）。

---

## 2. パッケージ名の置換（`xxx` → 実値）

合流先の名前空間に合わせ、**`jp.co.xxx.common.app.lib.logging` を実際の名前空間へ一括置換**する。
影響範囲は src 配下の全 java/xml（`jp.co.xxx` 文字列を含むのは 47 箇所）＋ディレクトリパス＋下記。

置換が必要な箇所（漏れやすい順）:
1. **ソースのパッケージ宣言・import**（`jp.co.xxx.common.app.lib.logging...`）
2. **ディレクトリ階層** `src/.../java/jp/co/xxx/...`（IDE のパッケージリネームで一括）
3. **logback xml の provider FQCN**（文字列参照のため IDE リネームに追従しない・要手動）:
   - `jp.co.xxx.common.app.lib.logging.logback.MdcOrderedJsonProvider`
4. **build の `group`**（`jp.co.xxx.common.app`）

> IDE を使わない場合の目安: `jp.co.xxx`（ドット）と `jp/co/xxx`（パス）の2系統を置換し、
> ディレクトリを `git mv` で移動。置換後に `appender-*.xml` の FQCN を grep で再確認すること。

---

## 3. 合流先ビルドに必要な依存

合流先（既存共通ライブラリ）の build に以下が無ければ追加する。バージョンは BOM 管理を推奨。

**BOM（バージョン整合）**
- `org.springframework.boot:spring-boot-dependencies:4.0.6`
- `io.awspring.cloud:spring-cloud-aws-dependencies:4.0.2`

**実装（lib＝ログ部品のみ。`api`/`implementation` は合流先の方針に合わせる）**
| 依存 | 用途 |
|---|---|
| `spring-boot-starter-web` | Filter / HandlerMapping / jakarta.servlet（APIアクセスログ） |
| `net.logstash.logback:logstash-logback-encoder:8.1` | JSON ログ provider（logback-classic を内包） |
| `io.awspring.cloud:spring-cloud-aws-starter-sqs` | `@SqsListener` / `MessageInterceptor`（SQS常駐ログ） |
| `software.amazon.awssdk:sqs` | `ResidentSqsConfig`(SqsAsyncClient型) |

> 接続部品を移設したため、**lib は `awssdk:s3` / `:kms` / `:dynamodb` / `mybatis` / `h2` を必要としない**
> （それらは検証アプリ tranning 側の依存）。

**注釈処理**
- `spring-boot-configuration-processor`（`LoggingProperties` の設定メタデータ生成。任意）

**テスト**
- `spring-boot-starter-test` / `org.junit.platform:junit-platform-launcher`

---

## 4. 有効化（配線）

### 4-1. コンポーネントスキャン
アプリの起点が lib パッケージを **スキャン対象に含める**こと。
```java
@SpringBootApplication(scanBasePackages = {"<アプリのbase>", "jp.co.<実値>.common.app.lib.log"})
```
※ lib パッケージがアプリの base package 配下にあるなら追記不要。

### 4-2. logback
`logback-spring.xml` をクラスパス先頭に置く（合流先に既存の logback がある場合は
`appender-*.xml` を取り込むか、provider 定義をマージする）。

### 4-3. プロパティ（application.yml）
独自プロパティは `cosmo-app.*` 配下。**マスク対象は yml で指定**（指定したものだけマスク・既定空）。マスク/message切詰は **appender 層（decorator＋`%truncMsg`）で全ロガー一律**に適用（呼出側は生ログ＝素 slf4j/root も対象）。最大長(message=4KB) は appender XML `%truncMsg{4096}`（converter 既定定数4096）、発生元の除外facade は lib のコード定数（合流時に `TODO【仮値】` を確定。**body は上限なし**）。
```yaml
cosmo-app:
  logging:
    custom:                  # LoggingProperties にバインド（マスク対象）
      mask-header-names: [authorization, cookie]
      mask-body-keys: [password, secret, token]
      mask-body-patterns: []   # 値パターンマスク（正規表現）。opt-in
  lpj:
    logging:
      sqs:
        enabled: true        # 常駐SQSログ部品を有効化（既定 false／opt-in・matchIfMissing=false。未指定なら無効）
```

> **発生元(class_name/method_name)**：appender の `CallerDataJsonProvider` が caller data（logger を呼んだ場所）から付与する。素通しfacade(`ApplicationLogger`)だけ飛ばし、それ以外（業務/アスペクト/フィルタ/各アクセス部品）はその出力元が入る。合流先に独自のログ**facadeクラス**（業務→既存facade→logger）がある場合は `CallerDataJsonProvider` の定数 `EXTRA_FACADE_PREFIXES` にそのFQCN接頭辞を足して除外する（合流時編集）。**既存部品が業務クラスで直接ロガーを呼ぶ場合は設定不要。** facadeの有無/実パッケージは合流時に確定（**TODO【合流時設定】**・`ログ設計書_ベース.md` 3-3）。

---

## 5. ドロップインの効き方（自動 vs 呼び出し側依存）

| 種別 | 部品 | 有効化 |
|---|---|---|
| **自動**（scan で差し込み） | ApiAccessLogFilter / 各 JsonProvider（SqsReceiveJournalInterceptor は opt-in） | アプリは何も書かなくてよい |
| **呼び出し側依存** | `ApplicationLogger`（業務ログ / 業務エラー） | 開発者が明示的に呼ぶ。呼ばなければ業務ログは出ない（＝それ以外のログは出る） |

> 外部HTTP(HttpClientJournalInterceptor)・SQL(SqlJournalInterceptor)・AWSアクセスの出力部品は **lib から除外**（検証アプリへ移設/廃止）。本番は既存部品が担い、lib は **MDC を供給し logback 定義を提供**する。

### 条件付き Bean（合流時の競合に注意）
- `RestClientConfig`: `@ConditionalOnMissingBean(RestTemplate.class)` … アプリ側に RestTemplate があればそちらを尊重。
- `ResidentSqsConfig` / `SqsReceiveJournalInterceptor`: `@ConditionalOnProperty(cosmo-app.logging.sqs.enabled, 既定true)`。
  **アプリが独自に `SqsMessageListenerContainerFactory` を定義すると本部品が無効化される** → その場合は自作
  ファクトリにも `SqsReceiveJournalInterceptor` を `messageInterceptor(...)` で追加すること（詳細は `ログ設計書_ベース.md` 第2部「常駐SQS共通ログ部品」の注意書き）。

---

## 6. 合流時の注意点

- **logback の provider FQCN** はリネーム時に追従しないので必ず手動確認（`appender-*.xml` の `<provider class="...">`、特に `CallerDataJsonProvider`）。
- `ApplicationLogger` を呼ぶ業務コードは lib に依存する（呼び出し箇所は lib 無しではコンパイル不可）。
  これが唯一「実装と分離できない」結合点。
- lib 本体は `com.example`（検証アプリ）に一切依存しない（確認済み）。`cosmo-app.app.mode` にも非依存。

---

## 7. 検証状況

3モード（API/単発/常駐）＋ AWS（KMS/DynamoDB）＋ SQS（ElasticMQ）を実機検証済み。
単体/結合テスト パス。詳細はルートの設計書（`ログ設計書_ベース.md`（第1部=設計／第2部=部品詳細） /
`部品一覧.md` / `部品確認ケース.md` / `ログ項目仕様（種類別）.md`）を参照。
