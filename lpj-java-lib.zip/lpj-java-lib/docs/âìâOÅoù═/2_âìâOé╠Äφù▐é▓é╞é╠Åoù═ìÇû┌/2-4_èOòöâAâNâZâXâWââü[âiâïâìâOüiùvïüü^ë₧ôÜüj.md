## 2-4. 外部アクセスジャーナルログ（要求/応答）

| 論理名 | 物理名 | 設定値の説明（appender が値を得る経路） |
|---|---|---|
| タイムスタンプ | `timestamp` | logback 標準 `<timestamp>` |
| コンテナID | `id` | logback で環境変数 `CONTAINER_ID` を参照（未設定時 `"null"`） |
| コンテナ名 | `name` | logback で環境変数 `CONTAINER_NAME` を参照（未設定時 `"null"`） |
| ログレベル | `level` | logback 標準 `<logLevel>` |
| ログレベル値 | `level_value` | logback 標準 `<logLevelValue>`（**数値**） |
| ロガー名 | `logger_name` | logback 標準 `<loggerName>` |
| ログ種類 | `type` | appender で固定。`"app"` |
| ログ種類詳細 | `subtype` | appender で固定。`"APL"` |
| スレッド | `thread` | logback 標準 `<threadName>` |
| 機能ID | `function` | `MDC("function")`（[3-6. MDC項目追加](#3-6-mdc項目追加)） |
| トレースID | `trace` | `MDC("trace")` |
| メッセージ | `message` | [3-5. 出力長制限](#3-5-出力長制限)（マスク後に切詰・上限 yml） |
| URL | `url` | `marker` |
| HTTPステータス | `status` | `marker`（要求側は `"null"`） |
| ヘッダー情報 | `headers` | `marker`（対象は[3-4. マスキング](#3-4-マスキング)で伏字、[3-5. 出力長制限](#3-5-出力長制限)で上限） |
| ボディ情報 | `body` | `marker`（応答側。対象は[3-4. マスキング](#3-4-マスキング)で伏字後、[3-5. 出力長制限](#3-5-出力長制限)で切詰） |
| 処理時間 | `latency` | `marker`（要求側は `"null"`） |
| クラス名 | `class_name` | [3-7. 発生元（クラス名・メソッド名）追加](#3-7-発生元クラス名メソッド名追加) |
| メソッド名 | `method_name` | [3-7. 発生元（クラス名・メソッド名）追加](#3-7-発生元クラス名メソッド名追加) |
