## 2-12. システムログ

明示出力しないフレームワーク等のログ

> `class_name`／`method_name` は付与しない（root には [3-7. 発生元（クラス名・メソッド名）追加](#3-7-発生元クラス名メソッド名追加) を効かせない）。MDC スコープ外で出るため、スコープ項目は `"null"`。

| 論理名 | 物理名 | 設定値の説明（appender が値を得る経路） |
|---|---|---|
| タイムスタンプ | `timestamp` | logback 標準 `<timestamp>` |
| コンテナID | `id` | logback で環境変数 `CONTAINER_ID` を参照（未設定時 `"null"`） |
| コンテナ名 | `name` | logback で環境変数 `CONTAINER_NAME` を参照（未設定時 `"null"`） |
| ログレベル | `level` | logback 標準 `<logLevel>` |
| ログレベル値 | `level_value` | logback 標準 `<logLevelValue>`（**数値**） |
| ロガー名 | `logger_name` | logback 標準 `<loggerName>`（実クラス FQCN） |
| ログ種類 | `type` | appender で固定。`"app"`（ERROR 時 `"monitor"`） |
| ログ種類詳細 | `subtype` | appender で固定。固定ロガー外のため `"SYSTEM"` |
| スレッド | `thread` | logback 標準 `<threadName>` |
| 機能ID | `function` | `MDC("function")`（MDC スコープ外のため `"null"`） |
| トレースID | `trace` | `MDC("trace")`（同上 `"null"`） |
| メッセージ | `message` | [3-5. 出力長制限](#3-5-出力長制限)（マスク後に切詰・上限 yml） |

---
