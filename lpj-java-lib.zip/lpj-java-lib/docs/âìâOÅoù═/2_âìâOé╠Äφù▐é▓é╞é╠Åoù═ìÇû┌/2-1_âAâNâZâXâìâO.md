## 2-1. アクセスログ

| 論理名 | 物理名 | 設定値の説明（appender が値を得る経路） |
|---|---|---|
| タイムスタンプ | `timestamp` | logback 標準 `<timestamp>` |
| コンテナID | `id` | logback で環境変数 `CONTAINER_ID` を参照（未設定時 `"null"`） |
| コンテナ名 | `name` | logback で環境変数 `CONTAINER_NAME` を参照（未設定時 `"null"`） |
| ログレベル | `level` | logback 標準 `<logLevel>` |
| ログレベル値 | `level_value` | logback 標準 `<logLevelValue>`（**数値**） |
| ロガー名 | `logger_name` | logback 標準 `<loggerName>` |
| ログ種類 | `type` | appender で固定。アクセスログは `"trail"` |
| スレッド | `thread` | logback 標準 `<threadName>` |
| 機能ID | `function` | `MDC("function")`（[3-6. MDC項目追加](#3-6-mdc項目追加)が列挙出力） |
| 操作 | `action` | `MDC("action")` |
| ユーザーID | `user` | `MDC("user")` |
| クライアントIP | `source_ip` | `MDC("source_ip")` |
| メッセージ | `message` | [3-5. 出力長制限](#3-5-出力長制限)（マスク後に切詰・上限 yml） |
| URL | `url` | `marker`（出力元の機能が設定） |
| HTTPステータス | `status` | `marker` |
| 処理時間 | `latency` | `marker` |
| クラス名 | `class_name` | [3-7. 発生元（クラス名・メソッド名）追加](#3-7-発生元クラス名メソッド名追加)（caller data） |
| メソッド名 | `method_name` | [3-7. 発生元（クラス名・メソッド名）追加](#3-7-発生元クラス名メソッド名追加)（caller data） |
