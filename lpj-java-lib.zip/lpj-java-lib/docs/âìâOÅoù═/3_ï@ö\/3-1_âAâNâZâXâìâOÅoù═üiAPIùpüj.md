## 3-1. アクセスログ出力（API用）

### 部品概要

#### 目的

HTTP リクエスト単位でログスコープを開始し、アクセスログ（1件サマリ）とアクセスジャーナル（要求/応答）を出力する。

#### 前提
  - Spring MVC（Servlet環境）で動作することを前提とする（WebFlux 非対応）。  
    `@Component` としてスキャンされ、`OncePerRequestFilter` として API リクエストの前後にフックする。
  - `application.yml`（`cosmo-app.logging.api.enabled=true`）で有効化して使う（既定 OFF）。
  - アクセスジャーナルログは本フィルタが担う前提。  
    **既存のアクセスジャーナル用 `AccessLogInterceptor implements HandlerInterceptor` は登録しない**こと（両方登録すると二重出力）。  
    ※ 利用者側で `@Configuration`（`WebMvcConfigurer#addInterceptors`）登録しないこと。

#### 特記事項
  - `OncePerRequestFilter` を継承し `doFilterInternal` を実装することで、HTTP リクエストの前後で処理を挟む。
  - `@Order(Ordered.HIGHEST_PRECEDENCE)` を付けて**最も外側**のフィルタにすることで、  
    後続の全処理を MDC スコープの中に入れる（既存部品のフィルタよりも外側になる）。
  - レスポンスを確実に返すため、`ContentCachingResponseWrapper` は最後に必ず `copyBodyToResponse()` を呼ぶ  
    （キャッシュしたボディを本物のレスポンスへ書き戻す）。
  - アクセスログ用（`"SPRINGBOOT_API_ACCESS_LOG"`）/ アクセスジャーナル用（`"SPRINGBOOT_API_ACCESS_JNL_LOG"`）の `Logger` は固定ロガー名のため  
    `static final` フィールドでクラスロード時に1度だけ取得し、全リクエストで共有する。
    `Logger` はスレッドセーフでステートレスなので使い回しで問題ない。
  - ボディはキャッシュ自体は全量（`Integer.MAX_VALUE`）で保持し、長さ制限は**出力時**に適用する。  
    `body`／`headers` とも masker（decorator）内で切詰める（[3-5. 出力長制限](#3-5-出力長制限)）。本フィルタは切詰を行わない。

### 処理フロー

本部品は以下のような処理フローで動作する。

1. ボディをキャッシュするため、引数の `HttpServletRequest` を `ContentCachingRequestWrapper` でラップする。（上限なし＝Integer.MAX_VALUE）
2. ボディをキャッシュするため、引数の `HttpServletResponse` を `ContentCachingResponseWrapper` でラップする。(デフォルトで上限なし)
3. 以下の処理でリクエスト元IPアドレスを取得する。
    1. `ContentCachingRequestWrapper.getHeader("X-Forwarded-For")` から、クライアントIPアドレスを取得する。
    2. クライアントIPアドレスが存在する場合
        1. クライアントIPアドレスの1件目をリクエスト元IPアドレスとする。
    3. クライアントIPアドレスが存在しない場合
        1. `ContentCachingRequestWrapper.getRemoteAddr()` をリクエスト元IPアドレスとする。
4. 以下の表の内容を、`MDC` に追加する。

    | キー | 設定値 |
    |---|---|
    | `"function"` | `ContentCachingRequestWrapper.getMethod()` + " " + `ContentCachingRequestWrapper.getRequestURI()` |
    | `"action"` | `ContentCachingRequestWrapper.getMethod()` + " " + `ContentCachingRequestWrapper.getRequestURI()` |
    | `"user"` | `ContentCachingRequestWrapper.getHeader("X-User-ID")` |
    | `"trace"` | `ContentCachingRequestWrapper.getHeader("X-Trace-ID")`（無ければ `UUID.randomUUID()` で自動採番） |
    | `"source_ip"` | リクエスト元IPアドレス |

5. 以下の処理で URL を取得する。
    1. `ContentCachingRequestWrapper.getQueryString()` から、クエリ文字列を取得する。
    2. クエリ文字列が null 以外の場合、クエリ文字列を 「"?" + クエリ文字列」とする。
    3. `ContentCachingRequestWrapper.getMethod()` + " " + `ContentCachingRequestWrapper.getRequestURI()` + クエリ文字列を URL とする。
6. 処理開始時間（ns）を取得する（`System.nanoTime()`）。
7. 引数の `FilterChain` から、`FilterChain.doFilter()` で後続フィルタ・コントローラを実行する。
8. 処理終了時間（ns）を取得し、開始との差分から処理時間（ms）を算出する。
9. `finally` で以下の処理でアクセスログを出力する。
    1. 以下の表の内容で、 `LogstashMarker` を生成する。

        | キー | 設定値 |
        |---|---|
        | `"url"` | URL |
        | `"status"` | `ContentCachingResponseWrapper.getStatus()` |
        | `"latency"` | 処理時間（ms） |

    2. アクセスログ用（`"SPRINGBOOT_API_ACCESS_LOG"`）の `Logger` から、以下の内容でログを出力する。

        | 引数 | 設定値 |
        |---|---|
        | `marker` | 生成した `LogstashMarker` |
        | `msg` | `"アクセスログ"` |

10. `finally` で以下の処理でアクセスジャーナルログ（要求）を出力する。
    1. `ContentCachingRequestWrapper.getHeaderNames()`、`ContentCachingRequestWrapper.getHeader()` から、リクエストヘッダーのマップを生成する。
    2. `ContentCachingRequestWrapper.getContentAsByteArray()` から、`UTF-8` で文字列に変換し、リクエストボディの文字列を生成する。（null または 0桁の場合、null）
    3. 以下の表の内容で、 `LogstashMarker` を生成する。

        | キー | 設定値 |
        |---|---|
        | `"url"` | URL |
        | `"status"` | `null` |
        | `"headers"` | リクエストヘッダーのマップ |
        | `"body"` | リクエストボディの文字列 |
        | `"latency"` | `null` |

    4. アクセスジャーナル用（`"SPRINGBOOT_API_ACCESS_JNL_LOG"`）の `Logger` から、以下の内容でログを出力する。

        | 引数 | 設定値 |
        |---|---|
        | `marker` | 生成した `LogstashMarker` |
        | `msg` | `"アクセスジャーナル（要求）"` |

11. `finally` で以下の処理でアクセスジャーナルログ（応答）を出力する。
    1. `ContentCachingResponseWrapper.getHeaderNames()`、`ContentCachingResponseWrapper.getHeader()` から、レスポンスヘッダーのマップを生成する。
    2. `ContentCachingResponseWrapper.getContentAsByteArray()` から、`UTF-8` で文字列に変換し、レスポンスボディの文字列を生成する。（null または 0桁の場合、null）
    3. 以下の表の内容で、 `LogstashMarker` を生成する。

        | キー | 設定値 |
        |---|---|
        | `"url"` | URL |
        | `"status"` | `ContentCachingResponseWrapper.getStatus()` |
        | `"headers"` | レスポンスヘッダーのマップ |
        | `"body"` | レスポンスボディの文字列 |
        | `"latency"` | 処理時間（ms） |

    4. アクセスジャーナル用（`"SPRINGBOOT_API_ACCESS_JNL_LOG"`）の `Logger` から、以下の内容でログを出力する。

        | 引数 | 設定値 |
        |---|---|
        | `marker` | 生成した `LogstashMarker` |
        | `msg` | `"アクセスジャーナル（応答）"` |

12. `ContentCachingResponseWrapper.copyBodyToResponse()` でレスポンス返却する。
13. `finally` で MDC を全 remove する。


### クラス一覧
| クラス名 | 役割 |
|---|---|
| `ApiAccessLogFilter` | アクセスログ・ジャーナルの出力＋実行単位 MDC スコープ管理 |

### メソッド一覧
| メソッド | 概要 |
|---|---|
| `doFilterInternal(HttpServletRequest, HttpServletResponse, FilterChain) throws ServletException, IOException` | アクセスログ／アクセスジャーナルログを出力するフィルタ本体。 |

### 利用ガイド
コンポーネントスキャンに含めたうえで、`application.yml` で有効化する（業務コードの記述は不要）。

```yaml
cosmo-app:
  logging:
    api:
      enabled: true   # 既定 false
```

---
