## 3-4. マスキング

### 部品概要

#### 目的

個人情報・機密情報を `***` に置き換えて伏せる。  
呼び出し側を通さず、出力直前に全ログ（slf4j や root ロガーも含む）へまとめて適用する。

#### 前提
  - マスク対象は `application.yml`（`cosmo-app.logging.mask.*`）で指定する。**指定したものだけ**マスクし、デフォルトは空（何もマスクしない）。
  - マスクは1クラス `LogMasker` が担う。logstash の値マスク（`ValueMasker`）とヘッダ名マスク（`FieldMasker`）の両口を実装し、appender の `MaskingJsonGeneratorDecorator` に差す。
  - logback の masker は config 時に no-arg 生成され Bean を DI できないため、規則は `LoggingProperties`（`@PostConstruct`）が起動時に `LogMasker` の静的フィールドへ充填する（masker は実行時に静的参照）。

#### 特記事項
  - 規則は起動時に充填されるため、それより前（Bean 生成前の起動最初期）のフレームワークログだけは、規則が空のままマスクされずに出力される（設計上の許容）。
  - ネストした構造化オブジェクトの**キー名**によるマスクは `headers` 以外には未対応（必要なら値パターンで補う）。
  - 出力長制限（[3-5. 出力長制限](#3-5-出力長制限)）は別クラス `LogLengthLimiter` が**同じ decorator でマスクの後に**動く。マスキング自身は切詰を行わない（出力長制限を知らない）。

### 処理フロー

本部品は以下のような処理フローで動作する。

#### アプリケーション起動時

> ※ Spring 起動時に1回だけ実行される。

1. `LoggingProperties` が `cosmo-app.logging.mask.*` をバインドする。
2. `LoggingProperties.install()`（`@PostConstruct`）が、ヘッダ名（小文字化）・bodyキー・値パターン（事前コンパイル）を `LogMasker.install(..)` で静的フィールドへ充填する。

#### ログ出力時

> ※ ログ1件ごとに実行される。

ログ1件を encoder が JSON へ書き出す瞬間、`MaskingJsonGeneratorDecorator` が各フィールドで `LogMasker` の2口を呼ぶ。

1. `LogMasker.mask(context, value)`（全フィールドの **値** が対象）
    1. value が `CharSequence`（文字列）でなければ `null`（対象外）を返す。
    2. 文字列なら `maskKeys(..)` を適用する。
        1. （キー名ベース）`bodyKeys` の各キー（**大小文字を無視＝`(?i)`**）を3形式で `***` に置換する。
            - `"key":"value"`（JSON 文字列値。`\"` エスケープを含む値も末尾まで）
            - `"key":123` / `true` / `false` / `null`（非文字列の**スカラ値のみ**。オブジェクト/配列値は JSON 破壊を避けるため対象外）
            - `key=value`（クエリ／フォーム／フリーテキスト形式。区切りは `, & ; 空白 ) }`）
        2. （値パターンベース）`bodyPatterns` の各 `Pattern` のマッチ箇所を `***` に置換する。
    3. 変化した場合のみ masked を返す。無変化なら `null`（素通し）。
2. `LogMasker.mask(context)`（**フィールド名** が対象＝`headers` 直下のヘッダを値ごと伏せる）
    1. フィールド名（`getCurrentName()`）が `null` なら `null`（対象外）。
    2. 親 context のフィールド名が `headers` でなければ `null`（対象外）。
        - **`headers` 直下に限定**：フィールド名だけで判定すると yml のヘッダ名が MDC 等の構造化フィールド名（例 `user`）と衝突した際に誤爆するため。
    3. フィールド名（小文字）が対象集合に含まれれば `"***"` を返す。含まれなければ `null`。

### クラス一覧／メソッド一覧

| クラス | メソッド | 概要 |
|---|---|---|
| `LogMasker` | `mask(JsonStreamContext, Object)` ／ `mask(JsonStreamContext)` | 値マスク（`ValueMasker`）＋ヘッダ名マスク（`FieldMasker`）の両口 |
| 〃 | `install()` ／ `headerLower()` ／ `bodyKeys()` ／ `bodyPatterns()` | yml 規則の充填・参照（静的。既定は空） |
| 〃 | `maskKeys()` ／ `maskHeaders()` ／ `maskUrlKeys()` *(static)* | マスクの純粋ロジック |

### 利用ガイド
```yaml
cosmo-app:
  logging:
    mask:
      header-names: [authorization, cookie, x-api-key]
      body-keys:    [password, secret, token]
      body-patterns: []   # 値パターン（正規表現）opt-in
```
各 appender の `<encoder>` の `<jsonGeneratorDecorator>` に `LogMasker` を `<valueMasker>` と `<fieldMasker>` で差す（本ライブラリに同梱）。  
出力長制限の `LogLengthLimiter` も同じ decorator に `<valueMasker>` として**後ろに**並ぶ（[3-5. 出力長制限](#3-5-出力長制限)）。

```xml
<jsonGeneratorDecorator class="net.logstash.logback.mask.MaskingJsonGeneratorDecorator">
    <valueMasker class="jp.co.xxx.common.app.lib.logging.mask.LogMasker"/>        <!-- ① マスク -->
    <valueMasker class="jp.co.xxx.common.app.lib.logging.mask.LogLengthLimiter"/> <!-- ② 切詰（3-5） -->
    <fieldMasker class="jp.co.xxx.common.app.lib.logging.mask.LogMasker"/>
</jsonGeneratorDecorator>
```

---
