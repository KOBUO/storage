## 3-7. 発生元（クラス名・メソッド名）追加

### 部品概要

#### 目的

`org.slf4j.Logger` の呼び出し元スタックから発生元を特定し、その発生元のクラス名（`class_name`）／メソッド名（`method_name`）をログイベントに追加する。

#### 前提

  - ログに出力項目を追加するため、provider（`net.logstash.logback.composite.JsonProvider`）として appender に登録して使用する。
  - provider として機能させるために、`net.logstash.logback.composite.AbstractJsonProvider<ILoggingEvent>` を継承して実装する。
  - 発生元（クラス・メソッド）を特定するために、呼び出し元スタック（`ILoggingEvent.getCallerData()`）を使用する。
  - 中継クラスを発生元から除外するために、除外対象（FQCN〔完全修飾クラス名〕の接頭辞）のリストを定義する。

#### 特記事項

  - 発生元が取れない場合、クラス名（`class_name`）／メソッド名（`method_name`）には `"null"` を出力する。
  - 除外リストに未登録の独自の中継クラスを介してログを出力した場合、その中継クラスが発生元になる。

### 処理フロー

本部品は以下のような処理フローで動作する。

1. 引数(`ILoggingEvent`)から、`ILoggingEvent.getCallerData()` を使用して、呼び出し元スタック(`StackTraceElement[]`)を取得する。
2. 以下の処理で発生元のフレーム(`StackTraceElement`)を取得する。
    1. 呼び出し元スタックが `null` の場合
        1. 発生元のフレームは `null` とする。
    2. 上記以外の場合
        1. 呼び出し元スタックを先頭から順に確認し、以下の定義外の最初の1件を発生元のフレームとする。

            | 除外対象（FQCN の接頭辞） | 備考 | 
            |---|---|
            | `"jp.co.xxx.common.app.lib.logging.ApplicationLogger"` | 本ライブラリの中継クラス |
            | `"jp.co.xxx.xxx.app.lib.logging.JournalLogger"` | `TODO` の中継クラス |
            | `"jp.co.xxx.xxx.app.lib.logging.ApLogger"` | `TODO` の中継クラス |

            >※ 全フレームが除外対象だった場合、発生元のフレームは `null` とする。

3. 引数(`JsonGenerator`)から、`JsonGenerator.writeStringField(..)` を使用して、以下の内容を出力する。

    | 項目名 | 設定値 | 
    |---|---|
    | `"class_name"` | 発生元のフレームの `StackTraceElement.getClassName()` の値 |
    | `"method_name"` | 発生元のフレームの `StackTraceElement.getMethodName()` の値 |

    >※ 発生元のフレームが `null` の場合は、`"null"` を設定する。

### クラス一覧／メソッド一覧

| クラス | メソッド | 概要 |
|---|---|---|
| `ClassMethodJsonProvider` | `writeTo(JsonGenerator, ILoggingEvent)` | 発生元のクラス名／メソッド名を出力 |

### 利用ガイド

appender の encoder（`LoggingEventCompositeJsonEncoder`）の `<providers>` に本 provider を登録する。  
設定要素は不要（自己終了タグ）で、登録した位置に `class_name` ／ `method_name` が出力される。

```xml
<appender name="APP" class="ch.qos.logback.core.ConsoleAppender">
    <encoder class="net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder">
        <providers>
            <!-- 他の provider … -->
            <provider class="jp.co.xxx.common.app.lib.logging.logback.ClassMethodJsonProvider"/>
        </providers>
    </encoder>
</appender>
```

出力例：

```json
{ "...": "...", "class_name": "com.example.SampleService", "method_name": "execute" }
```

---
