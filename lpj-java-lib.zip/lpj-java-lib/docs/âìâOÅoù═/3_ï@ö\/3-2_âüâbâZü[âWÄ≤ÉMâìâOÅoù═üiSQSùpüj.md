## 3-2. メッセージ受信ログ出力（SQS用）

### 部品概要

#### 目的

`@SqsListener` がメッセージを受信する前後に処理を挟み、受信ジャーナルログの出力と MDC スコープの設定・後始末を自動で行う。

#### 前提
  - `io.awspring.cloud:spring-cloud-aws-starter-sqs` を使い、`@SqsListener` を持つ常駐アプリで動作する。
  - デフォルト OFF。`cosmo-app.logging.sqs.enabled=true` を明示したときのみ有効（`matchIfMissing=false`）。
  - 1メッセージを1スレッドで処理する前提（受信 `intercept` →リスナー→完了 `afterProcessing` が同じスレッド）。  
    MDC はスレッドごとの領域なので、途中でスレッドが変わると値が引き継がれない。

#### 特記事項
  - `SqsReceiveJournalInterceptor` を単独の `@Component` にしているのは、  
    アプリが独自のファクトリを定義したときに、そのファクトリへ手動で差し込んで再利用できるようにするため（利用ガイド参照）。
  - 受信時の AWS メタ情報（`aws_request_id` など）は、SDK の受信処理を Spring が内部で握っているため取得できず `"null"` になる。  
    受信時に取れるのは `aws_sqs_message_id`（＝SQS が採番した MessageId。`MessageHeaders.getId()`）だけ。

### 処理フロー

本部品は以下のような処理フローで動作する。

#### ResidentSqsConfig

1. `SqsAsyncClient`（Spring Cloud AWS の自動構成）と `SqsReceiveJournalInterceptor`（`@Component`）を DI で取得する。
2. `SqsMessageListenerContainerFactory.builder()` に以下を設定する。
    1. `sqsAsyncClient(sqsAsyncClient)` で SQS クライアントを設定する。
    2. `messageInterceptor(interceptor)` で受信ジャーナル interceptor を設定する。
3. `build()` で `SqsMessageListenerContainerFactory` を生成し、Bean に登録する。

> 注：Bean 名 `defaultSqsListenerContainerFactory`（`@SqsListener` がデフォルトで使うファクトリ名）で登録することでデフォルトファクトリを置き換え、  
> 各リスナーの受信前後で `SqsReceiveJournalInterceptor` がフックされる。  
> 注：`@ConditionalOnMissingBean` を付与しているため、  
> アプリが独自に `SqsMessageListenerContainerFactory` を定義している場合は本 Bean は生成されない（そちらに譲る）。

#### SqsReceiveJournalInterceptor

1. SQSメッセージ受信時、`intercept(message)` が以下を行う。
    1. メッセージヘッダから メッセージID（`MessageHeaders.getId()`）を取得する。
    2. 以下の表の内容を `MDC` に追加する。（null／空白は設定しない）

        | キー | 設定値 |
        |---|---|
        | `"function"` | 受信キュー名（`SqsHeaders.SQS_QUEUE_NAME_HEADER`。取得不可時は `"sqs"`） |
        | `"action"` | `"CONSUME"`(TODO 仮値) |
        | `"trace"` | メッセージ属性 `"trace"`(TODO 仮値) |
        | `"user"` | メッセージ属性 `"user"`(TODO 仮値) |

    3. 以下の表の内容で、 `LogstashMarker` を生成する。

        | キー | 設定値 |
        |---|---|
        | `"latency"` | `null` |
        | `"aws_request_id"` | `null` |
        | `"aws_sqs_message_id"` | メッセージID |
        | `"aws_request_timestamp"` | `null` |
        | `"aws_response_time"` | `null` |

    4. 受信ログ用（`"SPRINGBOOT_SQS_JNL_LOG"`）の `Logger` から、`msg`=`"メッセージ受信ジャーナル"` でログを出力する。
    5. メッセージをそのまま返す。
2. 業務リスナーが実行される。
3. 処理完了時、`afterProcessing(message, throwable)` が `MDC.clear()` でスレッドの MDC を一掃する。  
   **失敗時のエラーログは出さない**（業務側＝`ApplicationLogger.error` が担う。例外はそのまま伝播＝リトライ/DLQ へ）。

### クラス一覧
| クラス名 | 役割 |
|---|---|
| `SqsReceiveJournalInterceptor` | 受信ジャーナル出力＋MDCスコープ（`MessageInterceptor` ／ `@Component`） |
| `ResidentSqsConfig` | デフォルトリスナーコンテナファクトリに interceptor を配線（`@Configuration`） |

### メソッド一覧
| クラス | メソッド | 概要 |
|---|---|---|
| `SqsReceiveJournalInterceptor` | `intercept(Message)` | MDC put ＋ 受信ジャーナル出力 |
| 〃 | `afterProcessing(Message, Throwable)` | `MDC.clear()` のみ（失敗時のエラーログは出さない・例外は伝播） |
| 〃 | `function / traceId / attr / messageId / put` *(private)* | ヘッダ／属性からの抽出と MDC 設定 |
| `ResidentSqsConfig` | `defaultSqsListenerContainerFactory(SqsAsyncClient, SqsReceiveJournalInterceptor)` *(@Bean)* | interceptor を挿したファクトリを生成（`@ConditionalOnMissingBean`） |

### 利用ガイド
- デフォルト OFF。スキャン対象に含めたうえで `cosmo-app.logging.sqs.enabled=true` を設定して有効化する。
- アプリが独自 `SqsMessageListenerContainerFactory` を定義する場合は本ファクトリが引っ込むため、  
  自作ファクトリに `SqsReceiveJournalInterceptor`（Bean）を `messageInterceptor(...)` で手動追加する。

---
