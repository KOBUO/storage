# 1. ログ出力の全体像

本ライブラリは **SLF4J + logback** を基盤に、すべてのログを**構造化 JSON（1ログ＝1行）**で標準出力／標準エラー（stdout / stderr）へ出力する。  
フォーマットの統一・共通項目の付与・マスク・長さ制限などは logback の **encoder／appender 層**で自動適用されるため、出力時に意識する必要はない。  
業務コードが明示的に出すログ（業務ログ／業務エラーログ）は **`ApplicationLogger`**（[3-3. 業務ログ出力](#3-3-業務ログ出力)）を使う。

| 取得・メソッド | 用途 |
|---|---|
| `ApplicationLoggerFactory.getLogger()` | `ApplicationLogger`（シングルトン）を取得する（DI 不要） |
| `ApplicationLogger.info(message)` | 業務ログ（`"SPRINGBOOT_API_LOG"`）を INFO 出力する |
| `ApplicationLogger.error(message, throwable)` | 業務エラーログ（`"SPRINGBOOT_ERROR_LOG"`）を ERROR 出力する（`stack_trace` あり） |
| `ApplicationLogger.error(message)` | 業務エラーログを ERROR 出力する（例外なし＝`stack_trace` なし） |

## 実行モード

アプリの実行形態は4つ。実行単位（リクエスト／メッセージ／ジョブ）ごとに MDC スコープを張り、境界で `MDC.clear()` するのが基本。

| 実行モード | 起動契機 | 実行単位 MDC スコープの起点 | 補足 |
|---|---|---|---|
| API | HTTP リクエスト | [3-1. アクセスログ出力（API用）](#3-1-アクセスログ出力api用) がリクエスト単位で MDC を張り、境界で `MDC.clear()` | Spring MVC（Servlet） |
| バッチ（単発） | コマンド／ジョブ起動 | 既存基盤（または開発者）がジョブ単位で張る。スレッド再利用がなくプロセス終了で消えるため境界クリアは必須でない | 1回実行して終了 |
| 常駐バッチ | タイマー／スケジューラ | 既存基盤が実行単位で張り、境界で `MDC.clear()`（スレッド再利用のため必須） | 常駐して定期実行 |
| SQS常駐バッチ | SQS メッセージ受信 | [3-2. メッセージ受信ログ出力（SQS用）](#3-2-メッセージ受信ログ出力sqs用) が受信単位で MDC を張り、`afterProcessing` で `MDC.clear()` | 常駐して `@SqsListener` で受信 |

> MDC スコープを担うのは **API**（3-1）と **SQS常駐バッチ**（3-2）。バッチ（単発）・常駐バッチ（タイマー）のスコープは既存基盤が担う前提。

---
