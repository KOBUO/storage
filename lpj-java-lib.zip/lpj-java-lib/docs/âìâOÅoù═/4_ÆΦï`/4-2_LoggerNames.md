## 4-2. LoggerNames

ログ種類ごとの固定ロガー名。Java クラス名ではなく、`logback.xml` の appender 振り分けキーとして使う。

| 定数 | ロガー名 | ログ種類 |
|---|---|---|
| `API_ACCESS` | `"SPRINGBOOT_API_ACCESS_LOG"` | アクセスログ（サマリ） |
| `API_ACCESS_JNL` | `"SPRINGBOOT_API_ACCESS_JNL_LOG"` | アクセスジャーナル（要求/応答） |
| `SERVICE_JNL` | `"SPRINGBOOT_SERVICE_JNL_LOG"` | サービスジャーナル（出力は既存部品） |
| `STORAGE_JNL` | `"SPRINGBOOT_STORAGE_JNL_LOG"` | ストレージアクセスジャーナル |
| `AWSCALL` | `"AWSCALL"` | ストレージアクセスジャーナルの別ロガー名（STORAGE appender・`subtype=AWSCALL` で同様に扱う） |
| `HTTP_CLIENT_JNL` | `"SPRINGBOOT_HTTP_CLIENT_JNL_LOG"` | 外部HTTPジャーナル |
| `SQS_JNL` | `"SPRINGBOOT_SQS_JNL_LOG"` | SQS受信ジャーナル |
| `SQL_JNL` | `"SPRINGBOOT_SQL_JNL_LOG"` | SQLジャーナル |
| `KMS_JNL` | `"SPRINGBOOT_KMS_JNL_LOG"` | KMSアクセスジャーナル |
| `DYNAMODB_JNL` | `"SPRINGBOOT_DYNAMODB_JNL_LOG"` | DynamoDBアクセスジャーナル |
| `API_LOG` | `"SPRINGBOOT_API_LOG"` | 業務ログ |
| `ERROR_LOG` | `"SPRINGBOOT_ERROR_LOG"` | 業務エラーログ |
