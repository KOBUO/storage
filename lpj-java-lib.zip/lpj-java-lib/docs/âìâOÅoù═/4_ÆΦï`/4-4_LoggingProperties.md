## 4-4. LoggingProperties

`application.yml` の `cosmo-app.logging.*` をバインドする設定。マスク対象（`custom.*`）と出力長上限（`limits.*`）を保持する。

### マスク対象（`cosmo-app.logging.mask.*`）

**指定したものだけ**マスクし、デフォルトはすべて空（[3-4. マスキング](#3-4-マスキング)）。

| プロパティ（yml） | フィールド | 内容 |
|---|---|---|
| `header-names` | `headerNames` | マスク対象ヘッダー名（小文字比較）。デフォルトは空 |
| `body-keys` | `bodyKeys` | マスク対象ボディ/引数キー（値を `***`）。デフォルトは空 |
| `body-patterns` | `bodyPatterns` | 値パターンマスク（正規表現）。キーに紐づかない PII 用の opt-in。デフォルトは空 |

### 出力長上限（`cosmo-app.logging.limits.*`）

フィールドごとの UTF-8 バイト上限。1行を 4KB 以内に収めるための値で、未指定時はデフォルトで動く（[3-5. 出力長制限](#3-5-出力長制限)）。

| プロパティ（yml） | フィールド | デフォルト | 内容 |
|---|---|---|---|
| `limits.message` | `limits.message` | 768 | `message` の上限。マスク後に切詰 |
| `limits.body` | `limits.body` | 1024 | `body` の上限。マスク後に切詰 |
| `limits.result` | `limits.result` | 1024 | `result`／`args` の上限。マスク後に切詰 |
| `limits.headers` | `limits.headers` | 512 | 各ヘッダ値の上限。`LogLengthLimiter` が decorator で切詰 |
| `limits.stack-trace` | `limits.stackTrace` | 2560 | `stack_trace` の上限。`ShortenedThrowableConverter` の `maxLength` へ注入 |

> マスク規則・上限値は `LoggingProperties.install()`（`@PostConstruct`）が `LogMasker`／`LogLengthLimiter` の静的フィールドへ充填する（config 時に no-arg 生成され Bean を DI できない logback masker への橋渡し）。
