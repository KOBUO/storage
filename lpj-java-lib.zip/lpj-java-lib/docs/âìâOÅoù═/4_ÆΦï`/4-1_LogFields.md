## 4-1. LogFields

ログ出力時に Marker でその場で設定する項目の物理名（JSONキー）。MDC・logback 組み込み・provider 由来の項目はここには含めない。

| 定数 | JSONキー | 内容 |
|---|---|---|
| `TYPE` | `"type"` | ログ種類の大分類 |
| `SUBTYPE` | `"subtype"` | ログ種類の詳細 |
| `URL` | `"url"` | アクセス先 URL |
| `STATUS` | `"status"` | HTTP ステータス |
| `HEADERS` | `"headers"` | 要求/応答ヘッダー |
| `BODY` | `"body"` | 要求/応答ボディ |
| `CLASS_NAME` | `"class_name"` | 出力元クラス |
| `METHOD_NAME` | `"method_name"` | 出力元メソッド |
| `ARGS` | `"args"` | メソッド引数 |
| `RESULT` | `"result"` | メソッド戻り値 |
| `LATENCY` | `"latency"` | 処理時間（ms） |
| `AWS_REQUEST_ID` | `"aws_request_id"` | AWS リクエストID |
| `AWS_REQUEST_TIMESTAMP` | `"aws_request_timestamp"` | AWS リクエスト時刻 |
| `AWS_RESPONSE_TIME` | `"aws_response_time"` | AWS 応答時間 |
| `AWS_SQS_MESSAGE_ID` | `"aws_sqs_message_id"` | SQS メッセージID |
