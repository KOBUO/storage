# バックエンドALBのサーバー証明書検証に用いるルート証明書

ACM が発行するサーバー証明書は、Amazon Trust Services のルート証明書に連なる。
バックエンドALBへ HTTPS で接続する際の検証（`proxy_ssl_verify on`）に用いる。

取得元: https://www.amazontrust.com/repository/

処理方式設計書「5-J). SSLサーバ証明書導入の流れと役割分担」の ※2 に
「ACM を利用する場合、上記URL先の**全ての**ルート証明書をクライアントに登録すること」とあるため、
同ページで配布されている PEM をすべて配置する。役割分担上、登録はベンダー（本テンプレートの利用者）が行う。

| ファイル | 主体 |
|---------|------|
| `AmazonRootCA1.pem` | Amazon Root CA 1（RSA 2048） |
| `AmazonRootCA2.pem` | Amazon Root CA 2（RSA 4096） |
| `AmazonRootCA3.pem` | Amazon Root CA 3（ECDSA P-256） |
| `AmazonRootCA4.pem` | Amazon Root CA 4（ECDSA P-384） |
| `G2-RootCA1.pem`〜`G2-RootCA4.pem` | 上記4つを Starfield Services Root CA - G2 が相互署名したもの |
| `SFSRootCAG2.pem` | Starfield Services Root Certificate Authority - G2 |
| `SFC2CA-SFSRootCAG2.pem` | 上記を Starfield Class 2 CA が相互署名したもの |
| `Amazon-RSA-2048-Root-EU-M1-*.pem` | Amazon RSA 2048 Root EU M1（自己署名／相互署名） |
| `Amazon-ECDSA-256-Root-EU-M1-*.pem` | Amazon ECDSA 256 Root EU M1（自己署名／相互署名） |
| `Amazon-ECDSA-384-Root-EU-M1-*.pem` | Amazon ECDSA 384 Root EU M1（自己署名／相互署名） |

ACM がどのルートを用いるかは発行時期・鍵種別・リージョンにより変わる。
また移行期には相互署名された証明書で連鎖するため、自己署名・相互署名の双方を配置する。

コンテナイメージのビルド時に1ファイル（`/etc/nginx/certs/amazon-root-ca.pem`）へ連結し、
`proxy_ssl_trusted_certificate` で参照する。

## 更新について

Amazon がルート証明書を追加・更新した場合は、上記URLから取得し直してイメージを再作成する。
