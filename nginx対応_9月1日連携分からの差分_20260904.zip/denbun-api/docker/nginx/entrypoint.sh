#!/bin/sh
set -eu

ROUTING_FILE_PATH="/shared/routing.json"
ROUTES_JS="/etc/nginx/njs/routes.js"
TEMPLATE="/etc/nginx/templates/nginx.conf.template"
NGINX_CONF="/etc/nginx/nginx.conf"
ERROR_PIPE="/tmp/nginx-error"
DEFAULT_BACKEND_CA_FILE="/etc/nginx/certs/amazon-root-ca.pem"

REQUIRED_ENV="BACKEND_SCHEME BACKEND_PORT MAX_CONNECTIONS WORKER_CONNECTIONS MAX_BODY_SIZE LIMIT_ZONE_SIZE
LIMIT_CONNECTION
PROXY_CONNECT_TIMEOUT PROXY_READ_TIMEOUT PROXY_SEND_TIMEOUT"

now_timestamp() {
    jq -rn 'now as $time
        | ($time | strflocaltime("%Y-%m-%d %H:%M:%S"))
          + "." + (("00" + (($time * 1000 | floor) % 1000 | tostring)) | .[-3:])'
}

log() {
    level=$1
    message=$2
    case "$level" in
        ERROR) level_value=40000; type=monitor ;;
        *)     level_value=20000; type=app ;;
    esac

    jq -c -n \
        --arg timestamp "$(now_timestamp)" \
        --arg id "${CONTAINER_ID:--}" \
        --arg name "${CONTAINER_NAME:--}" \
        --arg level "$level" \
        --argjson level_value "$level_value" \
        --arg type "$type" \
        --arg message "$message" \
        '{timestamp: $timestamp, id: $id, name: $name,
          level: $level, level_value: $level_value, type: $type, thread: "-",
          function: "-", user: "-", action: "-", subtype: "NGINX", trace: "-",
          message: $message}' >&3
}

abort() {
    handled=1
    log ERROR "$1"
    exit 1
}

# 起動処理中の標準エラーを退避し、想定外のエラー（列挙した abort 以外）でも
# 原因（失敗コマンドのエラー出力）を含めて JSON 形式でログを残してから終了する。
# fd3=本来の標準エラー（JSONログ出力先）、fd2=退避ファイル。
STARTUP_STDERR=$(mktemp)
exec 3>&2
exec 2>"$STARTUP_STDERR"

handled=0
on_exit() {
    code=$?
    if [ "$code" -ne 0 ] && [ "$handled" -eq 0 ]; then
        detail=$(tail -n 1 "$STARTUP_STDERR" 2>/dev/null)
        log ERROR "コンテナの起動処理で予期せぬエラーが発生しました。（終了コード: ${code}${detail:+ / $detail}）"
    fi
    rm -f "$STARTUP_STDERR"
}
trap on_exit EXIT

# Nginx のエラーログ行 "2026/01/01 00:00:00 [error] 1#1: メッセージ" から重大度を取り出す。
nginx_log_level() {
    case "$1" in
        *'[emerg]'*|*'[alert]'*|*'[crit]'*|*'[error]'*|*'[warn]'*) echo ERROR ;;
        *)                                                          echo INFO ;;
    esac
}

# ---- コンテナIDおよびコンテナ名の取得 ----
# タスクメタデータエンドポイントは Fargate でのみ提供される。取得できない場合は "-" とする。
CONTAINER_ID="-"
CONTAINER_NAME="-"
if [ -n "${ECS_CONTAINER_METADATA_URI_V4:-}" ]; then
    metadata=$(curl -sf --max-time 3 "$ECS_CONTAINER_METADATA_URI_V4" || true)
    if [ -n "$metadata" ]; then
        CONTAINER_ID=$(echo "$metadata" | jq -r '.DockerId // "-"')
        CONTAINER_NAME=$(echo "$metadata" | jq -r '.Name // "-"')
    fi
fi
export CONTAINER_ID CONTAINER_NAME

# ---- 必須環境変数の検証 ----
for name in $REQUIRED_ENV; do
    eval "value=\${$name:-}"
    [ -n "$value" ] || abort "必須環境変数が設定されていません。（環境変数名: ${name}）"
done

# ---- サーバー証明書の検証に用いるルート証明書 ----
# 既定は同梱の Amazon ルート証明書。試験で別の証明書を用いる場合のみ環境変数で差し替える。
BACKEND_CA_FILE="${BACKEND_CA_FILE:-$DEFAULT_BACKEND_CA_FILE}"
[ -f "$BACKEND_CA_FILE" ] || abort "ルート証明書が配置されていません。（配置先: ${BACKEND_CA_FILE}）"
export BACKEND_CA_FILE

# ---- 転送先スキームの検証 ----
# 対応するスキームは http と https のみ。誤設定を早期に検知する。
case "$BACKEND_SCHEME" in
    http|https) ;;
    *) abort "BACKEND_SCHEME は http または https を指定してください。（値: ${BACKEND_SCHEME}）" ;;
esac

# ---- DNS リゾルバの決定 ----
# resolve による都度再解決のため、コンテナの /etc/resolv.conf から nameserver を取得する。
DNS_RESOLVER=$(awk '/^nameserver/ { print $2; exit }' /etc/resolv.conf)
[ -n "$DNS_RESOLVER" ] || abort "DNS リゾルバを特定できませんでした。（/etc/resolv.conf）"
export DNS_RESOLVER

# ---- 転送先定義の生成 ----
# 転送先ドメインごとに upstream を生成する（max_conns は upstream 単位のため）。
destinations=$(jq -r '.destinations[]' "$ROUTING_FILE_PATH") \
    || abort "転送先定義の生成に失敗しました。"
[ -n "$destinations" ] || abort "転送先ドメインを取得できませんでした。（${ROUTING_FILE_PATH}）"

BACKEND_UPSTREAMS=""
BACKEND_UPSTREAM_MAP=""
index=0
for domain in $destinations; do
    index=$((index + 1))
    name="backend_${index}"
    BACKEND_UPSTREAMS="${BACKEND_UPSTREAMS}    upstream ${name} {
        zone ${name} 64k;
        server ${domain}:${BACKEND_PORT} resolve max_conns=${MAX_CONNECTIONS};
        keepalive 32;
    }
"
    BACKEND_UPSTREAM_MAP="${BACKEND_UPSTREAM_MAP}        \"${domain}\" ${name};
"
done
export BACKEND_UPSTREAMS BACKEND_UPSTREAM_MAP

# ---- 振分け定義の生成 ----
# 適用開始・終了（エポックミリ秒）は振分け処理がリクエスト受信時に判定する。
routes=$(jq -c \
    '{routing: (.routing | map_values({domain, dest, start: .apply_start, end: .apply_end})),
      default_routing: (.default_routing | map_values(map({domain, dest, start: .apply_start})))}' \
    "$ROUTING_FILE_PATH") \
    || abort "振分け定義の生成に失敗しました。"
printf 'export default %s;\n' "$routes" > "$ROUTES_JS"

# ---- Nginx 設定ファイルの生成 ----
# 展開対象を明示し、Nginx 自身の変数（$host など）が置換されないようにする。
EXPAND='${CONTAINER_ID} ${CONTAINER_NAME} ${WORKER_CONNECTIONS}
${LIMIT_CONNECTION} ${MAX_BODY_SIZE} ${LIMIT_ZONE_SIZE} ${DNS_RESOLVER}
${BACKEND_SCHEME} ${BACKEND_CA_FILE} ${BACKEND_UPSTREAMS} ${BACKEND_UPSTREAM_MAP}
${PROXY_CONNECT_TIMEOUT} ${PROXY_READ_TIMEOUT} ${PROXY_SEND_TIMEOUT}'

envsubst "$EXPAND" < "$TEMPLATE" > "$NGINX_CONF"

validation=$(nginx -t -c "$NGINX_CONF" 2>&1) \
    || abort "Nginx 設定ファイルの妥当性検証に失敗しました。（${validation}）"

# ---- Nginx の起動 ----
# Nginx のエラーログは JSON 形式で出力できないため、標準エラー出力を受け取って整形する。
rm -f "$ERROR_PIPE"
mkfifo "$ERROR_PIPE"
while IFS= read -r line; do
    log "$(nginx_log_level "$line")" "$line"
done < "$ERROR_PIPE" &

exec nginx -g 'daemon off;' -c "$NGINX_CONF" 2> "$ERROR_PIPE"
