# 修正: 自動設定化（マスキングが無言で無効になる根本対処）

## 症状

`@PostConstruct`／`InitializingBean.afterPropertiesSet()` のいずれも実行されず、`maskRules` が空のままでマスク・出力長制限が一切効かない。

## 原因

`afterPropertiesSet`（Spring コアが生成済み bean に必ず呼ぶ）すら走らない＝**`LoggingProperties` の bean がそもそも生成されていない**。
lib のパッケージ `jp.co.lawson.common.app.lib.logging` が、利用アプリ（`jp.co.nri.lpj`）のコンポーネントスキャン範囲外のため、`@Component`/`@ConfigurationProperties` が拾われず bean 化されない。

## 対処（Spring Boot 自動設定）

利用側のスキャン設定に依存せず、ライブラリが自分で bean 登録するようにした。

- 追加 `LoggingAutoConfiguration`（`@AutoConfiguration` ＋ `@EnableConfigurationProperties(LoggingProperties.class)` ＋ `@ComponentScan(basePackageClasses = LoggingAutoConfiguration.class)`）。
- 追加 `META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`（上記クラスを登録）。
- `LoggingProperties` から `@Component` を除去（`@EnableConfigurationProperties` で登録＋バインドするため。二重登録回避）。`@PostConstruct` → `InitializingBean.afterPropertiesSet()`（jakarta 非依存）も維持。

これで JAR を依存に追加するだけで、`LoggingProperties` ほか lib のコンポーネントが自動登録され、`afterPropertiesSet` が走って `maskRules` が投入される。

## 変更ファイル（src ルートからの相対パスで配置）

- `src/main/java/jp/co/lawson/common/app/lib/logging/LoggingAutoConfiguration.java`（新規）
- `src/main/resources/META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports`（新規）
- `src/main/java/jp/co/lawson/common/app/lib/logging/LoggingProperties.java`（変更：@Component 除去・InitializingBean）
- `src/test/java/jp/co/lawson/common/app/lib/logging/LoggingAutoConfigurationTest.java`（新規・検証）
- `src/test/java/jp/co/lawson/common/app/lib/logging/LoggingPropertiesTest.java`（変更：afterPropertiesSet 呼び出し）

## 重要: パッケージをリネームしている場合

lib パッケージを `jp.co.nri.lpj...` 等へリネームしているなら、以下も実値へ合わせること（文字列参照は IDE リネームに追従しない）。

- `LoggingAutoConfiguration.java` の `package` 宣言
- `AutoConfiguration.imports` 内の FQCN
- logback xml 内の provider/encoder FQCN（既知の注意点）

## 確認

`gradle :lpj-java-lib:test` 緑（62件 / 失敗0 / エラー0）。
うち `LoggingAutoConfigurationTest` が「コンポーネントスキャン無しでも LoggingProperties が登録され maskRules が反映される」ことを検証。
