package jp.co.lawson.common.app.lib.logging;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;

import jp.co.lawson.common.app.lib.logging.constant.LogFields;

/**
 * {@code cosmo-app.logging.*} プロパティ（マスク対象・出力長上限）をバインドし、マスカが参照する静的フィールドへ反映する設定クラス。
 */
@ConfigurationProperties(prefix = "cosmo-app.logging")
public class LoggingProperties implements InitializingBean {

    /** {@code stack_trace} の上限キー。appender（{@code ShortenedThrowableConverter}）で制限するため masker 対象外。 */
    private static final String STACK_TRACE = "stack-trace";

    /** 出力長上限の既定値（UTF-8 バイト）。プロパティ未指定時に使用する。（{@code stack_trace} は appender 側 springProperty が既定を保持する） */
    private static final Map<String, Integer> DEFAULT_LIMITS = Map.of(
            "message", 768,
            LogFields.BODY, 1024,
            LogFields.RESULT, 1024,
            LogFields.HEADERS, 512);

    /** マスカが参照する出力項目→マスク規則。{@code afterPropertiesSet} で反映。既定は空。（何もマスクしない） */
    private static volatile Map<String, MaskRule> maskRules = Map.of();
    /** マスカが参照する出力項目→UTF-8 バイト上限。{@code afterPropertiesSet} で反映。既定は空。 */
    private static volatile Map<String, Integer> fieldLimits = Map.of();

    /** マスク規則。（{@code cosmo-app.logging.mask.<出力項目>}）既定は空。（何もマスクしない） */
    private Map<String, MaskItem> mask = new LinkedHashMap<>();
    /** 出力長上限。（{@code cosmo-app.logging.limits.<出力項目>}）プロパティ指定分のみ保持し、未指定は {@code DEFAULT_LIMITS} で補う。 */
    private Map<String, Integer> limits = new LinkedHashMap<>();

    public Map<String, MaskItem> getMask() {
        return mask;
    }

    public void setMask(Map<String, MaskItem> mask) {
        this.mask = mask;
    }

    public Map<String, Integer> getLimits() {
        return limits;
    }

    public void setLimits(Map<String, Integer> limits) {
        this.limits = limits;
    }

    /**
     * マスカが参照する出力項目ごとのマスク規則を返却する。
     *
     * @return 出力項目名→マスク規則（既定は空）
     */
    public static Map<String, MaskRule> maskRules() {
        return maskRules;
    }

    /**
     * マスカが参照する出力項目ごとの UTF-8 バイト上限を返却する。
     *
     * @return 出力項目名→上限バイト（既定は空）
     */
    public static Map<String, Integer> fieldLimits() {
        return fieldLimits;
    }

    /**
     * 加工済みのマスク規則・出力長上限を静的フィールドへ充填する。（マスカが実行時に参照する）
     *
     * @param rules 出力項目→マスク規則
     * @param limits 出力項目→UTF-8 バイト上限
     */
    public static void install(Map<String, MaskRule> rules, Map<String, Integer> limits) {
        maskRules = Map.copyOf(rules);
        fieldLimits = Map.copyOf(limits);
    }

    /**
     * 起動時にプロパティをマスカ参照用の静的フィールドへ反映する。
     * 正規表現のコンパイル、上限の既定マージ（{@code stack-trace} は除外）を行う。
     * Spring が bean 初期化時に呼び出す（{@code InitializingBean}）。{@code @PostConstruct} と異なり {@code jakarta.annotation} に依存しない。
     * （単体テストのインスタンス生成では実行されないため、テストからは本メソッドを直接実行する）
     */
    @Override
    public void afterPropertiesSet() {
        Map<String, MaskRule> rules = new LinkedHashMap<>();
        mask.forEach((item, cfg) -> rules.put(item, new MaskRule(
                List.copyOf(cfg.getKeys()), cfg.getPatterns().stream().map(Pattern::compile).toList())));

        Map<String, Integer> effective = new LinkedHashMap<>(DEFAULT_LIMITS);
        effective.putAll(limits); // プロパティで上書き・出力項目追加
        effective.remove(STACK_TRACE); // appender 担当のため masker からは除外

        install(rules, effective);
    }

    /** 出力項目ごとのマスク規則（コンパイル済み）。keys＝伏せる名前、patterns＝正規表現。 */
    public record MaskRule(List<String> keys, List<Pattern> patterns) {
    }

    /** 出力項目ごとのマスク設定。keys＝伏せる名前、patterns＝正規表現（文字列）。既定は空。 */
    public static class MaskItem {

        /** 伏せる名前。（{@code headers} はヘッダ名、その他は JSON キー名）一致した値を *** に。 */
        private List<String> keys = new ArrayList<>();
        /** 正規表現。この項目の値で一致した箇所を *** に。 */
        private List<String> patterns = new ArrayList<>();

        public List<String> getKeys() {
            return keys;
        }

        public void setKeys(List<String> keys) {
            this.keys = keys;
        }

        public List<String> getPatterns() {
            return patterns;
        }

        public void setPatterns(List<String> patterns) {
            this.patterns = patterns;
        }
    }
}
