package jp.co.lawson.common.app.lib.logging;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;

/**
 * 本ライブラリのログ部品（マスク設定・各ログ部品）を、利用側のコンポーネントスキャン設定に依存せず自動登録する Spring Boot 自動設定クラス。
 */
@AutoConfiguration
@EnableConfigurationProperties(LoggingProperties.class)
@ComponentScan(basePackageClasses = LoggingAutoConfiguration.class)
public class LoggingAutoConfiguration {
}
