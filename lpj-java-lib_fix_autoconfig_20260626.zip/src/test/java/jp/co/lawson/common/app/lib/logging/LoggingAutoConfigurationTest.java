package jp.co.lawson.common.app.lib.logging;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;

/**
 * {@link LoggingAutoConfiguration} の単体テスト。
 */
class LoggingAutoConfigurationTest {

    private final ApplicationContextRunner runner = new ApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(LoggingAutoConfiguration.class));

    @AfterEach
    void resetStatics() {
        LoggingProperties.install(Map.of(), Map.of());
    }

    /**
     * 自動設定が、利用側のスキャン設定なしで LoggingProperties を登録し初期化すること。
     *
     * 試験条件
     * ・コンポーネントスキャンを設定しない文脈で、mask プロパティ付きで自動設定のみを読み込む。
     * 観点
     * ・利用側のスキャンに依存せず LoggingProperties が bean 登録され、afterPropertiesSet が走ること。
     * 想定結果
     * ・LoggingProperties bean が1つ生成され、maskRules に指定した出力項目が反映されていること。
     */
    @Test
    void registersLoggingPropertiesWithoutComponentScan() {
        runner.withPropertyValues("cosmo-app.logging.mask.headers.keys=authorization")
                .run(context -> {
                    assertThat(context).hasSingleBean(LoggingProperties.class);
                    assertThat(LoggingProperties.maskRules()).containsKey("headers");
                });
    }
}
