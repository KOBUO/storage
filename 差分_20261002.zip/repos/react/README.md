# React 画面配信 Nginx テンプレート

React で作成した画面の静的コンテンツを配信する Nginx のテンプレート。

静的コンテンツはコンテナイメージに同梱する。リクエストURIに対応するファイルが無い場合は、
画面遷移を React が担うため `index.html` を返却する。
あわせて、同時接続数の制限とエラー画面の返却を行う。

S3 へのアップロードとダウンロードを中継する処理（`/s3` 配下）も備える。
`/s3` 配下へのリクエストは S3 へ中継し、S3 が返した応答はそのままクライアントへ返却する。
画面で S3 を利用しない場合は削除できる。

同梱の静的コンテンツ（`docker/nginx/dist/`）は、動作を確認するためのサンプルである。
設計書（`docs/`）は、本部画面を例としたテンプレートである。

## 構成

| ディレクトリ | 内容 |
|---|---|
| `docker/nginx/` | Nginx のイメージ（設定ファイルのテンプレート、中継処理の njs、起動処理、静的コンテンツ） |
| `docs/` | 設計書 |

設定値はすべて環境変数で与える。一覧と既定値は `docs/本部画面.md` の環境変数の節に記載する。

## 利用する場合

各 React のプロジェクトへ複製したうえで次を変更する。

**1. 静的コンテンツを用意する**

React のビルド成果物がそのまま静的コンテンツとなる。
成果物のディレクトリは `.gitlab-ci.yml` の `DIST_DIR` で指定する（既定は `dist`）。
`index.html` と `error.html` は起動時に存在を検証するため、ビルド成果物に含める。
※ `error.html` は Nginx がエラー時に返却する画面であり、各プロジェクトで用意する。

**2. 環境変数を設定する**

タスク定義で環境変数を設定する。

**3. コンテナイメージを作成する**

コンテナイメージの作成と ECR への push は、pipeline-template（`lpj/common/template/pipeline-template`）で行う。
各プロジェクトの `.gitlab-ci.yml` で pipeline-template を `include` し、`.react-docker-build-base` と `.react-ecr-push-base` を利用する。
設定方法は pipeline-template の README を参照する。

**4. S3 への中継が不要な場合**

`docker/nginx/nginx.conf.template` の `location /s3/` と、`docker/nginx/njs/screen.js` の中継処理を削除する。
あわせて `S3_ENDPOINT`・`S3_PORT`・`S3_BUCKET`・`MAX_BODY_SIZE` と、S3 に関するタイムアウトの環境変数が不要になる。
