# pipeline-template README 変更箇所

## 1. 利用イメージ > アプリ開発（ECR Push）> React（70〜99行目）

修正前

````markdown
#### React

Reactでは、`package.json`に加え、`.npmrc`の設定が必要です。

```yaml
include:
  - project: 'lpj/common/template/pipeline-template'
    ref: main
    file: '/templates/common-pipeline.yml'
  - project: 'lpj/common/template/pipeline-template'
    ref: main
    file: '/templates/react-pipeline.yml'

stages:
  - build
  - test
  - sonar
  - docker-build
  - ecr-push

react-docker-build:
  extends: .react-docker-build-base

react-ecr-push:
  extends: .react-ecr-push-base

variables:
  ECR_REPOSITORY: my-app
  SONAR_PROJECT_KEY: lpj-my-app
```
````

修正後

````markdown
#### React

Reactでは、`package.json`に加え、`.npmrc`の設定が必要です。

React のビルド成果物（`dist/`）を Nginx のイメージに同梱して ECR へ Push します。
Nginx の設定ファイルは各プロジェクトで `nginx/` に配置します。詳細は「React の Docker イメージ」を参照してください。

```yaml
include:
  - project: 'lpj/common/template/pipeline-template'
    ref: main
    file: '/templates/common-pipeline.yml'
  - project: 'lpj/common/template/pipeline-template'
    ref: main
    file: '/templates/react-pipeline.yml'

stages:
  - build
  - test
  - eslint
  - sonar
  - docker-build
  - ecr-push

react-docker-build:
  extends: .react-docker-build-base

react-ecr-push:
  extends: .react-ecr-push-base

variables:
  ECR_REPOSITORY: my-app
  SONAR_PROJECT_KEY: lpj-my-app
```
````

## 2. 機能説明 > `templates/react-pipeline.yml` のジョブ一覧（264〜265行目）

修正前

```markdown
| `.react-docker-build-base`  | Docker image を build                             |
| `.react-ecr-push-base`      | Docker image を build し ECR へ Push（タグ時のみ） |
```

修正後

```markdown
| `.react-docker-build-base`  | Nginx の Docker image を build                             |
| `.react-ecr-push-base`      | Nginx の Docker image を build し ECR へ Push（タグ時のみ） |
```

## 3. 機能説明 > `react-sonar` の後（317行目の `---` の前）に追加

````markdown
#### React の Docker イメージ

`react-build` で作成した `dist/` と、プロジェクトの `nginx/` から Nginx のイメージを作成します。
ビルドのコンテキストは `APP_DIR` です。`APP_DIR` に次のファイルを配置してください。

```text
APP_DIR/
├── nginx/                    本リポジトリの nginx/ をコピーして配置する
│   ├── nginx.conf.template   Nginx 設定ファイルのテンプレート
│   ├── entrypoint.sh         起動処理
│   └── njs/                  njs のスクリプト
└── dist/                     react-build の成果物（index.html と error.html を含む）
```

成果物のディレクトリは `DIST_DIR` で変更できます（既定は `dist`）。React のビルドの出力先と合わせてください。

イメージの内容は次のとおりです。

| 項目 | 内容 |
| ---- | ---- |
| ベースイメージ | `nginx:1.30.4-alpine` |
| 追加パッケージ | `gettext` `jq` `curl` `tzdata` `ca-certificates` |
| タイムゾーン | `Asia/Tokyo` |
| 待ち受けポート | `8080` |
| 停止シグナル | `SIGQUIT` |
| 起動 | `nginx/entrypoint.sh` |
````

## 4. ファイル構成（24〜28行目）

修正前

```markdown
| ファイル                          | 内容                                                                     |
| ------------------------------- | ----------------------------------------------------------------------- |
| `templates/common-pipeline.yml` | Docker / DinD / Docker build / ECR Push などの共通定義                       |
| `templates/java-pipeline.yml`   | Java / Gradle 向け build / test / sonar / Nexus publish / ECR push 定義 |
| `templates/react-pipeline.yml`  | React / pnpm 向け build / test / sonar / Nexus publish / ECR push 定義  |
```

修正後

```markdown
| ファイル                          | 内容                                                                     |
| ------------------------------- | ----------------------------------------------------------------------- |
| `templates/common-pipeline.yml` | Docker / DinD / Docker build / ECR Push などの共通定義                       |
| `templates/java-pipeline.yml`   | Java / Gradle 向け build / test / sonar / Nexus publish / ECR push 定義 |
| `templates/react-pipeline.yml`  | React / pnpm 向け build / test / sonar / Nexus publish / ECR push 定義  |
| `nginx/`                        | React の Docker イメージで使う Nginx の設定ファイル等。各プロジェクトへコピーして使用する |
```

## 5. CI 変数 > テンプレートグローバル変数（396行目の後に追加）

```markdown
| `DIST_DIR`                   | `"dist"`                           | React のビルド成果物のディレクトリ。`APP_DIR` からの相対パス |
```

## 6. CI 変数 > プロジェクト変数（432行目の後に追加）

```markdown
| `DIST_DIR`           | React のビルド成果物のディレクトリ。未指定時は `dist` |
```

## 7. 機能説明 > react-pipeline.yml のジョブ一覧と `react-test`（261行目、294〜310行目）

ジョブ一覧（261行目）

修正前

```markdown
| `react-test`                | pnpm test:ci を実行 (Vitest)                     |
```

修正後

```markdown
| `react-test`                | pnpm coverage を実行 (Vitest)                    |
```

`react-test`（294〜310行目）

修正前

````markdown
#### `react-test`

Vitest を利用してテストを実行し、カバレッジレポートを生成します。

```bash
pnpm --dir "$APP_DIR" run test:ci
```

`package.json` に以下のスクリプトを定義してください。

```json
{
  "scripts": {
    "test:ci": "vitest run --coverage"
  }
}
```
````

修正後

````markdown
#### `react-test`

Vitest を利用してテストを実行し、カバレッジレポートを生成します。

```bash
pnpm --dir "$APP_DIR" run coverage
```

`package.json` に以下のスクリプトを定義してください。

```json
{
  "scripts": {
    "coverage": "vitest run --coverage"
  }
}
```
````
