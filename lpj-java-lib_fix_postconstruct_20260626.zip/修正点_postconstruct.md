# 修正: @PostConstruct → InitializingBean（マスキングが無言で無効になる不具合）

## 症状

`@PostConstruct`（`LoggingProperties.init`）が環境によって発火せず、`maskRules` が空のままになり、マスク・出力長制限が一切効かない（秘密値が素のまま出力される）。

## 原因

`@PostConstruct` は `jakarta.annotation-api` が実行時クラスパスに在って初めて処理される。web/sqs を `compileOnly` 化したことで lib の `runtimeClasspath` から `jakarta.annotation-api` が外れ、依存が揃わない環境では `@PostConstruct` が黙ってスキップされる。

## 対処

`LoggingProperties` を `@PostConstruct` から Spring コアの `InitializingBean.afterPropertiesSet()` に変更。`jakarta.annotation` に非依存で、bean 初期化時に必ず実行される。

## 変更ファイル

- `LoggingProperties.java` … `implements InitializingBean`、`@PostConstruct void init()` → `@Override public void afterPropertiesSet()`、`jakarta.annotation.PostConstruct` import 削除、javadoc 追従。
- `LoggingPropertiesTest.java` … `props.init()` → `props.afterPropertiesSet()`、javadoc 追従。

## 確認

`gradle :lpj-java-lib:test` 緑（61件 / 失敗0 / エラー0）。Windows 側は `LoggingProperties.java` を差し替えれば解消（テストも持つ場合は `LoggingPropertiesTest.java` も差し替え）。
