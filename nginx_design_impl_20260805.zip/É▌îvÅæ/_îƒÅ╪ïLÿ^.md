# 結合検証記録（代替環境）

実環境の代替で **3パターンを実結合検証**した記録。ハーネスは `test/` 配下（docker compose）。
- S3 → **MinIO**、Aurora → **PostgreSQL**、backend → **traefik/whoami**、React資材 → **同梱サンプル**。
- nginx は **本番テンプレートをそのままビルド**（`nginx:1.28-alpine`、entrypoint で envsubst→`nginx -t`→起動）。

> ※ 代替での機能確認。実 S3(SigV4)・実 Aurora・実業務backend での確認は別途要（本番前）。

## ① 電文受付API（`test/01-denbun/`）= 全ケース PASS

構成: Postgres(init.sql)→loader→`/shared/routing.json`→entrypointが`routes.js`生成→njs BODY振分け→whoami×2 / go-httpbin(遅延)。

### ルーティング / エラー
| ケース | 結果 |
|--------|------|
| カナリア対象 000002+v2（POST body）| → **shop0002-v2-backend** ✅ |
| 対象外店舗 000001+v2 | → default ✅ |
| version未登録 000002+v1 | → default ✅ |
| BODY無し(GET) | → default ✅ |
| 未定義パス | → **404固定JSON（本文まで確認）** ✅ |
| BODY異常（非JSON / 空）| → default（設計どおり）✅ |

### 時間指定カナリア（start_at/end_at）
| ケース | 結果 |
|--------|------|
| 000002 有効期間内 | → shop ✅ |
| 000003 start_at=未来 | → **default（まだ無効）** ✅ |
| 000004 end_at=過去 | → **default（期限切れ）** ✅ |

### 流量制御・タイマー（実発火）
| 制御 | 条件 | 結果 |
|------|------|------|
| `limit_req` | rate=1r/s,burst=2 を30並列 | 200×3 / **503×27** ✅ |
| `limit_conn` | =1 で /delay/2 を5並列 | 200×1 / **503×4** ✅ |
| `max_conns` | =1 で /delay/1 を3並列 | 200×1 / **502×2** ✅ |
| タイマー | read_timeout=2s で /delay/5 | **504** ✅ |

→ **DB状態からの動的proxy（カナリア）＋時間指定＋流量制御＋タイマーが実動作**。

## ② ファイルDL（`test/02-filedl/`）= PASS（codex最大懸念を実証）

構成: MinIO にファイル配置→**path-style 署名付きURL**発行→nginx が **Host置換**して中継。

| ケース | 結果 |
|--------|------|
| 正常DL（署名付URL→nginx→MinIO）| → **200・中身一致** ✅ |
| 署名改ざん | → **403 素通し** ✅ |
| 不在キー | → 403 素通し ✅ |
| `/download/`以外 | → 404 ✅ |
| **帯域制御 `limit_rate`=1m** | 5MB → **5.16s（≒1MB/s）** ✅（無制限時0.016s）|

→ **「path-style＋Host置換で署名が通る」を実証**（codex #2 の403リスクに対する裏取り）。

> ★**検証で発見・修正した実装バグ**: `proxy_buffering off` だと **`limit_rate`（DL速度制限, 4-2-2/4-3-17）が効かない**
> （off:0.02s / on:5.16s）。方式資料は下り速度制限が必須のため、②③テンプレを **`proxy_buffering on`** に修正（UL方向の
> `proxy_request_buffering off` は独立で維持）。修正後 limit_rate が効くことを再検証済。

## ③ React（`test/03-react/`）= PASS

構成: **同梱root配信**（dist/ をイメージにCOPY）＋ `/files/` は MinIO 中継。

| ケース | 結果 |
|--------|------|
| 静的 index.html / assets/app.js | → 200・中身一致 ✅ |
| **SPA fallback**（未定義URL /orders/123, /admin/foo/bar）| → **index.html 200**（404にしない）✅ |
| `/files/` DL中継（署名付URL→MinIO）| → 200・中身一致 ✅ |
| `/files/` 署名改ざん | → 403 素通し ✅ |
| **`/files/` UL中継（presigned PUT→MinIO）** | → **PUT 200・MinIOに実保存を確認** ✅ |

→ **同梱静的配信＋SPA fallback＋S3のUL/DL中継（双方向）が動作**。

## 実施で確定/変更した仮決め（→設計・実装へ反映済）

| 項目 | 仮決め | 反映 |
|------|--------|------|
| Q14 React配置 | **ECS同梱（root配信）** ※利用者の記憶と一致 | 03テンプレを同梱rootに変更、S3バックは代替コメント |
| Q11/Q12 S3署名 | **path-style + Host置換**、endpoint=`host:port` | ②で実証。設計に明記 |
| Q5/Q6 BODY項目 | `storeCode` | ①で動作確認 |
| Q7 テーブル | init.sql（仮スキーマ）| `test/01-denbun/init.sql`。本番はテーブル定義書と突合 |
| 実装追加 | `S3_SCHEME`（既定https, 検証http）/ `REACT_ROOT`（同梱） | ②③テンプレ・entrypoint |
| **実装修正(バグ)** | `proxy_buffering off`→**on**（limit_rateが効かない不具合）| ②③テンプレ。検証で発見・再検証済 |

## 再現方法

```
cd test/01-denbun && docker compose up -d --build   # ①
cd test/02-filedl && docker compose up -d --build   # ②（out/にpresigned生成）
cd test/03-react  && docker compose up -d --build   # ③
# 各 README/この記録の curl で確認 → docker compose down -v
```

## 代替環境での検証カバレッジ（完了）
- ①: ルーティング / 時間指定カナリア / 404本文 / BODY異常 / **limit_req・limit_conn・max_conns・タイマー504** 実発火
- ②: 署名DL / 改ざん403 / **limit_rate 帯域制御**（proxy_buffering修正後）
- ③: 同梱静的 / SPA fallback / **UL・DL中継（双方向）**
- ※流量制御の設定は3パターンで同一のため、①で代表的に実発火確認（②③も同一directive）。

## 残（TODO＝仮決め / AWS未検証 のみ）
- 実 S3 での SigV4（本番 https・実エンドポイント形式）／ `PROXY_SSL_VERIFY` 方針。
- 実 Aurora・実業務backend での①通し／ テーブル定義書との突合（Q7）。
- 仮決め（Q14 同梱 / Q11・Q12 path-style / スキーマ）のチーム最終承認。

---

# 追記: 2026-08-05 検証（利用者指示4件の反映後）

対象実装 = 現行 `templates/`（清書世代 = ①ヘッダー方式）。全ケース **PASS**。

## ① 電文受付（`test/01-denbun/`）— スキーマ変更 + 新エラー電文

routing に**適用開始日・適用終了日**、default_routing に**適用開始日時（主キー）**を追加した init.sql / loader.py /
entrypoint.sh / route.js の新実装で検証。

| ケース | 結果 |
|--------|------|
| カナリア対象 000002 `order/v2`（`X-Store-Cd` ヘッダー・適用期間内）| → **shop backend** ✅ |
| 000003 `order/v2`（適用期間 2020年で**期限切れ**）| → **default へフォールバック** ✅ |
| 一般店舗 `order/v2`（default_routing に**将来世代 2099-01-01** あり）| → **現行世代(default)** ✅ 将来世代は未適用 |
| `order/v1` | → default ✅ |
| `X-Store-Cd` 欠落 | → **400** `{"apiStatus":"400","errors":[{"validationErrCd":"400","validationMessage":"Bad Request"}]}` ✅ |
| ルーティング先なし | → **404** `{"apiStatus":"404",...,"validationMessage":"Not Found"}` ✅ |
| backend 停止（connect timeout）| → **504** 新エラー電文（`error_page`→njs 差し替え動作）✅ |

- loader.py 単体: JST日付→エポックミリ秒換算（2020-01-01→1577804400000）、終了日=翌日0時（排他）、
  世代の**降順整列**をユニットテストで確認 ✅

## ② ファイルDL（`test/02-filedl/`）— X-BandWidth-Limit(Mbps) + S3素通し

※ MinIO は http のため、検証時のみ `proxy_pass https://s3`→`http://s3` に差し替えた conf を volume mount
（compose override）。テンプレ本体は https のまま。

| ケース | 結果 |
|--------|------|
| `X-BandWidth-Limit` 欠落 | → **400** 新エラー電文 ✅ |
| `X-BandWidth-Limit: abc`（不正値）| → **400** 新エラー電文 ✅ |
| 対象外パス | → **404** 新エラー電文 ✅ |
| 正常DL（`X-BandWidth-Limit: 8`）| → 200・中身一致 ✅ |
| **Mbps換算の実測**: 3MB を `8`(Mbps=1MB/s) | → **3.2s**（`800` 指定時 0.016s）✅ **×125,000 換算が機能** |
| 署名改ざん | → **403・S3のXML本文そのまま素通し**（JSON変換の廃止を確認）✅ |

## ③ React（`test/03-react/`）— エラー時 index.html

| ケース | 結果 |
|--------|------|
| 静的 `assets/app.js` | → 200 ✅ |
| SPA fallback（`/orders/123`）| → index.html 200 ✅ |
| **レート超過（rate=1r/s で連打）** | → **503・本文=index.html**（エラー電文でない）✅ |
| 503 時のログ | → `level:ERROR / message:リクエストのレートまたは同時接続数が上限を超えました。` ✅ |
