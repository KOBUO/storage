import routes from '/etc/nginx/njs/routes.js';

var STORE_CODE_HEADER = 'X-Store-Cd';

// generatedByNginx は Nginx 自身が生成する応答であることを示す。
// message はログ出力用。応答本文は HTTPステータスから一意に定める（respondError 参照）。
var ERRORS = {
    store_code_missing: { status: 400, message: '店舗コードが設定されていません。' },
    route_not_found:    { status: 404, message: 'ルーティング先が特定できません。' },
    limit_exceeded:     { status: 503, message: 'リクエストのレートまたは同時接続数が上限を超えました。', generatedByNginx: true },
    backend_unreachable:{ status: 502, message: 'バックエンドサービスへ接続できません。', generatedByNginx: true },
    backend_timeout:    { status: 504, message: 'バックエンドサービスからの応答がタイムアウトしました。', generatedByNginx: true },
    internal_error:     { status: 500, message: 'サーバ内部でエラーが発生しました。', generatedByNginx: true },
};

var REASON_PHRASES = {
    400: 'Bad Request',
    404: 'Not Found',
    500: 'Internal Server Error',
    502: 'Bad Gateway',
    503: 'Service Unavailable',
    504: 'Gateway Timeout',
};

function nginxErrorCodeOf(status) {
    for (var code in ERRORS) {
        if (ERRORS[code].generatedByNginx && ERRORS[code].status === status) {
            return code;
        }
    }
    return null;
}

// エラー電文（API共通仕様書のレスポンス仕様）。
// Nginx はステータス以外に理由を示す情報を持たないため、各項目はステータスから一意に定める。
function respondError(r, code) {
    var error = ERRORS[code];
    var status = String(error.status);
    // ログ出力時に応答したエラーを参照できるよう保持する。
    r.variables.error_code = code;
    r.headersOut['Content-Type'] = 'application/json';
    r.return(error.status, JSON.stringify({
        apiStatus: status,
        errors: [{ validationErrCd: status, validationMessage: REASON_PHRASES[error.status] }],
    }));
}

// リクエストURI /{コンテキストパス}/{バージョン}/{API名} から検索キーの構成要素を取り出す。
function splitUri(uri) {
    var segments = uri.split('/').filter(function (segment) {
        return segment !== '';
    });
    if (segments.length < 2) {
        return null;
    }
    return { contextPath: segments[0], version: segments[1] };
}

// 適用開始日・適用終了日はエポックミリ秒で保持される（開始は当日0時、終了は翌日0時=排他）。
function withinPeriod(entry, now) {
    if (entry.start !== null && now < entry.start) {
        return false;
    }
    if (entry.end !== null && now >= entry.end) {
        return false;
    }
    return true;
}

function lookupUpstream(storeCode, path) {
    var now = Date.now();

    // ルーティング情報は、適用期間内の場合のみ用いる。期間外は取得できなかったものとして扱う。
    var entry = routes.routing[storeCode + '|' + path.contextPath + '|' + path.version];
    if (entry && withinPeriod(entry, now)) {
        return entry.upstream;
    }

    // デフォルトルーティング情報は適用開始日時の降順に並ぶため、
    // 先頭から探索し、適用開始日時が現在日時以前の最新世代を用いる。
    var generations = routes.default_routing[path.contextPath + '|' + path.version];
    if (generations) {
        for (var i = 0; i < generations.length; i++) {
            if (generations[i].start === null || generations[i].start <= now) {
                return generations[i].upstream;
            }
        }
    }
    return null;
}

function handle(r) {
    var storeCode = r.headersIn[STORE_CODE_HEADER];
    if (!storeCode) {
        respondError(r, 'store_code_missing');
        return;
    }

    var path = splitUri(r.uri);
    var upstream = path ? lookupUpstream(storeCode, path) : null;
    if (!upstream) {
        respondError(r, 'route_not_found');
        return;
    }

    r.variables.upstream = upstream;
    r.internalRedirect('@backend');
}

// Nginx が生成したエラー応答をエラー電文に差し替える。
// error_page からの呼び出し時点では r.status が未確定のため、$status から元の応答コードを取る。
function errorResponse(r) {
    var code = nginxErrorCodeOf(Number(r.variables.status));
    respondError(r, code || 'internal_error');
}

// エラーコードが設定されているのは、Nginx がエラー応答を返した場合のみ。
// バックエンドサービスが返したエラーは Nginx としては正常処理のため INFO とする。
function logLevel(r) {
    return r.variables.error_code ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    var code = r.variables.error_code;
    return code ? ERRORS[code].message : '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { handle, errorResponse, logLevel, logMessage, logLatency, logTimestamp };
