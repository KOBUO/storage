# ECS タスク定義（電文受付 / Nginx + ルーティング情報取得サイドカー）

## コンテナ構成

```
Task: denbun-api (Fargate / awsvpc / LINUX)   cpu/memory: TODO サイジング
├─ container: nginx   (essential=true)
│   image: <ECR>/denbun-api-nginx:<tag>
│   portMappings: 80/tcp
│   environment:
│     WORKER_CONNECTIONS      = 512
│     MAX_CONNECTIONS         = 10
│     LIMIT_REQUEST_RATE      = 10r/s
│     LIMIT_REQUEST_BURST     = 20
│     LIMIT_CONNECTION        = 10
│     PROXY_CONNECT_TIMEOUT   = 5s
│     PROXY_READ_TIMEOUT      = 60s
│     PROXY_SEND_TIMEOUT      = 60s
│   mountPoints: shared-volume → /shared (readOnly=true)
│   dependsOn:   loader (condition=SUCCESS)
│   logConfiguration: awslogs
│
└─ container: loader  (essential=false)
    image: <ECR>/denbun-api-loader:<tag>
    environment:
      DATABASE_HOST            = <aurora-endpoint>
      DATABASE_PORT            = 5432
      DATABASE_NAME            = <db_name>
      DATABASE_USER            = <db_user>
      DATABASE_CONNECT_TIMEOUT = 5
    secrets:
      DATABASE_PASSWORD = arn:aws:secretsmanager:<region>:<account>:secret:<name>:password::
    mountPoints: shared-volume → /shared (readOnly=false)
    logConfiguration: awslogs

volumes: shared-volume (host: {})
family: denbun-api
executionRoleArn: <TaskExecutionRole>   # secretsmanager:GetSecretValue の権限が必要
networkMode: awsvpc
requiresCompatibilities: [FARGATE]
```

## 補足

- コンテナIDおよびコンテナ名は、タスクメタデータエンドポイントから起動時に取得するため、環境変数での指定は不要。
- ルーティング情報の変更を反映するには、タスクの再起動を要する。
- サイドカーが異常終了した場合、Nginx コンテナは起動せず、タスクの起動に失敗する。
- TODO cpu / memory のサイジング。
