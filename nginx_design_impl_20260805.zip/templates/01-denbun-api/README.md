# 電文受付（Nginx + ルーティング情報取得サイドカー）

設計: [`../../設計書/清書_電文受付.md`](../../設計書/清書_電文受付.md)

## 構成

| ファイル | 役割 |
|---|---|
| `loader/entrypoint.sh` | コンテナIDおよびコンテナ名を取得し、`loader.py` を実行する |
| `loader/loader.py` | Aurora DB からルーティング情報を取得し、共有ボリュームへ出力する |
| `entrypoint.sh` | コンテナIDおよびコンテナ名を取得し、振分け定義と転送先定義を生成して Nginx を起動する |
| `njs/route.js` | 店舗コードとリクエストURIから転送先を決定する。エラー応答とログ項目の組み立ても行う |
| `nginx.conf.template` | 環境変数を展開して Nginx 設定ファイルを生成する雛形 |

## 起動時の流れ

```
サイドカーコンテナ
  Aurora DB → ルーティング情報ファイル（/shared/routing.json）

Nginx コンテナ（サイドカーの正常終了後）
  ルーティング情報ファイル
    ├→ 振分け定義  （/etc/nginx/njs/routes.js）    検索キー → upstream 名
    └→ 転送先定義  （/etc/nginx/upstreams.conf）   upstream 名 → 接続先、同時接続数の上限
```

## ルーティング情報ファイルの形式

```json
{
  "routing": {
    "000002|order|v2": { "url": "http://blue.internal:8080", "apply_start": 1577804400000, "apply_end": 4102412400000 }
  },
  "default_routing": {
    "order|v2": [
      { "url": "http://green.internal:8080", "apply_start": 1577804400000 }
    ]
  }
}
```

検索キーは、ルーティング情報が `店舗コード|コンテキストパス|バージョン`、
デフォルトルーティング情報が `コンテキストパス|バージョン`。

- `apply_start` / `apply_end` は適用開始・終了のエポックミリ秒（JSTで解釈した値。終了は翌日0時＝排他）。
- デフォルトルーティング情報は同一キーに複数の世代を持ち、**適用開始日時の降順**に整列される。
  振分け時は、適用開始日時が現在日時以前で最新の世代を用いる（時間指定リリース）。

## 環境変数

| 変数 | 対象 | 例 |
|---|---|---|
| `DATABASE_HOST` / `DATABASE_PORT` / `DATABASE_NAME` / `DATABASE_USER` / `DATABASE_PASSWORD` | サイドカー | — |
| `DATABASE_CONNECT_TIMEOUT` | サイドカー | `5` |
| `WORKER_CONNECTIONS` | Nginx | `512` |
| `MAX_CONNECTIONS` | Nginx | `10` |
| `LIMIT_REQUEST_RATE` / `LIMIT_REQUEST_BURST` | Nginx | `10r/s` / `20` |
| `LIMIT_CONNECTION` | Nginx | `10` |
| `PROXY_CONNECT_TIMEOUT` / `PROXY_READ_TIMEOUT` / `PROXY_SEND_TIMEOUT` | Nginx | `5s` / `60s` / `60s` |

`CONTAINER_ID` と `CONTAINER_NAME` は、タスクメタデータエンドポイントから起動時に取得して設定する。

## ログ

アクセスログを標準出力へ、起動時および稼働中のエラーログを標準エラー出力へ、いずれも JSON 形式で出力する。
Nginx 自身のエラーログは JSON 形式で出力できないため、`entrypoint.sh` が受け取って整形する。

## TODO

- ルーティング情報のテーブル定義（列名 `routing_url` / `apply_start_date` / `apply_end_date` /
  `apply_start_datetime` は仮）をテーブル定義書と突合する。
- エラー電文は `{"apiStatus","errors":[{"validationErrCd","validationMessage"}]}` 形式
  （各値はHTTPステータスとリーズンフレーズから一意に定める。2026-08-05 確定）。
