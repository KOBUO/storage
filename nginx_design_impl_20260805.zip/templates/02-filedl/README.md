# ファイルダウンロード（S3 中継）— ビルド一式

設計: [`../../設計書/清書_ファイルダウンロード.md`](../../設計書/清書_ファイルダウンロード.md)

API が発行した署名付きURLのリクエストを受け、`Host` を S3 のエンドポイントに置換して中継する。
Nginx は署名を行わず、署名およびオブジェクトキーの妥当性は S3 の判断に委ねる。

## 構成

| ファイル | 役割 |
|---------|------|
| `nginx.conf.template` | S3 中継（Host置換）・エラー電文・JSONログの雛形 |
| `njs/download.js` | 帯域制限値の検証・換算、オブジェクトキーの組み立て、エラー電文とログ項目の組み立て |
| `entrypoint.sh` | コンテナID/名の取得 → 必須環境変数の検証 → conf 生成 → `nginx -t` → nginx 起動 |
| `Dockerfile` | nginx（njs 同梱）+ 検証用ツール |

## 帯域制御（ヘッダ駆動）

- リクエストヘッダ **`X-BandWidth-Limit`**（単位 **Mbps**）で下りの帯域制限値が指定される。
- njs が値（数値）を検証し、**バイト/秒へ換算（Mbps × 125,000）**して `$limit_rate` に設定する。
- ヘッダ欠落・不正値は **400**（エラー電文）。`0` は無制限（`limit_rate 0` の仕様）。
- `limit_rate` を効かせるため `proxy_buffering on` が前提（off だと効かない。検証済）。

## エラー応答

- Nginx 自身が生成するエラー（400/404/502/504/500 等）は、エラー電文で返却する。

```json
{"apiStatus":"400","errors":[{"validationErrCd":"400","validationMessage":"Bad Request"}]}
```

- **S3 が返却したエラーは加工せず、ステータス・本文（XML）ともそのまま返却する**（`proxy_intercept_errors off`）。

## 環境変数

| 変数 | 例 | 説明 |
|------|-----|------|
| `WORKER_CONNECTIONS` | `512` | ワーカーあたり同時接続数上限 |
| `S3_ENDPOINT` | `s3.ap-northeast-1.amazonaws.com` | 中継先 S3（Host置換先）。バケット名は含まない |
| `OFFLINE_BUCKET` | `cosmo-offline-files` | オフラインファイル用バケット |
| `PROXY_CONNECT_TIMEOUT` / `PROXY_READ_TIMEOUT` / `PROXY_SEND_TIMEOUT` | `5s` / `60s` / `60s` | S3 向けタイムアウト |

`CONTAINER_ID` / `CONTAINER_NAME` は起動時にタスクメタデータエンドポイントから取得する。
`S3_ADDRESS`（upstream 用 `host:port`）は `entrypoint.sh` が `S3_ENDPOINT` から組み立てる。

## 検証

`../../test/02-filedl/`（MinIO を S3 の代替とする docker compose）。
帯域制御の実測は 2026-08-05 PASS（`X-BandWidth-Limit: 8` 指定で 3MB ≒ 3.2秒）。詳細は `設計書/_検証記録.md`。
