var BANDWIDTH_HEADER = 'X-BandWidth-Limit';
var POS_VERSION_PARAMETER = 'posVersion';
var CONTEXT_PATH = '/download/';
var OFFLINE_PATH = '/download/offline/';

// 帯域制限値ヘッダの単位は Mbps。limit_rate はバイト毎秒のため換算する（1Mbps = 125,000バイト/秒）。
var BYTES_PER_SECOND_PER_MBPS = 125000;

// generatedByNginx は Nginx 自身が生成する応答であることを示す。
// message はログ出力用。応答本文は HTTPステータスから一意に定める（respondError 参照）。
// S3 が返却したエラーは加工せず、そのままクライアントへ返却する。
var ERRORS = {
    bandwidth_missing:  { status: 400, message: '帯域制限値が設定されていません。' },
    bandwidth_invalid:  { status: 400, message: '帯域制限値が不正です。' },
    pos_version_missing:{ status: 400, message: 'POSバージョンが設定されていません。' },
    path_not_supported: { status: 404, message: '対象外のパスです。' },
    s3_unreachable:     { status: 502, message: 'S3 へ接続できません。', generatedByNginx: true },
    s3_timeout:         { status: 504, message: 'S3 からの応答がタイムアウトしました。', generatedByNginx: true },
    internal_error:     { status: 500, message: 'サーバ内部でエラーが発生しました。', generatedByNginx: true },
};

var REASON_PHRASES = {
    400: 'Bad Request',
    404: 'Not Found',
    500: 'Internal Server Error',
    502: 'Bad Gateway',
    503: 'Service Unavailable',
    504: 'Gateway Timeout',
};

function nginxErrorCodeOf(status) {
    for (var code in ERRORS) {
        if (ERRORS[code].generatedByNginx && ERRORS[code].status === status) {
            return code;
        }
    }
    return null;
}

// エラー電文（API共通仕様書のレスポンス仕様）。
// Nginx はステータス以外に理由を示す情報を持たないため、各項目はステータスから一意に定める。
function respondError(r, code) {
    var error = ERRORS[code];
    var status = String(error.status);
    r.variables.error_code = code;
    r.headersOut['Content-Type'] = 'application/json';
    r.return(error.status, JSON.stringify({
        apiStatus: status,
        errors: [{ validationErrCd: status, validationMessage: REASON_PHRASES[error.status] }],
    }));
}

function queryParameters(r) {
    var parameters = {};
    (r.variables.args || '').split('&').forEach(function (pair) {
        if (!pair) {
            return;
        }
        var separator = pair.indexOf('=');
        var name = separator < 0 ? pair : pair.substring(0, separator);
        parameters[name] = separator < 0 ? '' : pair.substring(separator + 1);
    });
    return parameters;
}

// クエリパラメータが残る場合のみ "?" を付けた文字列を返す。
function buildQuery(parameters) {
    var query = Object.keys(parameters).map(function (name) {
        return name + '=' + parameters[name];
    }).join('&');
    return query ? '?' + query : '';
}

// オフラインファイルダウンロードは、バケット名と POSバージョンを Nginx がオブジェクトキーへ組み込む。
function buildOfflineKey(r) {
    var parameters = queryParameters(r);
    var posVersion = parameters[POS_VERSION_PARAMETER];
    if (!posVersion) {
        return null;
    }
    delete parameters[POS_VERSION_PARAMETER];
    r.variables.s3_args = buildQuery(parameters);

    var fileName = r.uri.substring(OFFLINE_PATH.length);
    return '/' + r.variables.offline_bucket + '/' + posVersion + '/' + fileName;
}

function handle(r) {
    var bandwidth = r.headersIn[BANDWIDTH_HEADER];
    if (!bandwidth) {
        respondError(r, 'bandwidth_missing');
        return;
    }
    if (!/^[0-9]+$/.test(bandwidth)) {
        respondError(r, 'bandwidth_invalid');
        return;
    }

    if (!r.uri.startsWith(CONTEXT_PATH)) {
        respondError(r, 'path_not_supported');
        return;
    }

    var key;
    if (r.uri.startsWith(OFFLINE_PATH)) {
        key = buildOfflineKey(r);
        if (!key) {
            respondError(r, 'pos_version_missing');
            return;
        }
    } else {
        key = r.uri.substring(CONTEXT_PATH.length - 1);
        r.variables.s3_args = r.variables.args ? '?' + r.variables.args : '';
    }

    // Mbps をバイト毎秒へ換算して下り帯域を制限する（0 は無制限 = limit_rate の仕様）。
    r.variables.limit_rate = String(Number(bandwidth) * BYTES_PER_SECOND_PER_MBPS);
    r.variables.s3_key = key;
    r.internalRedirect('@s3');
}

// Nginx が生成したエラー応答をエラー電文に差し替える。
// S3 が返却したエラーは proxy_intercept_errors off のためここへは到達せず、そのまま返却される。
// error_page からの呼び出し時点では r.status が未確定のため、$status から元の応答コードを取る。
function errorResponse(r) {
    var code = nginxErrorCodeOf(Number(r.variables.status));
    respondError(r, code || 'internal_error');
}

// エラーコードが設定されているのは、Nginx がエラー応答を返した場合のみ。
// S3 が返却したエラーは Nginx としては正常処理のため INFO とする。
function logLevel(r) {
    return r.variables.error_code ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    var code = r.variables.error_code;
    return code ? ERRORS[code].message : '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { handle, errorResponse, logLevel, logMessage, logLatency, logTimestamp };
