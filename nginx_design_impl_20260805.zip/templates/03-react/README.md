# 本部画面（React 静的配信）— ビルド一式

設計: [`../../設計書/清書_本部画面.md`](../../設計書/清書_本部画面.md)

本部画面（React）の静的コンテンツを配信する。**React のビルド資材はコンテナイメージに同梱する（確定）**。
認証は ALB（Entra ID / OIDC）が担い、Nginx は認証を行わない。

## 構成

| ファイル | 役割 |
|---------|------|
| `nginx.conf.template` | 静的配信・SPA fallback・流量制御・JSONログの雛形 |
| `njs/screen.js` | ログ項目（タイムスタンプ・レベル・メッセージ・処理時間）の組み立て |
| `entrypoint.sh` | コンテナID/名の取得 → 必須環境変数の検証 → 静的資材の検証 → conf 生成 → `nginx -t` → nginx 起動 |
| `Dockerfile` | nginx（njs 同梱）+ `dist/` を `/usr/share/nginx/html` へ COPY |
| `dist/` | 検証用サンプルの React ビルド資材（本番は実資材に差し替え）|

## 応答の方針

- 存在する静的ファイル → そのまま返却（200）。
- 存在しないURI → 画面遷移は React が担うため **index.html を 200 で返却**（`try_files`、SPA fallback）。
- **Nginx が生成するエラー（流量制御の 503 等）も index.html を返却**する（`error_page`）。
  エラー電文（JSON）は返却しない。返却ステータスは維持する（2026-08-05 確定）。

## 環境変数

| 変数 | 例 | 説明 |
|------|-----|------|
| `WORKER_CONNECTIONS` | `512` | ワーカーあたり同時接続数上限 |
| `LIMIT_REQUEST_RATE` / `LIMIT_REQUEST_BURST` | `10r/s` / `20` | レート制限 |
| `LIMIT_CONNECTION` | `10` | 同時接続数上限 |

`CONTAINER_ID` / `CONTAINER_NAME` は起動時にタスクメタデータエンドポイントから取得する。

## 検証

`../../test/03-react/`（docker compose）。静的配信 / SPA fallback / 503→index.html は 2026-08-05 PASS。
詳細は `設計書/_検証記録.md`。
