// エラー応答はエラー電文ではなく index.html を返却するため（画面遷移は React が担う）、
// 本モジュールはログ出力のみを担当する。

// Nginx が生成するエラーのうちログへ残すメッセージ。応答本文は index.html（ステータス維持）。
var ERROR_MESSAGES = {
    503: 'リクエストのレートまたは同時接続数が上限を超えました。',
    500: 'サーバ内部でエラーが発生しました。',
};

// Nginx に起因するエラー（5xx）の場合は ERROR、それ以外は INFO とする。
function logLevel(r) {
    return Number(r.variables.status) >= 500 ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    return ERROR_MESSAGES[Number(r.variables.status)] || '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { logLevel, logMessage, logLatency, logTimestamp };
