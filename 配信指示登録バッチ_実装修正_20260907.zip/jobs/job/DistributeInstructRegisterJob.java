package jp.co.lawson.laif.bt.daemon.jobs.job;

import jp.co.lawson.common.app.lib.logging.ApplicationLogger;
import jp.co.lawson.laif.bt.daemon.jobs.service.DistributeInstructRegisterServiceImpl;
import jp.co.nri.cortixa.batch.daemon.job.DaemonJob;
import jp.co.nri.xpalette.batch.core.exception.JobExecFailedException;
import jp.co.nri.xpalette.batch.core.result.JobExecutionResult;
import jp.co.nri.xpalette.batch.core.runner.JobContext;
import jp.co.nri.xpalette.batch.core.runner.JobIdentifier;
import lombok.RequiredArgsConstructor;

/**
 * 配信指示登録バッチ
 */
@JobIdentifier("DLAIF0100001")
@RequiredArgsConstructor
public class DistributeInstructRegisterJob extends DaemonJob {

    // ログ共通部品から取得したアプリロガー
    private static final ApplicationLogger log = ApplicationLogger.getLogger();

    private final DistributeInstructRegisterServiceImpl distributeInstructRegisterService;

    @Override
    protected JobExecutionResult execute(JobContext jobContext) {
        log.info("Job DLAIF0100001 start.");
        Long startTime = System.currentTimeMillis();
        String area = jobContext.getApplicationArguments().getSourceArgs()[1];

        log.info("処理対象配信エリア種別：" + area);

        try {
            // サービス処理実行
            distributeInstructRegisterService.execute(area);
        } catch (JobExecFailedException e) {
            // サービス処理内でエラーログ出力済みのため、そのままスローする
            throw e;
        } catch (Exception e) {
            // 上記以外のエラー
            log.error("LRIPB_E20001" + " Exception:" + e.getClass().getSimpleName(), e);
            throw new JobExecFailedException(
                "LRIPB_E20001" + " Exception:" + e.getClass().getSimpleName(), e);
        }

        log.info("Job DLAIF0100001 finished.");
        // 実行時間（ミリ秒）
        long timeElapsed = System.currentTimeMillis() - startTime;
        log.info("実行時間：" + timeElapsed + "ms" + " (" + timeElapsed / 1000.0 + "s)");

        return jobContext.getJobExecutionResult();
    }
}
