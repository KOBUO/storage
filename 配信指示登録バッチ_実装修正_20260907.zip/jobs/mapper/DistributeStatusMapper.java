package jp.co.lawson.laif.bt.daemon.jobs.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DistributeStatus;

@Mapper
public interface DistributeStatusMapper {

    /**
     * 配信状況レコードを取得
     *
     * @param distributeAreaType 配信エリア種別
     */
    @Select("""
        SELECT
          ds.distribute_id,
          ds.store_cd,
          ds.equipment_category,
          ds.equipment_no,
          ds.distribute_availability_fg,
          ds.distribute_channel
        FROM
          laif_distribute_status AS ds
        LEFT JOIN
          laif_distribute_completed AS dc
        ON
          ds.distribute_id = dc.distribute_id
        WHERE
          ds.distribute_area_category = #{distributeAreaCategory}
        AND
          dc.distribute_id IS NULL
        ORDER BY
          ds.distribute_priority_kbn DESC,
          ds.distribute_order ASC
        """)
    List<DistributeStatus> selectDistributeStatusByArea(String distributeAreaCategory);

    /**
     * 配信許可設定を行う
     *
     * @param distributeIdList 配信IDリスト
     */
    @Update("""
        <script>
        UPDATE laif_distribute_status
        SET
            distribute_availability_fg = '1',
            updater_id = 'DLAIF0100001',
            upd_dt_tm = NOW()
        WHERE  distribute_id = ANY(
            <foreach collection="distributeIdList" item="distributeId" open="ARRAY[" separator="," close="]::bigint[]">
                #{distributeId}
            </foreach>
        )
        </script>
        """)
    void updatetDistributePossib(List<Long> distributeIdList);
}
