package jp.co.lawson.laif.bt.daemon.jobs.common;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 配信制御設定情報
 */
@Validated
@ConfigurationProperties(prefix = "distribute.control.settings")
@Data
public class DistributeProperties {

    /**
     * 帯域上限(単位:Mbps)
     */
    private final Bandwidth bandwidth = new Bandwidth();
    /**
     * 転送帯域(単位:Mbps)
     */
    private final Transferband transferband = new Transferband();
    /**
     * 同時配信機器数
     */
    private final SimulEquipment simulEquipment = new SimulEquipment();

    /**
     * 登録済み配信制御情報
     */
    private final DistributeCtrlInfo distributeCtrlInfo = new DistributeCtrlInfo();

    /**
     * DBリトライ
     */
    private final DbRetry dbRetry = new DbRetry();

    /**
     * 帯域上限(単位:Mbps)
     */
    @Data
    public static class Bandwidth {
        /** 全体の帯域上限(単位:Mbps) */
        @NotNull
        private Integer overall;
        /** 配信チャネルBの帯域上限(単位:Mbps) */
        @NotNull
        private Integer channelB;
        /** 配信チャネルCの帯域上限(単位:Mbps) */
        @NotNull
        private Integer channelC;
    }

    /**
     * 転送帯域(単位:Mbps)
     */
    @Data
    public static class Transferband {
        /** 配信チャネルAの転送帯域(単位:Mbps) */
        @NotNull
        private Integer channelA;
        /** 配信チャネルBの転送帯域(単位:Mbps) */
        @NotNull
        private Integer channelB;
        /** 配信チャネルCの転送帯域(単位:Mbps) */
        @NotNull
        private Integer channelC;
    }

    /**
     * 同時配信機器数
     */
    @Data
    public static class SimulEquipment {
        /** 通常店の同時配信機器数 */
        @NotNull
        private Integer normal;
        /** 低速回線店の同時配信機器数 */
        @NotNull
        private Integer lowspeed;
    }

    /**
     * 登録済み配信制御情報
     */
    @Data
    public static class DistributeCtrlInfo {
        /** 保存期間（単位：h） */
        @NotNull
        private Integer retentionPeriod;
    }

    /**
     * DBリトライ
     */
    @Data
    public static class DbRetry {
        /** リトライ回数 */
        @NotNull
        private Integer count;
    }

}
