package jp.co.lawson.laif.bt.daemon.jobs.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import jp.co.lawson.common.app.lib.logging.ApplicationLogger;
import jp.co.nri.xpalette.batch.core.exception.JobExecFailedException;
import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeConst.DistributeAreaType;
import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeProperties;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DistributeStatus;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DownEquipment;
import jp.co.lawson.laif.bt.daemon.jobs.mapper.DistributeStatusMapper;
import jp.co.lawson.laif.bt.daemon.jobs.mapper.DownEquipmentMapper;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class DistributeInstructRegisterServiceImpl implements DistributeInstructRegisterService {

    // ログ共通部品から取得したアプリロガー
    private static final ApplicationLogger log = ApplicationLogger.getLogger();

    private final DistributeProperties distributeProperties;
    private final DistributeStatusMapper distributeStatusMapper;
    private final DownEquipmentMapper DownEquipmentMapper;

    /**
     * チャネルA
     */
    private static final String CHANNEL_A = "1";
    /**
     * チャネルB
     */
    private static final String CHANNEL_B = "2";
    /**
     * チャネルC
     */
    private static final String CHANNEL_C = "3";

    /**
     * サービス処理を行う
     */
    @Override
    @Transactional
    public void execute(String area) {

        // (1) ダウン機器取得
        List<String> equipmentKeysOfDownEquipment = getEquipmentKeysOfDownEquipment(
            selectWithRetry(() -> DownEquipmentMapper.findAllDownEquipment(), "ダウン機器取得"));

        // (2) 処理対象配信状況レコード取得
        List<DistributeStatus> distrSituOrgList =
            selectWithRetry(() -> distributeStatusMapper.selectDistributeStatusByArea(area),
                "処理対象配信状況レコード取得");

        // チャネルA店舗ごとに配信許可中の機器（キー：店舗コード、バリュー：配信許可中の機器リスト）
        Map<String, List<String>> distributePossibEquipmentMapOfCnelA = new HashMap<>();
        // チャネルB店舗ごとに配信許可中の機器
        Map<String, List<String>> distributePossibEquipmentMapOfCnelB = new HashMap<>();
        // チャネルC店舗ごとに配信許可中の機器
        Map<String, List<String>> distributePossibEquipmentMapOfCnelC = new HashMap<>();
        // チャネルごとに配信許可中の機器数（キー：チャネル、バリュー：配信許可中の機器数）
        Map<String, Integer> distributePossibEquipmentCntMap = initDistrPossibEquipmentCntMap();

        // チャネルA配信許可設定対象のレコードリスト
        List<DistributeStatus> distributeTargetListOfCnelA = new ArrayList<>();
        // チャネルB配信許可設定対象のレコードリスト
        List<DistributeStatus> distributeTargetListOfCnelB = new ArrayList<>();
        // チャネルC配信許可設定対象のレコードリスト
        List<DistributeStatus> distributeTargetListOfCnelC = new ArrayList<>();

        distrSituOrgList.stream().forEach(distrSitu -> {
          if ("1".equals(distrSitu.getDistributeAvailabilityFg())) {
            switch (distrSitu.getDistributeChannel()) {
              case CHANNEL_A:
                // チャネルA配信許可中の機器情報を保持するマップを更新
                updateDistrPossibDevicInfo(CHANNEL_A, distributePossibEquipmentMapOfCnelA,
                    distributePossibEquipmentCntMap, distrSitu);
                break;
              case CHANNEL_B:
                // チャネルB配信許可中の機器情報を保持するマップを更新
                updateDistrPossibDevicInfo(CHANNEL_B, distributePossibEquipmentMapOfCnelB,
                    distributePossibEquipmentCntMap, distrSitu);
                break;
              case CHANNEL_C:
                // チャネルC配信許可中の機器情報を保持するマップを更新
                updateDistrPossibDevicInfo(CHANNEL_C, distributePossibEquipmentMapOfCnelC,
                    distributePossibEquipmentCntMap, distrSitu);
                break;
              default:
                // 想定外の配信チャネル
                log.error("想定外の配信チャネルです。配信ID:" + distrSitu.getDistributeId()
                    + ", 配信チャネル:" + distrSitu.getDistributeChannel());
                break;
            }
          } else {
            switch (distrSitu.getDistributeChannel()) {
              case CHANNEL_A:
                distributeTargetListOfCnelA.add(distrSitu);
                break;
              case CHANNEL_B:
                distributeTargetListOfCnelB.add(distrSitu);
                break;
              case CHANNEL_C:
                distributeTargetListOfCnelC.add(distrSitu);
                break;
              default:
                // 想定外の配信チャネル
                log.error("想定外の配信チャネルです。配信ID:" + distrSitu.getDistributeId()
                    + ", 配信チャネル:" + distrSitu.getDistributeChannel());
                break;
            }
          }
        });

        log.info("==========全処理実施前のデータ初期状態==========");
        log.info("ダウン機器のレコード数：" + equipmentKeysOfDownEquipment.size());
        log.info("未配信、配信中の合計レコード数：" + distrSituOrgList.size());
        int noDistributeCntOrg = distributeTargetListOfCnelA.size() + distributeTargetListOfCnelB.size()
            + distributeTargetListOfCnelC.size();
        log.info("未配信の合計レコード数：" + noDistributeCntOrg);
        log.info("チャネルB未配信レコード数：" + distributeTargetListOfCnelB.size());
        log.info("チャネルC未配信レコード数：" + distributeTargetListOfCnelC.size());
        log.info("チャネルA未配信レコード数：" + distributeTargetListOfCnelA.size());
        log.info("チャネルB配信中の機器数：" + distributePossibEquipmentCntMap.get(CHANNEL_B));
        log.info("チャネルC配信中の機器数：" + distributePossibEquipmentCntMap.get(CHANNEL_C));
        log.info("チャネルA配信中の機器数：" + distributePossibEquipmentCntMap.get(CHANNEL_A));
        int distributingCntOrg = distrSituOrgList.size() - noDistributeCntOrg;
        log.info("配信中の合計レコード数：" + distributingCntOrg);
        log.info("================================");


        // ○付け実施対象の配信IDリスト
        List<Long> distributePossibDistrIdList = new ArrayList<>();

        log.info("配信チャネルB→C→Aの順番で、チャネルごとに配信許可の設定処理を行う。");
        // ④ 配信チャネルB→C→Aの順番で、チャネルごとに配信許可の設定処理を行う。
        /** ============チャネルBの処理を行う============= */
        List<Long> distributePossibDistrIdListOfCnelB =
            distributePossibExec(distributePossibEquipmentMapOfCnelB, distributePossibEquipmentCntMap,
                distributeTargetListOfCnelB, CHANNEL_B, area, equipmentKeysOfDownEquipment);
        distributePossibDistrIdList.addAll(distributePossibDistrIdListOfCnelB);

        /** ============チャネルCの処理を行う============= */
        List<Long> distributePossibDistrIdListOfCnelC =
            distributePossibExec(distributePossibEquipmentMapOfCnelC, distributePossibEquipmentCntMap,
                distributeTargetListOfCnelC, CHANNEL_C, area, equipmentKeysOfDownEquipment);
        distributePossibDistrIdList.addAll(distributePossibDistrIdListOfCnelC);

        /** ============チャネルAの処理を行う============= */
        List<Long> distributePossibDistrIdListOfCnelA =
            distributePossibExec(distributePossibEquipmentMapOfCnelA, distributePossibEquipmentCntMap,
                distributeTargetListOfCnelA, CHANNEL_A, area, equipmentKeysOfDownEquipment);
        distributePossibDistrIdList.addAll(distributePossibDistrIdListOfCnelA);

        if (distributePossibDistrIdList.size() > 0) {
          // ⑤ 決定された配信許可対象を書き込むため、配信状況テーブルに更新し、処理を終了する。
          distributeStatusMapper.updatetDistributePossib(distributePossibDistrIdList);
        }

        // log.info("○付け実施成功の配信ID：" + distributePossibDistrIdList);

        log.info("==========全処理実施後のデータ状態==========");
        log.info("未配信、配信中の合計レコード数：" + distrSituOrgList.size());
        log.info("未配信の合計レコード数：" + (noDistributeCntOrg - distributePossibDistrIdList.size()));
        log.info("チャネルB未配信レコード数："
            + (distributeTargetListOfCnelB.size() - distributePossibDistrIdListOfCnelB.size()));
        log.info("チャネルC未配信レコード数："
            + (distributeTargetListOfCnelC.size() - distributePossibDistrIdListOfCnelC.size()));
        log.info("チャネルA未配信レコード数："
            + (distributeTargetListOfCnelA.size() - distributePossibDistrIdListOfCnelA.size()));
        log.info("チャネルB配信中の機器数：" + distributePossibEquipmentCntMap.get(CHANNEL_B));
        log.info("チャネルC配信中の機器数：" + distributePossibEquipmentCntMap.get(CHANNEL_C));
        log.info("チャネルA配信中の機器数：" + distributePossibEquipmentCntMap.get(CHANNEL_A));
        log.info("配信中の合計レコード数：" + (distributingCntOrg + distributePossibDistrIdList.size()));
        log.info("今回○付け実施成功数：" + distributePossibDistrIdList.size());
        log.info("================================");

    }


    /**
     * 同一機器を特定する文字列取得
     */
    private String getEquipmentKey(DistributeStatus distrSitu) {
      return concatString(distrSitu.getStoreCd(), distrSitu.getEquipmentCategory(),
          distrSitu.getEquipmentNo());
    }

    /**
     * ダウン機器テーブルから同一機器を特定する文字列取得
     */
    private List<String> getEquipmentKeysOfDownEquipment(List<DownEquipment> DownEquipmentList) {
      List<String> equipmentKeysOfDownEquipment = new ArrayList<>();
      for (DownEquipment DownEquipment : DownEquipmentList) {
        equipmentKeysOfDownEquipment.add(concatString(DownEquipment.getStoreCd(),
            DownEquipment.getEquipmentCategory(), DownEquipment.getEquipmentNo()));
      }
      return equipmentKeysOfDownEquipment;
    }

    private String concatString(String... params) {
      StringBuffer stringBuffer = new StringBuffer();
      for (String param : params) {
        stringBuffer.append(param.trim());
      }
      return stringBuffer.toString();
    }

    /**
     * チャネルごとに配信許可中の機器数のマップを初期化
     *
     * @return チャネルごとに配信許可中の機器数のマップ初期値
     */
    private Map<String, Integer> initDistrPossibEquipmentCntMap() {
      Map<String, Integer> distributePossibEquipmentCntMap = new HashMap<>();
      distributePossibEquipmentCntMap.put(CHANNEL_A, 0);
      distributePossibEquipmentCntMap.put(CHANNEL_B, 0);
      distributePossibEquipmentCntMap.put(CHANNEL_C, 0);
      return distributePossibEquipmentCntMap;
    }

    /**
     * DBエラー時にリトライ回数までリトライして取得を行う
     *
     * @param <T> 取得結果の型
     * @param supplier DB取得処理
     * @param dbProcessName DB処理内容（エラーログの置換文字列に使用）
     * @return 取得結果
     */
    private <T> T selectWithRetry(Supplier<T> supplier, String dbProcessName) {
      int retryCount = distributeProperties.getDbRetry().getCount();
      DataAccessException lastException = null;

      // リトライ回数まで実施する
      for (int i = 0; i <= retryCount; i++) {
        try {
          return supplier.get();
        } catch (DataAccessException e) {
          lastException = e;
          log.info("DBエラーが発生しました。リトライします。DB処理:" + dbProcessName + ", 実施回数:"
              + (i + 1) + "/" + (retryCount + 1));
        }
      }

      // リトライ回数までの実施が完了してもDBエラーが発生した場合、
      // エラーログを出力してエラーをスローし処理を終了する
      log.error("LLAIF_E10001" + " DB処理:" + dbProcessName, lastException);
      throw new JobExecFailedException("LLAIF_E10001" + " DB処理:" + dbProcessName, lastException);
    }

    /**
     * 配信許可中の機器情報を保持するマップを更新
     *
     * @param channel 配信チャネル
     * @param distributePossibEquipmentMap 店舗ごとに配信中の機器リストのマップ
     * @param distributePossibEquipmentCntMap チャネルごとに配信許可中の機器数のマップ
     * @param distrSitu 配信状況レコード
     */
    private void updateDistrPossibDevicInfo(String channel,
        Map<String, List<String>> distributePossibEquipmentMap,
        Map<String, Integer> distributePossibEquipmentCntMap, DistributeStatus distrSitu) {

      String StoreCd = distrSitu.getStoreCd();
      List<String> equipmentList =
          distributePossibEquipmentMap.get(StoreCd) == null ? new ArrayList<String>()
              : distributePossibEquipmentMap.get(StoreCd);

      // チャネルごとに配信許可中の機器数
      int devicCnt = distributePossibEquipmentCntMap.get(channel);
      // 該当機器初回の場合のみカウントする
      if (!equipmentList.contains(getEquipmentKey(distrSitu))) {
        devicCnt++;
      }
      // チャネルごとに配信許可中の機器数更新
      distributePossibEquipmentCntMap.put(channel, devicCnt);

      equipmentList.add(getEquipmentKey(distrSitu));
      // 店舗ごとに配信中の機器セットを更新
      distributePossibEquipmentMap.put(StoreCd, equipmentList);
    }

    /**
     * 残配信可能機器数を取得
     *
     * @param distributePossibEquipmentCntMap チャネルごとに配信許可中の機器数
     * @param channel チャネル情報
     * @return 残配信可能機器数
     */
    private int getDistributCntAvailable(Map<String, Integer> distributePossibEquipmentCntMap,
        String channel) {

      // 配信で利用可能な全体の帯域上限から、すでに別配信チャネルで配信許可中の帯域を除いた、配信チャネルの残配信可能数を確認する。
      // チャネルA利用中の転送帯域
      int distributingBandwidthCnelA = distributePossibEquipmentCntMap.get(CHANNEL_A)
          * distributeProperties.getTransferband().getChannelA();
      // チャネルB利用中の転送帯域
      int distributingBandwidthCnelB = distributePossibEquipmentCntMap.get(CHANNEL_B)
          * distributeProperties.getTransferband().getChannelB();
      // チャネルC利用中の転送帯域
      int distributingBandwidthCnelC = distributePossibEquipmentCntMap.get(CHANNEL_C)
          * distributeProperties.getTransferband().getChannelC();

      log.info("チャネルA利用中の転送帯域：" + distributingBandwidthCnelA + "Kbps");
      log.info("チャネルB利用中の転送帯域：" + distributingBandwidthCnelB + "Kbps");
      log.info("チャネルC利用中の転送帯域：" + distributingBandwidthCnelC + "Kbps");

      // 配信に利用できる帯域(単位Kbps)
      // 配信に利用できる帯域＝全体の帯域上限－（配信許可設定済みの機器数×配信チャネルの転送帯域）
      int bandwidthAvailable = distributeProperties.getBandwidth().getOverall()
          - distributingBandwidthCnelA - distributingBandwidthCnelB - distributingBandwidthCnelC;
      bandwidthAvailable = bandwidthAvailable > 0 ? bandwidthAvailable : 0;
      log.info("全体の残帯域：" + bandwidthAvailable + "Kbps");
      // 転送帯域定義
      int transferband = 0;
      switch (channel) {
        case CHANNEL_A:
          // チャネルAの転送帯域
          transferband = distributeProperties.getTransferband().getChannelA();
          break;
        case CHANNEL_B:
          // チャネルBの転送帯域
          transferband = distributeProperties.getTransferband().getChannelB();
          // チャネルB配信に利用できる帯域(単位Kbps)
          if (distributeProperties.getBandwidth().getChannelB() < bandwidthAvailable) {
            // 配信チャネルB,Cはそれぞれの帯域上限を超えないようにする
            bandwidthAvailable = distributeProperties.getBandwidth().getChannelB();
          }
          break;
        case CHANNEL_C:
          // チャネルCの転送帯域
          transferband = distributeProperties.getTransferband().getChannelC();
          // チャネルC配信に利用できる帯域(単位Kbps)
          if (distributeProperties.getBandwidth().getChannelC() < bandwidthAvailable) {
            // 配信チャネルB,Cはそれぞれの帯域上限を超えないようにする
            bandwidthAvailable = distributeProperties.getBandwidth().getChannelC();
          }
          break;
      }
      log.info("チャネル" + channel + "配信に利用できる帯域：" + bandwidthAvailable + "Kbps");
      // 残配信可能数＝配信に利用できる帯域/配信1本の帯域
      int remainingAvailableEquipmentCnt = bandwidthAvailable / transferband;
      log.info("チャネル" + channel + "の残配信可能数（多重度）：" + remainingAvailableEquipmentCnt);

      log.info("チャネル" + channel + "の配信許可設定済み機器数（既存配信中のデータ）："
          + distributePossibEquipmentCntMap.get(channel));

      // 残配信可能数＝配信に利用できる帯域/配信1本の帯域
      return remainingAvailableEquipmentCnt;

    }

    /**
     * 同時配信機器数取得
     *
     * @param distrAreaType 配信エリア種別
     * @return 同時配信機器
     */
    private int getSimulEquipmentCnt(String distrAreaType) {
      if (DistributeAreaType.LOW_SPEED.getCode().equals(distrAreaType)) {
        return distributeProperties.getSimulEquipment().getLowspeed();
      } else {
        return distributeProperties.getSimulEquipment().getNormal();
      }
    }


    /**
     * 配信許可設定実施
     *
     * @param distributePossibEquipmentMap 店舗ごとに配信許可中の機器セットのマップ
     * @param distributePossibEquipmentCntMap チャネルごとに配信許可中の機器数のマップ
     * @param distributeTargetList 配信許可設定対象リスト
     * @param channel 配信チャネル
     * @param area ジョブ引数から渡される配信エリア種別
     * @return 配信許可設定済みの配信IDリスト
     */
    private List<Long> distributePossibExec(Map<String, List<String>> distributePossibEquipmentMap,
        Map<String, Integer> distributePossibEquipmentCntMap,
        List<DistributeStatus> distributeTargetList, String channel, String area,
        List<String> equipmentKeysOfDownEquipment) {

      log.info("========チャネル" + channel + "の配信許可設定実施前の状態========");
      List<Long> distributePossibDistrIdList = new ArrayList<>();
      // ④-1-1．センター側の配信帯域制御として、回線ごとの同時配信数の上限となる、多重度の計算を行う。
      int distributAvailableCnt = getDistributCntAvailable(distributePossibEquipmentCntMap, channel);

      // ④-3-1．店舗側の配信帯域制御として、同時配信機器数の上限を設ける。
      int simulEquipmentCnt = getSimulEquipmentCnt(area);
      log.info("=====================================");
      log.info("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓（装飾用の記号列・判読不可）");
      log.info("チャネル" + channel + "の配信許可設定実施開始");
      if (DistributeAreaType.LOW_SPEED.getCode().equals(area)) {
        // 低速回線店の場合多重度制御行わない、店舗の同時配信機器数制御のみ実施する
        // ④-3-2．配信帯域制御の条件を満たしていることを確認しながら、配信可否フラグに配信可（○つけ済）を設定する。
        for (DistributeStatus distributePossibSetting : distributeTargetList) {

          // 店舗コード
          String storeCd = distributePossibSetting.getStoreCd();
          // 機器を特定するためのキー
          String equipmentKey = getEquipmentKey(distributePossibSetting);
          // 該当店舗配信中の機器リスト
          List<String> equipmentList = distributePossibEquipmentMap.get(storeCd);
          // b.店舗側の配信帯域制御
          // 該当店舗配信中の機器数
          int distributingEquipmentCntWithoutDownEquipment =
              getDistributingEquipmentCntWithoutDownEquipment(equipmentList,
                  equipmentKeysOfDownEquipment);
          // 店舗の同時配信機器数の上限に到達した場合（ダウン機器テーブルに存在する場合場合制御しない）
          if (simulEquipmentCnt <= distributingEquipmentCntWithoutDownEquipment
              && (equipmentList == null || !equipmentList.contains(equipmentKey))
              && !equipmentKeysOfDownEquipment.contains(equipmentKey)) {
            // 上限に到達した店舗の配信許可設定をスキップする。
            // 低速回線店の場合は、すべての店舗がスキップ対象になった場合、次の配信チャネルの配信許可設定を行う。
            // 全配信チャネルの処理が終わったら、⑤の処理に移行する。
            continue;
          }
          // ○付け実施対象の配信IDリストに追加
          distributePossibDistrIdList.add(distributePossibSetting.getDistributeId());

          // ダウン機器は多重度・同時配信機器数のカウント対象外のため、マップ更新を行わない
          if (!equipmentKeysOfDownEquipment.contains(equipmentKey)) {
            // 配信許可中の機器情報を保持するマップを更新
            updateDistrPossibDevicInfo(channel, distributePossibEquipmentMap,
                distributePossibEquipmentCntMap, distributePossibSetting);
          }
        }

      } else {
        // 低速回線店以外の場合、多重度と店舗の同時配信機器数制御両方行う
        // 今回配信許可済みの機器数
        int distributeEquipmentCnt = 0;

        // ④-3-2．配信帯域制御の条件を満たしていることを確認しながら、配信可否フラグに配信可（○つけ済）を設定する。
        for (DistributeStatus distributePossibSetting : distributeTargetList) {
          // a.センター側配信帯域制御（低速回線店の場合を除く）
          // 配信チャネルの帯域上限に到達した場合
          if (distributAvailableCnt <= distributeEquipmentCnt)
            // 現在処理している配信チャネルの配信許可設定処理を終了する。
            // 次の配信チャネルの配信許可設定を行う。
            // または⑤の処理に移行する。（最後のチャネルの場合）
            break;

          // 店舗コード
          String storeCd = distributePossibSetting.getStoreCd();
          // 機器を特定するためのキー
          String equipmentKey = getEquipmentKey(distributePossibSetting);
          // 該当店舗配信中の機器リスト
          List<String> equipmentList = distributePossibEquipmentMap.get(storeCd);
          // b.店舗側の配信帯域制御
          // 該当店舗配信中の機器数
          int distributingEquipmentCntWithoutDownEquipment =
              getDistributingEquipmentCntWithoutDownEquipment(equipmentList,
                  equipmentKeysOfDownEquipment);
          // 店舗の同時配信機器数の上限に到達した場合（ダウン機器テーブルに存在する場合場合制御しない）
          if (simulEquipmentCnt <= distributingEquipmentCntWithoutDownEquipment
              && (equipmentList == null || !equipmentList.contains(equipmentKey))
              && !equipmentKeysOfDownEquipment.contains(equipmentKey)) {
            // 上限に到達した店舗の配信許可設定をスキップする。
            // 低速回線店の場合は、すべての店舗がスキップ対象になった場合、次の配信チャネルの配信許可設定を行う。
            // 全配信チャネルの処理が終わったら、⑤の処理に移行する。
            continue;
          }

          // ○付け実施対象の配信IDリストに追加
          distributePossibDistrIdList.add(distributePossibSetting.getDistributeId());

          // 該当機器初回配信許可設定の場合、今回配信許可済みの機器数にカウントする（前回と異なる機器を処理した場合）
          // かつ、ダウン機器テーブルに存在しない場合
          if ((equipmentList == null || !equipmentList.contains(equipmentKey))
              && !equipmentKeysOfDownEquipment.contains(equipmentKey)) {
            distributeEquipmentCnt++;
          }

          // ダウン機器は多重度・同時配信機器数のカウント対象外のため、マップ更新を行わない
          if (!equipmentKeysOfDownEquipment.contains(equipmentKey)) {
            // 配信許可中の機器情報を保持するマップを更新
            updateDistrPossibDevicInfo(channel, distributePossibEquipmentMap,
                distributePossibEquipmentCntMap, distributePossibSetting);
          }

        }
      }

      log.info("チャネル" + channel + "の配信許可設定実施終了");
      log.info("チャネル" + channel + "○付け実施成功数（今回の○付けレコード数）：" + distributePossibDistrIdList.size());
      log.info(
          "チャネル" + channel + "の配信許可設定済み機器数（既存配信中込み）：" + distributePossibEquipmentCntMap.get(channel));
      log.info("〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓〓（装飾用の記号列・判読不可）");
      return distributePossibDistrIdList;
    }

    /**
     * ダウン機器以外同一店舗配信許可中の機器数取得
     *
     * @param equipmentList 同一店舗配信許可中の機器リスト
     * @param equipmentKeysOfDownEquipment ダウン機器リスト
     * @return ダウン機器以外同一店舗配信許可中の機器数
     */
    private int getDistributingEquipmentCntWithoutDownEquipment(List<String> equipmentList,
        List<String> equipmentKeysOfDownEquipment) {
      if (equipmentList == null || equipmentList.isEmpty())
        return 0;

      HashSet<String> equipmentSet = new HashSet<>(equipmentList);
      int cnt = 0;
      for (String equipmentKey : equipmentSet) {
        if (!equipmentKeysOfDownEquipment.contains(equipmentKey)) {
          cnt++;
        }
      }
      return cnt;
    }

}
