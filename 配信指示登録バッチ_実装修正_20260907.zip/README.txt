配信指示登録バッチ 実装修正（2026-09-07）

配置先: src/main/java/jp/co/lawson/laif/bt/daemon/jobs/ 配下

  common/DistributeProperties.java
  job/DistributeInstructRegisterJob.java
  mapper/DistributeStatusMapper.java
  service/DistributeInstructRegisterServiceImpl.java

【修正内容】

1. DistributeInstructRegisterServiceImpl.java
   - CHANNEL_A/B/C の値を "A"/"B"/"C" から "1"/"2"/"3" に修正
     （エンティティ定義書 laif_distribute_status.distribute_channel = 1:A / 2:B / 3:C）
   - switch 2箇所に default 節を追加（想定外チャネルはエラーログを出力してスキップ）
   - ダウン機器の場合は updateDistrPossibDevicInfo() を呼ばないよう修正（2箇所）
     詳細設計 (11)-① / (12)-① に合わせ、多重度・同時配信機器数のカウントから除外
   - selectWithRetry() を追加し、(1) ダウン機器取得 / (2) 処理対象配信状況レコード取得 に適用
     リトライ上限到達時は LLAIF_E10001 のエラーログを出力し JobExecFailedException をスロー

2. DistributeInstructRegisterJob.java
   - ロガーを @Slf4j から ApplicationLogger に変更（ServiceImpl と統一）
   - log.debug を log.info に変更（ApplicationLogger に debug が無いため）
   - DB以外のエラーで LRIPB_E20001 のエラーログを出力
     （DBエラーは ServiceImpl で出力済みのため、JobExecFailedException はそのまま再スロー）

3. DistributeProperties.java
   - DbRetry.count を追加（DBエラー時のリトライ回数）

4. DistributeStatusMapper.java
   - updatetDistributePossib の SQL キャストを ::int[] から ::bigint[] に修正
     （distribute_id は bigint、MAXVALUE 8999999999999）

【application.yml への追記が必要】

distribute.control.settings 配下に以下を追加してください。
（application.yml はコンフリクト中のため本zipには含めていません）

      db-retry:
        # DBエラー時のリトライ回数
        count: ${ENV_DISTRIBUTE_DB_RETRY_COUNT:3}

【注意】

- メッセージIDは "LLAIF_E10001" / "LRIPB_E20001" の文字列リテラルで埋めています。
  ApplicationLogger にメッセージID解決の仕組みが無いためです。
- これらのファイルはMR差分画面の写真からの文字起こしを元にしています。
  修正箇所以外に文字起こし由来の差異が含まれる可能性があるため、
  上書きではなく差分を確認したうえで適用してください。
