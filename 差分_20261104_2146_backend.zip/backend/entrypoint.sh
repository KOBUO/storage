#!/bin/sh
set -eu

# DB 接続情報が与えられていれば、起動時にテストデータ（ddl.sql + data.sql）を投入する。
# DB コンソールに直接触れない環境で、本コンテナのデプロイだけで ① の検証データを用意するため。
# 再実行できるよう、既存テーブルを削除してから作り直す。
if [ -n "${DATABASE_HOST:-}" ]; then
    export PGPASSWORD="${DATABASE_PASSWORD:-}"
    PSQL="psql -h ${DATABASE_HOST} -p ${DATABASE_PORT:-5432} -U ${DATABASE_USER} -d ${DATABASE_NAME} -v ON_ERROR_STOP=1"
    $PSQL -c "DROP TABLE IF EXISTS laif_routing_info, laif_default_routing;"
    $PSQL -f /seed/ddl.sql
    # ルーティング先ドメイン。ECS では自タスクのプライベート IP（ALB を置かない環境向け）、それ以外は compose のサービス名。
    if [ -z "${BACKEND_DOMAIN:-}" ]; then
        if [ -n "${ECS_CONTAINER_METADATA_URI_V4:-}" ]; then
            BACKEND_DOMAIN=$(wget -qO- "${ECS_CONTAINER_METADATA_URI_V4}" \
                | sed -n 's/.*"IPv4Addresses":\["\([^"]*\)".*/\1/p')
            [ -n "$BACKEND_DOMAIN" ] || { echo "自タスクの IP を取得できませんでした。" >&2; exit 1; }
        else
            BACKEND_DOMAIN=backend
        fi
    fi
    sed "s/__BACKEND_DOMAIN__/${BACKEND_DOMAIN}/g" /seed/data.sql | $PSQL -f -
    echo "ルーティング先ドメイン: ${BACKEND_DOMAIN}"
    echo "テストデータを投入しました。（laif_routing_info / laif_default_routing）"
fi

exec nginx -g 'daemon off;'
