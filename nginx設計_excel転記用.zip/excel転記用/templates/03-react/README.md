# パターン3 本部画面用 React（静的配信 + S3中継）— ビルド一式

方式資料 4-3（4-3-4 p81 / 4-3-6 / 4-3-9 p92 / 4-3-14 / 4-3-16 / 4-3-17 / 4-3-19）準拠。
**S3 をバックに静的コンテンツを配信**し、**SPA fallback（未定義URL→index.html 200）**、
**UL/DL を VPC Gateway EP 経由で S3 中継**する Web サーバ nginx。njs/loader/DB 不要。
**認証は ALB(OIDC/Entra ID) が担うため nginx は認証しない**（4-3-14）。

## ファイル

| ファイル | 役割 |
|---------|------|
| `nginx.conf.template` | S3バック静的配信・SPA fallback・UL/DL中継・帯域/同時接続制御 |
| `entrypoint.sh` | envsubst で conf 生成 → 構文チェック(`nginx -t`) → nginx起動 |
| `Dockerfile` | nginx + gettext(envsubst)。njs 不要 |

## 環境変数

| 変数 | 例 | 説明 |
|------|-----|------|
| `SERVER_NAME` | `_` | server_name |
| `WORKER_CONNECTIONS` | `512` | 4-3-6 デフォルト基本 |
| `S3_ENDPOINT` | `example-bucket.s3.ap-northeast-1.amazonaws.com` | 静的/UL/DL の中継先S3ドメイン（VPC GW EP 経由で解決）|
| `FILE_RELAY_PATH` | `/files/` | UL/DL中継のコンテキストパス（4-3-16/17）|
| `MAX_UPLOAD_SIZE` | `100m` | UL用サイズ上限 `client_max_body_size`（4-3-16）|
| `LIMIT_CONN` | `10` | 同時接続数（S3向け, 4-3-6）|
| `LIMIT_CONN_STATUS` | `503` | 超過時ステータス |
| `LIMIT_RATE` | `1m` | DL下り帯域上限（4-3-17）|
| `LIMIT_RATE_AFTER` | `1m` | この量までは無制限 |
| `PROXY_CONNECT_TIMEOUT` | `5s` | 接続TO（4-3-7）|
| `PROXY_READ_TIMEOUT` | `60s` | 読取TO（超過504）|
| `PROXY_SEND_TIMEOUT` | `60s` | 送信TO |
| `REACT_ROOT` *(代替)* | `/usr/share/nginx/html` | 同梱root版を採用時のみ。envsubst列挙外→採用時に entrypoint へ追加 |

## ローカル動作確認（例）

```sh
docker build -t react-web .
docker run --rm -p 8080:80 \
  -e SERVER_NAME=_ -e WORKER_CONNECTIONS=512 \
  -e S3_ENDPOINT=example-bucket.s3.ap-northeast-1.amazonaws.com \
  -e FILE_RELAY_PATH=/files/ -e MAX_UPLOAD_SIZE=100m \
  -e LIMIT_CONN=10 -e LIMIT_CONN_STATUS=503 -e LIMIT_RATE=1m -e LIMIT_RATE_AFTER=1m \
  -e PROXY_CONNECT_TIMEOUT=5s -e PROXY_READ_TIMEOUT=60s -e PROXY_SEND_TIMEOUT=60s \
  react-web
curl -i http://localhost:8080/health          # → 200 ok
# ※ 静的配信/SPA fallback/UL・DL は実 S3(または VPC GW EP)到達が前提のため、
#   ローカル単体では /health のみ確認可。S3系は擬似バックエンドを立てて検証する。
```

## ★確定が必要な設計事項（このパターンの肝）

1. **静的配信方式（S3 proxy か 同梱root か）**（docs 07-I / 03-react.md TODO / 4-3-4 p81）
   - 本conf の既定は **S3 を `proxy_pass` で配信**（方式資料は「nginx が S3 をバックに配信」）。
   - 代替の **同梱root版**（`root ${REACT_ROOT}` + `try_files $uri $uri/ /index.html`）を
     `nginx.conf.template` にコメントで併記。**どちらを採用するか要確定**。
     同梱版採用時は Dockerfile の `COPY dist/` と entrypoint の `${REACT_ROOT}` 列挙を有効化。

2. **SPA fallback の実装確認（S3が404返す前提）**（★相違F / 4-3-9 p92, 1-5）
   - S3 proxy 版は `proxy_intercept_errors on` + `error_page 403 404 = @spa_fallback` で
     **未定義URL→index.html を 200** にしている（404にしない）。
   - **前提: S3 が不在キーに 403 or 404 を返すこと**（バケットポリシー/公開設定で挙動が変わる。
     ListBucket 不許可だと 403、許可だと 404 になりがち）。実バケットの返却コードを確認し
     `error_page` の対象コードを合わせること。index.html 自体の欠損時は素通し（無限ループ回避済）。

3. **UL/DL のプリサインドURL署名方式（ホスト置換で署名が通るか）**（★相違E / パターン2と同一論点 / 4-3-16,17）
   - 本conf は「**Host を S3 に置換 + ?署名クエリ保持**」で中継する（nginxは署名しない）。
   - **API側がどのホスト・どのスタイル（パス/仮想ホスト）で署名するか**で SigV4 の一致可否が決まる。
     ホスト名を nginx 経由に置換して署名が通る形か、API チームと合意すること（パターン2 README と同論点）。
   - UL物理名=システム時刻+UUID（上書き禁止）、論理↔物理はDB管理＝**API側の責務**（nginxは中継のみ）。

4. **VPC Gateway エンドポイント**（4-3-16/17）
   - UL/DL/静的配信が S3 へ到達するルートテーブル・バケットポリシー（VPC EP からのみ許可 等）。
   - `S3_ENDPOINT` は envsubst 後に固定ホスト→起動時解決で足りる想定。IP変動を考慮するなら
     `resolver` + 変数 proxy_pass 方式を検討（TODO）。

5. **キャッシュ制御**（03-react.md TODO / 4-3-4）
   - `index.html` は **no-cache**、ハッシュ付き資産（`*.[hash].js/css`）は**長期キャッシュ**。
   - S3 オブジェクトの `Cache-Control` で持たせるか、nginx 側で location 分岐 + `add_header` で
     上書きするか要確定（conf にプレースホルダ TODO を記載済）。

6. **ログ**（08-logging.md / 4-2-13）
   - `log_format json_nginx`（subtype=NGINX）は暫定。項目・TraceIDヘッダ名・JST整形は後続確定。

7. **その他**
   - nginx バージョン（docs 07-H: 方式書記載 1.28 / JIKIPH0-267）。Dockerfile は暫定 1.27-alpine。
   - コンテキストパス設計（複数画面アプリの共存 / 4-3, 03-react.md TODO）。
