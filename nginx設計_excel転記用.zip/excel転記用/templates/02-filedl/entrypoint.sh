#!/bin/sh
# パターン2 ファイルDL: nginx.conf.template を envsubst で展開して nginx 起動。
# njs / loader は無いのでシンプル。
set -eu

TEMPLATE="/etc/nginx/templates/nginx.conf.template"
OUT="/etc/nginx/nginx.conf"

# 必須環境変数の検証（未定義/空なら起動失敗させる。envsubstは未定義を空展開するため事前検証が必須）
for v in SERVER_NAME WORKER_CONNECTIONS LIMIT_CONN LIMIT_CONN_STATUS \
         LIMIT_REQ_RATE LIMIT_REQ_BURST LIMIT_REQ_STATUS \
         FILE_DL_PATH S3_ENDPOINT LIMIT_RATE LIMIT_RATE_AFTER \
         PROXY_CONNECT_TIMEOUT PROXY_READ_TIMEOUT PROXY_SEND_TIMEOUT; do
    eval ": \"\${$v:?$v is required}\""
done

# 任意変数の既定値（export必須: envsubstは環境変数しか見ない）
export PROXY_SSL_VERIFY="${PROXY_SSL_VERIFY:-on}"   # S3証明書検証（VPC GW EP経由ならoff可）
export S3_SCHEME="${S3_SCHEME:-https}"              # S3中継スキーム（既定https。検証MinIOはhttp）

# 展開対象の環境変数を明示（列挙外の $var（$host 等）はそのまま残す）
VARS='${SERVER_NAME} ${WORKER_CONNECTIONS} ${PROXY_SSL_VERIFY} ${S3_SCHEME}
${LIMIT_CONN} ${LIMIT_CONN_STATUS}
${LIMIT_REQ_RATE} ${LIMIT_REQ_BURST} ${LIMIT_REQ_STATUS}
${FILE_DL_PATH} ${S3_ENDPOINT}
${LIMIT_RATE} ${LIMIT_RATE_AFTER}
${PROXY_CONNECT_TIMEOUT} ${PROXY_READ_TIMEOUT} ${PROXY_SEND_TIMEOUT}'

echo "Generating $OUT from $TEMPLATE ..."
envsubst "$VARS" < "$TEMPLATE" > "$OUT"

echo "===== nginx.conf ====="
cat "$OUT"

# 構文チェックしてから起動
nginx -t -c "$OUT"
echo "Start nginx"
exec nginx -g 'daemon off;' -c "$OUT"
