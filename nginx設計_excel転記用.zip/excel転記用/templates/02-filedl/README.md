# パターン2 ファイルDL — ビルド一式

方式資料 4-2-18(p70) 準拠。**署名付きURL を S3 へ中継**する nginx。njs/loader/DB 不要。

## ファイル

| ファイル | 役割 |
|---------|------|
| `nginx.conf.template` | S3中継・ホスト名置換・帯域制御・404 |
| `entrypoint.sh` | envsubst で conf 生成 → 構文チェック → nginx起動 |
| `Dockerfile` | nginx + gettext(envsubst) |

## 環境変数

| 変数 | 例 | 説明 |
|------|-----|------|
| `SERVER_NAME` | `_` | server_name |
| `WORKER_CONNECTIONS` | `512` | 4-2-7 デフォルト基本 |
| `FILE_DL_PATH` | `/download/` | DL のコンテキストパス |
| `S3_ENDPOINT` | `bucket-host.s3.ap-northeast-1.amazonaws.com` | 中継先S3ドメイン（VPC GW EP 経由で解決）|
| `LIMIT_CONN` | `10` | 同時接続数 |
| `LIMIT_CONN_STATUS` | `503` | 超過時ステータス |
| `LIMIT_RATE` | `1m` | 下り帯域上限 |
| `LIMIT_RATE_AFTER` | `1m` | この量までは無制限 |
| `PROXY_CONNECT_TIMEOUT` | `5s` | 接続TO |
| `PROXY_READ_TIMEOUT` | `60s` | 読取TO（超過504）|
| `PROXY_SEND_TIMEOUT` | `60s` | 送信TO |

## ローカル動作確認（例）

```sh
docker build -t filedl .
docker run --rm -p 8080:80 \
  -e SERVER_NAME=_ -e WORKER_CONNECTIONS=512 \
  -e FILE_DL_PATH=/download/ -e S3_ENDPOINT=example-bucket.s3.ap-northeast-1.amazonaws.com \
  -e LIMIT_CONN=10 -e LIMIT_CONN_STATUS=503 -e LIMIT_RATE=1m -e LIMIT_RATE_AFTER=1m \
  -e PROXY_CONNECT_TIMEOUT=5s -e PROXY_READ_TIMEOUT=60s -e PROXY_SEND_TIMEOUT=60s \
  filedl
curl -i http://localhost:8080/health
```

## ★確定が必要な設計事項（このパターンの肝）

1. **署名付きURLの署名方式（最重要）**
   - 本conf は「**パススタイル** + **Host を S3 に置換**」を前提。
   - つまり **API側のプリサインドURL生成が、S3エンドポイントのホストで・パススタイルで署名**していること。
   - もし仮想ホスト形式（`bucket.s3...`）で署名していると、Host置換で **SigV4 署名不一致**になる。
   - → API チームと「どのホスト・どのスタイルで署名するか」を合意。conf をそれに合わせる。
2. **`/download/<バケット>/<パス>` の分解規則**: 現状は `rewrite` でプレフィックス除去のみ。
   バケットを Host/パスのどちらに載せるか（パススタイルなら `/<バケット>/<キー>`）を確定。
3. **VPC Gateway エンドポイント**: ルートテーブル / バケットポリシー（VPC EP からのみ許可 等）。
4. **resolver 要否**: `S3_ENDPOINT` は envsubst 後に固定ホストになるため通常は起動時解決で足りるが、
   IP変動を考慮するなら `resolver` + 変数 proxy_pass 方式も検討。
5. **帯域制御ヘッダ**（4-2-2 "with 帯域制御ヘッダ"）の仕様: ヘッダで帯域を可変にするか、固定か。
6. **ログ**: `log_format json_nginx` の項目・TraceIDヘッダ名・JST整形（4-2-13、後続確定）。
