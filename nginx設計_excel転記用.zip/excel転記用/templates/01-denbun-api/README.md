# パターン1 電文受付① 通常API（njs カナリアリリース）— ビルド一式

方式資料 4-2-2 / 4-2-7 / 4-2-8 / 4-2-10 / 4-2-13 準拠。
POS/SC からの通常API電文を受け付け、**店舗×バージョンで転送先(backend)を動的に切替える
カナリアリリース**を行う nginx。あわせて流量制御・タイマー・404固定JSON を担う。

**★方式資料準拠の最重要ポイント（相違A, 07-discrepancies.md）**:
振分けキーは **「BODYの店舗コード」**（PoC は X-Shop-Id ヘッダー）。
njs でリクエストBODY(JSON)を読むため、`js_content` ハンドラ + `internalRedirect` 方式に再設計した。

## ファイル一覧

| ファイル | 役割 |
|---------|------|
| `nginx.conf.template` | njs読込・流量制御(limit_conn)・タイマー・proxy・404固定JSON・JSONログ |
| `njs/route.js` | ★採用版。振分けロジック（BODYの店舗コードで判定、js_content + internalRedirect） |
| `njs/route.header-poc.js` | 参考。PoC のヘッダー(X-Shop-Id)版。ビルド不使用 |
| `njs/routes.js` | **生成物（非コミット）**。entrypoint が routing.json から起動時生成（routingTable+upstreamMap） |
| `entrypoint.sh` | routing.json→routes.js 生成 → envsubst展開 → `nginx -t` → 起動 |
| `Dockerfile` | nginx + njs(nginx-mod-http-js) + gettext(envsubst) |
| `loader/loader.py` | Aurora(routing/default_routing)→ /shared/routing.json 出力（サイドカー, ワンショット） |
| `loader/Dockerfile` | python:3.12-slim + psycopg2-binary |
| `task-def.md` | ECSタスク定義（nginx + loader essential=false/dependsOn SUCCESS, DB_PASSWORDはSecrets） |

## 環境変数

### nginx コンテナ

| 変数 | 例 | 説明 / 根拠 |
|------|-----|------|
| `SERVER_NAME` | `_` | server_name（limit_conn_zone のキー, 4-2-7） |
| `WORKER_CONNECTIONS` | `512` | 4-2-7 デフォルト基本（相違C: PoCは1024） |
| `LIMIT_CONN` | `10` | 同時接続数上限（4-2-7、limit_reqは方式外=相違D） |
| `LIMIT_CONN_STATUS` | `503` | 超過時ステータス |
| `DENBUN_PATH` | `/order/` | 通常APIのコンテキストパス（4-2-2） |
| `CLIENT_BODY_BUFFER_SIZE` | `64k` | ★BODY振分けの副作用: 想定最大電文を収容（超過で店舗コード取得不可→default routing） |
| `PROXY_CONNECT_TIMEOUT` | `5s` | 接続TO（4-2-8, 超過504） |
| `PROXY_READ_TIMEOUT` | `60s` | アイドルTO（4-2-8, 超過504） |
| `PROXY_SEND_TIMEOUT` | `60s` | 送信TO |
| `ROUTING_FILE` | `/shared/routing.json` | loader 出力（entrypoint が読む） |
| `DEFAULT_UPSTREAM` | `http://backend:80` | upstreamMap の DEFAULT（entrypoint がroutes.jsに埋め込む） |
| `SHOP0002_V2_UPSTREAM` | `http://canary:80` | upstreamMap の SHOP0002_V2（★version毎に追加＝拡張性課題） |

### loader コンテナ

| 変数 | 例 | 説明 |
|------|-----|------|
| `ROUTING_JSON_PATH` | `/shared/routing.json` | 出力先 |
| `DB_HOST` `DB_PORT` `DB_NAME` `DB_USER` | – | Aurora 接続情報 |
| `DB_PASSWORD` | – | ★Secrets Manager/SSM から task-def `secrets` で注入（平文禁止） |
| `DB_CONNECT_TIMEOUT` | `5` | 接続タイムアウト秒 |

## ローカル動作確認（例）

loader は Aurora が要るため、ローカルでは **routing.json を手で用意**して nginx 単体を確認する。

```sh
# 1) 最小の routing.json を用意（loader 出力の代替）
mkdir -p /tmp/shared
cat > /tmp/shared/routing.json <<'JSON'
{"defaults":{"|order|v1":[{"routing_version":"DEFAULT","start_at":null,"end_at":null}]},
 "stores":{"000002|order|v2":[{"routing_version":"SHOP0002_V2","start_at":null,"end_at":null}]}}
JSON

# 2) nginx イメージをビルド・起動
docker build -t denbun-api-nginx .
docker run --rm -p 8080:80 \
  -v /tmp/shared:/shared:ro \
  -e ROUTING_FILE=/shared/routing.json \
  -e SERVER_NAME=_ -e WORKER_CONNECTIONS=512 \
  -e LIMIT_CONN=10 -e LIMIT_CONN_STATUS=503 \
  -e DENBUN_PATH=/order/ -e CLIENT_BODY_BUFFER_SIZE=64k \
  -e PROXY_CONNECT_TIMEOUT=5s -e PROXY_READ_TIMEOUT=60s -e PROXY_SEND_TIMEOUT=60s \
  -e DEFAULT_UPSTREAM=http://default-backend:80 \
  -e SHOP0002_V2_UPSTREAM=http://canary-backend:80 \
  denbun-api-nginx

# 3) 確認
curl -i http://localhost:8080/health
# BODY の店舗コードで振分け（backend が無ければ 502 になるが、route.js の判定ログは error_log で確認可）
curl -i -X POST http://localhost:8080/order/v2/serviceA \
  -H 'Content-Type: application/json' -d '{"storeCode":"000002"}'
curl -i http://localhost:8080/notfound     # → 404 固定JSON(JIKIPH0-2288)
```

> 注: 実際に backend まで疎通させるには `DEFAULT_UPSTREAM`/`SHOP0002_V2_UPSTREAM` を
> 起動中の到達可能なコンテナに向ける（docker network 等）。

## ★「BODYの店舗コードをnjsで読む」実装上の判断と注意点

- **js_content + internalRedirect 方式**を採用（js_set ではない）。
  body 取得 `r.requestText()` はコンテンツフェーズでのみ確実に読めるため、
  `location /order/` を `js_content route.route;` にし、upstream を `$upstream`(js_var)へ set 後、
  内部 location `@backend`（`proxy_pass $upstream`）へ `r.internalRedirect()` する。body は保持され転送される。
- **ペイロード肥大**: `client_body_buffer_size` を超える body は一時ファイル化し `r.requestText()` が
  取得不可 → 店舗コード無し扱いで default routing に倒れる。想定最大電文サイズに合わせて設定必須。
- **二重読み/パフォーマンス**: 振分けのため nginx が body を一旦メモリ保持してから backend へ転送する。
  ヘッダー版よりレイテンシ・メモリ負荷が増える（大量トラフィック時のサイジングに影響）。
- **GET/非JSON**: body 無し・JSONパース失敗はフォールバック（空店舗コード→default routing）で安全側。

## ★確定が必要な設計事項（このパターンの肝）

1. **相違A: 振分けキー = BODYの店舗コード（4-2-2）** — 上記実装で対応済。ただし
   **BODY内の店舗コードのフィールド名/位置**（route.js の `STORE_BODY_FIELD='storeCode'`）は
   API共通仕様と要突合（TODO）。ネスト構造なら取得ロジック修正。
2. **upstreamMap の拡張性（最重要）** — `DEFAULT`/`SHOP0002_V2` を entrypoint.sh と task-def の env に
   ハードコード列挙。routing_version が増えるたび両方修正が必要 → DB化/動的生成へ再設計（TODO）。
3. **DB認証の Secrets 化** — PoC は平文 env。商用は Secrets Manager/SSM + task-def `secrets`（対応済記述、値は要設定）。
4. **未定義コンテキストパスの 404固定JSON（JIKIPH0-2288）** — `location /` で返却。
   `@backend` は `internal` のため無限ループにならない。エラーコード/メッセージ書式は要確定。
5. **njs/nginx 商用バージョン（JIKIPH0-267）** — PoC 1.27。方式資料 1.28（脆弱性対応で要UP）。
   njs モジュール(nginx-mod-http-js)の入手性含め確定。
6. **タイマー値（4-2-8）** — `PROXY_*_TIMEOUT` の実値。「呼出元リクエストTO ≥ 呼出先の接続+完了最大時間」で設計。
7. **ログ（4-2-13, subtype=NGINX）** — `log_format json_nginx` は暫定。JST/ミリ秒整形・TraceIDヘッダ名・
   route.js の `r.error()` デバッグログとの棲み分けは後続定義（08-logging.md, TODO）。
8. **DBテーブル定義** — `routing`/`default_routing` の正式スキーマをテーブル定義書と要突合。
9. **時間指定リリース運用 / njs Date.parse のタイムゾーン制約（検証で判明・要注意）** —
   `start_at`/`end_at` を使うか。**njs(0.8.x) の `Date.parse` は `+09:00` 形式のオフセットを解釈できず
   `NaN` を返す**（= 時間指定カナリアが常に無効化される）。`Z` 形式 or オフセット無し形式のみ解釈可。
   → loader.py の `iso_for_njs()` で **timestamptz を UTC 'Z' 形式に正規化**して回避済。
   DBカラム型（timestamptz/timestamp）とタイムゾーン基準（UTC/JST）を確定し整形を合わせること。
   `start_at` が `null`/`NaN` のルートは「非有効」となり選ばれない（安全側）点にも注意。
