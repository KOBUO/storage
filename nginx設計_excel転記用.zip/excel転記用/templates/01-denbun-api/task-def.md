# ECS タスク定義（パターン1 電文受付① / nginx + loader サイドカー）

PoC `reference/poc-source/task-def/nginx-task.md`（`poc-canary-deployment-nginx-revision11.json`）を
商用化した記述。**DB 認証情報を Secrets Manager 化**、平文をやめるのが最大の差分。

## コンテナ構成

```
Task: denbun-api (Fargate / awsvpc / LINUX)   cpu/memory: ★サイジング要検討（PoCは256/512）
├─ container: nginx   (essential=true)
│   image: <ECR>/denbun-api-nginx:<tag>
│   portMappings: 80/tcp
│   environment:
│     ROUTING_FILE          = /shared/routing.json
│     SERVER_NAME           = _
│     WORKER_CONNECTIONS    = 512                 # 4-2-7 デフォルト基本
│     LIMIT_CONN            = 10
│     LIMIT_CONN_STATUS     = 503
│     DENBUN_PATH           = /order/             # コンテキストパス（4-2-2）
│     CLIENT_BODY_BUFFER_SIZE = 64k               # ★BODY振分けの副作用: 想定最大電文を収容
│     PROXY_CONNECT_TIMEOUT = 5s
│     PROXY_READ_TIMEOUT    = 60s                 # アイドルTO→504（4-2-8）
│     PROXY_SEND_TIMEOUT    = 60s
│     DEFAULT_UPSTREAM      = http://<default-backend>:80
│     SHOP0002_V2_UPSTREAM  = http://<canary-backend>:80   # ★拡張性課題: version毎にenv追加
│   mountPoints: shared-volume → /shared (readOnly=true)
│   dependsOn:   loader (condition=SUCCESS)        # ★loader 正常終了後に起動
│   logConfiguration: awslogs
│
└─ container: loader  (essential=false, ワンショット)
    image: <ECR>/denbun-api-loader:<tag>
    environment:
      ROUTING_JSON_PATH = /shared/routing.json
      DB_HOST           = <aurora-endpoint>
      DB_PORT           = 5432
      DB_NAME           = <db_name>
      DB_USER           = <db_user>
      DB_CONNECT_TIMEOUT = 5
    secrets:
      # ★平文をやめ、Secrets Manager / SSM Parameter Store から注入（07/01 の TODO）
      DB_PASSWORD = arn:aws:secretsmanager:<region>:<account>:secret:<name>:password::
      # 必要に応じ DB_USER 等も secrets 化
    mountPoints: shared-volume → /shared (readOnly=false)
    logConfiguration: awslogs

volumes: shared-volume (host: {})                 # Fargate タスクローカルの空ボリューム
family: denbun-api
executionRoleArn: <TaskExecutionRole>             # secrets 取得の権限が必要（secretsmanager:GetSecretValue 等）
networkMode: awsvpc
requiresCompatibilities: [FARGATE]
```

## 商用化の要点

1. **起動順序**: `loader(essential=false) → SUCCESS → nginx 起動`。
   loader が routing.json を書いて exit → nginx 起動。loader 失敗時 nginx は起動しない（安全側）。踏襲するか要確認。
2. **DB 認証を Secrets 化**: `environment` の平文をやめ `secrets` で注入。ExecutionRole に取得権限。→ 07/01 TODO
3. **upstream の env 注入（拡張性課題）**: `DEFAULT_UPSTREAM` / `SHOP0002_V2_UPSTREAM` を routing_version 毎に env 追加。
   バージョン追加ごとに task-def と entrypoint.sh の両方修正が必要 → DB化/動的生成が TODO。
4. **共有ボリューム**は `host: {}`（タスクローカル）。nginx は readOnly、loader は書込。
5. **DB 変更の反映** = ECS タスク再起動（起動時に routing.json → routes.js 再生成）。ローリング中の整合を設計。
6. cpu/memory はサイジング要検討（PoC 値 256/512）。
