#!/usr/bin/env python3
# =============================================================================
# パターン1 電文受付① loader（PoC loader.py を商用化）
# -----------------------------------------------------------------------------
# 役割: Aurora(PostgreSQL) の routing / default_routing を SELECT し、
#       /shared/routing.json（共有ボリューム）へ出力する。
#       ワンショット実行（常駐しない）。ECS では essential=false + dependsOn(SUCCESS) で
#       nginx より先に完了させる（失敗時は nginx を起動させない安全側）。
#
# ★商用化ポイント:
#   - DB 認証情報は Secrets Manager / SSM Parameter Store + ECS task-def `secrets` で注入する前提
#     （PoC は平文 env DB_PASSWORD=poc_a）。本コードは環境変数から読むが、値は secrets 由来とする。
#   - 例外処理・接続タイムアウト・ログ出力を追加。異常時は非0で exit（nginx 起動を止める）。
# =============================================================================
import json
import logging
import os
import sys
from datetime import timezone

import psycopg2

logging.basicConfig(
    level=os.environ.get("LOG_LEVEL", "INFO"),
    format="%(asctime)s %(levelname)s loader %(message)s",
)
log = logging.getLogger("loader")


def env(name, default=None, required=False, cast=str):
    val = os.environ.get(name, default)
    if required and (val is None or val == ""):
        log.error("required env %s is not set", name)
        sys.exit(2)
    if val is None:
        return None
    try:
        return cast(val)
    except (TypeError, ValueError) as e:
        log.error("env %s cast error: %s", name, e)
        sys.exit(2)


ROUTING_JSON_PATH = env("ROUTING_JSON_PATH", required=True)
DB_HOST = env("DB_HOST", required=True)
DB_PORT = env("DB_PORT", default="5432", cast=int)
DB_NAME = env("DB_NAME", required=True)
DB_USER = env("DB_USER", required=True)
# ★DB_PASSWORD は Secrets Manager/SSM から task-def `secrets` 経由で注入される想定（平文禁止）。
DB_PASSWORD = env("DB_PASSWORD", required=True)
DB_CONNECT_TIMEOUT = env("DB_CONNECT_TIMEOUT", default="5", cast=int)

def iso_for_njs(dt):
    """start_at/end_at を njs の Date.parse が解釈できる ISO8601 文字列に整形する。

    ★重要（検証で判明）: njs(0.8.x) の Date.parse は "+09:00" 形式のタイムゾーン
    オフセットを解釈できず NaN を返す（route.js の isActive が常に false → 時間指定
    カナリアが無効化される）。そのため:
      - tz-aware(PostgreSQL timestamptz): UTC へ正規化し末尾 'Z' 形式で出力（njs 解釈可）。
      - naive(timestamp without time zone): オフセット無し形式で出力（njs 解釈可）。
    route.js 側の nowMs = Date.now()（UTC epoch）と突き合わせるため UTC 基準で統一する。
    TODO: DB カラムの型（timestamptz か timestamp か）とタイムゾーン基準を確定し、本整形を合わせる。
    """
    if dt is None:
        return None
    if dt.tzinfo is not None:
        return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return dt.strftime("%Y-%m-%dT%H:%M:%S")


SQL_DEFAULT = """
SELECT request_context_path, request_version, routing_version, start_at
FROM default_routing
ORDER BY request_context_path, request_version, start_at
"""

SQL_ROUTING = """
SELECT store_code, request_context_path, request_version, routing_version, start_at, end_at
FROM routing
ORDER BY store_code, request_context_path, request_version, start_at
"""


def load():
    result = {"defaults": {}, "stores": {}}

    log.info("connecting to %s:%s/%s ...", DB_HOST, DB_PORT, DB_NAME)
    conn = psycopg2.connect(
        host=DB_HOST,
        port=DB_PORT,
        dbname=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        connect_timeout=DB_CONNECT_TIMEOUT,
    )
    try:
        with conn:
            with conn.cursor() as cur:
                # default_routing → result["defaults"]  キー: "|{context_path}|{version}"
                cur.execute(SQL_DEFAULT)
                for request_context_path, request_version, routing_version, start_at in cur.fetchall():
                    key = f"|{request_context_path}|{request_version}"
                    result["defaults"].setdefault(key, []).append({
                        "routing_version": routing_version,
                        "start_at": iso_for_njs(start_at),
                        "end_at": None,
                    })

                # routing → result["stores"]  キー: "{store_code}|{context_path}|{version}"
                cur.execute(SQL_ROUTING)
                for store_code, request_context_path, request_version, routing_version, start_at, end_at in cur.fetchall():
                    key = f"{store_code}|{request_context_path}|{request_version}"
                    result["stores"].setdefault(key, []).append({
                        "routing_version": routing_version,
                        "start_at": iso_for_njs(start_at),
                        "end_at": iso_for_njs(end_at),
                    })
    finally:
        conn.close()

    log.info(
        "loaded: defaults=%d keys, stores=%d keys",
        len(result["defaults"]), len(result["stores"]),
    )
    return result


def main():
    try:
        result = load()
    except psycopg2.Error as e:
        # DB 接続/実行エラー: 非0 exit で nginx 起動を止める（dependsOn SUCCESS）。
        log.error("database error: %s", e)
        sys.exit(1)

    # アトミックに書き出し（部分書き込みを nginx に読ませない）。
    tmp = ROUTING_JSON_PATH + ".tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(result, f)
        os.replace(tmp, ROUTING_JSON_PATH)
    except OSError as e:
        log.error("failed to write %s: %s", ROUTING_JSON_PATH, e)
        sys.exit(1)

    log.info("wrote %s", ROUTING_JSON_PATH)


if __name__ == "__main__":
    main()
