// =============================================================================
// パターン1 電文受付① njs 振分けロジック（★方式資料準拠: BODYの店舗コードで振分け）
// -----------------------------------------------------------------------------
// 方式資料 4-2-2 / 07-discrepancies.md 相違A。PoC(reference/poc-source/nginx/route.js)は
// X-Shop-Id ヘッダーで振分けていたが、方式では「カナリア時は BODY の店舗コード」で振分ける。
// PoC のヘッダー版は njs/route.header-poc.js に参考として残す。
//
// 実装方式:
//   - js_content ハンドラ route(r) をエントリにする（js_set ではない）。
//     理由: リクエストBODYの取得(r.requestText())は本文がバッファリングされている
//           コンテンツフェーズで行う必要があり、変数評価(js_set)フェーズでは body 未確定のため。
//   - upstream を決定したら r.variables.upstream に set し、内部 location(@backend) へ
//     r.internalRedirect() で渡す。proxy_pass $upstream が実転送する。
//
// ★BODYベースにしたことで生じる注意点（README にも明記）:
//   1) ペイロード肥大: 大きい body は client_body_buffer_size を超えると一時ファイルに落ち、
//      r.requestText() が undefined を返す（= 店舗コード取得不可 → default routing に倒れる）。
//   2) 二重読み/バッファリング: 振分けのために nginx が body を一旦メモリに保持してから
//      backend へ転送するため、ヘッダー版よりレイテンシ・メモリ負荷が増える。
//   3) GET 等 body の無いリクエスト: 店舗コードは取得できない → default routing。
//   4) 非JSON body: パース失敗 → 空扱い（default routing）。フォールバックで安全側に倒す。
// =============================================================================

import config from '/etc/nginx/njs/routes.js';

// BODY(JSON) 内で店舗コードが格納されるフィールド名。
// TODO: 電文(API共通仕様)の正式なフィールド名/ネスト位置を確定（例: storeCode / header.storeCode 等）。
var STORE_BODY_FIELD = 'storeCode';

// internalRedirect 先の内部 location 名（nginx.conf.template と一致させる）。
var BACKEND_LOCATION = '@backend';

// ---- BODY(JSON) から店舗コードを取得。取得不可時は '' を返す（→ default routing） ----
function extractStoreCodeFromBody(r) {
    var text;
    try {
        // r.requestText は「メソッドではなくプロパティ(getter)」。バッファリング済みの本文を文字列で返す。
        // 本文が一時ファイル化(client_body_buffer_size超過)/本文無しの場合は undefined。
        // ※ r.requestText は js_content ハンドラでのみ利用可（njs HTTP API）。
        text = r.requestText;
    } catch (e) {
        r.error('body read error: ' + e.message);
        return '';
    }
    if (!text) {
        // GET など body 無し、または client_body_buffer_size 超過で一時ファイル化。
        return '';
    }
    var body;
    try {
        body = JSON.parse(text);
    } catch (e) {
        // 非JSON body はフォールバック（default routing）へ。
        r.error('body is not valid JSON, fallback to default routing');
        return '';
    }
    if (body && typeof body === 'object') {
        var v = body[STORE_BODY_FIELD];
        if (v !== undefined && v !== null) {
            return String(v);
        }
    }
    return '';
}

// ---- 元の URI を取得（request_uri 優先、クエリ除去）----
function getOriginalUri(r) {
    var requestUri = r.variables.request_uri || r.uri || '';
    var qpos = requestUri.indexOf('?');
    if (qpos >= 0) {
        return requestUri.substring(0, qpos);
    }
    return requestUri;
}

// ---- URI を context_path / version に分解（例: /order/v2/... → order, v2）----
function splitUri(uri) {
    var parts = uri.split('/').filter(Boolean);
    if (parts.length < 2) {
        return null;
    }
    return {
        request_context_path: parts[0],
        request_version: parts[1]
    };
}

// ---- ルートが現在時刻で有効か（start_at / end_at の期間判定）----
// ★注意（検証で判明）: njs の Date.parse は "+09:00" 形式のオフセットを解釈できず NaN を返す。
//   → start_at/end_at は UTC 'Z' 形式 or オフセット無し形式である必要がある（loader.py の iso_for_njs で整形）。
//   NaN の start_at は下記で「非有効」となり、そのルートは選ばれない（安全側に倒れる）。
function isActive(nowMs, route) {
    var startMs = Date.parse(route.start_at);
    if (isNaN(startMs) || nowMs < startMs) return false;
    if (route.end_at) {
        var endMs = Date.parse(route.end_at);
        if (!isNaN(endMs) && nowMs >= endMs) return false;
    }
    return true;
}

// ---- 有効なルートのうち、最も新しい start_at のものを選ぶ ----
function findActiveRoute(routeList, nowMs) {
    var i;
    var candidate = null;
    if (!routeList || routeList.length === 0) return null;
    for (i = 0; i < routeList.length; i++) {
        var route = routeList[i];
        if (!isActive(nowMs, route)) continue;
        if (candidate == null) {
            candidate = route;
            continue;
        }
        var c = Date.parse(candidate.start_at);
        var n = Date.parse(route.start_at);
        if (!isNaN(n) && !isNaN(c) && n > c) {
            candidate = route;
        }
    }
    return candidate;
}

// ---- routing_version（例 "SHOP0002_V2" / "DEFAULT"）→ upstream URL ----
function routingVersionToUpstream(version) {
    if (!version) return null;
    return config.upstreamMap[version] || null;
}

function safeJson(value) {
    try {
        return JSON.stringify(value);
    } catch (e) {
        return '[json stringify error]';
    }
}

// ==== upstream 決定（PoC の stores→defaults→DEFAULT フォールバックと時間判定を踏襲）====
function pick_upstream(r) {
    var storeCode = extractStoreCodeFromBody(r);   // ★方式: BODYの店舗コード
    var originalUri = getOriginalUri(r);
    var parsed = splitUri(originalUri);

    // デバッグログ（PoC 踏襲。商用はログ量/レベル/出力先を再設計。08-logging.md）
    r.error('===== route decision start =====');
    r.error('r.uri=' + r.uri);
    r.error('originalUri=' + originalUri);
    r.error('storeCode(from body)=' + storeCode);

    if (!parsed) {
        r.error('fallback reason=parsed uri is invalid');
        r.error('===== route decision end =====');
        return config.upstreamMap['DEFAULT'];
    }

    var nowMs = Date.now();
    var storeKey   = storeCode + '|' + parsed.request_context_path + '|' + parsed.request_version;
    var defaultKey =             '|' + parsed.request_context_path + '|' + parsed.request_version;

    r.error('storeKey=' + storeKey);
    r.error('defaultKey=' + defaultKey);

    // 1) 店舗固有ルート
    var storeRouteList = config.routingTable.stores && config.routingTable.stores[storeKey];
    var activeStoreRoute = findActiveRoute(storeRouteList, nowMs);
    var storeUpstream = activeStoreRoute && routingVersionToUpstream(activeStoreRoute.routing_version);
    if (storeUpstream) {
        r.error('selected route=store specific, upstream=' + storeUpstream);
        r.error('===== route decision end =====');
        return storeUpstream;
    }

    // 2) デフォルトルート（店舗コードなしのキー）
    var defaultRouteList = config.routingTable.defaults && config.routingTable.defaults[defaultKey];
    var activeDefaultRoute = findActiveRoute(defaultRouteList, nowMs);
    var defaultUpstream = activeDefaultRoute && routingVersionToUpstream(activeDefaultRoute.routing_version);
    if (defaultUpstream) {
        r.error('selected route=default, upstream=' + defaultUpstream);
        r.error('===== route decision end =====');
        return defaultUpstream;
    }

    // 3) 最終フォールバック
    r.error('fallback reason=route not found, upstream=' + config.upstreamMap['DEFAULT']);
    r.error('===== route decision end =====');
    return config.upstreamMap['DEFAULT'];
}

// ==== js_content エントリ: upstream を決めて内部 location へ internalRedirect ====
function route(r) {
    var upstream = pick_upstream(r);
    // njs から nginx 変数へ書き込み（js_var $upstream; 宣言が前提）。
    r.variables.upstream = upstream;
    // 内部 location @backend（proxy_pass $upstream）へ委譲。body は保持され backend へ転送される。
    r.internalRedirect(BACKEND_LOCATION);
}

export default { route, pick_upstream };
