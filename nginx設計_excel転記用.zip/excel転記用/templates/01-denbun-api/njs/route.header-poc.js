// =============================================================================
// 【参考・非使用】PoC のヘッダー版振分けロジック（X-Shop-Id ヘッダー）
// -----------------------------------------------------------------------------
// これは PoC(reference/poc-source/nginx/route.js) の実装で、店舗コードを
// リクエストヘッダー X-Shop-Id から取得する版。
// 本番採用は njs/route.js（★方式資料準拠: BODYの店舗コード）。
// 本ファイルは「ヘッダー版 vs BODY版」の差分を残すための参考。ビルドには使わない。
//
// 差分の要点:
//   - ヘッダー版: getHeaderCaseInsensitive(r.headersIn, 'X-Shop-Id') で取得。
//     body を読まないためバッファリング不要・低レイテンシ。js_set でも実装可能。
//   - BODY版(採用): r.requestText() で本文JSONを読み店舗コードを取得。
//     本文バッファリングが必要なため js_content + internalRedirect で実装。
// =============================================================================

import config from '/etc/nginx/njs/routes.js';

var HEADER_STORE = 'X-Shop-Id';   // 店舗コードを載せるヘッダー名

function getHeaderCaseInsensitive(headers, name) {
    var key;
    for (key in headers) {
        if (key.toLowerCase() === name.toLowerCase()) {
            return headers[key];
        }
    }
    return '';
}

function normalizeHeaderValue(value) {
    if (!value) return '';
    if (Array.isArray(value)) return value[0];
    return value;
}

function getOriginalUri(r) {
    var requestUri = r.variables.request_uri || r.uri || '';
    var qpos = requestUri.indexOf('?');
    if (qpos >= 0) {
        return requestUri.substring(0, qpos);
    }
    return requestUri;
}

function splitUri(uri) {
    var parts = uri.split('/').filter(Boolean);
    if (parts.length < 2) {
        return null;
    }
    return {
        request_context_path: parts[0],
        request_version: parts[1]
    };
}

function isActive(nowMs, route) {
    var startMs = Date.parse(route.start_at);
    if (isNaN(startMs) || nowMs < startMs) return false;
    if (route.end_at) {
        var endMs = Date.parse(route.end_at);
        if (!isNaN(endMs) && nowMs >= endMs) return false;
    }
    return true;
}

function findActiveRoute(routeList, nowMs) {
    var i;
    var candidate = null;
    if (!routeList || routeList.length === 0) return null;
    for (i = 0; i < routeList.length; i++) {
        var route = routeList[i];
        if (!isActive(nowMs, route)) continue;
        if (candidate == null) {
            candidate = route;
            continue;
        }
        var c = Date.parse(candidate.start_at);
        var n = Date.parse(route.start_at);
        if (!isNaN(n) && !isNaN(c) && n > c) {
            candidate = route;
        }
    }
    return candidate;
}

function routingVersionToUpstream(version) {
    if (!version) return null;
    return config.upstreamMap[version] || null;
}

// PoC は js_set $upstream route.pick_upstream; で公開していた（body 読取り不要のため）。
function pick_upstream(r) {
    var storeCode = normalizeHeaderValue(getHeaderCaseInsensitive(r.headersIn, HEADER_STORE));
    var originalUri = getOriginalUri(r);
    var parsed = splitUri(originalUri);

    if (!parsed) {
        return config.upstreamMap['DEFAULT'];
    }

    var nowMs = Date.now();
    var storeKey   = storeCode + '|' + parsed.request_context_path + '|' + parsed.request_version;
    var defaultKey =             '|' + parsed.request_context_path + '|' + parsed.request_version;

    var storeRouteList = config.routingTable.stores && config.routingTable.stores[storeKey];
    var activeStoreRoute = findActiveRoute(storeRouteList, nowMs);
    var storeUpstream = activeStoreRoute && routingVersionToUpstream(activeStoreRoute.routing_version);
    if (storeUpstream) return storeUpstream;

    var defaultRouteList = config.routingTable.defaults && config.routingTable.defaults[defaultKey];
    var activeDefaultRoute = findActiveRoute(defaultRouteList, nowMs);
    var defaultUpstream = activeDefaultRoute && routingVersionToUpstream(activeDefaultRoute.routing_version);
    if (defaultUpstream) return defaultUpstream;

    return config.upstreamMap['DEFAULT'];
}

export default { pick_upstream };
