# njs/ ディレクトリの中身について

- `route.js` … ★採用版。BODYの店舗コードで振分ける（js_content + internalRedirect）。Dockerfile が COPY する。
- `route.header-poc.js` … 参考。PoC のヘッダー(X-Shop-Id)版。ビルドには使わない。
- `routes.js` … **コミットしない（生成物）**。
  ECS 起動時に `entrypoint.sh` が `/shared/routing.json`（loader が出力）をラップして
  `/etc/nginx/njs/routes.js`（`export default { routingTable, upstreamMap }`）を生成する。
  DB のルーティング情報が変わったら ECS タスク再起動で作り直す運用。
