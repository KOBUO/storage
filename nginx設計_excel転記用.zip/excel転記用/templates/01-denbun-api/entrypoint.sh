#!/bin/sh
# =============================================================================
# パターン1 電文受付① entrypoint（PoC entrypoint.sh を商用化）
# 手順:
#   1) loader が出力した /shared/routing.json を njs 用 routes.js にラップ生成
#      （routingTable + upstreamMap）
#   2) nginx.conf.template を envsubst で展開（展開対象は明示列挙 = 未定義→空文字事故防止）
#   3) nginx -t で構文チェック（routes.js/route.js を含めて検証）
#   4) nginx 起動
# =============================================================================
set -eu

ROUTES_JS="/etc/nginx/njs/routes.js"
TEMPLATE="/etc/nginx/templates/nginx.conf.template"
OUT="/etc/nginx/nginx.conf"

# ---- 0) ①固有の必須変数を先に検証（routes.js/upstreams.conf 生成で使用するため）【codex再#①検証】----
#   未定義だけでなく空値も検知。形式検証（URL/整数）は TODO。
for v in ROUTING_FILE DEFAULT_UPSTREAM SHOP0002_V2_UPSTREAM MAX_CONNS; do
    eval ": \"\${$v:?$v is required}\""
done
# TODO: DEFAULT_UPSTREAM/SHOP0002_V2_UPSTREAM は http(s)://host:port 形式、MAX_CONNS は整数、を形式検証する。

# ---- 1) routing.json → routes.js 生成 ----------------------------------------
echo "Generating $ROUTES_JS from $ROUTING_FILE ..."
if [ ! -f "$ROUTING_FILE" ]; then
    echo "ERROR: $ROUTING_FILE not found (loader サイドカーが未完了の可能性)" >&2
    exit 1
fi

cat > "$ROUTES_JS" <<EOF
export default {
    routingTable:
EOF

cat "$ROUTING_FILE" >> "$ROUTES_JS"

# ★商用課題（拡張性）: upstreamMap / upstream ブロックを環境変数でハードコード列挙している。
#   routing_version（=upstream名）が増えるたびに env と本行の両方を増やす必要 → DB化/動的生成が TODO。
# njs は upstream ブロック名（"http://up_xxx"）を返す。変数 proxy_pass は upstream 名に一致する。
cat >> "$ROUTES_JS" <<EOF
,
    upstreamMap: {
        "DEFAULT": "http://up_default",
        "SHOP0002_V2": "http://up_shop0002_v2"
    }
};
EOF

echo "===== routes.js ====="
cat "$ROUTES_JS"

# ---- 1.5) upstream ブロック生成（max_conns=サーバー単位の同時接続制御 / Confluence）----
#   env の "http://host:port" から scheme を除いて server 行にする。zone は max_conns 共有に必要。
UPSTREAMS="/etc/nginx/upstreams.conf"
strip_scheme() { echo "$1" | sed -E 's#^https?://##'; }
cat > "$UPSTREAMS" <<EOF
upstream up_default {
    zone up_default 64k;
    server $(strip_scheme "$DEFAULT_UPSTREAM") max_conns=${MAX_CONNS};
}
upstream up_shop0002_v2 {
    zone up_shop0002_v2 64k;
    server $(strip_scheme "$SHOP0002_V2_UPSTREAM") max_conns=${MAX_CONNS};
}
EOF
echo "===== upstreams.conf ====="
cat "$UPSTREAMS"

# ---- 2) nginx.conf.template を envsubst 展開 ---------------------------------
# 展開対象の環境変数を明示（列挙外の $var（$host, $upstream, $status 等）はそのまま残す）。
# 必須環境変数の検証（未定義/空なら起動失敗させる。envsubstは未定義を空展開するため事前検証が必須）
# ※ DEFAULT_UPSTREAM/SHOP0002_V2_UPSTREAM/MAX_CONNS/ROUTING_FILE は上の routes.js/upstreams.conf 生成で使用済。
for v in SERVER_NAME WORKER_CONNECTIONS LIMIT_CONN LIMIT_CONN_STATUS \
         LIMIT_REQ_RATE LIMIT_REQ_BURST LIMIT_REQ_STATUS LIMIT_RATE LIMIT_RATE_AFTER \
         DENBUN_PATH CLIENT_BODY_BUFFER_SIZE \
         PROXY_CONNECT_TIMEOUT PROXY_READ_TIMEOUT PROXY_SEND_TIMEOUT; do
    eval ": \"\${$v:?$v is required}\""
done

VARS='${SERVER_NAME} ${WORKER_CONNECTIONS}
${LIMIT_CONN} ${LIMIT_CONN_STATUS}
${LIMIT_REQ_RATE} ${LIMIT_REQ_BURST} ${LIMIT_REQ_STATUS}
${LIMIT_RATE} ${LIMIT_RATE_AFTER}
${DENBUN_PATH} ${CLIENT_BODY_BUFFER_SIZE}
${PROXY_CONNECT_TIMEOUT} ${PROXY_READ_TIMEOUT} ${PROXY_SEND_TIMEOUT}'

echo "Generating $OUT from $TEMPLATE ..."
envsubst "$VARS" < "$TEMPLATE" > "$OUT"

echo "===== nginx.conf ====="
cat "$OUT"

# ---- 3) 構文チェック（route.js/routes.js の読み込みも検証される）----
nginx -t -c "$OUT"

# ---- 4) 起動 ----
echo "Start nginx"
exec nginx -g 'daemon off;' -c "$OUT"
