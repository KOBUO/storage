# 04. ③ 本部画面用 React（静的配信 + S3中継）

## 1. 処理概要

- **目的**: 本部画面（React SPA）を配信。**静的コンテンツは ECS同梱(root)配信**、ファイルの**UL/DLはS3へ中継**（VPC GW EP）。
- **認証はALB(OIDC/Entra ID)**。nginxは認証しない。**閉塞はAPI判定**（nginx非関与）。【出典: 4-3-14 / 4-3-19】

### 特記事項
- ★未定義URLは**index.htmlを200で返す（404にしない）**＝SPA fallback。電文受付の404とは**逆**。【出典: 4-3-9 p92】
- **【Q14 仮確定】静的配信 = ECS同梱root**（利用者記憶「コンテナにReact資材」と一致）。`dist/`をイメージにCOPY→`root`+`try_files`。**結合検証PASS**（`_検証記録.md`）。S3バック版は conf に代替コメントとして保持。
  - → 同梱にしたことで **S3静的の認可(codex #3)・SPA403混在(codex #4) は解消**（静的はローカル完結）。S3認可の論点は **UL/DL中継のみ**に縮小。
- 🟡[要確認] UL/DLの署名ホスト/スタイル → ②で **path-style + Host置換** を実証済（同方式採用予定）。【Q15はUL/DL中継のS3認可として継続】

## 2. 処理詳細

```
【リクエスト時】
 (A) ファイルUL/DL中継 /files/...                      … S3_ENDPOINT / MAX_UPLOAD_SIZE / LIMIT_RATE
     1. 流量制御（レート/同時接続）
        ＜超過した場合＞ → 503
     2. ホスト名をS3に置換して中継（VPC GW EP）【出典: 4-3-16/17】
        ＜ULの場合＞ client_max_body_size で上限。ストリーム中継
        ＜DLの場合＞ 下り帯域制御
     3. ＜S3がエラーの場合＞ → そのまま返却（リトライしない=4-3-11）

 (B) 静的コンテンツ配信 /  （ECS同梱root, Q14仮確定）      … REACT_ROOT
     1. 流量制御（レート/同時接続）
     2. 同梱資材(root=REACT_ROOT)から try_files で配信
        ＜ファイルが存在する場合＞   → そのまま返却（200）
        ＜存在しない(未定義URL)場合＞ → index.html を 200 で返す（SPA fallback）【出典: 4-3-9 p92】

 ※ 認証は前段のALBで実施済（未認証はALBがIdPへリダイレクト）。nginxは認証済み前提で配信。【出典: 4-3-14】
```

## 3. nginx.config

> 実体: `../templates/03-react/nginx.conf.template`

```nginx
worker_processes auto;
events { worker_connections ${WORKER_CONNECTIONS}; }
http {
    include /etc/nginx/mime.types; default_type application/octet-stream;
    log_format json_nginx escape=json '{ …subtype=NGINX… }';
    access_log /var/log/nginx/access.log json_nginx;

    limit_req_zone  $binary_remote_addr zone=reqlimit:10m rate=${LIMIT_REQ_RATE};
    limit_conn_zone $server_name        zone=perserver:10m;
    limit_conn_status ${LIMIT_CONN_STATUS};
    limit_req_status  ${LIMIT_REQ_STATUS};
    proxy_http_version 1.1; proxy_ssl_server_name on;

    server {
        listen 80; server_name ${SERVER_NAME};
        location = /health { return 200 'ok'; }

        # (A) UL/DL中継（S3へ, Host置換）
        location ${FILE_RELAY_PATH} {              # 例 /files/
            limit_req  zone=reqlimit burst=${LIMIT_REQ_BURST} nodelay;
            limit_conn perserver ${LIMIT_CONN};
            limit_rate ${LIMIT_RATE}; limit_rate_after ${LIMIT_RATE_AFTER};
            client_max_body_size ${MAX_UPLOAD_SIZE};
            rewrite ^${FILE_RELAY_PATH}(.*)$ /$1 break;
            proxy_set_header Host ${S3_ENDPOINT};
            proxy_pass ${S3_SCHEME}://${S3_ENDPOINT};   # 既定https（VPC GW EP）
            proxy_request_buffering off; proxy_next_upstream off; proxy_intercept_errors off;
        }
        # (B) 静的配信（ECS同梱root）+ SPA fallback  ★Q14=同梱で仮確定・検証PASS
        location / {
            limit_req  zone=reqlimit burst=${LIMIT_REQ_BURST} nodelay;
            limit_conn perserver ${LIMIT_CONN};
            root  ${REACT_ROOT};                   # 同梱資材（dist/ を COPY）
            try_files $uri $uri/ /index.html;      # SPA fallback（未定義URL→index.html 200）
        }
        # ※認証=ALB(OIDC), 閉塞=API判定 → nginx非関与
        # ※S3バック配信にする場合は proxy_pass + error_page 404=@spa_fallback（403は除外, codex#4）に置換
    }
}
```

## 4. 想定

| # | ケース（＜〜の場合＞）| リクエスト例 | 結果 |
|---|-------------------|------------|------|
| 1 | ＜存在する静的ファイルの場合＞ | `GET /assets/app.js` | 同梱rootから配信→200 |
| 2 | ＜未定義URL（画面ルーティング）の場合＞ | `GET /orders/123` | **index.html を200**（SPA fallback）|
| 3 | ＜ファイルULの場合＞ | `PUT /files/xxx?<署名>` | S3へ中継（UL）|
| 4 | ＜ファイルDLの場合＞ | `GET /files/xxx?<署名>` | S3から中継（DL）|
| 5 | ＜未認証でアクセスした場合＞ | 任意 | ALBがIdPへリダイレクト（nginx到達前）|
| 6 | ＜レート/同時接続を超過した場合＞ | 超過 | 503 |

## 5. エラーハンドリング

【出典: 4-3-9 p92（静的コンテンツ / S3リクエスト）】。方針=「未定義URL→index.html(200)」「S3エラー→エラー画面」。

### 静的コンテンツに対するリクエスト（ECS同梱root）
| # | 発生箇所 | ＜エラー内容の場合＞ | 処理方法 | 返却ステータス | クライアント側 |
|---|---------|-------------------|---------|-------------|-------------|
| 1-1 | ELB | ＜呼び出し先タイムアウトの場合＞ | ELBの仕様 | 502 Bad Gateway(リクエストTO) / 504(コネクションTO) | ブラウザ表示に従う |
| 1-2 | ELB | ＜認証エラーの場合＞ | **IdPログイン画面へリダイレクト**（nginx非関与）| **302 Found** | IdPへリダイレクト |
| 1-5 | **nginx** | ＜想定していないURLへのアクセスの場合＞ | **`try_files` で index.html を返却**（同梱root, S3往復なし）| **200 OK**（index.html）| ブラウザ表示に従う |
| 1-6 | nginx | ＜その他想定外エラーの場合＞ | nginx デフォルト挙動 | （nginx デフォルト）| ブラウザ表示に従う |

### S3 に対するリクエスト（UL/DL中継）
| # | 発生箇所 | ＜エラー内容の場合＞ | 処理方法 | 返却ステータス | クライアント側 |
|---|---------|-------------------|---------|-------------|-------------|
| 3-3 | nginx | ＜S3アクセスでタイムアウトの場合＞ | nginx デフォルト挙動 | **504 Gateway Timeout** | HTTPステータス確認しエラーメッセージ表示 |
| 3-5 | nginx | ＜S3がエラーを返した場合＞ | そのまま返却 | S3のステータス | — |
| 3-6 | S3(クライアント起因) | ＜URI不正/アクセスキー不正/権限不足の場合＞ | S3の仕様 | **4xx**（404/400/403）| **エラー画面に遷移** |
| 3-7 | S3(サーバ起因) | ＜内部失敗/リクエスト過多の場合＞ | S3の仕様 | **5xx**（500/504）| **DL/静的GETは業務要件に応じ再試行可。ULは再送しない（重複防止, 4-3-11）** |

> ※ 静的の SPA fallback（1-5）は **同梱root＋`try_files`** でローカル完結（S3往復なし）。UL/DL中継（3-x）の 404/403 は S3 素通し。両者は別扱い。
> ※【codex #4 解消】同梱rootにしたため、S3静的時代の「`error_page 403 404`で403も200化」問題は**該当しなくなった**（`try_files`は不在時のみindex.html化, 403の隠蔽なし）。S3バック版を採る場合のみ「404のみfallback」を適用（confの【代替】に記載）。
> 🟡[要確認]【codex #9 / Q17】UL/DL でリトライ方針を分ける（**UL=再送禁止 / DL=再試行可**）。用途・HTTPメソッド別に確定。

### TODO（③固有）
- [x] **【Q14】静的配信方式 = ECS同梱root で仮確定**（結合検証PASS）。本番方針としてチーム最終合意はTODO。4-3-4
- [x] **【Q16】SPA fallback**: 同梱root+`try_files`で **404を返さずindex.html(200)**。検証PASS（S3バックの403混在問題は同梱化で解消）
- [ ] 🟡【Q15】UL/DL中継のS3認可（署名付きURL=②同方式 / バケットポリシー+VPC EP）を確定（静的は同梱で対象外に縮小）
- [ ] 🟡【Q17】UL/DL リトライ方針（UL=再送禁止 / DL=再試行可）を確定。codex #9 / 4-3-11
- [ ] 🟡 キャッシュ制御（index.html no-cache / ハッシュ資産 長期）
- [ ] 🟡 UL(PUT)中継の実測（本検証はDL中継まで。機構は同じHost置換proxy）
- [ ] 🟡【Q21】React で参照すべき資料をアプリチームに確認（未入手）
