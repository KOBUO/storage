# ログ出力方式（4-2-13）

出典: 方式設計書 4-2-13（画像 IMG_5397, 5398）。

## 方針

- ログは **JSON 形式**。下記項目を出力（必要に応じ追加可）。
- **nginx 等 MW が出力するログフォーマットは「下記を踏襲しつつカスタマイズ可能な範囲を確認し、別途後続で定義」**
  → **nginx の log_format をこの JSON 項目に寄せる作業が残る（TODO・後続定義）**。

## ログ項目（共通基盤利用ガイドライン準拠）

| 項目名 | JSONキー | 説明 | 運用監視ログ | アプリ実行ログ | 証跡ログ |
|--------|---------|------|-------------|--------------|---------|
| タイムスタンプ | `timestamp` | サーバ時刻(JST) 書式 `yyyy-MM-ddHH:mm:ss.SSS` | 対象 | 対象 | 対象 |
| コンテナID | `id` | 実行コンテナのID | 対象 | 対象 | 対象 |
| コンテナ名 | `name` | 実行コンテナ名 | 対象 | 対象 | 対象 |
| ログレベル | `level` | ログレベル | ERROR | ERROR/WARN/INFO/DEBUG（稼働後DEBUG対象外）| INFO |
| ログ種類 | `type` | ログ種類識別 | `monitor` | `app` | `trail` |
| スレッド番号 | `thread` | 各処理の一意識別（バッチは任意）| スレッドID | スレッドID | スレッドID |
| 機能ID | `function` | 機能の一意識別 | API名 | API名 | API名 |
| ユーザID | `user` | 利用者の一意識別 | - | - | POS:端末情報 / 内部API:クライアント情報 |
| 操作 | `action` | 操作情報（内容はシステムごと検討）| - | - | API名 |
| ログ種類詳細 | `subtype` | 出力箇所特定（下表）| 対象 | 対象 | - |
| トレースID | `trace` | クライアント送信のTraceID（無い処理は出力しない）| 対象※可能な場合 | 対象※可能な場合 | 対象 |
| 本文 | `message` | ログ本文 | 対象 | 対象 | 対象 |

## ログ種別（type）3系統

- `monitor` 運用監視ログ（ERROR）
- `app` アプリ実行ログ（ERROR/WARN/INFO/DEBUG）
- `trail` 証跡ログ（INFO）

## subtype 一覧

| subtype | 概要 | 説明 |
|---------|------|------|
| SYSTEM | システムログ | Tomcat/Spring 出力 |
| **NGINX** | **nginx ログ** | **nginx のログ** |
| AWSCALL | AWS呼出 | AWS-API呼出時。Request ID / Request Timestamp / Response Time / S3 Extended Request ID(S3のみ) / MessageId(SQSのみ) |
| DBCALL | DB呼び出し | 実行SQL関連 |
| APL | その他アプリログ | アプリ開発側で必要なログ |

## nginx への落とし込み（TODO）

- nginx は `subtype=NGINX`。`log_format` を上記 JSON キーに合わせて定義する:
  - `timestamp`（JST, ミリ秒）, `id`/`name`（コンテナ）, `level`, `type`, `thread`, `function`, `trace`, `message` 等
  - nginx 変数で取得可能なもの（`$time_iso8601`, `$request`, `$status`, `$upstream_addr`, リクエストヘッダのTraceID等）とのマッピングを定義
- **正式な nginx ログフォーマットは後続で別途定義**（方式資料明記）。ここは確定していない。
- カナリア route.js の `r.error(...)` デバッグログ（PoC）との整合・棲み分けも要検討。
