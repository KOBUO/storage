# 10. 環境変数 命名規約 / 統一表（横断）

> 3本の nginx conf テンプレート（①電文受付API / ②ファイルDL / ③React）で使う環境変数を統一する規約。
> **基準は完成手本 `templates/02-filedl/`**。環境変数の実装一覧は `設計書/05_環境変数一覧.md` を参照。
> 出典: 方式設計書 4-2-7 / 4-2-8 / 4-2-18 / 4-3-6 / 4-3-7 / 4-3-16、Confluence「環境変数で設定」IMG_5011。

## 命名規約

1. **UPPER_SNAKE_CASE**。conf 内は `${VAR}` 形式（envsubst 展開）。
2. **役割プレフィックスで揃える**: `LIMIT_*`（流量/帯域）, `PROXY_*`（プロキシ挙動）, `S3_*`（中継先）, `DB_*`（loader）, `WORKER_*`。
3. **同一概念は同一名**。パターンをまたいで意味が同じ変数は必ず同名にする（例: 同時接続数は常に `LIMIT_CONN`）。
4. **パスは `*_PATH`**、末尾スラッシュ込みの location プレフィックスを入れる（例 `/download/`, `/files/`）。
5. **流量制御は方式資料∪Confluenceの両方を反映**（相違D解消）。`limit_req`+`limit_conn`+`limit_rate` を**3 conf 共通**で使う。→ `LIMIT_REQ_*`・`LIMIT_RATE*` は共通変数（下表）。
6. **envsubst は展開対象を明示列挙**（entrypoint.sh の `VARS`）。未定義変数を空に潰す事故を防ぐ。
7. 秘匿値（DBパスワード等）は env 直書きせず **Secrets Manager / SSM**（task-def `secrets`）。

## 共通変数（全 conf）

| 変数 | 例 | 用途 | 方式根拠 |
|------|-----|------|---------|
| `SERVER_NAME` | `_` | `server_name` | — |
| `WORKER_CONNECTIONS` | `512` | `worker_connections`。**デフォルト512基本**（相違C、PoCの1024は不採用）| 4-2-7 / 4-3-6 |
| `LIMIT_CONN` | `10` | location への `limit_conn` 同時接続数 | 4-2-7 / 4-3-6 |
| `LIMIT_CONN_STATUS` | `503` | `limit_conn` 超過時ステータス（**599採用可否は要確認**）| docs/04 |
| `LIMIT_REQ_RATE` | `10r/s` | `limit_req_zone` のレート（Confluence反映）| docs/04 |
| `LIMIT_REQ_BURST` | `20` | `limit_req` の burst | docs/04 |
| `LIMIT_REQ_STATUS` | `503` | `limit_req` 超過時ステータス | docs/04 |
| `LIMIT_RATE` | `0`(=無制限) / `1m` | 下り帯域上限（**3 conf 共通**。DL不要な①や静的は `0`）| 4-2-2 / 4-3-17 |
| `LIMIT_RATE_AFTER` | `1m` | この量までは無制限 | 4-2-2 / 4-3-17 |
| `PROXY_CONNECT_TIMEOUT` | `5s` | 接続TO | 4-2-8 / 4-3-7 |
| `PROXY_READ_TIMEOUT` | `60s` | 読取(アイドル)TO → 超過504 | 4-2-8 / 4-3-7 |
| `PROXY_SEND_TIMEOUT` | `60s` | 送信TO | 4-2-8 / 4-3-7 |

> ログのコンテナ識別（方式ログ項目 `id`/`name`）を env で入れる場合は `CONTAINER_ID` / `CONTAINER_NAME` を追加（現状は `$hostname` 代用）。TraceID ヘッダ名確定と合わせて docs/08 で決定。

## ① 電文受付API 固有（`templates/01-denbun-api`）

| 変数 | 例 | 用途 | 方式根拠 |
|------|-----|------|---------|
| `DENBUN_PATH` | `/order/` | 通常API の location プレフィックス | 4-2-2 |
| （loader）`DB_HOST` `DB_PORT` `DB_NAME` `DB_USER` | — | Aurora 接続 | PoC IMG_5379 |
| （loader）`DB_PASSWORD` | — | **→ Secrets Manager 化必須**（PoCは平文）| task-def |
| `ROUTING_JSON_PATH` (=`ROUTING_FILE`) | `/shared/routing.json` | loader 出力 / nginx 参照。**PoCで2名が混在→要統一** | IMG_5377/5378 |
| （entrypoint）`DEFAULT_UPSTREAM` `SHOP0002_V2_UPSTREAM`… | `http://host:80` | upstream ブロック生成元 + upstreamMap 注入。**routing_version ごとに増える＝拡張性課題** | IMG_5377 |
| `MAX_CONNS` | `10` | **upstream `max_conns`（サーバー単位の同時接続, Confluence）**。①のみ（②③はS3相手で不要）。entrypointが upstream ブロックに付与 | Confluence(location流量制御調査) |

> PoC の task-def は `ROUTING_JSON_PATH`(loader) と `ROUTING_FILE`(nginx) の**2名**で同じファイルを指す。商用では1名に統一すること。

> **流量制御変数（`WORKER_CONNECTIONS` / `LIMIT_CONN` / `LIMIT_CONN_STATUS` / `LIMIT_REQ_*` / `LIMIT_RATE` / `LIMIT_RATE_AFTER`）は上の「共通変数」に集約**。3 conf 共通で同名・同値（帯域を効かせない所は `LIMIT_RATE=0`）。以下は各パターン固有変数のみ。

## ② ファイルDL 固有（`templates/02-filedl` = 基準）

| 変数 | 例 | 用途 | 方式根拠 |
|------|-----|------|---------|
| `FILE_DL_PATH` | `/download/` | DL の location プレフィックス | 4-2-18 |
| `S3_ENDPOINT` | `bucket.s3.ap-northeast-1.amazonaws.com` | 中継先S3ドメイン（Host置換 + proxy_pass、VPC GW EP 経由）| 4-2-18 |

## ③ React 固有（`templates/03-react`）

| 変数 | 例 | 用途 | 方式根拠 |
|------|-----|------|---------|
| `FILE_RELAY_PATH` | `/files/` | UL/DL中継の location プレフィックス（②の `FILE_DL_PATH` と役割は別: 双方向中継）| 4-3-16/17 |
| `S3_ENDPOINT` | 同上 | 静的配信バック兼中継先 | 4-3-4/16/17 |
| `MAX_UPLOAD_SIZE` | `100m` | `client_max_body_size`（UL）| 4-3-16 |
| （同梱時のみ）`REACT_ROOT` | `/usr/share/nginx/html` | root配信の代替版で使用 | docs/07-I |

## 廃止 / 非推奨（旧ドラフト由来。使わない）

| 変数 | 理由 | 代替 |
|------|------|------|
| `LIMIT_CONN_PER_LOCATION` | 命名ゆれ | `LIMIT_CONN` |
| `PROXY_PASS_URL` | 動的 proxy は njs の `$upstream`（①）/ S3中継（②③）に集約 | 各 conf の方式に従う |
| `PROXY_BACKEND` | 動的 proxy は njs の `$upstream`（①）に集約。upstream ブロックは entrypoint 生成 | — |
| `S3_BUCKET` / `S3_REGION` | `S3_ENDPOINT` に集約（ドメインで表現）| `S3_ENDPOINT` |
| `REACT_ORIGIN` | 配置はS3バック確定（相違I）。CloudFront proxy案は不採用 | `S3_ENDPOINT`（S3バック）/ `REACT_ROOT`（同梱時）|

## 残課題（値の確定待ち）

- `LIMIT_CONN` / `LIMIT_CONN_STATUS`（599採否）の正式値 … 業務要件・タスク多重度と合わせ（docs/04）
- タイムアウト各値 … 業務要件（docs/05 §2）
- コンテナ識別・TraceID ヘッダ名 … ログ仕様確定（docs/08, 4-2-13）
- `WORKER_CONNECTIONS` を 512 で確定してよいか（4-2-7 デフォルト基本）
