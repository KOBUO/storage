# 流量制御（Rate Limiting）

> ✅ **【原則】流量制御は「処理方式設計書」と「先行連携の Confluence（流量制御調査）」の両方を反映する。**
> また **3パターン（①②③）とも同じ流量制御を入れる**。
> - 方式設計書(4-2-7/4-3-6): `worker_processes`/`worker_connections`（デフォルト512基本）, `limit_conn`/`limit_conn_zone`($server_name)
> - Confluence(本資料): `limit_req`/`limit_req_zone`（レート制限）, `limit_rate`/`limit_rate_after`（帯域）, （`limit_conn_zone` のキー候補 $uri/$binary_remote_addr）, （`max_conns`）
> → **採用セット = `limit_req` + `limit_conn` + `limit_rate` + worker**（3 conf 共通）。
>   ※以前「`limit_req` は方式外につき不採用」としていたのは誤り。**Confluence を反映する原則により `limit_req` は採用**。
>   ※ `max_conns`（サーバー単位, Confluence）は **①で採用**。entrypoint が backend ごとに upstream ブロック（`max_conns` 付）を生成し、njs は upstream 名を返す。②③はS3相手のため不要。

出典: Confluence「3. API の流量制御に関連する設定項目の調査」（2026/06/15 更新）
    + 「location による Nginx の流量制御調査(20260511)」

## 方針

- 各所で多層的に流量制御を行う（POS 向け API は ①〜⑤、内部 API は ④⑤ のみ）。
- ECS 内の設定値は **タスク単位**。オートスケール時は変動を加味。
- **設定値は環境変数化**する（今回のテンプレート化の対象）。

## 設定項目一覧（多層防御）

| # | 分類 | コンポーネント | 設定項目 / 小項目 | 説明 | 超過時の挙動 |
|---|------|--------------|------------------|------|-------------|
| 1 | 電文受付 | ELB | Target Optimizer | ターゲット単位の最大同時リクエスト数 | 503 |
| 2 | | **nginx** | `limit_conn` | 同一 IP からの接続数制限 | デフォルト503（`limit_conn_status`で変更可） |
| 3 | | **nginx** | `limit_conn_zone` | server_name に対する接続数制限 | 同上 |
| 4 | | java | （共通部品で流量制御） | 独自実装が必要 | - |
| 5 | アプリ | ELB | Target Optimizer | ターゲット単位の最大同時リクエスト数 | 503 |
| 6 | | API/Tomcat | `maxThreads` | 最大スレッド数（同時処理数） | 503 |
| 7 | | | `maxConnections` | 最大同時接続数（NIO/NIO2でスレッド数より大きく可） | 429 |
| 8 | | | `acceptCount` | 全スレッド埋まった際のOSキュー待機最大数 | 503 |
| 9 | | HikariCP | `maximumPoolSize` | コネクションプールの上限 | 拒否 or タイムアウト |
| 11 | | Aurora | （流量制御項目なし） | 読み取りレプリカ / Serverless ACU 自動スケール | - |

## Nginx の流量制御（検証済の結論）

nginx では **2 系統** で流量制御可能:

| 手段 | 制御単位 | 用途 | 設定場所 |
|------|---------|------|---------|
| `limit_conn` (+ `limit_conn_zone`) | **サービス単位** | 特定ユーザー/サービスのバースト防止 | location / http |
| `max_conns`（upstream server） | **バックエンドサーバー単位** | backend のキャパシティ超過(過負荷)防止 | upstream の server 行 |

### limit_conn_zone のキー選択

| キー | 制御単位 | 例 |
|------|---------|-----|
| `$server_name` | ホスト単位 | api.example1.com, api.example2.com |
| `$uri` | URI（サービス）単位 | /api1, /api2, /api1/app1 |
| `$binary_remote_addr` | 接続元 IP 単位 | 192.168.0.10, ... |

### 具体的な設定例（調査メモより）

```nginx
http {
    # リクエストレート制限: IP ごとに 1 秒 10 リクエストまで
    limit_req_zone $binary_remote_addr zone=mylimit:10m rate=10r/s;

    server {
        location /api {
            limit_req zone=mylimit burst=20;          # 超過分 20 までバッファ
            # limit_req zone=mylimit burst=20 nodelay; # 即時処理 or 破棄
            limit_conn myconn 10;                      # IP ごと最大 10 接続
            limit_rate 100k;                           # 帯域 100KB/s
            limit_rate_after 1m;                       # 1MB 以降に帯域制限
            proxy_pass http://backend_server;
        }
    }
}
```

### 検証で確認済（location 単位 + upstream max_conns）

- `limit_conn_zone $uri zone=perlocation:10m;` + location ごとに `limit_conn perlocation 1;`
  → **location(バックエンド)単位で同時接続数制御ができる**ことを実機確認（`limit_conn_status 599`）。
- `upstream backend { zone backend_zone 64k; server ${PROXY_BACKEND} max_conns=1; }`
  → **バックエンドサーバー(ホスト+ポート)単位で同時接続制御ができる**ことを確認。
- 結論: **max_conns = サーバー単位 / limit_conn = サービス単位** の流量制御が可能。

## 環境変数化の実例（検証テンプレートより）

- `proxy_pass ${PROXY_PASS_URL};`
- `upstream backend { server ${PROXY_BACKEND} max_conns=1; }`

## TODO

- [ ] POS 向け(①〜⑤)と内部(④⑤)で適用範囲を分ける方法（location 分割 / 別 conf）
- [ ] 各制限値の正式値（rate / burst / conn 数 / max_conns）とタスク多重度の考え方
- [ ] `limit_conn_status` の統一（599 を採用するか、他値か）
- [ ] 超過時のレスポンス body（電文仕様に合わせた JSON か）
- [ ] `limit_conn_zone` のキーを最終的にどれにするか（$uri / $server_name / IP の組合せ）
- [ ] 環境変数の命名規約（下記テンプレートと統一）
