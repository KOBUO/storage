# 資料: 流量制御が「効く」仕組み（config の該当行で解説）

nginx の流量制御は **「定義（zone）」と「適用」の2行がペアで揃って初めて効く**（片方だけでは効かない）。
本書は、実際の config（`templates/01-denbun-api/nginx.conf.template` ＋ entrypoint 生成の `upstreams.conf`）の
**どの行があるから、どの流量制御が効いているか**を対応づけて示す。

> ①電文受付は流量制御が全部入り（`limit_req` + `limit_conn` + `limit_rate` + `max_conns`）なので例に使う。
> ②③は `max_conns` を除き同じセット（相手が S3 のため server 単位は不要）。

---

## 全体像：どの行がどの制御を効かせるか

```nginx
# ===== events =====
events {
    worker_connections ${WORKER_CONNECTIONS};   # (0) nginx自身が捌ける最大同時接続
}

http {
    # ===== ① http：ゾーン定義（ここで宣言しないと下の適用が効かない） =====
    limit_req_zone  $binary_remote_addr zone=reqlimit:10m rate=${LIMIT_REQ_RATE};  # (1定義) レート
    limit_conn_zone $server_name        zone=perserver:10m;                        # (2定義) 同時接続
    limit_conn_status ${LIMIT_CONN_STATUS};   # 超過時ステータス（例 503）
    limit_req_status  ${LIMIT_REQ_STATUS};

    include /etc/nginx/upstreams.conf;         # (4定義) upstream(max_conns) を読み込む

    js_import route from /etc/nginx/njs/route.js;
    js_var $upstream;

    server {
        location /order/ {
            # ===== ② location：適用（上の zone を参照して初めて効く） =====
            limit_req  zone=reqlimit burst=${LIMIT_REQ_BURST} nodelay;  # (1適用) → レート制限が効く
            limit_conn perserver ${LIMIT_CONN};                         # (2適用) → 同時接続制限が効く
            js_content route.route;
        }
        location @backend {
            internal;
            limit_rate       ${LIMIT_RATE};       # (3適用) → 下り帯域制限が効く（0=無制限）
            limit_rate_after ${LIMIT_RATE_AFTER};
            proxy_pass $upstream;                 # (4適用) $upstream="http://up_default" → upstream名に一致
        }
    }
}
```

```nginx
# entrypoint が生成する /etc/nginx/upstreams.conf
upstream up_default {
    zone up_default 64k;
    server 192.168.1.227:80 max_conns=${MAX_CONNS};   # (4定義) → backendサーバー単位の同時接続が効く
}
upstream up_shop0002_v2 {
    zone up_shop0002_v2 64k;
    server 192.168.0.65:80 max_conns=${MAX_CONNS};
}
```

---

## (1) レート制限（`limit_req`）が効く理由

| 役割 | config の行 | 場所 |
|------|-----------|------|
| **定義** | `limit_req_zone $binary_remote_addr zone=reqlimit:10m rate=${LIMIT_REQ_RATE};` | http |
| **適用** | `limit_req zone=reqlimit burst=${LIMIT_REQ_BURST} nodelay;` | location |

- **この2行が揃っているから**、接続元IP（`$binary_remote_addr`）ごとに **1秒あたり `${LIMIT_REQ_RATE}`（例 10r/s）** のレート制限が効く。
- `burst` は瞬間的な超過を `${LIMIT_REQ_BURST}` 個までバッファ。超過は `limit_req_status`（例 503）で返す。
- ❌ もし `limit_req_zone`（定義）だけで location に `limit_req`（適用）が無ければ **一切効かない**（ゾーンを用意しただけ）。

## (2) 同時接続制限（`limit_conn`）が効く理由

| 役割 | config の行 | 場所 |
|------|-----------|------|
| **定義** | `limit_conn_zone $server_name zone=perserver:10m;` | http |
| **適用** | `limit_conn perserver ${LIMIT_CONN};` | location |

- **この2行が揃っているから**、`$server_name` 単位で **同時接続 `${LIMIT_CONN}`（例 10）** に制限される。
- 超過は `limit_conn_status`（例 503）。
- キーを `$server_name` にしているので「server_name 単位」。`$binary_remote_addr` にすればIP単位、`$uri` にすればURI単位（方式資料は `$server_name`）。
- ⚠️ **実効範囲の注意**: 共有ゾーンは**同一 nginx(ECSタスク)内の worker 間のみ共有**。ECSタスク間では共有されない。
  よって「サービス全体上限」ではなく **ECSタスク内の上限**であり、実効上限 ≒ **設定値 × 稼働タスク数**。値は最大タスク数を加味して算定する。【codex #6】
- ⚠️ ALB経由だと `limit_req` の `$binary_remote_addr` は**ALBのIP**になる。実IPで制御するなら `real_ip`（`X-Forwarded-For` + 信頼CIDR）が必要。【codex #7】

## (3) 下り帯域制限（`limit_rate`）が効く理由

| 役割 | config の行 | 場所 |
|------|-----------|------|
| **適用のみ** | `limit_rate ${LIMIT_RATE}; limit_rate_after ${LIMIT_RATE_AFTER};` | location |

- `limit_rate` は **zone 定義が不要**（location に書くだけで効く）。
- **この行があるから**、1コネクションあたりの下り速度が `${LIMIT_RATE}`（例 1m=1MB/s）に制限される。`${LIMIT_RATE_AFTER}` までは無制限。
- `${LIMIT_RATE}=0` なら**無制限**（＝実質オフ）。①APIは 0、②③のDLで有効値、という使い分け。

## (4) サーバー単位の同時接続（`max_conns`）が効く理由

| 役割 | config の行 | 場所 |
|------|-----------|------|
| **定義** | `upstream up_default { zone up_default 64k; server host:port max_conns=${MAX_CONNS}; }` | upstream（`upstreams.conf`）|
| **適用** | `proxy_pass $upstream;`（`$upstream` = `"http://up_default"` = upstream名）| location |

- `max_conns` は **`upstream{}` ブロックの `server` 行にしか書けない**。だから ①は upstream ブロックを使う。
- **この定義があるから**、特定 backend サーバーへの同時接続が `${MAX_CONNS}` に制限される（＝サーバー過負荷防止）。
- `zone` を書くことで、複数 worker プロセス間で `max_conns` のカウントが共有される（無いと worker 単位になる）。
- njs が `$upstream` に **upstream 名**（`http://up_default`）を返す → 変数 `proxy_pass` は**まず upstream 名を探す**ので一致して効く。
- ②③は相手が S3（1台のサーバーではない）なので `max_conns` は不要（方式資料も「S3は前段の limit_conn で制限」）。

## (0) `worker_connections`（nginx 自身の上限）

- `events { worker_connections ${WORKER_CONNECTIONS}; }`。**この行があるから** nginx 1 worker が同時に扱える接続数が決まる（過負荷防止の土台）。方式資料は**デフォルト512基本**。

---

## まとめ：定義↔適用のペア対応表

| 制御 | 定義（http/upstream）| 適用（location）| 効く単位 | 3conf |
|------|------------------|----------------|---------|:-----:|
| レート `limit_req` | `limit_req_zone ... rate=` | `limit_req zone=reqlimit burst=` | IP単位 | ①②③ |
| 同時接続 `limit_conn` | `limit_conn_zone $server_name` | `limit_conn perserver` | サービス単位 | ①②③ |
| 帯域 `limit_rate` | （定義不要）| `limit_rate` / `limit_rate_after` | コネクション単位 | ①②③（0=無効可）|
| サーバー単位 `max_conns` | `upstream{ server ... max_conns= }` | `proxy_pass $upstream` | サーバー単位 | ①のみ |
| nginx上限 `worker_connections` | `events{ worker_connections }` | — | コンテナ全体 | ①②③ |

> **要点**: `limit_req`/`limit_conn`/`max_conns` は **定義と適用の2行が揃って初めて効く**。
> `limit_rate` と `worker_connections` は単独で効く。
> 実体: `templates/01-denbun-api/nginx.conf.template`（②③は `templates/02-filedl/`・`03-react/`）。3本とも `nginx -t` 通過済み。
