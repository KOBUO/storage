# 連携資料（画像）インデックス

業務端末の画面撮影画像（閲覧用 JPG）を保管。内容は設計書に反映済み。

- `images/` … 閲覧用 JPG（計81枚）
- ※ HEIC原本（236MB）は内容を本インデックス＋設計書に集約済みのため削除。原本は業務端末側 `~/Downloads` に存在。

抜け漏れ確認用に、各画像の内容を1行で記録（第1弾29枚）。

| ファイル | 内容 |
|---------|------|
| IMG_3007 | Confluence「Nginxパラメータ設計」全体（conf gitlab管理 / 対象=電文受付・ファイルDL・React / エラー時挙動 JIKIPH0-2288 / 見直し資料）|
| IMG_3008 | 同上の拡大（対象3つ・見直して反映してほしい資料=方式設計書 特に流量制御・テーブル定義書）|
| IMG_3009 | Confluence コメント「画面によっては、ファイルULなどがあって」（松尾優一）|
| IMG_3010 | IMG_3008 の別ズーム（Nginxパラメータ設計の対象一覧）|
| IMG_3011 | Confluence コメント「環境変数で設定できるようにする」（松尾優一）|
| IMG_3012 | JIRA JIKIPH0-2288 電文受付で存在しないコンテキストパス→404 の課題（説明・無限ループ懸念）|
| IMG_3013 | JIKIPH0-2288 コメント（404固定JSON: apiStatus/errors/validationErrCd/Message）|
| IMG_3014 | Confluence NRI アプリアーキ（配信制御登録API仕様変更 / 定義書:ユーザ情報・認可情報・暗号化・ファイルアップロード / トランザクションTO JIKIPH0-2261 → 電文受付Nginxでアイドルタイムアウト）|
| IMG_3015 | JIRA JIKIPH0-267 Nginx脆弱性対応（1.28に脆弱性・バージョンアップ必要・内結テストまで目途）|
| IMG_3016 | Confluence「nginxのproxy_read_timeoutの検証」（5s設定, sleep4s=200/5s=境界/6s=504）|
| IMG_3017 | Confluence「3.APIの流量制御に関連する設定項目の調査」構成図（①〜⑥ ELB/nginx/java/Aurora）+ 設定項目表 頭 |
| IMG_3018 | 流量制御 設定項目一覧（1-12: ELB Target Optimizer / nginx limit_conn・limit_conn_zone / Tomcat maxThreads等 / HikariCP / Aurora）|
| IMG_3019 | 流量制御 一覧の右側（項目説明・流量超過時の挙動 503/429・参照URL）|
| IMG_3020 | 流量制御 調査メモ（nginx設定例: limit_req_zone/limit_req burst/limit_conn/limit_rate）|
| IMG_3021 | 「locationによるNginxの流量制御調査」比較表 + limit_conn_zone $server_name / $binary_remote_addr の設定例 |
| IMG_3022 | 同 設定例続き（perip の location / limit_conn_status 599）|
| IMG_3023 | upstream max_conns の説明・設定例 + 検証内容（location単位 limit_conn）|
| IMG_3024 | 検証用 nginx.conf.template（limit_conn_zone $uri perlocation / api1・api2 / health / ${PROXY_PASS_URL}）|
| IMG_3025 | 同テンプレート続き + 検証ケース（proxy先API 10秒sleep 前提）|
| IMG_3026 | 検証ケース表（ケース1-4: api1/api2 へ 200/599 確認）+ 検証結果ターミナル |
| IMG_3027 | 検証結果 実施結果OK + 結論（limit_connで制御可）+ 追加検証(upstream max_conns) 導入 |
| IMG_3028 | 追加資材 nginx.conf.template（upstream backend zone/server ${PROXY_BACKEND} max_conns=1 / api1・api2 proxy_pass http://backend/）|
| IMG_3029 | 追加検証ケース表 + 検証結果（502/599/200）|
| IMG_3030 | 追加検証 結論（max_connsでサーバー単位制御可）+「全体を通して」max_conns/limit_conn のキー表（$server_name/$uri/$binary_remote_addr）|
| IMG_3031 | JIRA JIKIPH0-220 カナリアリリース njs検証（概要・検証観点: sidecarでAurora routing/default_routingを共有ボリュームへキャッシュ、nginx+njsで参照proxy・参考資料）|
| IMG_3032 | JIKIPH0-220 コメント（構成: Client→Nginx(Fargate)→route.js→backend(default/shop002_v2) + 資材ツリー init/loader/nginx/routing_backend）|
| IMG_3033 | JIKIPH0-220 資材ツリー続き + routing_backend の RESPONSE_NAME/MESSAGE 表（default / shop002_v2）|
| IMG_3034 | JIKIPH0-220 処理の流れ（1-7: DB取得→loader.py JSON→起動時route.js→X-Shop-Id/request_uri→store+version判定→backend転送）+ 試験ケース（店舗コード×バージョン×ルーティング先）|
| IMG_3035 | JIKIPH0-220 検証結果（bastion SSM curl: X-Shop-Id 000002+v2 のみ shop0002_v2、他はdefault）+ 結論・クローズ |

## 第2弾（IMG_5366〜5384, 19枚）— PoC 実ソース

`canary_deployment` プロジェクトを IDE で開いた画面。復元コードは `reference/poc-source/` に格納。
一部は縦向き（回転）撮影。

| ファイル | 内容 |
|---------|------|
| IMG_5366 | README.md「やること」前半（loader用コンテナ/Dockerfile/loader.py/nginx用コンテナ/entrypoint.sh/routes.js/route.js/nginx.conf の役割一覧）|
| IMG_5367 | README.md 続き（共有領域 /shared/routing.json、ECSタスク構成 nginx/loader(sidecar)/共有Volume）|
| IMG_5368 | nginx/nginx.conf（js_import route、js_set $upstream route.pick_upstream、location / で proxy_pass $upstream、/health）★方式B |
| IMG_5369 | nginx/entrypoint.sh（routing.json をラップして routes.js 生成、upstreamMap を env で埋込、nginx 起動）|
| IMG_5370 | nginx/Dockerfile（FROM nginx:1.27-alpine、nginx-mod-http-js jq、COPY 各種、ENTRYPOINT）|
| IMG_5371 | route.js 前半（HEADER_STORE='X-Shop-Id'、getHeaderCaseInsensitive、normalizeHeaderValue、getOriginalUri、splitUri）|
| IMG_5372 | route.js（isActive 期間判定、findActiveRoute、routingVersionToUpstream 冒頭）|
| IMG_5373 | route.js（findActiveRoute/routingVersionToUpstream/safeJson、pick_upstream 前半：storeKey/defaultKey 生成、デバッグlog）|
| IMG_5374 | route.js（pick_upstream：storeRouteList→findActiveRoute→storeUpstream、defaults 分岐、fallback DEFAULT）|
| IMG_5375 | route.js（default 分岐続き、最終 fallback、export default { pick_upstream }）|
| IMG_5376 | プロジェクトツリー（canary_deployment: init/loader/nginx/routing_backend/shared/README、各 task-def json）|
| IMG_5377 | nginx task-def json 前半（containerDefinitions nginx、portMappings 80、environment ROUTING_FILE/SHOP0002_V2_UPSTREAM/DEFAULT_UPSTREAM、mountPoints shared→/shared readOnly、dependsOn loader SUCCESS）|
| IMG_5378 | nginx task-def（DEFAULT_UPSTREAM=http://192.168.1.227:80、loader コンテナ定義、DB_NAME=poc_db、ROUTING_JSON_PATH、awslogs）|
| IMG_5379 | nginx task-def（loader environment DB_HOST=lsc-poc-aurora...rds、DB_PORT=5432、DB_USER=poc_a、DB_PASSWORD=poc_a、shared-volume readOnly=false）|
| IMG_5380 | nginx task-def（volumesFrom/LogConfiguration awslogs、family、executionRoleArn LSC-POC-IAMR-TASKEXECUTION、networkMode awsvpc、volumes shared-volume host{}）|
| IMG_5381 | nginx task-def（requiresAttributes 各 capability、placementConstraints、compatibilities FARGATE、cpu 256/memory 512、runtimePlatform X86_64/LINUX、registeredAt/By）|
| IMG_5382 | loader/loader.py 前半（import、env DB接続情報、psycopg2.connect、result{defaults/stores}、sql_default/sql_routing、fetch ループ）|
| IMG_5383 | loader/loader.py（sql の SELECT カラム、setdefault で defaults/stores 構築、start_at/end_at isoformat）|
| IMG_5384 | loader/Dockerfile（FROM python:3.12-slim、WORKDIR /app、pip install psycopg2-binary、COPY loader.py、CMD）|

## 第3弾（IMG_5385〜5417, 33枚）— 方式設計書（優先資料）

`【COSMO_Ph0】SSD-010_処理方式設計書_方式設計_v1.00.10.pptx`。最優先資料。docs/06〜08 に反映。

| ファイル | 内容 |
|---------|------|
| IMG_5385 | 4-2-2 電文受付機能（通常API/ファイルDLで処理方式を分ける理由、URL構造、nginx①②、ファイルULは通常API扱い）|
| IMG_5386 | 4-2-7 流量制御方式（電文受付②nginx+⑤API、設定値タスク単位）表 前半 |
| IMG_5387 | 4-2-7 流量制御 表（②nginx worker_processes/connections デフォルト基本、limit_conn/limit_conn_zone server_name単位、⑤maxThreads/HikariCP）|
| IMG_5388 | 4-2-8 タイマー制御（コネクション/リクエストTO、T4/T8/T10設定対象外）|
| IMG_5389 | 4-2-8 タイマー制御 T5のみ処理TO 補足 |
| IMG_5390 | 4-2-8 タイマー表（T1〜T11。T3 nginx→ALB=nginx設定ファイル504、※ファイルDLはnginx→S3）|
| IMG_5391 | 4-2-10 エラーハンドリング（通常API: ELB/nginx/API、到達前後、JSON形式）|
| IMG_5392 | 4-2-10 エラーハンドリング箇所 構成図（通常API: ①クライアント②ELB③nginx④ELB⑤Tomcat⑥Java）|
| IMG_5393 | 4-2-10 通常API エラー表（1-1〜1-6: nginxタイムアウト504、1-6 呼び出し先エラーそのまま返却）|
| IMG_5394 | 4-2-10 ファイルDL エラーハンドリング箇所 構成図（②ELB③nginx④S3、with帯域制御ヘッダ）|
| IMG_5395 | 4-2-10 ファイルDL エラー表（3-3 nginx→S3 504、3-6/3-7 S3 4xx/5xx）|
| IMG_5396 | 4-2-13 ログ出力方式（JSON項目 timestamp/id/name/level/type/thread/function/user/action/subtype/trace/message、nginxログは後続定義）|
| IMG_5397 | 4-2-13 ログ項目 詳細表（運用監視/アプリ実行/証跡の出力内容）|
| IMG_5398 | 4-2-13 ログ種別（subtype: SYSTEM/NGINX/AWSCALL/DBCALL/APL）|
| IMG_5399 | 4-2-18 ファイルDL方式（通常方式=配信計画で返却したURLにPOSアクセス、署名付き、nginxがS3ドメイン置換中継 / オフラインDL 固定URL posVersion）|
| IMG_5400 | 4-3-4 負荷分散方式（画面系: LAW端末→ALB→Webサーバnginx→S3、①ELB設定対象、②nginx設定対象外、統合認証基盤）|
| IMG_5401 | 4-3-6 流量制御方式（画面系: ②nginx worker_processes/connections デフォルト、limit_conn/limit_conn_zone S3エンドポイント同時接続制限）|
| IMG_5402 | 4-3-7 タイマー制御 シーケンス図（T1〜T11、クライアント/ALB/Nginx/S3/API/ElastiCache/DB/外部）|
| IMG_5403 | 4-3-7 タイマー制御 コネクション/リクエストTOの関係（アイドルタイムアウト補足、ALB/nginx）|
| IMG_5404 | 4-3-7 タイマー表（T3 nginx→S3=nginx設定ファイル504、T1でReactアプリ内エラーハンドリング）|
| IMG_5405 | 4-3-9 エラーハンドリング（1.静的コンテンツ: 存在しないURL→index.html返却/404にしない、2.API、3.S3）|
| IMG_5406 | 4-3-9 静的コンテンツ エラーハンドリング箇所 構成図（②nginx、Webサーバnginx→S3）|
| IMG_5407 | 4-3-9 静的コンテンツ エラー表（1-5 nginx想定外URL→index.html 200、1-2 認証エラー→IdPリダイレクト302）|
| IMG_5408 | 4-3-9 S3リクエスト エラーハンドリング箇所 構成図（③nginx④S3）|
| IMG_5409 | 4-3-9 S3リクエスト エラー表（3-3 nginx→S3 504、3-6/3-7 S3 4xx/5xx、エラー画面遷移）|
| IMG_5410 | 4-3-11 リトライ方式（画面(React)→APIはリトライしない、API→Aurora/ElastiCache参照系のみ設定、ファイルUL Nginxリトライしない）|
| IMG_5411 | 4-3-14 認証・認可方式 認証フロー（Entra ID OIDC: 未認証→IdPログイン→認可コード→IDトークンJWT→認証セッションID→静的コンテンツ、ALBで認証）|
| IMG_5412 | 4-3-16 ファイルアップロード方式 基本方針（S3格納 物理名=時刻+UUID上書禁止、論理名↔物理名DB、React直接UL、閉域網でNginx経由、VPC Gateway EP）|
| IMG_5413 | 4-3-16 ファイルUL 処理フロー（ユーザ/React/API(Spring)/Nginx/S3/DB、格納先URLホスト名Nginx置換、UL中継、UL管理DB、業務DB別TX）|
| IMG_5414 | 4-3-17 ファイルダウンロード方式 基本方針（S3取得、React直接DL、閉域網Nginx経由、ホスト名置換、VPC Gateway EP中継）|
| IMG_5415 | 4-3-17 ファイルDL 処理フロー（取得元URL発行→ホスト名Nginx置換→Nginx VPC GW EP経由S3中継、DL管理DB）|
| IMG_5416 | 4-3-19 閉塞制御方式1（初回画面起動時、API→Aurora閉塞状態問合せ、alt 閉塞OFF=トップ/ON=閉塞画面）|
| IMG_5417 | 4-3-19 閉塞制御方式2（ユーザ操作時、各APIで閉塞状態問合せ、alt OFF=操作画面/ON=閉塞画面）|

## 第4弾（IMG_5435〜5436, 2枚）— loader.py 全体（末尾の書き出し部含む）

| ファイル | 内容 |
|---------|------|
| IMG_5435 | loader.py 前半（import/env/psycopg2.connect/result/sql_default/sql_routing/with conn ループ）|
| IMG_5436 | loader.py 後半（L38-63: 2ループ + **書き出し `with open(...,"w",encoding=utf-8): json.dump(result,f,ensure_ascii=False)` + 確認print3行**）|

→ 第2弾で未撮影だった **routing.json 書き出し部を確認**。`reference/poc-source/loader/loader.py` を実物に修正済み。

> 追加で連携される画像は、`sources/images/` に追記し、本表にも行を足していく。
> **抜け漏れ確認**: 第1弾29 + 第2弾19 + 第3弾33 + 第4弾2 = **計83枚**。
