// エラー応答は index.html / error.html（nginx.conf の error_page）のため、本モジュールはログ出力のみを担う。

var ERROR_MESSAGES = {
    503: '同時接続数が上限を超えました。',
    500: 'サーバ内部でエラーが発生しました。',
};

function logLevel(r) {
    return Number(r.variables.status) >= 500 ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    return ERROR_MESSAGES[Number(r.variables.status)] || '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { logLevel, logMessage, logLatency, logTimestamp };
