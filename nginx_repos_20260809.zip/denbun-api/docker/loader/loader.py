#!/usr/bin/env python3
"""ルーティング情報を Aurora DB から取得し、共有ボリュームへ出力する。

ワンショット実行。異常時は非0で終了し、Nginx コンテナを起動させない。
"""
import json
import os
import sys
from datetime import datetime, timedelta, timezone

import psycopg2

ROUTING_FILE_PATH = "/shared/routing.json"

# 適用開始日時・適用終了日時は JST として解釈する。
JST = timezone(timedelta(hours=9))

# 検索キー重複時の採用行を一意に決めるため、明示的に整列して取得する。
SQL_ROUTING = """
SELECT store_cd, request_context_path, request_ver, routing_dest_ver,
       appl_start_dt_tm, appl_end_dt_tm
FROM laif_routing_info
ORDER BY store_cd, request_context_path, request_ver, appl_start_dt_tm
"""

SQL_DEFAULT_ROUTING = """
SELECT request_context_path, request_ver, routing_dest_ver, appl_start_dt_tm
FROM laif_default_routing
ORDER BY request_context_path, request_ver, appl_start_dt_tm
"""


def log(level, message):
    now = datetime.now(JST)
    levels = {"ERROR": (40000, "monitor"), "INFO": (20000, "app")}
    level_value, log_type = levels[level]
    record = {
        "timestamp": now.strftime("%Y-%m-%d %H:%M:%S.") + f"{now.microsecond // 1000:03d}",
        "id": os.environ.get("CONTAINER_ID", "-"),
        "name": os.environ.get("CONTAINER_NAME", "-"),
        "level": level,
        "level_value": level_value,
        "type": log_type,
        "thread": "-",
        "function": "-",
        "user": "-",
        "action": "-",
        "subtype": "NGINX",
        "trace": "-",
        "message": message,
    }
    print(json.dumps(record, ensure_ascii=False), file=sys.stderr)


def abort(message):
    log("ERROR", message)
    sys.exit(1)


def required_env(name):
    value = os.environ.get(name)
    if not value:
        abort(f"必須環境変数が設定されていません。（環境変数名: {name}）")
    return value


def connect():
    host = required_env("DATABASE_HOST")
    port = required_env("DATABASE_PORT")
    try:
        return psycopg2.connect(
            host=host,
            port=port,
            dbname=required_env("DATABASE_NAME"),
            user=required_env("DATABASE_USER"),
            password=required_env("DATABASE_PASSWORD"),
            connect_timeout=int(os.environ.get("DATABASE_CONNECT_TIMEOUT", "5")),
            # sslmode: 平文で流さない。statement_timeout: DB応答遅延でタスク起動を止めない。
            sslmode=os.environ.get("DATABASE_SSLMODE", "require"),
            options="-c statement_timeout=10000",
        )
    except psycopg2.Error:
        abort(f"データベースへの接続に失敗しました。（接続先: {host}:{port}）")


def epoch_milliseconds(value):
    """日時を JST として解釈し、エポックミリ秒へ変換する。

    振分け処理（njs）での日時文字列の解釈差を避けるため、数値で受け渡す。
    """
    if value is None:
        return None
    jst_datetime = value if value.tzinfo else value.replace(tzinfo=JST)
    return int(jst_datetime.timestamp() * 1000)


def fetch(connection):
    """ルーティング情報およびデフォルトルーティング情報を全件一括で取得する。"""
    with connection.cursor() as cursor:
        try:
            cursor.execute(SQL_ROUTING)
            routing_rows = cursor.fetchall()
        except psycopg2.Error:
            abort("ルーティング情報の取得に失敗しました。（対象: laif_routing_info）")

        try:
            cursor.execute(SQL_DEFAULT_ROUTING)
            default_routing_rows = cursor.fetchall()
        except psycopg2.Error:
            abort("ルーティング情報の取得に失敗しました。（対象: laif_default_routing）")

    if not default_routing_rows:
        abort("デフォルトルーティング情報が取得できませんでした。")

    return routing_rows, default_routing_rows


def shape(routing_rows, default_routing_rows):
    """検索キーからルーティング先バージョンを引ける形に整形する。"""
    routing = {}
    for store_cd, context_path, request_ver, dest_ver, start, end in routing_rows:
        routing[f"{store_cd}|{context_path}|{request_ver}"] = {
            "dest": dest_ver,
            "apply_start": epoch_milliseconds(start),
            "apply_end": epoch_milliseconds(end),
        }

    default_routing = {}
    for context_path, request_ver, dest_ver, start in default_routing_rows:
        key = f"{context_path}|{request_ver}"
        default_routing.setdefault(key, []).append({
            "dest": dest_ver,
            "apply_start": epoch_milliseconds(start),
        })

    # 振分け処理が「適用開始日時が現在日時以前の最新世代」を先頭から探せるよう、降順に整列する。
    for generations in default_routing.values():
        generations.sort(key=lambda generation: generation["apply_start"] or 0, reverse=True)

    return {"routing": routing, "default_routing": default_routing}


def write(routing_information, path):
    # 書き込み途中のファイルを Nginx に読ませないため、一時ファイル経由で差し替える。
    temporary_path = path + ".tmp"
    try:
        with open(temporary_path, "w", encoding="utf-8") as f:
            json.dump(routing_information, f, ensure_ascii=False)
        os.replace(temporary_path, path)
    except OSError:
        abort(f"ルーティング情報ファイルの出力に失敗しました。（出力先: {path}）")


def main():
    connection = connect()
    try:
        routing_rows, default_routing_rows = fetch(connection)
    finally:
        connection.close()
    routing_information = shape(routing_rows, default_routing_rows)
    write(routing_information, ROUTING_FILE_PATH)
    log("INFO", "ルーティング情報を出力しました。"
        f"（routing: {len(routing_information['routing'])}件 / "
        f"default_routing: {len(routing_information['default_routing'])}キー）")


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        abort("コンテナの起動処理で予期せぬエラーが発生しました。")
