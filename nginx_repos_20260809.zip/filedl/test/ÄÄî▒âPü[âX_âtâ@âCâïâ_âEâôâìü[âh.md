# 試験ケース — ファイルダウンロード

- 設計根拠: ファイルダウンロード.md
- 対象実装: 本リポジトリの `docker/`
- 前提: ダウンロードURLは API が発行する path-style の素のURL（署名なし）。ホスト名を nginx に置換して実行する。アクセス認可はバケットポリシー（VPCエンドポイント経由）で行う。
- エラー電文 = `{"apiStatus":"<code>","errors":[{"validationErrCd":"<code>","validationMessage":"<reason>"}]}`
- 証跡取得時は接続先を直書きせず、事前に `接続先=http://<実際の接続先>` を実行（この行は証跡に含めない）し、
  `curl -i "$接続先/…"` の形で実行する。

---

## ケース1 ファイルが帯域制限つきでダウンロードできること

- **条件**: 通常のタスク定義でデプロイ。S3 に検証用オブジェクトを配置する:
  s3/hello.txt と、3MB程度のファイル（`head -c 3000000 /dev/zero > large.bin` で作成）。
  ダウンロードURLは `http://<接続先>/download/<バケット>/hello.txt` の形式（ホストは nginx）とする。
- **手順**:
  ```sh
  curl -s -H 'X-BandWidth-Limit: 8' -o out.bin "$URL_小"   # 取得後、元ファイルと比較
  curl -s -o /dev/null -w '8Mbps: %{time_total}s\n'   -H 'X-BandWidth-Limit: 8'   "$URL_3MB"
  curl -s -o /dev/null -w '800Mbps: %{time_total}s\n' -H 'X-BandWidth-Limit: 800' "$URL_3MB"
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 1-1 | 起動成功・コンテナ情報の取得 | タスク起動成功。ログの `id`/`name` にタスクメタデータ由来の値 | 起動は代替済（id/name は Fargate でのみ確認可） |
| 1-2 | **実S3でのダウンロード（Host置換でS3へ中継）** | 200・取得ファイルが元と一致 | 代替済（MinIO。実S3は AWS で） |
| 1-3 | 帯域制御（Mbps→バイト/秒 換算） | `8` 指定 ≒ サイズ(MB)÷1 秒（3MBなら約3秒）。`800` 指定は即時 | 代替済（3.2s/0.016s） |
| 1-4 | 正常ログ項目 | level=INFO / type=app / **url はクエリ込みで出力（秘匿情報を含まない）**/ status=200 / latency(ms) / timestamp=JSTミリ秒 | 代替済 |

## ケース2 帯域制限値ヘッダやパスが不正な場合、エラー電文が返ること

- **手順**:
  ```sh
  curl -i "$URL_小"                                   # ヘッダ無し
  curl -i -H 'X-BandWidth-Limit: abc' "$URL_小"        # 不正値
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/other/x"          # 対象外パス
  curl -i -H 'X-BandWidth-Limit: 8000000000000000' "$URL_小"  # 上限超過(16桁)
  curl -i -X POST -H 'X-BandWidth-Limit: 8' "$URL_小"          # GET/HEAD以外
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/fixed.txt?posVersion=..%2Fx"  # posVersion不正
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 2-1 | 帯域制限値ヘッダ欠落 | **400** + エラー電文（validationMessage=`Bad Request`）。ログ ERROR「帯域制限値が設定されていません。」 | 代替済 |
| 2-2 | 帯域制限値が不正 | 400 + エラー電文。ログ ERROR「帯域制限値が不正です。」 | 代替済 |
| 2-3 | 対象外パス | **404** + エラー電文（`Not Found`）。ログ ERROR「対象外のパスです。」 | 代替済 |
| 2-4 | 帯域制限値が上限超過（16桁等） | **400**（換算後の指数表記による帯域制限バイパスを防止） | 代替済 |
| 2-5 | GET/HEAD 以外のメソッド | **405** + エラー電文（`Method Not Allowed`）。S3 への PUT/DELETE 中継を遮断 | 代替済 |
| 2-6 | posVersion が不正（`../` 等） | **400** + エラー電文。バケット外への参照を遮断 | 代替済 |

## ケース3 S3が返したエラーが加工されずに返却されること

- **手順**: 存在しない、またはバケットポリシーで許可されていないオブジェクトを要求して実行。
  ```sh
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/<バケット>/nonexistent.bin"
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 3-1 | S3エラーの透過 | S3 の **403（`AccessDenied`）/404（`NoSuchKey`）** をステータス・本文（XML）とも加工せず返却。Content-Type も S3 のまま | 代替済 |
| 3-2 | S3起因エラーのログ | level=**INFO**（nginxとしては正常処理。message=`-`） | 代替済 |

## ケース4（任意）オフラインファイルがダウンロードできること

- **条件**: オフライン用バケット（`OFFLINE_BUCKET`）に s3/offline/2.0.0/fixed.txt を
  キー `2.0.0/fixed.txt` で配置する。
- **手順**:
  ```sh
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/<固定ファイル名>?posVersion=2.0.0"
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/<固定ファイル名>"   # posVersion無し
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 4-1 | オブジェクトキーの組み立て | 200。S3キー=`/<OFFLINE_BUCKET>/2.0.0/<固定名>`、転送時のクエリから `posVersion` は除去 | 代替済 |
| 4-2 | posVersion 欠落 | 400 + エラー電文。ログ ERROR「POSバージョンが設定されていません。」 | 代替済 |

## ケース5 低速クライアントでも転送ファイルが Nginx 内に溜まり続けないこと

- **背景**: `proxy_buffering on`（`limit_rate` を効かせるために必須）では、クライアントの受信が遅いと
  Nginx が S3 から先読みした分を保持する。`proxy_max_temp_file_size 0` により、この保持がディスクへ退避されず、
  かつ全量には及ばないことを確認する。
- **条件**: S3 に大きめのファイル（例: 500MB。`head -c 500000000 /dev/zero > big.bin`）を配置する。
  転送中に、ECS Exec で Nginx コンテナに入り、一時ファイル領域とワーカーのメモリを観察する。
- **手順**: クライアントを十分に低速（`X-BandWidth-Limit: 1`）にして大きめファイルをダウンロードし、
  転送中に別セッションで Nginx コンテナ内を繰り返し観察する。
  ```sh
  # クライアント（低速でダウンロードを継続）
  curl -s -H 'X-BandWidth-Limit: 1' -o /dev/null "$URL_big" &
  # Nginx コンテナ内（転送中に繰り返し確認）
  du -sh /var/cache/nginx/proxy_temp                  # 一時ファイル領域
  grep VmRSS /proc/$(pgrep -n nginx)/status           # ワーカーのメモリ
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 5-1 | ディスクへの退避が発生しないこと | `proxy_max_temp_file_size 0` により、一時ファイル領域（`proxy_temp`）にファイルが作られない（サイズは 0 のまま） | AWSで実施 |
| 5-2 | メモリ保持が全量に及ばないこと | ワーカーのメモリが転送ファイルサイズまで増えず、`proxy_buffers` 相当の範囲に収まる。S3 からの読み出しはクライアントの受信速度に追従する | AWSで実施 |
| 5-3 | ファイルの完全性 | 低速でも最終的に全量を取得でき、内容が元ファイルと一致する | AWSで実施 |

---

> 追加検証済（代替）: 同時ダウンロード数上限(`LIMIT_CONNECTION`)超過で503 / 日本語・空白キーのエンコード保持でキー破損なし / S3への余計なヘッダ(Cookie/Authorization/X-BandWidth-Limit)除去 / 上流DNSの都度再解決(resolve)。
>
> 対象外: S3接続不可502／応答タイムアウト504（実S3では再現困難。njsとerror_pageの機構は電文受付と同一で代替環境確認済み）／
> 起動異常系（必須env検証は電文受付・本部画面と同一実装。ローカル確認で足りる）／帯域 `0`=無制限（`limit_rate 0` の nginx 仕様）。
