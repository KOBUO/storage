# 第1部　要件・項目定義（Excel資料レベル）

> この部は「Markdown設計書を書けるレベル」の情報をまとめたもの。
> 出典：顧客設計書 **SSD-010 処理方式設計書**。
> **(TODO)** は未確定・要確認事項を表す。

---

## 1.1 ログ種類・logback定義

| ログ種類名 | 物理名 | type | logger_name | ログレベル | 出力先 | subtype例 |
|---|---|---|---|---|---|---|
| Nginxログ | nginx | app/monitor | （既存・固定名なし／レベルで判定） | INFO | stdout/stderr | NGINX |
| アクセスログ | access | app | SPRINGBOOT_API_ACCESS_LOG | INFO | stdout | APL |
| アクセスジャーナルログ | access_jnl | app | SPRINGBOOT_API_ACCESS_JNL_LOG | INFO | stdout | APL |
| サービスジャーナルログ | service_jnl | app | SPRINGBOOT_SERVICE_JNL_LOG | INFO | stdout | APL |
| SQLジャーナルログ | sql_jnl | app | SPRINGBOOT_SQL_JNL_LOG | INFO | stdout | DBCALL |
| ストレージアクセスジャーナルログ | storage_jnl | app | SPRINGBOOT_STORAGE_JNL_LOG | INFO | stdout | AWSCALL |
| 外部アクセスジャーナルログ | external_jnl | app | SPRINGBOOT_HTTP_CLIENT_JNL_LOG | INFO | stdout | APL |
| キャッシュジャーナルログ | cache_jnl | app | SPRINGBOOT_CACHE_JNL_LOG | INFO | stdout | APL |
| メッセージジャーナルログ | msg_jnl | app | SPRINGBOOT_SQS_JNL_LOG | DEBUG/INFO/WARN | stdout | AWSCALL |
| KMSアクセスジャーナルログ | kms_jnl | app | SPRINGBOOT_KMS_JNL_LOG | INFO | stdout | AWSCALL |
| DynamoDBアクセスジャーナルログ | dynamodb_jnl | app | SPRINGBOOT_DYNAMODB_JNL_LOG | INFO | stdout | AWSCALL |
| 業務ログ | app | app | SPRINGBOOT_API_LOG | DEBUG/INFO/WARN | stdout | APL |
| 業務エラーログ | app_err | monitor | SPRINGBOOT_ERROR_LOG | ERROR | stderr | APL |
| システムログ | (root) | app/monitor | **（固定名なし・root）** | INFO/WARN/ERROR | stdout(ERROR→stderr) | SYSTEM |

- **出力先方針（確定）**：CloudWatch Logs 収集のため stdout/stderr を明示。**ERROR→stderr / それ以外→stdout** を `LevelFilter` で振り分ける。
- **encoder方針（確定）**：logstash-logback-encoder。`@timestamp`→`timestamp`（`yyyy-MM-dd HH:mm:ss.SSS` / JST）、`@version` は抑止。MDC は `<mdc>` provider で出力（`includeMdcKeyName` で出力キーを明示）。
- **type はレベル判定で導出**：`ERROR→monitor` / それ以外→`app`（`trail`=証跡は現状未使用）。subtype は logger_name から導出（固定ロガー以外＝システムログ＝`SYSTEM`）。
- **システムログ** = 実装で明示出力していない＝固定ロガーに該当しない root のログ（Spring/Tomcat等のFW・未捕捉）。「システムログ＋システムエラーログ」を包含。
- KMS / DynamoDB は**追加ログ種類**として logger_name を定義（`SPRINGBOOT_KMS_JNL_LOG` / `SPRINGBOOT_DYNAMODB_JNL_LOG`、AWSCALL）。マトリクスL〜Zには列が無い。
- **アクセスログ**は nginx ではなく**アプリ側**で出力する（HttpLoggingFilter がアクセスジャーナルとは別に1件出力）。

---

## 1.2 ログ出力項目定義（32項目）

| No | 論理名 | 物理名 | 概要 | デフォルト値 | サンプル値 | MDC | スコープ |
|---|---|---|---|---|---|---|---|
| 1 | タイムスタンプ | timestamp | ログ出力時のサーバ時刻(JST) | (必ず設定) | 2026-02-20 12:34:34.123 | 不要 | logback自動 |
| 2 | コンテナID | id | ECS Task ID | (必ず設定) | 1b2c3d4e… | 不要 | アプリ共通 |
| 3 | コンテナ名 | name | ECS Service名 | (必ず設定) | my-service | 不要 | アプリ共通 |
| 4 | ログレベル | level | DEBUG/INFO/WARN/ERROR | (必ず設定) | INFO | 不要 | logback自動 |
| 5 | ログレベル値 | level_value | レベルの数値表現 | (必ず設定) | 20000 | 不要 | logback自動 |
| 6 | ロガー名 | logger_name | ログ種類ごとの固定ロガー名 | (必ず設定) | SPRINGBOOT_API_LOG | 不要 | logback自動 |
| 7 | ログ種類 | type | 大分類 app/monitor/trail | (必ず設定) | app | 不要 | logback自動 |
| 8 | スレッド番号 | thread | Javaスレッド名 | (必ず設定) | http-nio-8080-exec-1 | 不要 | logback自動 |
| 9 | 機能ID | function | API/ジョブ/処理機能の単位 | null | 配信計画API | **要** | 実行単位(MDC) |
| 10 | ユーザーID | user | 利用者識別子 | null | U0001 | **要** | 実行単位(MDC) |
| 11 | 操作 | action | 実行された操作内容 | null | download | **要** | 実行単位(MDC) |
| 12 | ログ種類詳細 | subtype | SHELL/SYSTEM/NGINX/AWSCALL/DBCALL/APL | (必ず設定) | DBCALL | 不要 | logback自動 |
| 13 | トレースID | trace_id | リクエスト/処理を一意識別 | null | 00-abc…-01 | **要** | 実行単位(MDC) |
| 14 | ログメッセージ | message | ログ本文 | null | sample log | 不要 | 出力時に指定 |
| 15 | スタックトレース | stack_trace | 例外のスタックトレース | null | java.lang.RuntimeException… | 不要 | 出力時に指定 |
| 16 | クライアントIPアドレス | source_ip | リクエスト元IP | null | 203.0.113.10 | **要** | 実行単位(MDC) |
| 17 | URL | url | アクセスURL | null | GET /v1/xxx?id=123 | 不要 | 出力時に指定 |
| 18 | HTTPステータス | status | レスポンスステータスコード | null | 200 | 不要 | 出力時に指定 |
| 19 | ヘッダ情報 | headers | リクエスト/レスポンスヘッダ | null | {"host":[…]} | 不要 | 出力時に指定 |
| 20 | ボディ情報 | body | リクエスト/レスポンスボディ | null | {"id":"123"} | 不要 | 出力時に指定 |
| 21 | クラス名 | class_name | ログ出力元クラス名 | (必ず設定) | com.example.Sample | 不要 | 出力時に指定 |
| 22 | メソッド名 | method_name | ログ出力元メソッド名 | (必ず設定) | getOrder | 不要 | 出力時に指定 |
| 23 | 引数 | args | メソッド引数 | null | ["123","456"] | 不要 | 出力時に指定 |
| 24 | 実行結果 | result | メソッド実行結果 | null | 123 hello 456 | 不要 | 出力時に指定 |
| 25 | バケット名 | bucket_name | S3対象バケット名 | (必ず設定) | my-bucket | 不要 | 出力時に指定 |
| 26 | パス | path | S3対象キー | (必ず設定) | input/customer.csv | 不要 | 出力時に指定 |
| 27 | 処理時間 | latency | 処理にかかった時間(ms) | null | 123 | 不要 | 出力時に指定 |
| 28 | AWS Request ID | aws_request_id | AWS APIのリクエストID | null | TA1B2C3D4E5F6789 | 不要 | 出力時に指定 |
| 29 | AWS Request Timestamp | aws_request_timestamp | AWS API実行日時 | null | 2026-02-20T04:12:34Z | 不要 | 出力時に指定 |
| 30 | AWS Response Time | aws_response_time | AWS API経過時間(ms) | null | 45 | 不要 | 出力時に指定 |
| 31 | S3 Extended Request ID | aws_s3_extended_request_id | S3拡張リクエストID | null | h9nBAbC6EFG12345 | 不要 | 出力時に指定 |
| 32 | SQS Message ID | aws_sqs_message_id | SQSメッセージID | null | 2f3c4a5b-… | 不要 | 出力時に指定 |

- `class_name` / `method_name` は、固定ロガー名のままでは発生元が分からなくなるため、サービスジャーナルログ（AOP）と業務ログ（StackWalker による自動取得）で出力する。
- 29 `aws_request_timestamp` / 30 `aws_response_time` は **AWSCALL系（S/U/W＋KMS/DynamoDB）で出力すると確定（○）**。`latency` と併存（2026-06-09 確定）。
- `headers`/`body` は要求・応答で物理名を分けず、ログ種類で相乗り。

---

## 1.3 取得方法（項目別）

| 論理名（物理名） | 取得方法 |
|---|---|
| タイムスタンプ（timestamp） | logback encoder。`@timestamp`→`timestamp`、`yyyy-MM-dd HH:mm:ss.SSS`/Asia/Tokyo |
| コンテナID / コンテナ名（id / name） | ECSメタデータ（`ECS_CONTAINER_METADATA_URI_V4` + `/task` を GET）を起動時1回取得しキャッシュ。または entrypoint.sh で環境変数化 |
| ログレベル / ログレベル値（level / level_value） | `LoggingEvent#getLevel()` / `.toInt()` |
| ロガー名（logger_name） | `LoggerFactory.getLogger("SPRINGBOOT_xxx")` |
| ログ種類 / ログ種類詳細（type / subtype） | ログ種類定義の固定値 |
| スレッド番号（thread） | `LoggingEvent#getThreadName()`。nginxは擬似ID `$pid-$connection-$connection_requests` |
| 機能ID（function） | オンライン:API名 / バッチ:JOB ID / 常駐:JOB ID。MDC設定（ヘッダ `X-Function-Id` 等）|
| ユーザーID（user） | オンライン:ヘッダ `X-User-Id` / バッチ・常駐:JOB ID/機能ID。MDC設定 **(TODO: バッチ/常駐の値)** |
| 操作（action） | アプリ定義。MDC設定（ヘッダ `X-Action` 等）。出力対象はシステムごとに検討 |
| トレースID（trace_id） | オンライン:`traceparent`（無ければ生成）/ バッチ:ジョブ実行ID / 常駐:MessageId。MDC設定 |
| ログメッセージ（message） | `logger.info("…")` |
| スタックトレース（stack_trace） | `logger.error("…", throwable)` |
| クライアントIPアドレス（source_ip） | `X-Forwarded-For` 先頭、無ければ `getRemoteAddr()`。MDC設定 |
| URL / HTTPステータス（url / status） | `HttpServletRequest` / `response.getStatus()` |
| ヘッダ情報 / ボディ情報（headers / body） | ヘッダAPI / `ContentCaching(Request\|Response)Wrapper` |
| クラス名 / メソッド名（class_name / method_name） | AOP:`JoinPoint`署名 / 業務ログ:`StackWalker` / MyBatis:ステートメントID |
| 引数 / 実行結果（args / result） | AOP:`getArgs()` / 戻り値 |
| バケット名 / パス（bucket_name / path） | S3 SDK リクエスト情報 |
| 処理時間（latency） | 開始〜終了の差分 |
| AWS Request ID（aws_request_id） | SDK `responseMetadata().requestId()` |
| S3 Extended Request ID（aws_s3_extended_request_id） | S3 `S3ResponseMetadata#extendedRequestId()`（x-amz-id-2） |
| SQS Message ID（aws_sqs_message_id） | 送信:`SendMessageResponse#messageId()` / 受信:`Message#messageId()` |

---

## 1.4 出力対象ログ（L〜Z）

ログ種類の記号（列）：

| 記号 | ログ種類 | 記号 | ログ種類 |
|---|---|---|---|
| L | Nginxログ | S | ストレージアクセスJNL |
| M | アクセスログ | T | 外部アクセスJNL（要求） |
| N | アクセスJNL（要求） | U | 外部アクセスJNL（応答） |
| O | アクセスJNL（応答） | V | キャッシュJNL |
| P | サービスJNL（開始） | W | メッセージJNL |
| Q | サービスJNL（終了） | X | 業務ログ |
| R | SQLジャーナル | Y | 業務エラーログ |
|   |   | Z | システムログ |

凡例：`△`=案・未確定 **(TODO)**。「全ログ」= L〜Z すべて。

### 出力対象ログ マトリクス（論理名 × L〜Z）

![出力対象ログ マトリクス](img/matrix.png)

> ○=出力対象（確定）／△=案・未確定。画像は拡大表示できる。
> **ログ種類ごとの「出力項目＋appender定義＋MDC.putサンプル」は第4部を参照。**

---

## 1.5 要確認事項（TODO一覧）

| 項目 | 論点 |
|---|---|
| pid（プロセスID） | SSD-010元資料に存在するが合意済み32項目に無い。採否 **(TODO)** |
| ~~aws_request_timestamp / aws_response_time~~ | **確定（2026-06-09）**：AWSCALL系（S/U/W＋KMS/DynamoDB）で出力（○）。 |
| ~~latency / aws_response_time~~ | **確定（2026-06-09）**：`latency` と `aws_response_time` は併存（両方出力）。 |
| user（バッチ/常駐） | 値の取得元（JOB ID/機能ID/固定） **(TODO)** |
| headers | 全量出力か許可リスト方式か **(TODO)** |
| class_name / method_name | caller data 取得の性能影響（常時/限定） **(TODO)** |
| message | 未指定時デフォルト / 4KB制約しきい値 **(TODO)** |
