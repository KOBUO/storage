plugins {
    java
    id("org.springframework.boot") version "4.0.6"
    id("io.spring.dependency-management") version "1.1.7"
}

group = "com.example"
version = "0.0.1-SNAPSHOT"

java {
    toolchain {
        // Amazon Corretto 25 を使う。Gradle 9.5.1 が JDK25 toolchain に対応。
        languageVersion = JavaLanguageVersion.of(25)
    }
}

// Spring Cloud AWS（@SqsListener）。4.0.x は Spring Boot 4 / Spring Framework 7 対応。
val springCloudAwsVersion = "4.0.2"

repositories {
    mavenCentral()
}

dependencyManagement {
    imports {
        // Spring Cloud AWS の BOM。awssdk のバージョンもこちらに揃える（明示 BOM は持たない）。
        mavenBom("io.awspring.cloud:spring-cloud-aws-dependencies:$springCloudAwsVersion")
    }
}

dependencies {
    implementation("org.springframework.boot:spring-boot-starter-web")
    // Boot 4 で spring-boot-starter-aop は spring-boot-starter-aspectj に改名された（@Aspect 利用）。
    implementation("org.springframework.boot:spring-boot-starter-aspectj")
    // キャッシュジャーナル(@Cacheable)用。既定の ConcurrentMapCacheManager を使う。
    implementation("org.springframework.boot:spring-boot-starter-cache")
    // 構造化(JSON)ログ出力。8.1 は logback 1.5.x（Boot 4）+ Jackson 2 系で、独自 provider はそのまま使える。
    implementation("net.logstash.logback:logstash-logback-encoder:8.1")

    // 常駐バッチの SQS 受信（@SqsListener）。ローカルは ElasticMQ をエンドポイント指定で利用。
    implementation("io.awspring.cloud:spring-cloud-aws-starter-sqs")

    // AWSアクセス部品(S3 / SQS / KMS / DynamoDB)。バージョンは Spring Cloud AWS BOM 管理。
    implementation("software.amazon.awssdk:s3")
    implementation("software.amazon.awssdk:sqs")
    implementation("software.amazon.awssdk:kms")
    implementation("software.amazon.awssdk:dynamodb")

    // SQLジャーナル(MyBatis Interceptor)はコンパイルのみ。
    // 実DBを持たないため Spring Boot へは自動登録しない（参照実装）。
    compileOnly("org.mybatis:mybatis:3.5.16")

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")
    testImplementation("org.springframework.boot:spring-boot-starter-test")
}

tasks.named<Test>("test") {
    useJUnitPlatform()
}
