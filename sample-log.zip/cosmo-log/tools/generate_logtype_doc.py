#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第4部 ログ種類別定義（出力項目＋appender定義＋MDC.putサンプル）を生成する。"""

# 項目マスタ: 物理名 -> (論理名, スコープ, MDCキー or "")
_AUTO, _APP, _EXEC, _OUT = "logback自動", "アプリ共通", "実行単位(MDC)", "出力時に指定"
ITEM = {
    "timestamp": ("タイムスタンプ", _AUTO, ""),
    "id": ("コンテナID", _APP, ""),
    "name": ("コンテナ名", _APP, ""),
    "level": ("ログレベル", _AUTO, ""),
    "level_value": ("ログレベル値", _AUTO, ""),
    "logger_name": ("ロガー名", _AUTO, ""),
    "type": ("ログ種類", _AUTO, ""),
    "thread": ("スレッド番号", _AUTO, ""),
    "function": ("機能ID", _EXEC, "function"),
    "user": ("ユーザーID", _EXEC, "user"),
    "action": ("操作", _EXEC, "action"),
    "subtype": ("ログ種類詳細", _AUTO, ""),
    "trace_id": ("トレースID", _EXEC, "trace_id"),
    "message": ("ログメッセージ", _OUT, ""),
    "stack_trace": ("スタックトレース", _OUT, ""),
    "source_ip": ("クライアントIPアドレス", _EXEC, "source_ip"),
    "url": ("URL", _OUT, ""),
    "status": ("HTTPステータス", _OUT, ""),
    "headers": ("ヘッダ情報", _OUT, ""),
    "body": ("ボディ情報", _OUT, ""),
    "class_name": ("クラス名", _OUT, ""),
    "method_name": ("メソッド名", _OUT, ""),
    "args": ("引数", _OUT, ""),
    "result": ("実行結果", _OUT, ""),
    "bucket_name": ("バケット名", _OUT, ""),
    "path": ("パス", _OUT, ""),
    "latency": ("処理時間", _OUT, ""),
    "aws_request_id": ("AWS Request ID", _OUT, ""),
    "aws_request_timestamp": ("AWS Request Timestamp", _OUT, ""),
    "aws_response_time": ("AWS Response Time", _OUT, ""),
    "aws_s3_extended_request_id": ("S3 Extended Request ID", _OUT, ""),
    "aws_sqs_message_id": ("SQS Message ID", _OUT, ""),
}

# 列(L〜Z)ごとの出力項目(物理名)。△は (phys, True)
ALLITEMS = list(ITEM.keys())
COMMON = ["timestamp", "id", "name", "level", "level_value", "type", "function", "subtype", "message"]
LOGGERTHREAD = ["logger_name", "thread"]

def cols(base, extra=None, tri=None):
    extra = extra or []
    tri = tri or []
    return [(p, False) for p in base + extra] + [(p, True) for p in tri]

# ログ種類定義
SECTIONS = [
    {
        "name": "Nginxログ", "phys": "nginx", "type": "app/monitor", "subtype": "NGINX",
        "level": "INFO", "out": "stdout/stderr", "logger": None,
        "items": cols(COMMON, ["user", "action", "source_ip", "url", "status", "latency"]),
        "ctx": "online-nginx",
        "note": "nginx 側で出力（Spring Boot の logback 対象外）。`log_format` で1行JSONを `access_log /dev/stdout`、`error_log /dev/stderr`。",
    },
    {
        "name": "アクセスログ", "phys": "access", "type": "app", "subtype": "APL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_API_ACCESS_LOG", "part": "HttpLoggingFilter",
        "items": cols(COMMON + LOGGERTHREAD, ["user", "action", "source_ip", "url", "status", "latency"]),
        "ctx": "online",
        "note": "**アプリ側のサマリ**（アクセスジャーナルと同じ HttpLoggingFilter が別ログとして1件出力）。nginxではない。",
    },
    {
        "name": "アクセスジャーナルログ", "phys": "access_jnl", "type": "app", "subtype": "APL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_API_ACCESS_JNL_LOG", "part": "HttpLoggingFilter",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "url", "status", "headers", "body", "latency"]),
        "ctx": "online",
        "note": "**要求/応答（送信/受信）の詳細**。`latency` は応答のみ。`headers`/`body` は要求=リクエスト、応答=レスポンス。",
    },
    {
        "name": "サービスジャーナルログ", "phys": "service_jnl", "type": "app", "subtype": "APL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_SERVICE_JNL_LOG", "part": "ServiceJournalAspect",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "class_name", "method_name", "args", "result", "latency"]),
        "ctx": "online",
        "note": "開始/終了の2回出力。`latency` は終了のみ。`result` は両方に出力するが、開始時はデフォルト値（`null`）で、終了時に実際の戻り値が入る。",
    },
    {
        "name": "SQLジャーナルログ", "phys": "sql_jnl", "type": "app", "subtype": "DBCALL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_SQL_JNL_LOG", "part": "SqlJournalInterceptor",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "latency"]),
        "ctx": "online",
        "note": "マトリクス準拠で `class_name`/`method_name`/`args` は出力しない（これらはサービスジャーナルログ側で出力する）。必要なSQL詳細は message へ載せる想定。バッチ/常駐は全件出力せず件数・進捗・エラー時の詳細SQLに限定 **(TODO)**。",
    },
    {
        "name": "ストレージアクセスジャーナルログ", "phys": "storage_jnl", "type": "app", "subtype": "AWSCALL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_STORAGE_JNL_LOG", "part": "S3AccessService",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "bucket_name", "path", "latency", "aws_request_id", "aws_s3_extended_request_id", "aws_request_timestamp", "aws_response_time"]),
        "ctx": "online",
        "note": "S3アクセス。`aws_request_timestamp`/`aws_response_time` も出力（`latency` 併存。2026-06-09 確定）。",
    },
    {
        "name": "外部アクセスジャーナルログ", "phys": "external_jnl", "type": "app", "subtype": "APL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_HTTP_CLIENT_JNL_LOG", "part": "HttpClientJournalInterceptor",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "url", "status", "headers", "body", "latency", "aws_request_id", "aws_request_timestamp", "aws_response_time"]),
        "ctx": "online",
        "note": "要求/応答の2回出力。`latency`/`aws_request_id` は応答のみ。",
    },
    {
        "name": "キャッシュジャーナルログ", "phys": "cache_jnl", "type": "app", "subtype": "APL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_CACHE_JNL_LOG", "part": "CacheJournalAspect",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "latency"]),
        "ctx": "online",
        "note": "",
    },
    {
        "name": "メッセージジャーナルログ", "phys": "msg_jnl", "type": "app", "subtype": "AWSCALL",
        "level": "DEBUG/INFO/WARN", "out": "stdout", "logger": "SPRINGBOOT_SQS_JNL_LOG", "part": "SqsAccessService",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "latency", "aws_request_id", "aws_sqs_message_id", "aws_request_timestamp", "aws_response_time"]),
        "ctx": "resident",
        "note": "SQS送受信。常駐(メッセージ処理)スコープ。`trace_id` は MessageId。",
    },
    {
        "name": "KMSアクセスジャーナルログ", "phys": "kms_jnl", "type": "app", "subtype": "AWSCALL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_KMS_JNL_LOG", "part": "KmsAccessService",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "latency", "aws_request_id", "aws_request_timestamp", "aws_response_time"]),
        "ctx": "online",
        "note": "KMS暗号/復号。マトリクス(L〜Z)には列が無い**追加ログ種類**。AWSCALL。`aws_request_timestamp`/`aws_response_time` も出力（2026-06-09 確定）。",
    },
    {
        "name": "DynamoDBアクセスジャーナルログ", "phys": "dynamodb_jnl", "type": "app", "subtype": "AWSCALL",
        "level": "INFO", "out": "stdout", "logger": "SPRINGBOOT_DYNAMODB_JNL_LOG", "part": "DynamoDbAccessService",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "latency", "aws_request_id", "aws_request_timestamp", "aws_response_time"]),
        "ctx": "online",
        "note": "DynamoDB Get/Put等。マトリクス(L〜Z)には列が無い**追加ログ種類**。AWSCALL。`aws_request_timestamp`/`aws_response_time` も出力（2026-06-09 確定）。",
    },
    {
        "name": "業務ログ", "phys": "app", "type": "app", "subtype": "APL",
        "level": "DEBUG/INFO/WARN/ERROR", "out": "stdout(ERROR→stderr)", "logger": "SPRINGBOOT_API_LOG", "part": "ApplicationLogger#info",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "class_name", "method_name"]),
        "ctx": "online",
        "note": "業務上重要なイベントを記録する。固定ロガー名のままでは発生元が分からなくなるため、**呼び出し元のクラス名・メソッド名を StackWalker で自動取得**して付与する（実装者は info を呼ぶだけでよい）。",
    },
    {
        "name": "業務エラーログ", "phys": "app_err", "type": "monitor（レベル判定:ERROR）", "subtype": "APL",
        "level": "ERROR", "out": "stderr", "logger": "SPRINGBOOT_ERROR_LOG", "part": "ApplicationLogger#error",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "stack_trace", "class_name", "method_name"]),
        "ctx": "online",
        "note": "**明示的に出力する業務エラー**（`logger.error`）。`stack_trace` は例外オブジェクトを渡して出力する。クラス名・メソッド名は StackWalker で自動取得する。",
    },
    {
        "name": "システムログ", "phys": "(root)", "type": "app/monitor（レベル判定）", "subtype": "SYSTEM",
        "level": "INFO/WARN/ERROR", "out": "stdout(ERROR→stderr)", "logger": None, "root": True, "part": "—（明示出力なし。Spring/Tomcat等のFW・未捕捉）",
        "items": cols(COMMON + LOGGERTHREAD, ["trace_id", "stack_trace"]),
        "ctx": "root",
        "note": "**実装で明示出力していない＝固定ロガー(SPRINGBOOT_*)に該当しない root のログ**。logger_name は実クラス名、subtype=SYSTEM、type はレベル判定。システムログ＋システムエラーログ（FWのエラー）を包含。",
    },
]

# 実行単位スコープ(MDC)項目は『スコープ内の全ログに付与』（2026-06-09 確定。実装に合わせる）。
# function は COMMON に含む。user/action/trace_id/source_ip を各ログ種類へ補完する。
# trace_id は nginx(L) 以外、source_ip は メッセージジャーナル(msg_jnl=常駐) 以外。
_MDC_ALL = ["user", "action", "trace_id", "source_ip"]
for _s in SECTIONS:
    _have = {p for p, _ in _s["items"]}
    for _p in _MDC_ALL:
        if _p in _have:
            continue
        if _p == "trace_id" and _s["phys"] == "nginx":
            continue
        if _p == "source_ip" and _s["phys"] == "msg_jnl":
            continue
        _s["items"].append((_p, False))

MDC_SRC = {  # MDCキー -> (オンライン取得元, バッチ, 常駐)
    "function": ("ヘッダ X-Function-Id / 解決", "JOB名", "メッセージ処理機能"),
    "user": ("ヘッダ X-User-Id", "JOB ID/機能ID", "JOB ID/機能ID"),
    "action": ("ヘッダ X-Action / 解決", "処理区分", "処理区分"),
    "trace_id": ("ヘッダ traceparent / 生成", "ジョブ実行ID", "MessageId"),
    "source_ip": ("X-Forwarded-For 先頭", "（なし）", "（なし）"),
}


def render():
    out = []
    out.append("# 第4部　ログ種類別定義\n")
    out.append("> ログ種類ごとに【出力項目】【appender定義】【MDC.putサンプル】をまとめる。")
    out.append("> 各セクションは独立して読めるよう、共通部分も重複して記載する。**(TODO)** は未確定。\n")
    out.append("## 出力方針（全ログ種類共通）\n")
    out.append("- 出力は **JSON（1行）**。`net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder` を使用。\n"
               "- 出力先は **stdout / stderr**（CloudWatch Logs が収集）。**ERROR→stderr / それ以外→stdout** を `LevelFilter` で振り分け。\n"
               "- appender は `STDOUT` / `STDERR` の2本を全ログ種類で共有し、各ログ種類は `logger_name` の `<logger>` でレベルと振り分けを指定する。\n"
               "- **type / subtype は Marker では持たせず `TypeSubtypeJsonProvider` が付与**する：\n"
               "  **type = レベル判定（`ERROR→monitor` / それ以外→`app`）**、**subtype = logger_name から導出**。\n"
               "- **システムログ**は、固定ロガー(SPRINGBOOT_*)に該当しない＝**実装で明示出力していない root のログ**（Spring/Tomcat等）。"
               "logger_name は実クラス名、subtype は既定の `SYSTEM`、type はレベル判定。\n"
               "- 以降の各セクションには、その場で読めるよう **appender定義（JSON）と振り分けを全文併記**する（重複あり）。\n")

    for s in SECTIONS:
        out.append(f"## {s['name']}（{s['phys']}）\n")
        # 概要
        out.append("**概要**\n")
        out.append("| 項目 | 値 |")
        out.append("|---|---|")
        out.append(f"| ログ種類(type) | {s['type']} |")
        out.append(f"| ログ種類詳細(subtype) | {s['subtype']} |")
        logger = s["logger"] or ("（固定名なし／root・実クラス名）" if s.get("root") else "（nginx側・固定ロガーなし）")
        out.append(f"| ロガー名(logger_name) | {logger} |")
        out.append(f"| ログレベル | {s['level']} |")
        out.append(f"| 出力先 | {s['out']} |")
        if s.get("part"):
            out.append(f"| 出力部品 | {s['part']} |")
        out.append("")
        if s["note"]:
            out.append(f"※ {s['note']}\n")

        # 出力項目
        out.append("**出力項目**\n")
        out.append("| 論理名 | 物理名 | スコープ |")
        out.append("|---|---|---|")
        for phys, is_tri in s["items"]:
            ja, scope, _ = ITEM[phys]
            mark = "（△未確定）" if is_tri else ""
            out.append(f"| {ja}{mark} | {phys} | {scope} |")
        out.append("")

        # appender定義（JSON / 自己完結で全文併記）
        out.append("**appender定義（logback-spring.xml / JSON出力）**\n")
        if s["logger"]:
            lvl = s["level"].split("/")[0]
            out.append(f"""```xml
<!-- 出力先: JSON / stdout・stderr。ERROR以外→stdout, ERROR→stderr -->
<appender name="STDOUT" class="ch.qos.logback.core.ConsoleAppender">
  <target>System.out</target>
  <filter class="ch.qos.logback.classic.filter.LevelFilter">
    <level>ERROR</level><onMatch>DENY</onMatch><onMismatch>NEUTRAL</onMismatch>
  </filter>
  <encoder class="net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder">
    <providers>
      <timestamp><fieldName>timestamp</fieldName><pattern>yyyy-MM-dd HH:mm:ss.SSS</pattern><timeZone>Asia/Tokyo</timeZone></timestamp> <!-- タイムスタンプ -->
      <logLevel><fieldName>level</fieldName></logLevel>                 <!-- ログレベル -->
      <logLevelValue><fieldName>level_value</fieldName></logLevelValue> <!-- ログレベル値 -->
      <loggerName><fieldName>logger_name</fieldName></loggerName>       <!-- ロガー名 -->
      <threadName><fieldName>thread</fieldName></threadName>            <!-- スレッド番号 -->
      <message><fieldName>message</fieldName></message>                 <!-- ログメッセージ -->
      <provider class="com.example.cosmolog.logging.logback.ContainerInfoJsonProvider"/> <!-- コンテナID / コンテナ名 -->
      <provider class="com.example.cosmolog.logging.logback.TypeSubtypeJsonProvider"/>   <!-- type(レベル判定) / subtype(logger_nameから) -->
      <mdc>                 <!-- 出力するMDCキーを明示 -->
        <includeMdcKeyName>function</includeMdcKeyName>  <!-- 機能ID -->
        <includeMdcKeyName>user</includeMdcKeyName>      <!-- ユーザーID -->
        <includeMdcKeyName>action</includeMdcKeyName>    <!-- 操作 -->
        <includeMdcKeyName>trace_id</includeMdcKeyName>  <!-- トレースID -->
        <includeMdcKeyName>source_ip</includeMdcKeyName> <!-- クライアントIPアドレス -->
      </mdc>
      <!-- Markerで付与（type/subtypeはproviderが付与するためMarkerには含めない）: url:URL / status:HTTPステータス /
           headers:ヘッダ情報 / body:ボディ情報 / class_name:クラス名 / method_name:メソッド名 /
           args:引数 / result:実行結果 / bucket_name:バケット名 / path:パス / latency:処理時間 / aws_*:AWS項目 -->
      <logstashMarkers/>
      <arguments/>
      <stackTrace><fieldName>stack_trace</fieldName></stackTrace>      <!-- スタックトレース -->
    </providers>
  </encoder>
</appender>
<appender name="STDERR" class="ch.qos.logback.core.ConsoleAppender">
  <target>System.err</target>
  <filter class="ch.qos.logback.classic.filter.LevelFilter">
    <level>ERROR</level><onMatch>ACCEPT</onMatch><onMismatch>DENY</onMismatch>
  </filter>
  <!-- encoder は STDOUT と同一(JSON) -->
  <encoder class="net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder">
    <providers><!-- STDOUT と同じ providers --></providers>
  </encoder>
</appender>

<!-- このログ種類の振り分け -->
<logger name="{s['logger']}" level="{lvl}" additivity="false">
  <appender-ref ref="STDOUT"/>  <!-- ERROR以外 → System.out(JSON) -->
  <appender-ref ref="STDERR"/>  <!-- ERROR     → System.err(JSON) -->
</logger>
```\n""")
        elif s.get("root"):
            out.append("""```xml
<!-- システムログ = root（固定ロガーに該当しないログ）。STDOUT/STDERR は他種類と同一(JSON)。 -->
<root level="INFO">
  <appender-ref ref="STDOUT"/>  <!-- ERROR以外 → System.out(JSON) -->
  <appender-ref ref="STDERR"/>  <!-- ERROR     → System.err(JSON) -->
</root>
<!-- logger_name=実クラス名 / type=レベル判定(ERROR→monitor/他→app) / subtype=SYSTEM が自動付与される -->
```\n""")
        else:
            out.append("""```nginx
# nginx.conf（Spring Bootのlogback対象外。1行JSONで出力）
log_format access_json escape=json '{ "timestamp":"$jst_timestamp", "type":"access", ... }';
access_log /dev/stdout access_json;   # 通常 → stdout
error_log  /dev/stderr warn;          # エラー → stderr
```\n""")

        # MDC.put サンプル
        mdc_items = [(phys, ITEM[phys][2]) for phys, _ in s["items"] if ITEM[phys][2]]
        out.append("**MDC.put サンプル（実行単位スコープ開始時に設定 → 終了時にクリア）**\n")
        if s["ctx"] == "root":
            out.append("rootのため**明示的なMDC設定はしない**。リクエスト処理中であれば Filter 等が設定した "
                       "MDC（function / trace_id 等）がそのまま乗る。FW起動時など実行単位スコープ外では付かない。\n")
        elif not mdc_items:
            out.append("このログ種類に MDC 由来の項目はない。\n")
        elif s["ctx"] == "online-nginx":
            out.append("nginx 側のため Java の MDC ではなく nginx 変数で設定する（例）。\n")
            out.append("""```nginx
set $log_function $http_x_function_id;   # 機能ID
set $log_user     $http_x_user_id;       # ユーザーID
set $log_action   $http_x_action;        # 操作
# source_ip は $http_x_forwarded_for 先頭 / $remote_addr
```\n""")
        else:
            ctx_idx = {"online": 0, "batch": 1, "resident": 2}[s["ctx"]]
            ctx_label = {"online": "オンライン", "batch": "バッチ", "resident": "常駐"}[s["ctx"]]
            lines = [f"// {ctx_label}の実行単位スコープ開始時に設定（try-with-resources で終了時クリア）"]
            for phys, key in mdc_items:
                ja = ITEM[phys][0]
                src = MDC_SRC[key][ctx_idx]
                lines.append(f'MDC.put("{key}", {key}Value); // {ja}：{src}')
            lines.append("// ... 処理 ...")
            lines.append("// finally: function/user/action/trace_id/source_ip を MDC.remove")
            body = "\n".join(lines)
            out.append(f"```java\n{body}\n```\n")
            out.append("> 実体は `ExecutionScopeMdc.open(function, action, user, traceId, sourceIp)`（第3部 3.4）を使い、"
                       "`try (var scope = ...) { ... }` で自動クリアする。\n")

    return "\n".join(out)


with open("/Users/kobuo/workspace/cosmo-log/book/04_ログ種類別定義.md", "w") as f:
    f.write(render())
print("written book/04_ログ種類別定義.md")
