#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ログ設計.xlsx を生成する（Excelシート構成計画.md の5シート構成）。
要確認は専用シートを作らず、各シートの「備考/要確認」欄に記載する。"""
from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

ITAL = Font(italic=True, color="555555", size=10)


def note(cell, text):
    """セルにコメント（説明）を付ける。"""
    c = Comment(text, "設計")
    c.width = 360
    c.height = 170
    cell.comment = c

HEAD_FILL = PatternFill("solid", fgColor="4472C4")
HEAD_FONT = Font(color="FFFFFF", bold=True)
SUB_FILL = PatternFill("solid", fgColor="D9E1F2")
YEL = PatternFill("solid", fgColor="FFF2CC")
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(vertical="top", wrap_text=True)
CENTER = Alignment(horizontal="center", vertical="center")

COLS = ["L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
ALL = set(COLS)

# 物理名 -> (論理名, 概要, 必須, デフォルト, サンプル, 取得方法, MDC, MDCキー, スコープ, 備考/要確認, present, tri)
ITEMS = [
    ("timestamp", "タイムスタンプ", "ログ出力時のサーバ時刻(JST)", "必須", "(必ず設定)", "2026-02-20 12:34:34.123",
     "logback encoder。@timestamp→timestamp、yyyy-MM-dd HH:mm:ss.SSS/Asia/Tokyo", "不要", "", "ログイベント", "", ALL, set()),
    ("id", "コンテナID", "ECS Task ID", "必須", "(必ず設定)", "1b2c3d4e…",
     "ECSメタデータ(ECS_CONTAINER_METADATA_URI_V4 +/task)を起動時1回取得しキャッシュ/entrypoint.sh", "不要", "", "アプリケーション", "", ALL, set()),
    ("name", "コンテナ名", "ECS Service名", "必須", "(必ず設定)", "my-service",
     "ECSメタデータ または 環境変数。起動時1回取得", "不要", "", "アプリケーション", "", ALL, set()),
    ("level", "ログレベル", "DEBUG/INFO/WARN/ERROR", "必須", "(必ず設定)", "INFO",
     "LoggingEvent#getLevel()", "不要", "", "ログイベント", "", ALL, set()),
    ("level_value", "ログレベル値", "レベルの数値表現", "必須", "(必ず設定)", "20000",
     "getLevel().toInt() (DEBUG10000/INFO20000/WARN30000/ERROR40000)", "不要", "", "ログイベント", "", ALL, set()),
    ("logger_name", "ロガー名", "ログ種類ごとの固定ロガー名", "必須", "(必ず設定)", "SPRINGBOOT_API_LOG",
     "LoggerFactory.getLogger(\"SPRINGBOOT_xxx\")", "不要", "", "ログイベント", "", ALL - {"L"}, set()),
    ("type", "ログ種類", "大分類 app/monitor/trail", "必須", "(必ず設定)", "app",
     "ログ種類定義の固定値", "不要", "", "ログイベント", "", ALL, set()),
    ("thread", "スレッド番号", "Javaスレッド名", "必須", "(必ず設定)", "http-nio-8080-exec-1",
     "getThreadName()。nginxは擬似ID $pid-$connection-$connection_requests", "不要", "", "ログイベント", "", ALL - {"L"}, set()),
    ("function", "機能ID", "API/ジョブ/処理機能の単位", "任意", "null", "配信計画API",
     "オンライン:API名/バッチ:JOB ID/常駐:JOB ID。MDC設定(X-Function-Id等)", "要", "function", "実行単位", "", ALL, set()),
    ("user", "ユーザーID", "利用者識別子", "任意", "null", "U0001",
     "オンライン:X-User-Id/バッチ・常駐:JOB ID/機能ID。MDC設定", "要", "user", "実行単位",
     "実行単位スコープ(MDC)。スコープ内の全ログに付与。値:online=X-User-Id/batch・常駐=JOB ID/機能ID(要確認)", ALL, set()),
    ("action", "操作", "実行された操作内容", "任意", "null", "download",
     "アプリ定義。MDC設定(X-Action等)", "要", "action", "実行単位",
     "実行単位スコープ(MDC)。スコープ内の全ログに付与", ALL, set()),
    ("subtype", "ログ種類詳細", "SHELL/SYSTEM/NGINX/AWSCALL/DBCALL/APL", "必須", "(必ず設定)", "DBCALL",
     "処理種別に応じた固定値", "不要", "", "ログイベント", "", ALL, set()),
    ("trace_id", "トレースID", "リクエスト/処理を一意識別", "任意", "null", "00-abc…-01",
     "オンライン:traceparent(無ければ生成)/バッチ:ジョブ実行ID/常駐:MessageId。MDC設定", "要", "trace_id", "実行単位",
     "実行単位スコープ(MDC)。L(nginx)以外の全ログに付与", ALL - {"L"}, set()),
    ("message", "ログメッセージ", "ログ本文", "任意", "null", "sample log",
     "logger.info(\"…\")", "不要", "", "ログイベント", "★未指定時のデフォルト/4KB制限 要確認。改行エスケープ・PIIマスク", ALL, set()),
    ("stack_trace", "スタックトレース", "例外のスタックトレース", "任意", "null", "java.lang.RuntimeException…",
     "logger.error(\"…\", throwable)", "不要", "", "ログイベント", "例外時のみ。マスク要否", {"Y", "Z"}, set()),
    ("source_ip", "クライアントIPアドレス", "リクエスト元IP", "任意", "null", "203.0.113.10",
     "X-Forwarded-For先頭、無ければgetRemoteAddr()。MDC設定", "要", "source_ip", "実行単位",
     "実行単位スコープ(MDC)。スコープ内ログに付与。オンラインのみ値あり(batch/常駐は未設定=欠落)", ALL - {"W"}, set()),
    ("url", "URL", "アクセスURL", "任意", "null", "GET /v1/xxx?id=123 HTTP/1.1",
     "request.getMethod()/getRequestURI()/getQueryString()", "不要", "", "ログイベント", "", {"L", "M", "N", "O", "T", "U"}, set()),
    ("status", "HTTPステータス", "レスポンスステータスコード", "任意", "null", "200",
     "response.getStatus()", "不要", "", "ログイベント", "", {"L", "M", "N", "O", "T", "U"}, set()),
    ("headers", "ヘッダ情報", "リクエスト/レスポンスヘッダ", "任意", "null", '{"host":[…]}',
     "getHeaderNames()/getHeaders()をMap化", "不要", "", "ログイベント",
     "★全量 or 許可リスト 要確認。Authorization/Cookie等マスク", {"N", "O", "T", "U"}, set()),
    ("body", "ボディ情報", "リクエスト/レスポンスボディ", "任意", "null", '{"id":"123"}',
     "ContentCaching(Request|Response)Wrapper", "不要", "", "ログイベント", "マスク/最大長/copyBodyToResponse注意", {"N", "O", "T", "U"}, set()),
    ("class_name", "クラス名", "ログ出力元クラス名", "必須", "(必ず設定)", "com.example.Sample",
     "サービスジャーナル:AOP / 業務ログ:StackWalker（自動取得）", "不要", "", "メソッド実行", "サービスジャーナル・業務ログで出力", {"P", "Q", "X", "Y"}, set()),
    ("method_name", "メソッド名", "ログ出力元メソッド名", "必須", "(必ず設定)", "getOrder",
     "サービスジャーナル:AOP / 業務ログ:StackWalker（自動取得）", "不要", "", "メソッド実行", "サービスジャーナル・業務ログで出力", {"P", "Q", "X", "Y"}, set()),
    ("args", "引数", "メソッド引数", "任意", "null", '["123","456"]',
     "AOP:getArgs()", "不要", "", "メソッド実行", "★サービスジャーナルのみ。マスク要", {"P", "Q"}, set()),
    ("result", "実行結果", "メソッド実行結果", "任意", "null", "123 hello 456",
     "AOP:戻り値", "不要", "", "メソッド実行", "★サービスジャーナルのみ。マスク/最大長", {"P", "Q"}, set()),
    ("bucket_name", "バケット名", "S3対象バケット名", "必須", "(必ず設定)", "my-bucket",
     "S3 SDKリクエスト情報", "不要", "", "AWS呼び出し", "", {"S"}, set()),
    ("path", "パス", "S3対象キー", "必須", "(必ず設定)", "input/customer.csv",
     "S3 SDKリクエスト情報", "不要", "", "AWS呼び出し", "", {"S"}, set()),
    ("latency", "処理時間", "処理にかかった時間(ms)", "任意", "null", "123",
     "開始〜終了の差分", "不要", "", "ログイベント", "★aws_response_timeと重複整理 要確認", {"L", "M", "O", "Q", "R", "S", "U", "V", "W"}, set()),
    ("aws_request_id", "AWS Request ID", "AWS APIのリクエストID", "任意", "null", "TA1B2C3D4E5F6789",
     "SDK responseMetadata().requestId()", "不要", "", "AWS呼び出し", "", {"S", "U", "W"}, set()),
    ("aws_request_timestamp", "AWS Request Timestamp", "AWS API実行日時", "任意", "null", "2026-02-20T04:12:34Z",
     "呼び出し直前の時刻を自前記録", "不要", "", "AWS呼び出し", "確定：AWSCALLで出力（S/U/W＋KMS/DynamoDB）", {"S", "U", "W"}, set()),
    ("aws_response_time", "AWS Response Time", "AWS API経過時間(ms)", "任意", "null", "45",
     "呼び出し開始〜受信の差分", "不要", "", "AWS呼び出し", "確定：AWSCALLで出力。latencyと併存（両方出力）", {"S", "U", "W"}, set()),
    ("aws_s3_extended_request_id", "S3 Extended Request ID", "S3拡張リクエストID", "任意", "null", "h9nBAbC6EFG12345",
     "S3 S3ResponseMetadata#extendedRequestId()(x-amz-id-2)", "不要", "", "AWS呼び出し", "S3専用", {"S"}, set()),
    ("aws_sqs_message_id", "SQS Message ID", "SQSメッセージID", "任意", "null", "2f3c4a5b-…",
     "送信:SendMessageResponse#messageId()/受信:Message#messageId()", "不要", "", "AWS呼び出し", "SQS専用", {"W"}, set()),
]
# 概要（意味＋何に使うか）。簡易すぎる概要をこの辞書で上書きする。
DESC = {
    "timestamp": "ログが出力された時刻（JST）。事象がいつ起きたかの特定や、複数のログを時系列で並べて突合するのに使う。",
    "id": "ログを出したコンテナ(ECS Task)の識別子。障害が起きたインスタンスの特定や、CPU/メモリ等メトリクス・CloudWatch側情報との突合に使う。",
    "name": "ログを出したサービス(ECS Service)の名前。どのサービスから出たログかを識別するのに使う。",
    "level": "ログの重大度（DEBUG/INFO/WARN/ERROR）。出力の絞り込みや、エラー(ERROR)の監視・検知に使う。",
    "level_value": "ログレベルを数値で表したもの。レベルでの絞り込み・並べ替えを数値で行うために使う。",
    "logger_name": "ログ種類を表す固定の名前。どの種類のログか（アクセス/業務/SQL等）を判別し、振り分けに使う。",
    "type": "ログの大分類（app=アプリ実行 / monitor=運用監視 / trail=証跡）。運用監視の対象かどうか等の振り分けに使う。",
    "thread": "ログを出したスレッドの名前。同時並行で動く処理の中で、どの処理から出たログかを区別するのに使う。",
    "function": "実行中の機能の単位（オンライン=API名 / バッチ=ジョブ名 / 常駐=処理機能）。どの機能で出たログかを示し、機能単位の絞り込みに使う。",
    "user": "処理を実行・依頼した利用者の識別子。誰の操作で出たログかの追跡・監査に使う。",
    "action": "機能の中で実行された具体的な操作（取得/登録/更新/削除 等）。何をした処理かを示す。",
    "subtype": "ログがどの仕組みから出たかの区分（シェル/フレームワーク/nginx/AWS呼び出し/DB呼び出し/アプリ）。絞り込みに使う。",
    "trace_id": "1件の処理（リクエスト/ジョブ/メッセージ）を一意に識別するID。同じ処理から出た複数のログを紐付けて追跡するのに使う。",
    "message": "ログの本文。何が起きたかを人が読んで把握するための説明文。",
    "stack_trace": "例外発生時の呼び出し履歴。エラーがどこで・なぜ起きたかの原因調査に使う。",
    "source_ip": "リクエスト元のIPアドレス。どこからのアクセスかの特定・監査に使う。",
    "url": "アクセスされたURL（HTTPメソッド＋パス）。どのエンドポイントへのアクセスかを示す。",
    "status": "レスポンスのHTTPステータスコード。処理が成功したか（200）・失敗したか（4xx/5xx）を示す。",
    "headers": "リクエスト/レスポンスのヘッダ情報。通信内容の確認・調査に使う（Authorization等の機微情報はマスク）。",
    "body": "リクエスト/レスポンスのボディ（中身）。送受信内容の確認・調査に使う（機微情報はマスク・長い場合は切詰め）。",
    "class_name": "ログを出力したコードのクラス名。固定ロガー名にしたことで分からなくなる『発生元』を追跡するために出す。",
    "method_name": "ログを出力したコードのメソッド名。クラス名と合わせて発生元の追跡に使う。",
    "args": "実行されたメソッドに渡された引数。処理内容や不具合の調査に使う（機微情報はマスク）。",
    "result": "メソッドの戻り値・処理結果。処理が何を返したかの調査に使う（機微情報はマスク・切詰め）。",
    "bucket_name": "アクセスしたS3バケットの名前。どのストレージへのアクセスかを示す（パスとセット）。",
    "path": "アクセスしたS3オブジェクトのキー（パス）。バケット名と合わせてアクセス先（s3://バケット/パス）を示す。",
    "latency": "処理にかかった時間（ミリ秒）。性能の監視や、遅い処理の検知に使う。",
    "aws_request_id": "AWS API呼び出しごとにAWSが払い出す識別子。障害時にAWSへ問い合わせる際の突合に使う。",
    "aws_request_timestamp": "AWS API呼び出しを実行した日時。AWS呼び出しがいつ行われたかの把握に使う。",
    "aws_response_time": "AWS API呼び出しの開始から応答までの時間（ミリ秒）。AWS呼び出しの性能把握に使う。",
    "aws_s3_extended_request_id": "S3が返す追加の識別子。AWSサポートへS3の調査を依頼する際に使う（S3専用）。",
    "aws_sqs_message_id": "SQSメッセージの識別子。メッセージの送受信を追跡するのに使う（SQS専用）。",
    "pid": "プロセスID。1コンテナ1JVMでは固定値になりがちで、識別はコンテナID/スレッドで足りるため候補（採否は要確認）。",
}

# 利用スコープ（値の供給方法で4分類）。物理名 -> スコープ
SC_APP = "アプリ共通"
SC_EXEC = "実行単位(MDC)"
SC_AUTO = "logback自動"
SC_OUT = "出力時に指定"
SCOPE = {
    "id": SC_APP, "name": SC_APP,
    "function": SC_EXEC, "user": SC_EXEC, "action": SC_EXEC, "trace_id": SC_EXEC, "source_ip": SC_EXEC,
    "timestamp": SC_AUTO, "level": SC_AUTO, "level_value": SC_AUTO, "logger_name": SC_AUTO,
    "thread": SC_AUTO, "type": SC_AUTO, "subtype": SC_AUTO,
}  # 上記以外は SC_OUT（出力時に指定）

# 取得方法（汎用的な内容に。コンテナ外/内・API/バッチ/常駐で細部は変わるため、ここでは概略のみ）
HOW = {
    "timestamp": "logback が出力時刻を付与",
    "id": "ECSメタデータから起動時に取得",
    "name": "ECSメタデータ/環境変数から起動時に取得",
    "level": "logback が出力レベルを付与",
    "level_value": "logback がレベルの数値を付与",
    "logger_name": "ロガー生成時に指定した固定名",
    "type": "ログレベルから自動判定",
    "thread": "logback がスレッド名を付与",
    "function": "処理開始時に、機能の識別子を MDC へ設定",
    "user": "処理開始時に、利用者の識別子を MDC へ設定",
    "action": "処理開始時に、操作内容を MDC へ設定",
    "subtype": "ロガー名から自動判定",
    "trace_id": "処理開始時に、トレースIDを MDC へ設定（無ければ生成）",
    "message": "ログ出力時にコードが指定",
    "stack_trace": "例外オブジェクトを渡して付与",
    "source_ip": "リクエスト元IPを取得し MDC へ設定",
    "url": "リクエスト情報から取得",
    "status": "レスポンス情報から取得",
    "headers": "リクエスト/レスポンスのヘッダを取得",
    "body": "リクエスト/レスポンスのボディを取得",
    "class_name": "ログ出力箇所のクラスを自動取得",
    "method_name": "ログ出力箇所のメソッドを自動取得",
    "args": "メソッドの引数を取得",
    "result": "メソッドの戻り値を取得",
    "bucket_name": "AWS(S3)呼び出し情報から取得",
    "path": "AWS(S3)呼び出し情報から取得",
    "latency": "処理の開始〜終了の差分",
    "aws_request_id": "AWSの応答から取得",
    "aws_request_timestamp": "AWS呼び出しの時刻を記録",
    "aws_response_time": "AWS呼び出しの所要時間",
    "aws_s3_extended_request_id": "S3の応答から取得",
    "aws_sqs_message_id": "SQS送受信の結果から取得",
    "pid": "プロセスIDを取得（採否は要確認）",
}

# 実行区分・出力場所（出力対象ログ L〜Z から導出）
EXEC_OF_COL = {
    "L": {"API"}, "M": {"API"}, "N": {"API"}, "O": {"API"},
    "P": {"API", "バッチ", "常駐"}, "Q": {"API", "バッチ", "常駐"},
    "R": {"API", "バッチ", "常駐"}, "S": {"API", "バッチ", "常駐"},
    "T": {"API", "バッチ", "常駐"}, "U": {"API", "バッチ", "常駐"},
    "V": {"API", "バッチ", "常駐"}, "W": {"常駐"},
    "X": {"API", "バッチ", "常駐"}, "Y": {"API", "バッチ", "常駐"}, "Z": {"API", "バッチ", "常駐"},
}


def exec_of(colset):
    e = set()
    for c in colset:
        e |= EXEC_OF_COL.get(c, set())
    return e

# pid 候補行（32項目外）
PID = ("pid", "プロセスID", "プロセスID", "-", "-", "12345", "-", "不要", "", "-",
       "★候補：SSD-010元資料にあるが合意済み32項目外。採否要確認", set(), set())

JNAME = {p: t[0] for p, *t in [(i[0], i[1]) for i in ITEMS]}
JNAME = {i[0]: i[1] for i in ITEMS}


def style_header(ws, row, ncols, fill=HEAD_FILL, font=HEAD_FONT):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(vertical="center", wrap_text=True)
        cell.border = BORDER


def put_row(ws, r, values, wrap=True):
    for j, v in enumerate(values, 1):
        cell = ws.cell(row=r, column=j, value=v)
        cell.alignment = WRAP if wrap else CENTER
        cell.border = BORDER


wb = Workbook()

# =========================================================================
# Sheet1: 定義一覧（4ブロック）
# =========================================================================
ws = wb.active
ws.title = "1.定義一覧"
r = 1


def block(title, headers, rows, widths, desc=None):
    global r
    ws.cell(row=r, column=1, value=title).font = Font(bold=True, size=12)
    r += 1
    if desc:
        cell = ws.cell(row=r, column=1, value="【説明】" + desc)
        cell.font = ITAL
        cell.alignment = WRAP
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=max(len(headers), 4))
        ws.row_dimensions[r].height = 42
        r += 1
    for j, h in enumerate(headers, 1):
        ws.cell(row=r, column=j, value=h)
    style_header(ws, r, len(headers))
    hr = r
    r += 1
    for row in rows:
        put_row(ws, r, row)
        r += 1
    for j, w in enumerate(widths, 1):
        cur = ws.column_dimensions[get_column_letter(j)].width or 0
        if w > cur:
            ws.column_dimensions[get_column_letter(j)].width = w
    r += 1  # 空行


block("■ 処理分類（実行区分）",
      ["処理分類", "概要", "備考"],
      [["オンライン(API)", "APIおよび画面など。HTTPリクエスト単位", ""],
       ["バッチ(コンテナ内)", "AWSバッチ等。ジョブ実行単位", ""],
       ["常駐バッチ", "メッセージ処理単位（≒バッチ。MDC起点が違うだけ）", "バッチと統合可：要確認"]],
      [18, 50, 24],
      desc="アプリがどう動くか（オンライン=API／バッチ／常駐バッチ）の分類。"
           "これによって『1件の処理＝ログをまとめる単位』が決まり（オンライン=1リクエスト／バッチ=1ジョブ／常駐=1メッセージ）、同じ処理から出たログの関連付けや、処理単位でのログの切り出しに使う。")

block("■ ログレベル",
      ["レベル", "level_value", "説明"],
      [["DEBUG", 10000, "開発者向け詳細"], ["INFO", 20000, "通常の動作情報"],
       ["WARN", 30000, "警告"], ["ERROR", 40000, "エラー（監視対象）"]],
      [10, 12, 40],
      desc="ログの重大度（DEBUG ＜ INFO ＜ WARN ＜ ERROR）。"
           "出力する／しないの絞り込みや、エラー監視（ERRORの抽出）の判断に使う。")

block("■ ログ種類",
      ["ログ種類名", "物理名", "ログ種類(type)", "ロガー名(logger_name)", "ログレベル", "出力先"],
      [["Nginxログ", "nginx", "app/monitor", "（既存・固定名なし）", "INFO", "stdout/stderr"],
       ["アクセスログ", "access", "app", "SPRINGBOOT_API_ACCESS_LOG", "INFO", "stdout"],
       ["アクセスジャーナルログ", "access_jnl", "app", "SPRINGBOOT_API_ACCESS_JNL_LOG", "INFO", "stdout"],
       ["サービスジャーナルログ", "service_jnl", "app", "SPRINGBOOT_SERVICE_JNL_LOG", "INFO", "stdout"],
       ["SQLジャーナルログ", "sql_jnl", "app", "SPRINGBOOT_SQL_JNL_LOG", "INFO", "stdout"],
       ["ストレージアクセスジャーナルログ", "storage_jnl", "app", "SPRINGBOOT_STORAGE_JNL_LOG", "INFO", "stdout"],
       ["外部アクセスジャーナルログ", "external_jnl", "app", "SPRINGBOOT_HTTP_CLIENT_JNL_LOG", "INFO", "stdout"],
       ["キャッシュジャーナルログ", "cache_jnl", "app", "SPRINGBOOT_CACHE_JNL_LOG", "INFO", "stdout"],
       ["メッセージジャーナルログ", "msg_jnl", "app", "SPRINGBOOT_SQS_JNL_LOG", "DEBUG/INFO/WARN", "stdout"],
       ["KMSアクセスジャーナルログ", "kms_jnl", "app", "SPRINGBOOT_KMS_JNL_LOG", "INFO", "stdout"],
       ["DynamoDBアクセスジャーナルログ", "dynamodb_jnl", "app", "SPRINGBOOT_DYNAMODB_JNL_LOG", "INFO", "stdout"],
       ["業務ログ", "app", "app", "SPRINGBOOT_API_LOG", "DEBUG/INFO/WARN", "stdout"],
       ["業務エラーログ", "app_err", "monitor", "SPRINGBOOT_ERROR_LOG", "ERROR", "stderr"],
       ["システムログ", "(root)", "app/monitor", "（固定名なし・root）", "INFO/WARN/ERROR", "stdout(ERROR→stderr)"]],
      [26, 14, 12, 30, 18, 20],
      desc="出力するログの種類（アクセス／サービス／SQL／ストレージ／業務 など、何についてのログか）。"
           "ログを目的別に分け、検索・集約・保存などの扱いを種類ごとに分けるために使う。")

block("■ ログ詳細種別（subtype） × 実行区分の適用",
      ["subtype", "オンライン", "バッチ", "常駐", "概要"],
      [["SHELL", "", "○", "", "コンテナ内Shellに出力するJOBログ"],
       ["SYSTEM", "○", "○", "○", "Tomcat/Spring等が出力"],
       ["NGINX", "○", "", "", "nginxのログ"],
       ["AWSCALL", "○", "○", "○", "AWS-API呼び出し時"],
       ["DBCALL", "○", "○", "○", "SQL実行ログ（バッチは件数制限）"],
       ["APL", "○", "○", "○", "アプリ開発者用の任意ログ"]],
      [10, 10, 8, 8, 40],
      desc="ログ種類の中をさらに細分する区分。そのログが『どの仕組みから出たものか』（シェル/フレームワーク/nginx/AWS呼び出し/DB呼び出し/アプリ）を表し、絞り込みに使う。")

block("■ 利用スコープ（値の供給方法による分類）",
      ["スコープ", "意味（どう供給されるか）", "該当項目（論理名）"],
      [["アプリ共通", "起動時に1回取得し、全ログへ自動付与", "コンテナID, コンテナ名"],
       ["実行単位(MDC)", "処理（リクエスト/ジョブ/メッセージ）の間だけ保持し、その間のログへ自動付与", "機能ID, ユーザーID, 操作, トレースID, クライアントIPアドレス"],
       ["logback自動", "ログ出力のたびに基盤（logback/provider）が自動付与（コードは指定しない）", "タイムスタンプ, ログレベル, ログレベル値, ロガー名, スレッド番号, ログ種類, ログ種類詳細"],
       ["出力時に指定", "ログ出力箇所でコード（logger呼び出し/出力部品）が渡す値", "ログメッセージ, スタックトレース, URL, HTTPステータス, ヘッダ情報, ボディ情報, クラス名, メソッド名, 引数, 実行結果, バケット名, パス, 処理時間, AWS各項目"]],
      [16, 56, 60],
      desc="各ログ出力項目が『どう供給されるか』の分類。自動で付くもの（アプリ共通／実行単位／logback自動）と、出力時にコードが渡すものを分ける。"
           "「いつ決まるか」で分けると AWS呼び出しとログイベントがほぼ同じになるため、供給方法で分類する。")

block("■ 用語・設計の基本",
      ["用語", "意味・用途"],
      [["MDC", "1回の処理（リクエスト/ジョブ/メッセージ）の間だけ、機能IDやトレースID等を保持しておく仕組み。その処理中に出る全ログへ自動で付くので、同じ処理のログをまとめて追える。"],
       ["ロガー名", "ログ種類ごとに付けた固定の名前。これでログの種類を見分け・振り分ける（このログがアクセスか・業務か・SQLか等が分かる）。"],
       ["ログ種類・詳細の自動付与", "個々のログでは指定せず、ログ種類はログレベルから、ログ種類詳細はロガー名から自動で決まる方針。実装者が毎回指定しなくてよい。"],
       ["システムログ", "アプリが明示的に出していない、基盤・フレームワーク（Spring/Tomcat等）が出すログの総称。アプリ起因でない動作やエラーの把握に使う。"],
       ["ジャーナルログ", "処理の内容（送信/受信＝要求/応答、開始/終了）を詳しく残す記録ログ。後から処理の中身や原因を追うために使う。"],
       ["標準出力/標準エラーへの出力", "ログをファイルではなく標準出力／標準エラーに出す方式。コンテナのログ収集（CloudWatch）がそのまま拾えるようにするため。"]],
      [24, 104],
      desc="ログ設計で使う主要用語の意味と用途。")

block("■ 出力対象ログの記号（L〜Z）",
      ["記号", "ログ種類", "記号", "ログ種類"],
      [["L", "Nginxログ", "S", "ストレージアクセスジャーナルログ"],
       ["M", "アクセスログ", "T", "外部アクセスジャーナルログ（要求）"],
       ["N", "アクセスジャーナルログ（要求）", "U", "外部アクセスジャーナルログ（応答）"],
       ["O", "アクセスジャーナルログ（応答）", "V", "キャッシュジャーナルログ"],
       ["P", "サービスジャーナルログ（開始）", "W", "メッセージジャーナルログ"],
       ["Q", "サービスジャーナルログ（終了）", "X", "業務ログ"],
       ["R", "SQLジャーナルログ", "Y", "業務エラーログ"],
       ["", "", "Z", "システムログ"]],
      [6, 30, 6, 30],
      desc="シート2の『出力対象ログ』列（L〜Z）の記号と、対応するログ種類（論理名）。"
           "○=その項目（JSONキー）を出力する（値がnull／デフォルトでも項目は存在する）。△=未確定。")

# =========================================================================
# Sheet2: ログ出力項目（32項目＋pid候補）
# =========================================================================
ws2 = wb.create_sheet("2.ログ出力項目")
EXEC_HEAD = ["API", "バッチ", "常駐バッチ", "コンテナ外", "コンテナ内"]
head = ["No", "論理名", "物理名", "概要", "階層", "必須", "デフォルト値", "サンプル",
        "取得方法", "MDC要否", "MDCキー", "利用スコープ"] + EXEC_HEAD + COLS + ["備考/要確認"]
for j, h in enumerate(head, 1):
    ws2.cell(row=1, column=j, value=h)
style_header(ws2, 1, len(head))
MCOL = 13 + len(EXEC_HEAD)   # 出力対象ログ(L〜Z)の開始列 = 18
BCOL = MCOL + len(COLS)       # 備考列 = 33

# pid は『操作』の次に置く
display = []
for it in ITEMS:
    display.append(it)
    if it[0] == "action":
        display.append(PID)

rownum = 2
seq = 0
for it in display:
    (p, ja, gai, must, deflt, sample, how, mdc, mkey, scope, biko, present, tri) = it
    gai = DESC.get(p, gai)                                  # 概要=意味＋用途
    how = HOW.get(p, how)                                   # 取得方法=汎用化
    scope = SCOPE.get(p, SC_OUT) if p != "pid" else "-"     # スコープ=4分類
    if p == "pid":
        no = "候補"
    else:
        seq += 1
        no = seq
    base = [no, ja, p, gai, 1, must, deflt, sample, how, mdc, mkey, scope]
    for j, v in enumerate(base, 1):
        ws2.cell(row=rownum, column=j, value=v).alignment = WRAP
        ws2.cell(row=rownum, column=j).border = BORDER
    # 実行区分・出力場所（API/バッチ/常駐バッチ/コンテナ外/コンテナ内）
    allcols = present | tri
    ex = exec_of(allcols)
    exvals = [
        "○" if "API" in ex else "",
        "○" if "バッチ" in ex else "",
        "○" if "常駐" in ex else "",
        "○" if "L" in allcols else "",        # コンテナ外＝nginx
        "○" if (allcols - {"L"}) else "",      # コンテナ内＝アプリ
    ]
    for k, v in enumerate(exvals):
        cell = ws2.cell(row=rownum, column=13 + k, value=v)
        cell.alignment = CENTER
        cell.border = BORDER
    # 出力対象ログ L〜Z
    for k, c in enumerate(COLS):
        cell = ws2.cell(row=rownum, column=MCOL + k)
        if c in present:
            cell.value = "○"
        elif c in tri:
            cell.value = "△"
            cell.fill = YEL
        cell.alignment = CENTER
        cell.border = BORDER
    bcell = ws2.cell(row=rownum, column=BCOL, value=biko)
    bcell.alignment = WRAP
    bcell.border = BORDER
    if p == "pid":
        for j in range(1, len(head) + 1):
            ws2.cell(row=rownum, column=j).fill = YEL
    rownum += 1
widths2 = [5, 18, 22, 52, 5, 6, 12, 22, 40, 8, 10, 14] + [6, 6, 9, 9, 9] + [4] * 15 + [34]
for j, w in enumerate(widths2, 1):
    ws2.column_dimensions[get_column_letter(j)].width = w
ws2.freeze_panes = "D2"
ws2.row_dimensions[1].height = 28

# =========================================================================
# Sheet3: ログ種類別定義（11行）
# =========================================================================
ws3 = wb.create_sheet("3.ログ種類別定義")
# logtype -> 代表列(出力項目導出用), MDC項目導出
present_by_col = {c: set() for c in COLS}
tri_by_col = {c: set() for c in COLS}
for it in ITEMS:
    p = it[0]
    for c in it[11]:
        present_by_col[c].add(p)
    for c in it[12]:
        tri_by_col[c].add(p)


def items_label(colset):
    seen = []
    for it in ITEMS:
        p = it[0]
        if any(p in present_by_col[c] for c in colset):
            seen.append(it[1])
        elif any(p in tri_by_col[c] for c in colset):
            seen.append(it[1] + "(△)")
    return ", ".join(seen)


def mdc_label(colset):
    keys = []
    for it in ITEMS:
        if it[7] == "要" and any(it[0] in present_by_col[c] for c in colset):
            keys.append(it[1])
    return ", ".join(keys)


h3 = ["ログ種類", "物理名", "ロガー名(logger_name)", "ログ種類(type)", "ログ種類詳細(subtype)", "ログレベル", "出力先", "出力部品",
      "出力項目", "MDC項目", "appender", "備考/要確認"]
lt = [
    ("Nginxログ", "nginx", "（既存・固定名なし）", "app/monitor", "NGINX", "INFO", "stdout/stderr", "nginx", {"L"}, "nginx側(logback対象外)。1行JSONを/dev/stdout"),
    ("アクセスログ", "access", "SPRINGBOOT_API_ACCESS_LOG", "app", "APL", "INFO", "stdout", "HttpLoggingFilter", {"M"}, "アプリ側のサマリ(nginxではない)。HttpLoggingFilterが別ログで1件出力"),
    ("アクセスジャーナルログ", "access_jnl", "SPRINGBOOT_API_ACCESS_JNL_LOG", "app", "APL", "INFO", "stdout", "HttpLoggingFilter", {"N", "O"}, "要求/応答(送信/受信)。latencyは応答のみ"),
    ("サービスジャーナルログ", "service_jnl", "SPRINGBOOT_SERVICE_JNL_LOG", "app", "APL", "INFO", "stdout", "ServiceJournalAspect", {"P", "Q"}, "開始/終了。result/latencyは終了のみ"),
    ("SQLジャーナルログ", "sql_jnl", "SPRINGBOOT_SQL_JNL_LOG", "app", "DBCALL", "INFO", "stdout", "SqlJournalInterceptor", {"R"}, "★class_name/method_name/argsは出さない。バッチ件数制限・SQL詳細の扱い要確認"),
    ("ストレージアクセスジャーナルログ", "storage_jnl", "SPRINGBOOT_STORAGE_JNL_LOG", "app", "AWSCALL", "INFO", "stdout", "S3AccessService", {"S"}, "aws_request_timestamp/response_time も出力（latency併存）"),
    ("外部アクセスジャーナルログ", "external_jnl", "SPRINGBOOT_HTTP_CLIENT_JNL_LOG", "app", "APL", "INFO", "stdout", "HttpClientJournalInterceptor", {"T", "U"}, "要求/応答の2回。AWS宛時のみaws_request_id"),
    ("キャッシュジャーナルログ", "cache_jnl", "SPRINGBOOT_CACHE_JNL_LOG", "app", "APL", "INFO", "stdout", "CacheJournalAspect", {"V"}, "★args/result等は出さない(latencyのみ)"),
    ("メッセージジャーナルログ", "msg_jnl", "SPRINGBOOT_SQS_JNL_LOG", "app", "AWSCALL", "DEBUG/INFO/WARN", "stdout", "SqsAccessService", {"W"}, "常駐スコープ。trace_id=MessageId。aws_request_timestamp/response_time も出力（latency併存）"),
    ("業務ログ", "app", "SPRINGBOOT_API_LOG", "app", "APL", "DEBUG/INFO/WARN", "stdout", "ApplicationLogger#info", {"X"}, "class_name/method_name を自動付与（発生元追跡）"),
    ("業務エラーログ", "app_err", "SPRINGBOOT_ERROR_LOG", "monitor", "APL", "ERROR", "stderr", "ApplicationLogger#error", {"Y"}, "明示的な業務エラー(logger.error)。class_name/method_name を自動付与"),
    ("システムログ", "(root)", "（固定名なし・root/実クラス名）", "app/monitor", "SYSTEM", "INFO/WARN/ERROR", "stdout(ERROR→stderr)", "—(明示出力なし。FW等)", {"Z"}, "★固定ロガーに該当しないログの総称。type=レベル判定/subtype=SYSTEM"),
    # KMS/DynamoDB はマトリクス(L〜Z)に列が無いため出力項目を直接指定（共通項目＋下記）
    ("KMSアクセスジャーナルログ", "kms_jnl", "SPRINGBOOT_KMS_JNL_LOG", "app", "AWSCALL", "INFO", "stdout", "KmsAccessService",
     ("共通＋ ロガー名, スレッド番号, トレースID, 処理時間, AWS Request ID, AWS Request Timestamp, AWS Response Time", "機能ID, トレースID"),
     "マトリクスL〜Z外の追加ログ種類。KMS暗号/復号"),
    ("DynamoDBアクセスジャーナルログ", "dynamodb_jnl", "SPRINGBOOT_DYNAMODB_JNL_LOG", "app", "AWSCALL", "INFO", "stdout", "DynamoDbAccessService",
     ("共通＋ ロガー名, スレッド番号, トレースID, 処理時間, AWS Request ID, AWS Request Timestamp, AWS Response Time", "機能ID, トレースID"),
     "マトリクスL〜Z外の追加ログ種類。DynamoDB Get/Put等"),
]
for j, h in enumerate(h3, 1):
    ws3.cell(row=1, column=j, value=h)
style_header(ws3, 1, len(h3))
for i, (name, phys, logger, tp, st, lv, out, part, cset, biko) in enumerate(lt, 2):
    app = "—(nginx側)" if logger.startswith("（既存") else "STDOUT/STDERR（共有・JSON）"
    if isinstance(cset, tuple) and cset and isinstance(cset[0], str):
        items_str, mdc_str = cset
    else:
        items_str, mdc_str = items_label(cset), mdc_label(cset)
    put_row(ws3, i, [name, phys, logger, tp, st, lv, out, part, items_str, mdc_str, app, biko])
for j, w in enumerate([24, 12, 30, 8, 12, 18, 18, 26, 50, 24, 26, 40], 1):
    ws3.column_dimensions[get_column_letter(j)].width = w
ws3.freeze_panes = "A2"

# =========================================================================
# Sheet4: 実装部品一覧
# =========================================================================
ws4 = wb.create_sheet("4.実装部品一覧")
h4 = ["#", "論理名", "物理名(クラス)", "実行区分", "スコープ", "実行タイミング", "実装方法", "取得/設定項目", "出力ロガー", "備考/要確認"]
parts = [
    [1, "コンテナ情報取得", "ContainerInfoProvider(+entrypoint.sh)", "共通", "アプリ", "起動時", "@PostConstruct/sh", "id, name", "—", ""],
    [2, "実行スコープMDC", "ExecutionScopeMdc", "共通", "実行単位", "処理開始〜終了", "try-with-resources", "function,user,action,trace_id,source_ip", "—", ""],
    [3, "HTTPログ制御", "HttpLoggingFilter", "API", "実行単位/イベント", "HTTPリクエスト", "OncePerRequestFilter", "url,status,headers,body,latency", "API_ACCESS(アクセスログ) / API_ACCESS_JNL(ジャーナル)", "アクセスログ＋ジャーナル要求/応答の3本"],
    [4, "機能・アクション解決", "FunctionActionResolver", "API", "実行単位", "処理開始時", "Filterから呼出", "function,action", "—", ""],
    [5, "バッチ起点", "BatchLogScope", "バッチ", "実行単位", "ジョブ開始〜終了", "ExecutionScopeMdc利用", "function=JOB, trace_id=ジョブ実行ID", "—", "★userの値/常駐との統合 要確認"],
    [6, "常駐起点", "MessageLogScope", "常駐", "実行単位", "メッセージ処理", "ExecutionScopeMdc利用", "function, trace_id=MessageId", "—", "★バッチと統合可"],
    [7, "サービスジャーナル", "ServiceJournalAspect", "共通", "メソッド実行", "@Service前後", "@Aspect+@Around", "class_name,method_name,args,result,latency", "SERVICE_JNL", ""],
    [8, "SQLジャーナル", "SqlJournalInterceptor", "共通", "メソッド実行", "SQL実行", "MyBatis Interceptor", "latency", "SQL_JNL", "★class_name/method_name/argsは出さない。SQL詳細はmessage。バッチ件数制限"],
    [9, "ストレージ(S3)", "S3AccessService", "共通", "AWS呼び出し", "S3 API", "S3 Clientラップ", "bucket_name,path,aws_request_id,aws_s3_extended_request_id,aws_request_timestamp,aws_response_time,latency", "STORAGE_JNL", "aws_request_timestamp/response_time も出力（latency併存）"],
    [10, "メッセージ(SQS)", "SqsAccessService", "共通", "AWS呼び出し", "SQS送受信", "SQS Clientラップ", "aws_sqs_message_id,aws_request_id,aws_request_timestamp,aws_response_time,latency", "SQS_JNL", "aws_request_timestamp/response_time も出力（latency併存）"],
    [11, "外部HTTP", "HttpClientJournalInterceptor", "共通", "外部呼び出し", "外部HTTP前後", "ClientHttpRequestInterceptor", "url,status,headers,body,latency", "HTTP_CLIENT_JNL", ""],
    [12, "キャッシュ", "CacheJournalAspect", "共通", "メソッド実行", "@Cacheable前後", "@Aspect", "latency", "CACHE_JNL", "★args/result等は出さない"],
    [13, "AWSメタデータ抽出", "AwsResponseMetadataExtractor", "共通", "AWS呼び出し", "AWS応答取得", "共通部品", "aws_request_id,aws_s3_extended_request_id", "—", ""],
    [14, "業務ログ", "ApplicationLogger", "共通", "イベント", "業務処理内", "Spring Bean(StackWalker)", "message,stack_trace,class_name,method_name", "API_LOG / ERROR_LOG", "発生元(class/method)をStackWalkerで自動取得"],
    [15, "マスキング", "LogMaskingService", "共通", "イベント", "出力直前", "各部品から呼出", "headers,body,message,args,result,stack_trace,url(クエリ)", "—", "URLクエリのPIIもマスク"],
    [16, "ログ設定保持", "LoggingProperties", "共通", "アプリ", "起動時", "@ConfigurationProperties", "body/message最大長,マスク対象", "—", ""],
    [19, "MDC伝播", "MdcTaskDecorator + AsyncConfig", "共通", "実行単位", "非同期/子スレッド", "TaskDecorator", "MDC(function/trace_id等)を子スレッドへ複製", "—", "@Async/プールでtrace_id欠落を防ぐ"],
    [20, "トレース伝播(SQS)", "SqsTraceSupport", "共通/常駐", "AWS呼び出し", "SQS送受信", "メッセージ属性traceparent", "trace_id", "—", "送信で付与/受信で抽出。下流へtrace連携"],
    [17, "KMSアクセス", "KmsAccessService", "共通", "AWS呼び出し", "暗号/復号", "KMS Clientラップ", "aws_request_id,aws_request_timestamp,aws_response_time,latency", "KMS_JNL", "マトリクスL〜Z外の追加ログ種類"],
    [18, "DynamoDBアクセス", "DynamoDbAccessService", "共通", "AWS呼び出し", "Get/Put/Query", "DynamoDB Clientラップ", "aws_request_id,aws_request_timestamp,aws_response_time,latency", "DYNAMODB_JNL", "マトリクスL〜Z外の追加ログ種類"],
]
for j, h in enumerate(h4, 1):
    ws4.cell(row=1, column=j, value=h)
style_header(ws4, 1, len(h4))
for i, row in enumerate(parts, 2):
    put_row(ws4, i, row)
    if row[8] == "未定":
        ws4.cell(row=i, column=9).fill = YEL
for j, w in enumerate([4, 20, 32, 10, 16, 16, 26, 44, 22, 40], 1):
    ws4.column_dimensions[get_column_letter(j)].width = w
ws4.freeze_panes = "A2"

# =========================================================================
# Sheet5: 出力方針(logback)
# =========================================================================
ws5 = wb.create_sheet("5.出力方針(logback)")
h5 = ["項目", "内容"]
pol = [
    ["出力先", "stdout / stderr。ERROR→stderr / それ以外→stdout（LevelFilter で振り分け）。CloudWatch Logs が収集"],
    ["appender", "STDOUT / STDERR の2本のみ。各ログ種類は logger_name の <logger> でレベルと振り分けを指定"],
    ["ログ種類の区別", "logger_name（JSONフィールド）で区別"],
    ["encoder", "LoggingEventCompositeJsonEncoder（JSON1行）"],
    ["timestamp", "@timestamp→timestamp にリネーム。yyyy-MM-dd HH:mm:ss.SSS / Asia/Tokyo"],
    ["@version", "出力しない（抑止）"],
    ["type / subtype", "独自provider TypeSubtypeJsonProvider が付与。type=レベル判定(ERROR→monitor/他→app)、subtype=logger_nameから導出(固定ロガー以外=SYSTEM)。Markerには持たせない"],
    ["システムログ(root)", "固定ロガーに該当しない＝明示出力していないFW等のログ。logger_name=実クラス名、type=レベル判定、subtype=SYSTEM が自動付与"],
    ["MDC", "<mdc> + includeMdcKeyName で function/user/action/trace_id/source_ip を明示"],
    ["id / name", "独自provider（ContainerInfoJsonProvider）。ECSメタデータを起動時1回取得"],
    ["その他項目", "type/subtype/url/status/headers/body/class_name/method_name/args/result/bucket_name/path/latency/aws_* は Marker で付与"],
    ["マスク", "headers/body/message/args/result/stack_trace/url(クエリ)。body/message は最大長制限"],
    ["トレース伝播", "外部HTTPは traceparent ヘッダ、SQSは メッセージ属性 traceparent で下流へ trace_id を連携"],
    ["MDC伝播", "非同期/子スレッドは MdcTaskDecorator で MDC を複製（@Async・独自プール）"],
    ["フィルタ順序", "HttpLoggingFilter は @Order(HIGHEST_PRECEDENCE) で最外周 wrap"],
]
for j, h in enumerate(h5, 1):
    ws5.cell(row=1, column=j, value=h)
style_header(ws5, 1, len(h5))
for i, row in enumerate(pol, 2):
    put_row(ws5, i, row)
ws5.column_dimensions["A"].width = 18
ws5.column_dimensions["B"].width = 90

# =========================================================================
# Sheet: 変更履歴（改訂記録）
# =========================================================================
ws_hist = wb.create_sheet("変更履歴")
h_hist = ["日付", "版", "対象シート/ファイル", "変更内容", "種別"]
HIST = [
    ["2026-06-08", "1.0", "全シート",
     "初版作成（0.前提 / 1.定義一覧 / 2.ログ出力項目 / 3.ログ種類別定義 / 4.実装部品一覧 / 5.出力方針(logback)）", "新規"],
    ["2026-06-09", "1.1", "2.ログ出力項目 / 3.ログ種類別定義 / 4.実装部品一覧",
     "aws_request_timestamp / aws_response_time を △→○ 確定（AWSCALL系 S/U/W＋KMS/DynamoDB で出力）。latency と併存（両方出力）", "確定"],
    ["2026-06-09", "1.1", "4.実装部品一覧",
     "ApplicationLogger の取得項目から line（行番号）を削除（合意32項目・実装に無いため）", "修正"],
    ["2026-06-09", "1.1", "変更履歴",
     "本シートを新設（改訂記録の管理。git は使用しないためExcel内で履歴管理）", "新規"],
    ["2026-06-09", "1.2", "2.ログ出力項目 / 3.ログ種類別定義",
     "実行単位スコープ(MDC)項目 user/action/trace_id/source_ip を『スコープ内の全ログに付与』へ確定（実装に合わせる）。"
     "user/action=全ログ、trace_id=L(nginx)以外、source_ip=W(常駐)以外。値の有無は実行区分に依存", "確定"],
]
for j, h in enumerate(h_hist, 1):
    ws_hist.cell(row=1, column=j, value=h)
style_header(ws_hist, 1, len(h_hist))
for i, row in enumerate(HIST, 2):
    put_row(ws_hist, i, row)
for j, w in enumerate([12, 6, 38, 78, 8], 1):
    ws_hist.column_dimensions[get_column_letter(j)].width = w
ws_hist.freeze_panes = "A2"

# =========================================================================
# Sheet0: 前提（先頭・読む順の最初）
# =========================================================================
ws0 = wb.create_sheet("0.前提", 0)
ws0.column_dimensions["A"].width = 22
ws0.column_dimensions["B"].width = 110
_r0 = [1]


def s0title(text):
    c = ws0.cell(row=_r0[0], column=1, value=text)
    c.font = Font(bold=True, size=12, color="FFFFFF")
    c.fill = HEAD_FILL
    ws0.merge_cells(start_row=_r0[0], start_column=1, end_row=_r0[0], end_column=2)
    _r0[0] += 1


def s0row(label, content):
    a = ws0.cell(row=_r0[0], column=1, value=label)
    a.font = Font(bold=True)
    a.alignment = WRAP
    a.border = BORDER
    b = ws0.cell(row=_r0[0], column=2, value=content)
    b.alignment = WRAP
    b.border = BORDER
    _r0[0] += 1


ws0.cell(row=_r0[0], column=1, value="前提・このシートについて").font = Font(bold=True, size=14)
_r0[0] += 2

s0title("■ この資料は何か")
s0row("目的", "Spring Bootアプリケーションの『ログ設計書（上位設計）』。出力するログ項目・ログ種類・出力方式・取得方法・利用スコープを定義する。")
s0row("設計の流れ", "本Excel（上位設計）→ Markdown設計書（下位設計）→ 実装。Excelで設計→Markdownへ反映→Markdownから実装、の順。"
                   "本Excelは外部資料を参照せず自己完結させる（下位の設計書/実装を参照しない）。")

s0title("■ どういう仕組み上で設計するか（前提とする基盤）")
s0row("ログ出力", "Spring Boot 上で logback を使ってログを出力する。ログは JSON 形式（1行）で出す。")
s0row("出力先", "標準出力(stdout)／標準エラー(stderr) に出す（ファイル出力しない）。ERRORは標準エラー、それ以外は標準出力。")
s0row("ログ収集", "標準出力/標準エラーを AWS の CloudWatch Logs が収集する（Logs Insights で検索・集約）。")
s0row("実行基盤", "ECS（コンテナ）上で動作。フロントに nginx。")
s0row("利用AWS", "S3 / SQS / KMS / DynamoDB を利用し、アクセス時にジャーナルログを出す。")
s0row("実行区分", "オンライン(API) / バッチ / 常駐バッチ（詳細は『1.定義一覧』の処理分類）。")

s0title("■ シート構成（読む順）")
s0row("1.定義一覧", "用語・処理分類・ログレベル・ログ種類・詳細種別・利用スコープ・出力対象ログの記号 などの定義。")
s0row("2.ログ出力項目", "各ログ出力項目（論理名/物理名/取得方法/スコープ/出力対象ログ L〜Z）。")
s0row("3.ログ種類別定義", "ログ種類ごとの出力項目・出力先・出力部品。")
s0row("4.実装部品一覧", "実装する部品（クラス）一覧と取得項目・出力ロガー。")
s0row("5.出力方針(logback)", "logback を作る際の確定方針（encoder/MDC/マスク/トレース伝播 等）。")
s0row("変更履歴", "日付/版/対象/変更内容/種別 の改訂記録（末尾シート）。")

s0title("■ 読み方・凡例")
s0row("名称", "論理名で記載し、物理名（JSONキー名）は補足として併記する。")
s0row("記号", "○=出力対象 ／ △=未確定（要確認）／ ★=要確認事項。")
s0row("用語", "不明な用語は『1.定義一覧』の用語ブロックを参照。")

# =========================================================================
# ヘッダのコメント説明（セルにマウスを乗せると表示）
# =========================================================================
note(ws2.cell(row=1, column=1), "シート2：各ログ出力項目の定義。用語は『1.定義一覧』を参照。")
note(ws2.cell(row=1, column=13), "API/バッチ/常駐バッチ/コンテナ外/コンテナ内：その項目が出力されうる実行区分・出力場所。○=該当。コンテナ外=nginx、コンテナ内=アプリ。")
note(ws2.cell(row=1, column=18), "出力対象ログ(L〜Z)：各記号の対応ログ種類は『1.定義一覧』の『出力対象ログの記号』を参照。○=その項目を出力（値がnull/デフォルトでも項目は存在）／△=未確定。")
note(ws3.cell(row=1, column=1), "シート3：ログ種類ごとの出力項目・出力先・出力部品。")
note(ws4.cell(row=1, column=1), "シート4：実装する部品（クラス）一覧。")
note(ws5.cell(row=1, column=1), "シート5：logback を作る際の確定方針。")

wb.save("/Users/kobuo/workspace/cosmo-log/ログ設計.xlsx")
print("written: ログ設計.xlsx  sheets =", wb.sheetnames)
