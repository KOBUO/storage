package com.example.cosmolog.logging.web;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.util.StreamUtils;

import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.MdcKeys;
import com.example.cosmolog.logging.StructuredLog;
import com.example.cosmolog.logging.mask.LogMaskingService;

/**
 * 外部HTTPジャーナルログ出力部品。
 * RestTemplate の呼び出し前後で「外部アクセスジャーナル(要求/応答)」を出力する。
 * レスポンスボディを読んでも消費しないよう、RestTemplate 側を BufferingClientHttpRequestFactory で構成する
 * （{@link RestClientConfig} 参照）。
 */
@Component
public class HttpClientJournalInterceptor implements ClientHttpRequestInterceptor {

    private static final Logger log = LoggerFactory.getLogger(LoggerNames.HTTP_CLIENT_JNL);

    private final LogMaskingService masking;

    public HttpClientJournalInterceptor(LogMaskingService masking) {
        this.masking = masking;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution)
            throws IOException {
        String url = request.getMethod() + " " + request.getURI();

        // トレース伝播：MDCのtrace_idを下流へ traceparent ヘッダで渡す（分散トレーシング）
        String traceId = MDC.get(MdcKeys.TRACE_ID);
        if (traceId != null && !traceId.isBlank() && !request.getHeaders().containsHeader("traceparent")) {
            request.getHeaders().add("traceparent", traceId);
        }

        // 外部アクセスジャーナル(要求): headers=リクエストヘッダー / body=リクエストボディ
        log.info(StructuredLog.create()
                .put(LogFields.URL, url)
                .put(LogFields.HEADERS, masking.maskHeaders(headers(request.getHeaders())))
                .put(LogFields.BODY, masking.maskBody(text(body)))
                .marker(), "http client journal (request)");

        long startNanos = System.nanoTime();
        ClientHttpResponse response = execution.execute(request, body);
        long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;
        String responseBody = StreamUtils.copyToString(response.getBody(), StandardCharsets.UTF_8);

        // 外部アクセスジャーナル(応答): headers=レスポンスヘッダー / body=レスポンスボディ
        log.info(StructuredLog.create()
                .put(LogFields.URL, url)
                .put(LogFields.STATUS, response.getStatusCode().value())
                .put(LogFields.HEADERS, masking.maskHeaders(headers(response.getHeaders())))
                .put(LogFields.BODY, masking.maskBody(responseBody))
                .put(LogFields.LATENCY, latencyMs)
                .marker(), "http client journal (response)");

        return response;
    }

    private Map<String, String> headers(org.springframework.http.HttpHeaders headers) {
        return headers.toSingleValueMap();
    }

    private String text(byte[] body) {
        return (body == null || body.length == 0) ? null : new String(body, StandardCharsets.UTF_8);
    }
}
