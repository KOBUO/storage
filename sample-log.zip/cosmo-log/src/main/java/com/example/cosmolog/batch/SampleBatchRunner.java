package com.example.cosmolog.batch;

import java.util.UUID;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.example.cosmolog.config.AppMode;
import com.example.cosmolog.demo.SampleBatchJob;

/**
 * 【単発バッチ】の起動起点。{@code app.mode=batch} のときだけ登録され、
 * 起動直後に {@link SampleBatchJob} を1回実行して JVM を終了する。
 *
 * 起動例:
 * <pre>{@code
 * ./gradlew bootRun --args='--app.mode=batch --spring.main.web-application-type=none'
 * }</pre>
 *
 * MDC(function/trace_id 等)とエラーハンドリングは {@link SampleBatchJob} 側が持つ。
 * ここはジョブ実行IDを払い出して起動し、終了コードを制御するだけ。
 */
@Component
@ConditionalOnProperty(name = "app.mode", havingValue = AppMode.BATCH)
public class SampleBatchRunner implements CommandLineRunner {

    private final SampleBatchJob batchJob;

    public SampleBatchRunner(SampleBatchJob batchJob) {
        this.batchJob = batchJob;
    }

    @Override
    public void run(String... args) {
        try {
            String jobExecutionId = UUID.randomUUID().toString();
            batchJob.run(jobExecutionId);
            System.exit(0);
        } catch (Exception e) {
            // 失敗の業務エラーログは SampleBatchJob 側で出力済み。終了コードのみここで制御する。
            System.exit(1);
        }
    }
}
