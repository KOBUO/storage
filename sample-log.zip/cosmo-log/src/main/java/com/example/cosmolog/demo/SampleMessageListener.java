package com.example.cosmolog.demo;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import com.example.cosmolog.config.AppMode;
import com.example.cosmolog.logging.ApplicationLogger;
import com.example.cosmolog.logging.LogFields;
import com.example.cosmolog.logging.LoggerNames;
import com.example.cosmolog.logging.StructuredLog;
import com.example.cosmolog.logging.aws.SqsTraceSupport;
import com.example.cosmolog.logging.scope.ExecutionScopeMdc;
import com.example.cosmolog.logging.scope.resident.MessageLogScope;

import io.awspring.cloud.sqs.annotation.SqsListener;

/**
 * 【常駐バッチ（メッセージ処理）】起点。{@code app.mode=resident} のときだけ登録され、
 * {@code @SqsListener} が SQS をポーリングし続ける（リスナーコンテナのスレッドが JVM を生かす）。
 *
 * 1メッセージごとに:
 *   1. メッセージジャーナルログ(W)を出力（aws_sqs_message_id 等）
 *   2. {@link MessageLogScope} で MDC(trace_id 等)を張り、業務ログ(開始/終了)を出力
 *   3. 失敗時は業務エラーログを残して再 throw（DLQ/リトライ前提）
 *
 * ローカルは ElasticMQ をエンドポイントに指定（{@code application-local.yml}）。
 * 本番は profile を付けず実 AWS SQS に接続する。
 */
@Component
@ConditionalOnProperty(name = "app.mode", havingValue = AppMode.RESIDENT)
public class SampleMessageListener {

    /** メッセージジャーナルログ(W)：SQS 受信の証跡。 */
    private static final Logger journalLog = LoggerFactory.getLogger(LoggerNames.SQS_JNL);

    private final ApplicationLogger appLogger;

    public SampleMessageListener(ApplicationLogger appLogger) {
        this.appLogger = appLogger;
    }

    @SqsListener("${app.sqs.queue-name}")
    public void onMessage(Message<String> message) {
        MessageHeaders headers = message.getHeaders();
        // SQS MessageId は Spring Cloud AWS 3.x が標準の MessageHeaders ID として設定する（SQS MessageId は UUID 形式）。
        UUID id = headers.getId();
        String messageId = id != null ? id.toString() : null;
        // trace_id: メッセージ属性 traceparent 優先（送信側が MDC の trace_id を載せている）、無ければ MessageId。
        String traceparent = stringHeader(headers, SqsTraceSupport.TRACEPARENT);
        String traceId = (traceparent != null && !traceparent.isBlank()) ? traceparent : messageId;
        String body = message.getPayload();

        try (ExecutionScopeMdc scope = MessageLogScope.open("配信計画メッセージ処理", traceId)) {
            // メッセージジャーナルログ(W): trace_id は MDC から付与される
            journalLog.info(StructuredLog.create()
                    .put(LogFields.AWS_SQS_MESSAGE_ID, messageId)
                    .marker(), "sqs journal (receive)");
            try {
                appLogger.info("メッセージ処理開始 body=" + body);
                // 【検証用トリガ】本文に "fail" を含むと処理失敗とする（業務エラーログ→再 throw→再配信/DLQ の確認用）。
                if (body != null && body.contains("fail")) {
                    throw new RuntimeException("意図的な処理失敗(検証用): " + body);
                }
                // ... 業務処理（サービスジャーナル等も同じ trace_id で出力される）...
                appLogger.info("メッセージ処理終了");
            } catch (RuntimeException e) {
                // メッセージ処理失敗を業務エラーログに残す（この後 DLQ/リトライへ）
                appLogger.error("メッセージ処理失敗 messageId=" + messageId, e);
                throw e;
            }
        }
    }

    private String stringHeader(MessageHeaders headers, String name) {
        Object value = headers.get(name);
        return value != null ? value.toString() : null;
    }
}
