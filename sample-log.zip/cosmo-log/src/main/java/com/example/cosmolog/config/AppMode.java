package com.example.cosmolog.config;

/**
 * 起動モード。{@code app.mode} プロパティで API / 単発バッチ / 常駐バッチ を切り替える。
 * 各起点クラスは {@code @ConditionalOnProperty(name="app.mode", havingValue=...)} で
 * モードに応じて Bean 登録される。
 */
public final class AppMode {

    /** オンライン(API)。web 起動。未指定時の既定。 */
    public static final String API = "api";
    /** 単発バッチ。CommandLineRunner 実行後に終了（web-application-type=none 推奨）。 */
    public static final String BATCH = "batch";
    /** 常駐バッチ。@SqsListener が SQS をポーリングし続ける（web-application-type=none 推奨）。 */
    public static final String RESIDENT = "resident";

    private AppMode() {
    }
}
