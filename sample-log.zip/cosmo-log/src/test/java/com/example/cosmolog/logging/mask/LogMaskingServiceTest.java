package com.example.cosmolog.logging.mask;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.example.cosmolog.logging.LoggingProperties;

/**
 * ヘッダー/ボディ/URL のマスキングと最大長切り詰めを検証する。
 */
class LogMaskingServiceTest {

    private LogMaskingService masking;

    @BeforeEach
    void setUp() {
        LoggingProperties props = new LoggingProperties();
        props.setMaskHeaderNames(List.of("authorization", "cookie"));
        props.setMaskBodyKeys(List.of("password", "token"));
        props.setBodyMaxLength(2048);
        props.setMessageMaxLength(10);
        masking = new LogMaskingService(props);
    }

    @Test
    void masksConfiguredHeadersCaseInsensitively() {
        Map<String, String> out = masking.maskHeaders(Map.of("Authorization", "Bearer x", "Accept", "*/*"));
        assertThat(out.get("Authorization")).isEqualTo("***");
        assertThat(out.get("Accept")).isEqualTo("*/*");
    }

    @Test
    void masksJsonBodyKeys() {
        String out = masking.maskBody("{\"id\":\"1\",\"password\":\"p@ss\",\"token\":\"abc\"}");
        assertThat(out).contains("\"password\":\"***\"").contains("\"token\":\"***\"").contains("\"id\":\"1\"");
    }

    @Test
    void masksUrlQueryValues() {
        assertThat(masking.maskUrl("GET /login?token=secret&id=1")).isEqualTo("GET /login?token=***&id=1");
    }

    @Test
    void truncatesMessageOverMaxLength() {
        assertThat(masking.maskMessage("0123456789ABCDEF")).startsWith("0123456789").endsWith("(truncated)");
    }

    @Test
    void nullSafe() {
        assertThat(masking.maskHeaders(null)).isNull();
        assertThat(masking.maskBody(null)).isNull();
        assertThat(masking.maskUrl(null)).isNull();
    }
}
