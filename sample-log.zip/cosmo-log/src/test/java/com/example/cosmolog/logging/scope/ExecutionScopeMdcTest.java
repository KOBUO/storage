package com.example.cosmolog.logging.scope;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import com.example.cosmolog.logging.MdcKeys;
import com.example.cosmolog.logging.scope.batch.BatchLogScope;
import com.example.cosmolog.logging.scope.resident.MessageLogScope;

/**
 * 実行単位スコープが MDC を設定し、close() で必ずクリアすることを検証する。
 */
class ExecutionScopeMdcTest {

    @AfterEach
    void clear() {
        MDC.clear();
    }

    @Test
    void setsAndClearsMdc() {
        try (ExecutionScopeMdc scope = ExecutionScopeMdc.open("f", "a", "u", "t", "ip")) {
            assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("f");
            assertThat(MDC.get(MdcKeys.ACTION)).isEqualTo("a");
            assertThat(MDC.get(MdcKeys.USER)).isEqualTo("u");
            assertThat(MDC.get(MdcKeys.TRACE_ID)).isEqualTo("t");
            assertThat(MDC.get(MdcKeys.SOURCE_IP)).isEqualTo("ip");
        }
        for (String key : MdcKeys.ALL) {
            assertThat(MDC.get(key)).as(key).isNull();
        }
    }

    @Test
    void blankValuesAreNotSet() {
        try (ExecutionScopeMdc scope = ExecutionScopeMdc.open("f", "a", null, "t", "")) {
            assertThat(MDC.get(MdcKeys.USER)).isNull();
            assertThat(MDC.get(MdcKeys.SOURCE_IP)).isNull();
            assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("f");
        }
    }

    @Test
    void batchScopeUsesJobExecutionIdAsTraceId() {
        try (ExecutionScopeMdc scope = BatchLogScope.open("売上集計バッチ", "job-1")) {
            assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("売上集計バッチ");
            assertThat(MDC.get(MdcKeys.TRACE_ID)).isEqualTo("job-1");
            assertThat(MDC.get(MdcKeys.ACTION)).isEqualTo("BATCH_EXEC");
        }
    }

    @Test
    void messageScopeUsesMessageIdAsTraceId() {
        try (ExecutionScopeMdc scope = MessageLogScope.open("配信計画メッセージ処理", "msg-1")) {
            assertThat(MDC.get(MdcKeys.FUNCTION)).isEqualTo("配信計画メッセージ処理");
            assertThat(MDC.get(MdcKeys.TRACE_ID)).isEqualTo("msg-1");
            assertThat(MDC.get(MdcKeys.ACTION)).isEqualTo("CONSUME");
        }
    }
}
