# java-base-image

Java アプリの実行用ベースイメージ（日本語対応版の amazoncorretto）を作成し、Nexus（lpj-docker-base）へ登録するプロジェクトです。

## イメージの内容

| 項目 | 内容 |
|---|---|
| ベースイメージ | `amazoncorretto:25`（sha256 で固定） |
| OS | Amazon Linux 2023 |
| 追加内容 | 日本語ロケール（`glibc-langpack-ja`）、`TZ=Asia/Tokyo`、`LANG=ja_JP.UTF-8` |

## バージョン一覧

| イメージのタグ | JDK | ベースイメージの sha256 | glibc-langpack-ja |
|---|---|---|---|
| `1.0.0` | 25.0.4.11-1 | `c4348c3d4e9c2219d6e09c2e9e473c9a5bafe0492c4a7038cd60f2f6a473c16b` | 2.34-231.amzn2023.0.5 |

## 構成

```
java-base-image/
├── docker/
│   ├── Dockerfile
│   └── rpms/
│       └── glibc-langpack-ja-<バージョン>.x86_64.rpm
├── .gitlab-ci.yml
└── README.md
```

## パイプラインの動き

pipeline-template（`common-pipeline.yml`）を利用しています。

| きっかけ | pre:pipeline | build | nexus-push |
|---|---|---|---|
| ブランチへの push／MR | 実行しない | 実行（ビルド確認のみ） | 実行しない |
| タグの作成（snapshot／release） | 実行（タグ名チェック） | 実行 | 実行（Nexus へ push） |

### タグ名の形式

タグ名は pipeline-template の `pre:pipeline` でチェックされます。形式が違うとパイプラインが失敗します。

| 種類 | git のタグ | イメージのタグ |
|---|---|---|
| release | `release-1.0.0`／`release-v1.0.0` | `1.0.0`／`v1.0.0` |
| snapshot | `snapshot-1.0.0-build1` | `1.0.0-build1` |
| snapshot | `snapshot-1.0.0-systest-build3` | `1.0.0-systest-build3` |

- 先頭の `release-`／`snapshot-` を除いた部分が、イメージのタグになります。
- release は数字3つで終わる形しか通らないため、release と snapshot でイメージのタグが重なることはありません。

## リリース手順

1. 変更を main にマージします。
2. 「バージョン一覧」の表に新しい行を追加します。
3. main からタグを作成します。
   ```sh
   git tag release-1.0.0
   git push origin release-1.0.0
   ```
4. パイプラインの `nexus-push` が成功したことを確認します。

動作確認用に登録したい場合は、`snapshot-1.0.0-build1` のような snapshot タグを作成します。

## 利用方法

```dockerfile
FROM ${DOCKER_BASE_REGISTRY}/amazoncorretto:1.0.0
```

## ベースイメージを更新するとき

`FROM` の sha を変えるときは、**rpm も必ず同時に入れ替えてください。**
rpm のバージョンがベースイメージの glibc と1つでもずれると、ビルドが次のエラーで失敗します。

```
error: Failed dependencies:
    glibc = 2.34-231.amzn2023.0.4 is needed by glibc-langpack-ja-2.34-231.amzn2023.0.4.x86_64
```

### 手順

1. 新しいベースイメージの glibc のバージョンを確認します。
   ```sh
   docker run --rm --platform linux/amd64 amazoncorretto@sha256:<新しいsha> rpm -q glibc
   ```
   例：`glibc-2.34-231.amzn2023.0.5.x86_64`
2. 同じバージョンの `glibc-langpack-ja` の rpm を取得し、`docker/rpms/` の古い rpm と**置き換え**ます。
   - 古い rpm は必ず削除してください。Dockerfile は `glibc-langpack-ja-*.rpm` でまとめてコピーするため、2つあると競合して失敗します。
3. `docker/Dockerfile` の `FROM` の sha を書き換えます。
4. 「バージョン一覧」に行を追加し、バージョンを上げてタグを作成します。
