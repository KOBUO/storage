# Spring Boot ログ設計書

顧客要件から整理したログ出力項目の設計ドキュメント。
各項目について「取得方法」「MDC要否」「利用スコープ」「出力対象ログ」を定義する。

---

## 1. 前提

- ログ出力項目は **32項目**。
- `logger_name` は Java の通常のクラスロガー名ではなく、**ログ種類ごとの固定ロガー名**として扱う。
  - 例：`LoggerFactory.getLogger("SPRINGBOOT_API_LOG")`
  - `logback.xml` 側で、この `logger_name` に応じてログ種類ごとの appender に振り分ける。
- 通常は `LoggerFactory.getLogger(対象クラス.class)` によりログ発生元クラスを追跡できるが、本設計では `logger_name` をログ種類固定名にするため、**ログ発生元クラス・メソッドは `class_name` / `method_name` で別途出力する**必要がある。

### 破棄した項目

検討途中で出た以下の項目は、今回のログ出力項目には存在しないため破棄する。

- `request_id`
- `session_id`
- `error_code`

### headers / body の扱い

`headers` / `body` は、リクエスト用・レスポンス用で物理名を分けない。
ログ種類が異なるため、同じ `headers` / `body` にリクエスト/レスポンスを相乗りさせる。

| ログ種類 | headers | body |
|---|---|---|
| リクエストログ | リクエストヘッダー | リクエストボディ |
| レスポンスログ | レスポンスヘッダー | レスポンスボディ |

---

## 2. ログ出力項目一覧（シート1：ログ出力項目定義）

| No | 物理名 | 概要 | サンプル値 | 取得方法（概要） | MDC | MDCキー | 利用スコープ |
|---|---|---|---|---|---|---|---|
| 1 | timestamp | ログ出力時刻 | `2026-06-05 15:37:00.123` | logback が出力時刻を付与 | 不要 | - | logback自動 |
| 2 | id | コンテナID | - | 環境変数 `CONTAINER_ID` から取得（未設定ならホスト名）。ContainerInfoJsonProvider | 不要 | - | アプリ共通 |
| 3 | name | コンテナ名 | - | 環境変数 `CONTAINER_NAME` から取得（未設定なら `cosmo-log`）。ContainerInfoJsonProvider | 不要 | - | アプリ共通 |
| 4 | level | ログレベル | `INFO` | logback が出力レベルを付与 | 不要 | - | logback自動 |
| 5 | level_value | ログレベル数値 | `20000` | logback がレベルの数値を付与 | 不要 | - | logback自動 |
| 6 | logger_name | 固定ロガー名 | `SPRINGBOOT_API_LOG` | ロガー生成時に指定した固定名 | 不要 | - | logback自動 |
| 7 | type | ログ種類大分類 | `app` | ログレベルから自動判定 | 不要 | - | logback自動 |
| 8 | thread | スレッド名 | `http-nio-8080-exec-1` | logback がスレッド名を付与 | 不要 | - | logback自動 |
| 9 | function | 機能単位 | `配信計画API` | 処理開始時に、機能の識別子を MDC へ設定 | **要** | function | 実行単位(MDC) |
| 10 | user | ユーザー識別子 | - | 処理開始時に、利用者の識別子を MDC へ設定 | **要** | user | 実行単位(MDC) |
| 11 | action | 操作・処理内容 | `配信計画取得` | 処理開始時に、操作内容を MDC へ設定 | **要** | action | 実行単位(MDC) |
| 12 | subtype | ログ種類詳細 | `DBCALL` | ロガー名から自動判定 | 不要 | - | logback自動 |
| 13 | trace_id | 一意識別子 | - | 処理開始時に、トレースIDを MDC へ設定（無ければ生成） | **要** | trace_id | 実行単位(MDC) |
| 14 | message | メッセージ本文 | - | ログ出力時にコードが指定 | 不要 | - | 出力時に指定 |
| 15 | stack_trace | スタックトレース | - | 例外オブジェクトを渡して付与 | 不要 | - | 出力時に指定 |
| 16 | source_ip | リクエスト元IP | - | リクエスト元IPを取得し MDC へ設定 | **要** | source_ip | 実行単位(MDC) |
| 17 | url | アクセスURL | - | リクエスト情報から取得 | 不要 | - | 出力時に指定 |
| 18 | status | HTTPステータス | `200` | レスポンス情報から取得 | 不要 | - | 出力時に指定 |
| 19 | headers | ヘッダー情報 | - | リクエスト/レスポンスのヘッダを取得 | 不要 | - | 出力時に指定 |
| 20 | body | ボディ情報 | - | リクエスト/レスポンスのボディを取得 | 不要 | - | 出力時に指定 |
| 21 | class_name | 出力元クラス名 | - | ログ出力箇所のクラスを自動取得 | 不要 | - | 出力時に指定 |
| 22 | method_name | 出力元メソッド名 | - | ログ出力箇所のメソッドを自動取得 | 不要 | - | 出力時に指定 |
| 23 | args | メソッド引数 | - | メソッドの引数を取得 | 不要 | - | 出力時に指定 |
| 24 | result | メソッド結果 | - | メソッドの戻り値を取得 | 不要 | - | 出力時に指定 |
| 25 | bucket_name | S3バケット名 | - | AWS(S3)呼び出し情報から取得 | 不要 | - | 出力時に指定 |
| 26 | path | S3オブジェクトキー | `input/customer.csv` | AWS(S3)呼び出し情報から取得 | 不要 | - | 出力時に指定 |
| 27 | latency | 処理時間（ms） | - | 処理の開始〜終了の差分 | 不要 | - | 出力時に指定 |
| 28 | aws_request_id | AWSリクエストID | - | AWSの応答から取得 | 不要 | - | 出力時に指定 |
| 29 | aws_request_timestamp | AWSリクエスト日時 | - | AWS呼び出しの時刻を記録 | 不要 | - | 出力時に指定 |
| 30 | aws_response_time | AWSレスポンス時間 | - | AWS呼び出しの所要時間 | 不要 | - | 出力時に指定 |
| 31 | aws_s3_extended_request_id | S3拡張リクエストID | - | S3の応答から取得 | 不要 | - | 出力時に指定 |
| 32 | aws_sqs_message_id | SQSメッセージID | - | SQS送受信の結果から取得 | 不要 | - | 出力時に指定 |

> `class_name` / `method_name` は、固定ロガー名のままでは発生元が分からなくなるため出力する。サービスジャーナルログでは AOP（@Service の対象）で、業務ログでは **StackWalker により呼び出し元を自動取得**する（実装者は意識しなくてよい）。

---

## 2-2. 出力対象ログ マトリクス（顧客設計書 L列〜Z列）

顧客設計書で定義された ○ を**正として転記**したもの。推測で ○ は付けていない。
`aws_request_timestamp` / `aws_response_time` は当初は顧客設計書で未整理（黄色）だったが、**AWSCALL系（S / U / W ＋ KMS / DynamoDB）で出力すると確定（○）**。`latency` とは併存（両方出力）する。（2026-06-09 確定）

### 列の凡例

| 列 | ログ種類 |
|---|---|
| L | Nginxログ |
| M | アクセスログ |
| N | アクセスジャーナルログ（要求） |
| O | アクセスジャーナルログ（応答） |
| P | サービスジャーナルログ（開始） |
| Q | サービスジャーナルログ（終了） |
| R | SQLジャーナルログ |
| S | ストレージアクセスジャーナルログ |
| T | 外部アクセスジャーナルログ（要求） |
| U | 外部アクセスジャーナルログ（応答） |
| V | キャッシュジャーナルログ（廃止） |
| W | メッセージジャーナルログ |
| X | 業務ログ |
| Y | 業務エラーログ |
| Z | システムログ |

凡例：`○`＝その項目（JSONキー）を出力する（顧客設計書で確定。値がnull／デフォルトでも項目は存在する）／`△`＝案（未整理項目に対する提案、確定ではない）／空欄＝対象外

> **V（キャッシュジャーナルログ）は廃止**（部品 CacheJournalAspect・ロガー `SPRINGBOOT_CACHE_JNL_LOG` とも削除）。以下マトリクスの V 列は参考（旧定義）として残すが、現状は出力されない。

### 項目 × ログ種類 マトリクス

| No | 物理名 | L | M | N | O | P | Q | R | S | T | U | V | W | X | Y | Z |
|---|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| 1 | timestamp | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 2 | id | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 3 | name | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 4 | level | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 5 | level_value | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 6 | logger_name |  | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 7 | type | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 8 | thread |  | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 9 | function | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 10 | user | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 11 | action | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 12 | subtype | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 13 | trace_id |  | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 14 | message | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| 15 | stack_trace |  |  |  |  |  |  |  |  |  |  |  |  |  | ○ | ○ |
| 16 | source_ip | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |  | ○ | ○ | ○ |
| 17 | url | ○ | ○ | ○ | ○ |  |  |  |  | ○ | ○ |  |  |  |  |  |
| 18 | status | ○ | ○ | ○ | ○ |  |  |  |  | ○ | ○ |  |  |  |  |  |
| 19 | headers |  |  | ○ | ○ |  |  |  |  | ○ | ○ |  |  |  |  |  |
| 20 | body |  |  | ○ | ○ |  |  |  |  | ○ | ○ |  |  |  |  |  |
| 21 | class_name |  |  |  |  | ○ | ○ |  |  |  |  |  |  | ○ | ○ |  |
| 22 | method_name |  |  |  |  | ○ | ○ |  |  |  |  |  |  | ○ | ○ |  |
| 23 | args |  |  |  |  | ○ | ○ |  |  |  |  |  |  |  |  |  |
| 24 | result |  |  |  |  | ○ | ○ |  |  |  |  |  |  |  |  |  |
| 25 | bucket_name |  |  |  |  |  |  |  | ○ |  |  |  |  |  |  |  |
| 26 | path |  |  |  |  |  |  |  | ○ |  |  |  |  |  |  |  |
| 27 | latency | ○ | ○ |  | ○ |  | ○ | ○ | ○ |  | ○ | ○ | ○ |  |  |  |
| 28 | aws_request_id |  |  |  |  |  |  |  | ○ |  | ○ |  | ○ |  |  |  |
| 29 | aws_request_timestamp |  |  |  |  |  |  |  | ○ |  | ○ |  | ○ |  |  |  |
| 30 | aws_response_time |  |  |  |  |  |  |  | ○ |  | ○ |  | ○ |  |  |  |
| 31 | aws_s3_extended_request_id |  |  |  |  |  |  |  | ○ |  |  |  |  |  |  |  |
| 32 | aws_sqs_message_id |  |  |  |  |  |  |  |  |  |  |  | ○ |  |  |  |

### AWSメタ日時項目の確定（旧△）

| 項目 | 出力対象（確定） | 確定理由 |
|---|---|---|
| 29. aws_request_timestamp | S, U, W（＋KMS/DynamoDB） | 同じ AWS 呼び出しメタデータである `aws_request_id` の出力先（S/U/W）に揃える。リクエストID と日時は対で出力するのが自然。 |
| 30. aws_response_time | S, U, W（＋KMS/DynamoDB） | 同上。`latency` と値が重複しうるが、**両方出力で確定**（`latency`＝処理全体、`aws_response_time`＝AWS呼び出し所要、として併存）。 |

> 2026-06-09 確定：当初△（案）だった上記2項目は **AWSCALL系で出力（○）** と確定。`latency` とは併存する。

### 転記から読み取れる特徴（参考）

- **function / user / action / trace_id / source_ip は実行単位スコープ(MDC)項目**で、**スコープ内の全ログに自動付与**される（2026-06-09 確定。実装に合わせる＝MDCはログ種類で出し分けない）。
  - `user` / `action` … 全ログ（L〜Z）。`trace_id` … L（Nginx）以外の全ログ。`source_ip` … W（メッセージ＝常駐）以外の全ログ（オンラインのみ値あり、batch/常駐は未設定で欠落）。
  - 値の有無は実行区分とスコープ設定に依存する（例: batch/常駐では `source_ip` は設定されない）。項目（JSONキー）の出力可否としては上記のとおり。
- **logger_name / thread** は L（Nginx）に付かない（Nginx は Java ロガー外のため）。
- **latency** は「応答／終了」側（O, Q, U）に付き、「要求／開始」側（N, P, T）には付かない。処理時間は終了時に確定するため整合的。
- **url / status** は L・M に加えて T・U（外部アクセス）にも付く＝外部HTTP呼び出しの宛先・結果を記録する想定。

---

## 2-3. ログ種類別 出力項目（マトリクスの逆引き）

各ログがどの項目を出力するか。

| ログ種類 | 出力項目 |
|---|---|
| L Nginxログ | timestamp, id, name, level, level_value, type, function, user, action, subtype, message, source_ip, url, status, latency |
| M アクセスログ | timestamp, id, name, level, level_value, logger_name, type, thread, function, user, action, subtype, message, source_ip, url, status, latency |
| N アクセスジャーナルログ（要求） | 共通8項目※ + trace_id, message, url, status, headers, body |
| O アクセスジャーナルログ（応答） | 共通8項目※ + trace_id, message, url, status, headers, body, latency |
| P サービスジャーナルログ（開始） | 共通8項目※ + trace_id, message, class_name, method_name, args, result |
| Q サービスジャーナルログ（終了） | 共通8項目※ + trace_id, message, class_name, method_name, args, result, latency |
| R SQLジャーナルログ | 共通8項目※ + trace_id, message, latency |
| S ストレージアクセスジャーナルログ | 共通8項目※ + trace_id, message, bucket_name, path, latency, aws_request_id, aws_s3_extended_request_id, aws_request_timestamp, aws_response_time |
| T 外部アクセスジャーナルログ（要求） | 共通8項目※ + trace_id, message, url, status, headers, body |
| U 外部アクセスジャーナルログ（応答） | 共通8項目※ + trace_id, message, url, status, headers, body, latency, aws_request_id, aws_request_timestamp, aws_response_time |
| V キャッシュジャーナルログ（廃止） | ～共通8項目※ + trace_id, message, latency～（部品廃止のため出力なし） |
| W メッセージジャーナルログ | 共通8項目※ + trace_id, message, latency, aws_request_id, aws_sqs_message_id, aws_request_timestamp, aws_response_time |
| X 業務ログ | 共通8項目※ + trace_id, message |
| Y 業務エラーログ | 共通8項目※ + trace_id, message, stack_trace |
| Z システムログ | 共通8項目※ + trace_id, message, stack_trace |

> ※**共通8項目** = timestamp, id, name, level, level_value, type, function, subtype（全ログ共通）。
> このうち logger_name・thread は L 以外の全ログに付く（L は対象外）。
> さらに **実行単位スコープ(MDC)項目 `user` / `action` / `trace_id` / `source_ip` も全ログに付与**される（2026-06-09 確定）。上の各行では個別列挙を省略している（`trace_id` は明記）。`trace_id` は L 以外、`source_ip` は W 以外、`user`/`action` は全ログ。値の有無は実行区分に依存。

---

## 3. type / subtype / logger_name の定義

`logger_name` / `type` / `subtype` はログ種類定義と対応する**固定値**として扱う。

### type（ログ種類の大分類）

| 値 | 説明 |
|---|---|
| `app` | アプリケーションログ |
| `monitor` | 監視ログ |
| `trail` | 証跡ログ |

### subtype（ログ種類詳細）

| 値 | 説明 |
|---|---|
| `SHELL` | シェル |
| `SYSTEM` | システム |
| `NGINX` | NGINX |
| `AWSCALL` | AWS API 呼び出し |
| `DBCALL` | DB 呼び出し |
| `APL` | アプリケーション |

### logger_name（固定ロガー名）

固定ロガー名は **11種**（セクション7と一致）。

- `SPRINGBOOT_API_ACCESS_LOG`（アクセスログ）
- `SPRINGBOOT_API_ACCESS_JNL_LOG`（アクセスジャーナルログ）
- `SPRINGBOOT_SERVICE_JNL_LOG`（サービスジャーナルログ）
- `SPRINGBOOT_SQL_JNL_LOG`（SQLジャーナルログ）
- `SPRINGBOOT_STORAGE_JNL_LOG`（ストレージアクセスジャーナルログ）※logback定義のみ存置。出力部品（S3AccessService）は廃止
- `SPRINGBOOT_HTTP_CLIENT_JNL_LOG`（外部アクセスジャーナルログ）
- `SPRINGBOOT_SQS_JNL_LOG`（メッセージジャーナルログ）
- `SPRINGBOOT_KMS_JNL_LOG`（KMSアクセスジャーナルログ）
- `SPRINGBOOT_DYNAMODB_JNL_LOG`（DynamoDBアクセスジャーナルログ）
- `SPRINGBOOT_API_LOG`（業務ログ）
- `SPRINGBOOT_ERROR_LOG`（業務エラーログ）

> Nginxログ・システムログ(root) は固定ロガー名を持たない（前者はnginx側、後者は実クラス名のままroot出力）。

---

## 4. スコープの考え方

値の供給方法で4つに分類する（『利用スコープ』の4分類）。「いつ決まる値か」で分けると AWS呼び出しとログ出力時がほぼ同じになるため、供給方法で分ける。

| スコープ | 説明 | 該当項目（例） |
|---|---|---|
| **アプリ共通** | アプリ起動時に1回決まり、全ログに共通で付く値 | id, name |
| **実行単位(MDC)** | 1処理（オンライン=リクエスト / バッチ=ジョブ / 常駐バッチ=メッセージ）の間、共有する値 | function, user, action, trace_id, source_ip |
| **logback自動** | logback／独自provider が出力時に自動で付与する値 | timestamp, level, level_value, logger_name, thread, type, subtype |
| **出力時に指定** | ログ出力箇所で、その都度指定する値 | message, stack_trace, url, status, headers, body, class_name, method_name, args, result, bucket_name, path, latency, aws_* |

> `timestamp` は `logback.xml` で定義するが、logback が出力時に自動付与するため**logback自動**として扱う。

---

## 5. MDC の考え方

MDC に設定するのは、**実行単位スコープで複数ログに使い回す値**のみ。

### MDC 設定項目

| MDCキー | 項目 |
|---|---|
| function | 9. function |
| user | 10. user |
| action | 11. action |
| trace_id | 13. trace_id |
| source_ip | 16. source_ip |

### MDC 設定／クリアのタイミング

| 実行単位 | MDC設定 | MDCクリア |
|---|---|---|
| オンライン | HTTPリクエスト開始時 | レスポンス返却後 |
| バッチ | ジョブ開始時 | ジョブ終了時 |
| 常駐バッチ | メッセージ受信・処理開始時 | メッセージ処理終了時 |

### MDC 不要な項目と理由

その場で取得できる値、logback が持つ値、ログ種類ごとの固定値、AWS呼び出し結果の値は、MDC に保持せずログ出力時に設定すればよい。

> 対象外：timestamp, id, name, level, level_value, logger_name, type, subtype, thread, message, stack_trace, url, status, headers, body, class_name, method_name, args, result, bucket_name, path, latency, aws_request_id, aws_request_timestamp, aws_response_time, aws_s3_extended_request_id, aws_sqs_message_id

---

## 6. 各項目の詳細

### 1. timestamp
- **取得内容**：ログ出力時刻
- **形式**：`yyyy-MM-dd HH:mm:ss.SSS`
- **取得元**：Logback
- **取得方法**：`logback.xml` / encoder 側の timestamp 設定で出力
- **MDC**：不要 ／ **スコープ**：logback自動
- **備考**：LoggingEvent 生成時刻

### 2. id
- **取得内容**：コンテナID
- **利用目的**：障害発生インスタンス特定 / Heap・CPU・GC・スレッドダンプ等メトリクスとの突合 / CloudWatch・ECS 側情報との突合
- **取得元**：環境変数 `CONTAINER_ID`（未設定ならホスト名）
- **取得方法**：`ContainerInfoJsonProvider` が環境変数から直接取得し、起動時に1回解決して保持
- **MDC**：不要 ／ **スコープ**：アプリ共通
- **備考**：ECSタスク定義等で `CONTAINER_ID` を設定する想定（旧 ECSメタデータAPI からの HTTP 取得は廃止）

### 3. name
- **取得内容**：コンテナ名
- **取得元**：環境変数 `CONTAINER_NAME`（未設定なら `cosmo-log`）
- **取得方法**：`ContainerInfoJsonProvider` が環境変数から直接取得し、起動時に1回解決して保持
- **MDC**：不要 ／ **スコープ**：アプリ共通

### 4. level
- **取得内容**：ログレベル（DEBUG / INFO / WARN / ERROR）
- **取得元**：Logback
- **取得方法**：`LoggingEvent#getLevel()`
- **MDC**：不要 ／ **スコープ**：logback自動
- **備考**：TRACE は対象外

### 5. level_value
- **取得内容**：ログレベルの数値表現（DEBUG=10000 / INFO=20000 / WARN=30000 / ERROR=40000）
- **取得元**：Logback
- **取得方法**：`LoggingEvent#getLevel().toInt()`
- **MDC**：不要 ／ **スコープ**：logback自動

### 6. logger_name
- **取得内容**：ログ種類ごとの固定ロガー名
- **取得元**：Logger生成時の指定値
- **取得方法**：`LoggerFactory.getLogger("SPRINGBOOT_API_LOG")` のように固定ロガー名を指定
- **MDC**：不要 ／ **スコープ**：logback自動
- **備考**：Javaクラス名ではなくログ種類を表す固定Logger名。logback.xml では logger_name によりログ種類ごとの appender へ振り分ける。通常のクラスロガー名が失われるため class_name / method_name で発生元を出力する必要がある

### 7. type
- **取得内容**：ログ種類の大分類（app / monitor / trail）
- **取得元**：ログ種類定義
- **取得方法**：logger_name / ログ種類に応じた固定値を設定
- **MDC**：不要 ／ **スコープ**：logback自動

### 8. thread
- **取得内容**：ログ出力時のJavaスレッド名（例：`http-nio-8080-exec-1`）
- **取得元**：Logback
- **取得方法**：`LoggingEvent#getThreadName()`
- **MDC**：不要 ／ **スコープ**：logback自動
- **備考**：項目名が「スレッド番号」の場合は「スレッド名」の方が実態に合う

### 9. function
- **取得内容**：API / ジョブ / 常駐処理などの機能単位（オンライン=API単位、バッチ=ジョブ単位、常駐バッチ=メッセージ処理機能単位）
- **サンプル**：配信計画API / 売上集計バッチ / 配信計画メッセージ処理
- **取得元**：アプリケーション定義
- **取得方法**：リクエスト受付時 / ジョブ開始時 / メッセージ処理開始時に設定
- **MDC**：要（キー：function）／ **スコープ**：実行単位(MDC)
- **備考**：action より大きい粒度

### 10. user
- **取得内容**：呼出元から連携されるユーザー識別子（オンライン=HTTPヘッダーから取得想定）
- **バッチ / 常駐バッチ**：取得元が存在しない可能性があり要検討（候補：固定値 SYSTEM/BATCH、ジョブ実行ユーザー、ジョブ実行ID、未設定/null）
- **取得元**：HTTPヘッダー等
- **取得方法**：リクエストヘッダーから取得
- **MDC**：要（キー：user）／ **スコープ**：実行単位(MDC)
- **備考**：バッチ・常駐バッチでの設定方法は要設計確認

### 11. action
- **取得内容**：実行された操作・処理内容
- **function との関係**：function=API/ジョブ/処理機能の単位、action=その中で実行されたリクエスト/操作の単位
- **例**：function=配信計画API、action=配信計画取得/登録/更新/削除
- **取得元**：アプリケーション定義
- **取得方法**：APIリクエスト受付時 / ジョブ開始時 / メッセージ処理開始時に設定
- **MDC**：要（キー：action）／ **スコープ**：実行単位(MDC)

### 12. subtype
- **取得内容**：ログ種類詳細（SHELL / SYSTEM / NGINX / AWSCALL / DBCALL / APL）
- **取得元**：ログ種類定義
- **取得方法**：ログ出力対象の処理種別に応じた固定値を設定
- **MDC**：不要 ／ **スコープ**：logback自動

### 13. trace_id
- **取得内容**：リクエストまたは処理を一意に識別する識別子
  - オンライン：HTTPヘッダーから取得、未設定ならアプリ側で生成
  - バッチ：ジョブ実行単位で生成、またはジョブ実行ID等を使用
  - 常駐バッチ：メッセージ単位で取得または生成、メッセージ属性に存在すれば引き継ぐ
- **取得元**：HTTPヘッダー / メッセージ属性 / アプリ生成値
- **取得方法**：処理開始時に取得または生成
- **MDC**：要（キー：trace_id）／ **スコープ**：実行単位(MDC)
- **備考**：同一リクエスト・同一処理で出力される複数ログを紐付けるキー

### 14. message
- **取得内容**：ログメッセージ本文
- **取得元**：アプリケーション
- **取得方法**：`logger.info("...")` / `logger.error("...")` 等で指定
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：
  - 明示的に指定しない場合、設定されない可能性 → デフォルト値設定 or 項目自体を不要とするか要検討
  - 改行が想定されるため出力時にエスケープ対応が必要
  - 個人情報に該当する内容は出力しない、またはマスク
  - ログ1行 4KB 以内制約がある場合、SQLジャーナルログ等で参照結果を message に出力すると超過の可能性 → しきい値制限が必要

### 15. stack_trace
- **取得内容**：例外発生時のスタックトレース情報
- **取得元**：Throwable / Exception
- **取得方法**：`logger.error("...", exception)` のように例外オブジェクトを渡す
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：例外時のみ設定 / JSONログではエスケープ対応が必要 / 個人情報・機密情報のマスク要否を検討

### 16. source_ip
- **取得内容**：リクエスト元IPアドレス
  - オンライン：`X-Forwarded-For` から取得、複数IPなら先頭をクライアントIPとして扱う
  - バッチ / 常駐バッチ：HTTPリクエストではないため取得不可。null または固定値とするか要確認
- **取得元**：HTTPヘッダー
- **取得方法**：`X-Forwarded-For` 優先、なければ `request.getRemoteAddr()`
- **MDC**：要（キー：source_ip）／ **スコープ**：実行単位(MDC)

### 17. url
- **取得内容**：アクセスされたURL
- **取得元**：HttpServletRequest
- **取得方法**：`request.getMethod()` / `getRequestURI()` / `getQueryString()` 等から組み立て
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：オンライン処理のみ取得可能。バッチ・常駐バッチでは取得不可

### 18. status
- **取得内容**：HTTPレスポンスステータスコード（200 / 400 / 401 / 403 / 404 / 500 等）
- **取得元**：HttpServletResponse
- **取得方法**：Filter の処理終了時に `response.getStatus()` から取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：オンライン処理のみ取得可能

### 19. headers
- **取得内容**：ヘッダー情報（リクエストログ=リクエストヘッダー、レスポンスログ=レスポンスヘッダー）
- **取得元**：HttpServletRequest / HttpServletResponse
- **取得方法**：`getHeaderNames()` / `getHeaders(name)` から取得して Map 形式に変換
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：Authorization・Cookie・APIキー・個人情報を含むヘッダーはマスクまたは除外 / 全量出力 or 許可リスト方式かを要確認

### 20. body
- **取得内容**：ボディ情報（リクエストログ=リクエストボディ、レスポンスログ=レスポンスボディ）
- **取得元**：HttpServletRequest / HttpServletResponse
- **取得方法**：`ContentCachingRequestWrapper` / `ContentCachingResponseWrapper` 等でキャッシュして取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：個人情報・認証情報・機密情報はマスクまたは除外 / 大容量時のため最大長を設ける / `ContentCachingResponseWrapper` 使用時は最後に `copyBodyToResponse()` を呼ばないとレスポンスが返却されない可能性

### 21. class_name
- **取得内容**：ログ出力元クラス名
- **取得元**：Logback / LoggingEvent
- **取得方法**：LoggingEvent の caller data から取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：logger_name をログ種類固定名として使用するため発生元追跡項目として重要。caller data 取得は性能影響があるため、常時出力 or ログ種類限定かを要検討

### 22. method_name
- **取得内容**：ログ出力元メソッド名
- **取得元**：Logback / LoggingEvent
- **取得方法**：LoggingEvent の caller data から取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：class_name 同様に発生箇所追跡のため重要。caller data 取得は性能影響あり

### 23. args
- **取得内容**：メソッド実行時の引数情報
- **取得元**：AOP
- **取得方法**：対象メソッド実行前に `JoinPoint#getArgs()` から取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：主にサービスジャーナルログ等で使用 / 個人情報・認証情報・機密情報のマスクまたは除外が必要 / 全メソッド出力はログ量・性能影響が大きいため対象範囲を限定

### 24. result
- **取得内容**：メソッド実行結果、または処理結果
- **取得元**：AOP
- **取得方法**：対象メソッドの正常終了後に戻り値を取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：主にサービスジャーナルログ等で使用 / マスクまたは除外が必要 / 戻り値が大きい場合は最大長や除外対象を設ける / 例外発生時は result ではなく stack_trace 等に出力

### 25. bucket_name
- **取得内容**：S3アクセス時の対象バケット名
- **取得元**：S3アクセス部品 / AWS SDK
- **取得方法**：S3 API 実行時のリクエスト情報から取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：S3アクセス時のジャーナルログで出力。path とセットでアクセス先を表す

### 26. path
- **取得内容**：S3アクセス時の対象パス（S3オブジェクトキー）
- **サンプル**：`input/customer.csv` / `archive/2026/06/05/result.json`
- **取得元**：S3アクセス部品 / AWS SDK
- **取得方法**：S3 API 実行時のリクエスト情報から対象オブジェクトキーを取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：bucket_name とセットで `s3://bucket_name/path` を表す

### 27. latency
- **取得内容**：処理にかかった時間（単位：ms 想定）
- **取得元**：アプリケーション
- **取得方法**：処理開始時刻と処理終了時刻の差分を算出
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：アクセスログ=リクエスト受付〜レスポンス返却 / ジャーナルログ=対象処理の開始〜終了 / S3=S3 API 呼び出し時間 / SQS=API 呼び出し時間 or メッセージ処理時間のどちらか要確認 / 単位は ms で統一

### 28. aws_request_id
- **取得内容**：AWS API 呼び出し時に AWS 側が払い出すリクエストID
- **対象**：S3 / SQS / KMS / DynamoDB 等の AWS API 呼び出し
- **取得元**：AWS SDK レスポンスメタデータ、または HTTP レスポンスヘッダー
- **取得方法**：各 AWS アクセス部品で SDK 呼び出し結果から取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：AWS 側の調査・問い合わせ時に使用。S3 の場合は `x-amz-request-id` に相当

### 29. aws_request_timestamp
- **取得内容**：AWS API リクエスト日時
- **取得元**：アプリケーション / AWSアクセス部品
- **取得方法**：AWS API 呼び出し直前の時刻を自前で記録
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：AWS から返る値というより、実装側で記録する可能性が高い

### 30. aws_response_time
- **取得内容**：AWS API レスポンス時間
- **取得元**：アプリケーション / AWSアクセス部品
- **取得方法**：AWS API 呼び出し開始からレスポンス受信までの差分を算出
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：latency と重複する可能性があるため用途整理が必要

### 31. aws_s3_extended_request_id
- **取得内容**：S3 が返却する拡張リクエストID
- **対象**：S3専用
- **取得元**：S3 レスポンスヘッダー
- **取得方法**：S3 API 実行結果から `x-amz-id-2` を取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：AWS サポート調査用。SQS / KMS / DynamoDB 等では取得できない

### 32. aws_sqs_message_id
- **取得内容**：SQSメッセージID
- **対象**：SQS専用
- **取得元**：SQS送信結果 / SQS受信メッセージ
- **取得方法**：送信時は `SendMessageResult`、受信時は `Message#getMessageId()` から取得
- **MDC**：不要 ／ **スコープ**：出力時に指定
- **備考**：SQSメッセージ追跡に使用。S3 / KMS / DynamoDB では取得できない

---

## 7. ログ種類・logback 定義（シート2）★顧客設計書 SSD-010 反映

`logback.xml` を作るための定義表。**出典：SSD-010 処理方式設計書**（値は確定）。

**type はレベル判定で導出する**（`ERROR→monitor` / それ以外→`app`）。下表の type 列はその結果（INFOのジャーナルは app、ERROR時は monitor）。

| ログ種類名 | 物理名 | type | logger_name | ログレベル | 備考 |
|---|---|---|---|---|---|
| Nginxログ | nginx | app/monitor | （既存・固定名なし） | INFO | **nginx側**で出力。type はレベル判定（ERROR→monitor / 他→app） |
| アクセスログ | access | app | `SPRINGBOOT_API_ACCESS_LOG` | INFO | **アプリ側**のサマリ（HttpLoggingFilter が別ログとして出力）。nginxではない |
| アクセスジャーナルログ | access_jnl | app | `SPRINGBOOT_API_ACCESS_JNL_LOG` | INFO | 要求/応答（送信/受信）の詳細（headers/body） |
| サービスジャーナルログ | service_jnl | app | `SPRINGBOOT_SERVICE_JNL_LOG` | INFO | クラス/メソッドの開始・終了 |
| SQLジャーナルログ | sql_jnl | app | `SPRINGBOOT_SQL_JNL_LOG` | INFO | **SQL用ロガーは設計上存在する**。MyBatis Interceptor で任意ロガー指定 |
| ストレージアクセスジャーナルログ | storage_jnl | app | `SPRINGBOOT_STORAGE_JNL_LOG` | INFO | S3アクセス。**logback定義のみ存置（appender-storage-jnl.xml）。出力部品 S3AccessService は廃止** |
| 外部アクセスジャーナルログ | external_jnl | app | `SPRINGBOOT_HTTP_CLIENT_JNL_LOG` | INFO | 外部接続（リクエスト/応答） |
| ~~キャッシュジャーナルログ~~ | ~~cache_jnl~~ | - | ~~`SPRINGBOOT_CACHE_JNL_LOG`~~ | - | **廃止**（部品 CacheJournalAspect・ロガー定義とも削除） |
| メッセージジャーナルログ | msg_jnl | app | `SPRINGBOOT_SQS_JNL_LOG` | DEBUG / INFO / WARN | SQS送受信 |
| KMSアクセスジャーナルログ | kms_jnl | app | `SPRINGBOOT_KMS_JNL_LOG` | INFO | KMS暗号/復号（AWSCALL）。マトリクスL〜Z外の追加ログ種類 |
| DynamoDBアクセスジャーナルログ | dynamodb_jnl | app | `SPRINGBOOT_DYNAMODB_JNL_LOG` | INFO | DynamoDB Get/Put等（AWSCALL）。マトリクスL〜Z外の追加ログ種類 |
| 業務ログ | app | app | `SPRINGBOOT_API_LOG` | DEBUG / INFO / WARN | 明示出力する業務イベント（ApplicationLogger#info） |
| 業務エラーログ | app_err | monitor | `SPRINGBOOT_ERROR_LOG` | ERROR | **明示出力する業務エラー**（ApplicationLogger#error） |
| システムログ | (root) | app/monitor | **（固定名なし・root）** | INFO/WARN/ERROR | **実装で明示出力していない＝固定ロガーに該当しないFW等のログ**。logger_name=実クラス名、subtype=SYSTEM。「システムログ＋システムエラーログ」を包含 |

### 7-1. 出力先の方針（stdout / stderr）★確定

CloudWatch Logs で収集するため、**標準出力(stdout) / 標準エラー(stderr) を明示指定**する（ファイル出力ではない）。
基本ルール（不変）：

- **ERROR → stderr**（`System.err`）
- **ERROR以外 → stdout**（`System.out`）

**appender はログの種類ごとに分割定義する**。`logback-spring.xml` から、ログ種類別の `logback/appender-*.xml`（`appender-access.xml` / `appender-access-jnl.xml` / `appender-service-jnl.xml` / `appender-sql-jnl.xml` / `appender-http-client-jnl.xml` / `appender-storage-jnl.xml` / `appender-sqs-jnl.xml` / `appender-kms-jnl.xml` / `appender-dynamodb-jnl.xml` / `appender-app.xml` / `appender-error.xml` / `appender-system.xml`）を `<include>` する。
各ファイルの中で `System.out` / `System.err` を決める。

- INFO のみの種類（アクセスジャーナル等）は `System.out` の ConsoleAppender を1つ定義する。
- ERROR のみの種類（業務エラーログ）は `System.err` の ConsoleAppender を1つ定義する。
- **INFO と ERROR の両方を出す種類**（サービスジャーナル / SQLジャーナル / システムログ(root) 等）は、同一ファイル内に out 用・err 用の ConsoleAppender を2つ定義し、`ch.qos.logback.classic.filter.LevelFilter` でレベルにより振り分ける。

> 旧方式（出力先で分割：`appender-stdout.xml` が ERROR以外→System.out、`appender-stderr.xml` が ERRORのみ→System.err の2本構成）から、**ログの種類ごとの分割**へ変更した。基本ルール（ERROR→stderr / 他→stdout）は不変。

両レベルを出す種類での LevelFilter 振り分け例（同一ファイル内に2 appender）：

```xml
<!-- out: ERRORは出さない -->
<appender name="XXX_OUT" class="ch.qos.logback.core.ConsoleAppender">
  <target>System.out</target>
  <filter class="ch.qos.logback.classic.filter.LevelFilter">
    <level>ERROR</level><onMatch>DENY</onMatch><onMismatch>NEUTRAL</onMismatch>
  </filter>
  <encoder ... />
</appender>
<!-- err: ERRORだけ出す -->
<appender name="XXX_ERR" class="ch.qos.logback.core.ConsoleAppender">
  <target>System.err</target>
  <filter class="ch.qos.logback.classic.filter.LevelFilter">
    <level>ERROR</level><onMatch>ACCEPT</onMatch><onMismatch>DENY</onMismatch>
  </filter>
  <encoder ... />
</appender>
```

### 7-2. encoder の方針（JSON / timestamp / version）★確定

JSON出力は `net.logstash.logback.encoder`（`LogstashEncoder` または `LoggingEventCompositeJsonEncoder`）を使用。
LogstashEncoder 既定の `@timestamp` / `@version` を整形・抑止する。

- `@timestamp` → **`timestamp`** にリネーム、形式 **`yyyy-MM-dd HH:mm:ss.SSS`（JST / Asia/Tokyo）**
- `@version` → **出力しない**
- MDC は `<mdc>` provider で出力（`includeMdcKeyName` で出力キーを明示制御可能）
- **type / subtype は独自 provider `TypeSubtypeJsonProvider` が付与**（Markerには持たせない）：
  - **type = レベル判定**（`ERROR→monitor` / それ以外→`app`）
  - **subtype = logger_name から導出**（固定ロガー以外＝システムログ＝`SYSTEM`）
- これにより **root（システムログ）でも type/subtype が自動付与**される。

> CloudWatch Logs 側では `@timestamp` / `@ingestionTime` / `@logStream` / `@log` / `@message` が付与され、
> `@message` に stdout/stderr へ出した 1行JSON が入る。

### 7-3. type / subtype 区分の確定値

- **type（大分類）**：`app`（アプリ実行）/ `monitor`（運用監視）/ `trail`（証跡）。
  - **type はログレベルで導出する**：`ERROR → monitor` / それ以外 → `app`（`TypeSubtypeJsonProvider`）。
  - `trail`（証跡）は**現状未使用**。証跡/監査ログを追加する場合に使用（要確認）。
- **subtype（種別）と適用区分**（SSD-010）。subtype は **logger_name から導出**（固定ロガー以外＝システムログ＝`SYSTEM`）：

| subtype | オンライン | バッチ(コンテナ内) | 常駐処理 | 概要 |
|---|:-:|:-:|:-:|---|
| SHELL | - | ○ | - | コンテナ内Shellに出力するJOBログ |
| SYSTEM | ○ | ○ | ○ | Tomcat/Spring 等が出力するログ |
| NGINX | ○ | - | - | nginx のログ |
| AWSCALL | ○ | ○ | ○ | AWS-API呼び出し時（aws_request_id 等を含める） |
| DBCALL | ○ | ○ | ○ | SQL実行ログ（バッチは件数制限あり・後述） |
| APL | ○ | ○ | ○ | アプリ開発者用の任意ログ |

### 7-4. AWSCALL / DBCALL の出力ルール（SSD-010）

- **AWSCALL**：AWS-API呼び出し時に `Request ID` / `Request Timestamp` / `Response Time` / `S3 Extended Request ID`（S3のみ）/ `MessageId`（SQSのみ）を含める。
  → これにより `aws_request_timestamp` / `aws_response_time` は **AWS呼び出しで出力すると確定（○）**（旧△、2026-06-09 確定）。設計書セクション2-2の出力対象（S/U/W）と整合。
- **DBCALL（バッチ/常駐）**：大量件数のため全DBアクセスは出力しない。**IN/OUT件数**、ループ時は「ループ処理開始/終了」「1000件完了」等の進捗、**SQLException等のエラー時は詳細SQL**を出力。

---

## 8. 実装部品・出力タイミング定義（シート3）

Java 側で作成するクラス一覧。

| # | 論理名 | 物理名 | 実行タイミング | 実装方法 | 役割 | 取得項目 / MDC設定項目 |
|---|---|---|---|---|---|---|
| 1 | コンテナ情報付与部品 | ContainerInfoJsonProvider | ログ出力時（値は起動時に解決） | logback の独自 provider | 環境変数 `CONTAINER_ID` / `CONTAINER_NAME` から id / name を直接取得し全ログに付与 | id, name |
| 2 | HTTPログ制御部品 | HttpLoggingFilter | HTTPリクエスト開始〜終了 | `OncePerRequestFilter` 継承 | HTTPリクエスト単位のログ制御 | 取得：user, trace_id, source_ip, url, status, headers, body, latency／MDC：user, trace_id, source_ip, function, action |
| 3 | 機能・アクション解決部品 | FunctionActionResolver | リクエスト/ジョブ/メッセージ処理開始時 | Filter・ジョブ起動・SQS Listener 等から呼出 | function / action を決定 | function, action（MDC設定） |
| 4 | サービスジャーナルログ出力部品 | ServiceJournalAspect | Serviceメソッド実行前後 | `@Aspect` + `@Around` | Serviceメソッドのジャーナルログ出力 | class_name, method_name, args, result, latency |
| 5 | SQLジャーナルログ出力部品 | SqlJournalInterceptor | SQL実行時 | MyBatis Interceptor | DBCALLログ出力（Aurora） | latency（★マトリクス準拠：class_name/method_name/args は出力しない。SQL詳細は message） |
| 6 | KMSアクセス部品 | KmsAccessService | 暗号化/復号/データキー取得時 | KMS Client ラップ | KMS呼び出し集約・AWS情報取得 | aws_request_id, aws_request_timestamp, aws_response_time |
| 7 | ~~S3アクセス部品~~ | ~~S3AccessService~~ | - | - | **廃止**（ロガー定義 `SPRINGBOOT_STORAGE_JNL_LOG`／appender-storage-jnl.xml は存置するが、出力部品 S3AccessService は削除） | ~~bucket_name, path, aws_request_id, aws_request_timestamp, aws_response_time, aws_s3_extended_request_id~~ |
| 8 | DynamoDBアクセス部品 | DynamoDbAccessService | Get/Put/Query 等 | DynamoDB Client ラップ | DynamoDB呼び出し結果からAWS情報取得・出力 | aws_request_id, aws_request_timestamp, aws_response_time |
| 9 | SQSアクセス部品 | SqsAccessService | SQS送信/受信/削除時 | SQS Client ラップ / Listener周辺 | SQSアクセスログ出力 | aws_request_id, aws_request_timestamp, aws_response_time, aws_sqs_message_id |
| 10 | AuroraDBアクセス部品 | DbAccessService / SqlJournalInterceptor | DBアクセス時 | Repository / MyBatis 経由 | AuroraDBアクセス共通・DBCALLログ | （SQLジャーナルは SqlJournalInterceptor 側） |
| 11 | 外部HTTPジャーナルログ出力部品 | HttpClientJournalInterceptor | 外部HTTP呼び出し前後 | RestTemplate `ClientHttpRequestInterceptor` / WebClient `ExchangeFilterFunction` | 外部API呼び出しジャーナルログ出力 | url, headers, body, status, latency |
| 12 | ~~キャッシュジャーナルログ出力部品~~ | ~~CacheJournalAspect~~ | - | - | **廃止**（部品・ロガー `SPRINGBOOT_CACHE_JNL_LOG`・`@EnableCaching`/`@Cacheable`/`PricingService` とも削除） | - |
| 13 | 業務ログ出力部品 | ApplicationLogger | 業務処理内で明示呼出時 | Spring Bean | 業務ログ(API_LOG)・業務エラーログ(ERROR_LOG)を固定 logger_name で出力。type/subtypeはproviderが付与 | message, stack_trace（★class_name/method_name は出力しない） |
| 14 | マスキング部品 | LogMaskingService | ログ出力直前 | 各ログ出力部品から呼出 | 個人情報・機密情報のマスク | 対象：headers, body, message, args, result, stack_trace |
| 15 | ログ設定保持部品 | LoggingProperties | アプリ起動時 | `@ConfigurationProperties` | ログ出力設定の保持 | 設定：出力有無, body最大長, message最大長, マスク対象, ヘッダー出力対象, ログ種類ごとのON/OFF |

---

## 9. 補足・検討事項

- 当初は `AwsExecutionInterceptor` のような横断部品を検討したが、実装設計上は KMS / S3 / DynamoDB / AuroraDB / SQS など、それぞれのアクセス部品で取得する方が自然。
- ただし `aws_request_id` 等の取り方は似るため、内部共通処理として `AwsResponseMetadataExtractor` のような小さな部品を作る余地はある。

### 要確認・要検討の論点（一覧）

| 項目 | 論点 |
|---|---|
| user | バッチ・常駐バッチでの設定値（SYSTEM/BATCH/ジョブ実行ID/null）要設計確認 |
| source_ip | バッチ・常駐バッチで null か固定値か要確認 |
| message | 未指定時のデフォルト値 / 項目自体の要否 / 4KB制約のしきい値 |
| headers | 全量出力か許可リスト方式か要確認 |
| class_name / method_name | caller data の性能影響。常時出力かログ種類限定か要検討 |
| ~~latency / aws_response_time~~ | **確定済（2026-06-09）**：`aws_request_timestamp` / `aws_response_time` は AWSCALL系で出力（○）。`latency` とは併存（両方出力）。重複は許容。 |
| SQS の latency | API 呼び出し時間かメッセージ処理時間か要確認 |
| **pid（プロセスID）** | SSD-010 の元資料には `pid` 項目が存在するが、合意済み32項目には無い。採否を要確認 |

### 実行区分別ログ流れの考慮事項（API/バッチ/常駐）

ログの流れをレビューして対応（✅実装 / 📝設計方針）。詳細は実装ガイド（第3部 3.10）。

| 考慮事項 | 対応 |
|---|---|
| MDCが子スレッド/非同期に伝播しない | ～✅ MdcTaskDecorator + AsyncConfig～（**部品廃止**：非同期MDC伝播部品は削除） |
| 下流へトレース伝播（外部HTTP/SQS送信） | ✅ traceparentヘッダ/メッセージ属性で付与 |
| nginx↔app の trace_id 連続性 | 📝 nginxで traceparent 生成・付与 |
| バッチDBログ量制限（IN/OUT・1000件） | 📝 TODO（バッチ基盤連携） |
| SQS受信ジャーナルのtrace_id欠落 | ✅ メッセージ毎scope内で出力 |
| フィルタ順序 | ✅ @Order(HIGHEST_PRECEDENCE) |
| URLクエリのマスク | ✅ maskUrl |
| ジョブ/メッセージ失敗時のエラーログ | ✅ 起点でtry/catch→ApplicationLogger.error |
| stdout/stderr分離での時系列乱れ | 📝 timestamp/trace_idで再整列前提 |

### SSD-010（顧客設計書）反映で確定した事項

- ログ種類の物理名・type・logger_name・ログレベルはセクション7のとおり確定。**SQL用ロガー `SPRINGBOOT_SQL_JNL_LOG` は存在する**（以前「8種に無い」とした判断は誤りで撤回）。
- 出力先は **stdout / stderr**（ERROR→stderr、他→stdout）。ファイル出力ではない（セクション7-1）。
- encoder は LogstashEncoder/Composite で `@timestamp`→`timestamp`、`@version` 抑止（セクション7-2）。
- id / name は **環境変数 `CONTAINER_ID` / `CONTAINER_NAME` から直接取得**（`ContainerInfoJsonProvider`）。ECSタスク定義や entrypoint.sh で環境変数を設定する想定（旧 ECSメタデータAPI からの HTTP 取得方式は廃止）。
- ヘッダ名の想定：`X-Function-Id`（function）/ `X-User-Id`（user）/ `X-Action`（action）/ `traceparent`（trace_id, W3C Trace Context）。
- nginx のスレッド擬似ID：`$pid-$connection-$connection_requests`。timestamp は njs/lua で `yyyy-MM-dd HH:mm:ss.SSS` に整形が必要。
