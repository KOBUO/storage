# ローカル環境構築手順（cosmo-log）

Spring Boot ログ設計サンプル `cosmo-log` を、ローカルでビルド・起動・検証するための手順。
3モード（API / 単発バッチ / 常駐バッチ）と、SQS（ElasticMQ）・S3/KMS/DynamoDB（LocalStack）の検証まで含む。

> 想定: macOS（Apple Silicon / aarch64）。Homebrew 導入済み。
> Intel Mac の場合は JDK/各イメージの arch を `x64` / `amd64` に読み替える。

---

## 0. 必要ソフトウェア一覧

| ソフト | バージョン | 必須 | 用途 |
|---|---|---|---|
| Amazon Corretto JDK | **25**（25.0.3 で確認） | ◯ | ビルド・実行 |
| Gradle | **9.5.1** | ◯（wrapper同梱なら不要） | ビルド。`./gradlew` 同梱 |
| Docker ランタイム（colima 等） | 任意 | △ | 常駐バッチ(SQS)・AWS部品(S3/KMS/DynamoDB)の検証時のみ |
| aws CLI | 任意 | △ | SQS/AWS への手動操作（無くても代替可） |
| pandoc | 3.x | △ | 設計書 EPUB を再ビルドする場合のみ |
| Python + openpyxl/Pillow | 3.x | △ | 設計 Excel / マトリクス画像を再生成する場合のみ |

**最小構成**: JDK 25 だけで「ビルド・テスト・API・単発バッチ」は動く。
常駐バッチ(SQS)と AWS 部品の検証に Docker が要る。

---

## 1. JDK（Amazon Corretto 25）の導入

### 方法A: Homebrew（推奨・要管理者パスワード）

```bash
brew install --cask corretto
# /Library/Java/JavaVirtualMachines/amazon-corretto-25.jdk にインストールされる
/usr/libexec/java_home -v 25   # パスを確認
```

### 方法B: tar.gz を展開（sudo 不要）

管理者権限が使えない場合は tar.gz をユーザー領域へ展開する。

```bash
mkdir -p ~/.jdks
curl -fL -o /tmp/corretto25.tar.gz \
  https://corretto.aws/downloads/latest/amazon-corretto-25-aarch64-macos-jdk.tar.gz
tar -xzf /tmp/corretto25.tar.gz -C ~/.jdks
# → ~/.jdks/amazon-corretto-25.jdk/Contents/Home が JAVA_HOME
~/.jdks/amazon-corretto-25.jdk/Contents/Home/bin/java -version   # 25.0.3 を確認
```

### JAVA_HOME の設定

ターミナルでビルドする場合は JAVA_HOME を通す（PATH 登録していないとき）:

```bash
export JAVA_HOME=~/.jdks/amazon-corretto-25.jdk/Contents/Home   # 方法Bの例
# 方法Aなら: export JAVA_HOME=$(/usr/libexec/java_home -v 25)
```

> **IntelliJ IDEA** は `~/.jdks` 配下を自動検出する。方法Bで入れても
> 「Project Structure → SDK」で Corretto 25 を選べる。

---

## 2. ビルドとテスト

Gradle Wrapper（`gradlew` / `gradle/wrapper/`、Gradle 9.5.1）を同梱済み。JDK さえあれば動く。

```bash
export JAVA_HOME=~/.jdks/amazon-corretto-25.jdk/Contents/Home   # 環境に合わせて

./gradlew compileJava     # コンパイル
./gradlew test            # ユニットテスト（provider / マスキング / MDCスコープ）
./gradlew build           # 上記 + 実行可能 JAR（build/libs/cosmo-log-0.0.1-SNAPSHOT.jar）
```

> Wrapper が無い場合のみ初回に生成: `gradle wrapper --gradle-version 9.5.1`
> （`gradle` 未導入なら `brew install gradle`）。

技術スタック: Spring Boot **4.0.6** / Java **25** / Spring Cloud AWS **4.0.2**（SQS）/ logstash-logback-encoder 8.1。

---

## 3. 3モードの起動

`app.mode` で API / 単発バッチ / 常駐バッチを切り替える（既定 `api`）。
コンテナ情報 `id` / `name` は環境変数から取得する（未設定ならホスト名にフォールバック）。

```bash
export CONTAINER_ID=task-local-001       # → ログの "id"（未設定ならホスト名）
export CONTAINER_NAME=cosmo-local        # → ログの "name"（未設定なら cosmo-log）
```

### API（既定・web 起動）

```bash
./gradlew bootRun
# 別シェルで:
curl -s "http://localhost:8080/api/orders/1" -H "traceparent: trace-1" -H "X-User-Id: u1"
```
→ アクセスログ / アクセスジャーナル(要求・応答) が 1行JSON で stdout に出る。

その他の確認用エンドポイント:
```bash
curl -s "http://localhost:8080/api/external?url=https://example.com"   # 外部HTTPジャーナル
curl -s "http://localhost:8080/api/orders/error"                       # 業務エラーログ(stack_trace)
curl -s -X POST "http://localhost:8080/api/orders" -H 'Content-Type: application/json' \
  -d '{"id":"9","password":"p@ss"}'                                    # password マスキング
```

### 単発バッチ（実行して終了）

```bash
./gradlew bootRun --args='--app.mode=batch --spring.main.web-application-type=none'
```

### 常駐バッチ（SQS）

→ 「4. Docker」「5. 常駐バッチ」を参照（ElasticMQ が必要）。

### IntelliJ IDEA Run/Debug（VM options）

| モード | VM options |
|---|---|
| API | `-Dapp.mode=api`（既定なので省略可） |
| 単発バッチ | `-Dapp.mode=batch -Dspring.main.web-application-type=none` |
| 常駐バッチ | `-Dapp.mode=resident -Dspring.main.web-application-type=none -Dspring.profiles.active=local` |

環境変数 `CONTAINER_ID` / `CONTAINER_NAME` は Run Configuration の Environment variables に設定。

---

## 4. Docker ランタイム（colima）

常駐バッチ(SQS) と AWS 部品(S3/KMS/DynamoDB) の検証に必要。

```bash
brew install colima docker docker-compose   # 未導入なら
colima start                                 # Docker デーモン起動
docker info >/dev/null && echo OK            # 動作確認
```

---

## 5. 常駐バッチ（ElasticMQ で SQS をローカル再現）

本番は AWS SQS。ローカルは **ElasticMQ**（SQS互換）を Docker で立て、アプリは `@SqsListener` で監視する。
接続先は `application-local.yml`（`spring.cloud.aws.sqs.endpoint=http://localhost:9324`）。

```bash
# 1) ElasticMQ 起動（sample-queue / DLQ sample-queue-dlq を自動作成）。管理UI: http://localhost:9325
docker compose up -d elasticmq

# 2) 常駐バッチ起動（local profile）
export JAVA_HOME=~/.jdks/amazon-corretto-25.jdk/Contents/Home
export CONTAINER_ID=task-resident CONTAINER_NAME=cosmo-resident
./gradlew bootRun --args='--app.mode=resident --spring.main.web-application-type=none --spring.profiles.active=local'

# 3) 別シェルからメッセージ送信
#  aws CLI がある場合:
aws sqs send-message --endpoint-url http://localhost:9324 \
  --queue-url http://localhost:9324/000000000000/sample-queue \
  --message-body '{"hello":"world"}' \
  --message-attributes 'traceparent={DataType=String,StringValue=trace-x}'
#  aws CLI が無い場合（SQSクエリAPIを curl で）:
curl -s "http://localhost:9324/000000000000/sample-queue" \
  --data-urlencode "Action=SendMessage" --data-urlencode "MessageBody={\"hello\":\"world\"}"
```

- 受信で SQSメッセージジャーナル + 業務ログ（開始/終了）が出る。`traceparent` 属性が `trace_id` になる。
- **失敗→再試行→DLQ の確認**: 本文に `fail` を含めると例外→業務エラーログ→再配信。
  2回失敗（`maxReceiveCount=2`、可視性10秒）で `sample-queue-dlq` へ移送される。

---

## 6. AWS アクセス部品（KMS / DynamoDB）を LocalStack で

`docker compose up -d localstack` で `localhost:4566` に KMS/DynamoDB を立てる。
AWS SDK v2 は環境変数 `AWS_ENDPOINT_URL` で LocalStack に向く（コード変更不要）。

```bash
# 1) LocalStack 起動
docker compose up -d localstack

# 2) リソース作成（コンテナ内蔵の awslocal。★リージョンはアプリと必ず揃える）
R=ap-northeast-1
docker exec cosmo-log-localstack awslocal --region $R dynamodb create-table --table-name demo-table \
  --attribute-definitions AttributeName=id,AttributeType=S --key-schema AttributeName=id,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST
KID=$(docker exec cosmo-log-localstack awslocal --region $R kms create-key --query 'KeyMetadata.KeyId' --output text)
docker exec cosmo-log-localstack awslocal --region $R kms create-alias --alias-name alias/demo --target-key-id "$KID"

# 3) AWS 用 env を付けて API 起動
export JAVA_HOME=~/.jdks/amazon-corretto-25.jdk/Contents/Home
export AWS_ENDPOINT_URL=http://localhost:4566 AWS_REGION=ap-northeast-1 \
       AWS_ACCESS_KEY_ID=test AWS_SECRET_ACCESS_KEY=test
./gradlew bootRun --args='--app.mode=api'

# 4) 叩く
curl -s localhost:8080/api/aws/kms      # KMSアクセスジャーナル
curl -s localhost:8080/api/aws/dynamo   # DynamoDBアクセスジャーナル
```

---

## 7.（任意）設計ドキュメントの再生成

設計 Excel・マトリクス画像・EPUB を編集後に作り直す場合のみ。

```bash
# Python 仮想環境（openpyxl / Pillow）
python3 -m venv .venv && . .venv/bin/activate
pip install openpyxl pillow

python tools/generate_xlsx.py          # ログ設計.xlsx
python tools/generate_matrix.py        # book/img/matrix.png（要 macOS 日本語フォント）
python tools/generate_logtype_doc.py   # book/04_ログ種類別定義.md

# EPUB（要 pandoc）。Makefile の book ターゲットでも可
brew install pandoc
make book      # → Springbootログ設計書.epub
```

---

## 8. 後片付け

```bash
docker compose down     # ElasticMQ / LocalStack を停止・削除
colima stop             # Docker デーモン停止
./gradlew --stop        # Gradle デーモン停止（使っていれば）
```

---

## 9. トラブルシュート（実際に遭遇した点）

| 症状 | 原因 / 対処 |
|---|---|
| `brew install --cask corretto` が `sudo: a password is required` で失敗 | cask の pkg インストールは管理者パスワードが要る。対話端末で実行するか、**方法B（tar.gz 展開）** を使う。 |
| `java: command not found` / `gradle: command not found` | PATH 未登録。`export JAVA_HOME=...` を付けて `./gradlew` を使う。 |
| LocalStack で `ResourceNotFound`（リソースは作ったのに） | **リージョン不一致**。`awslocal` 既定は `us-east-1`。アプリ(`AWS_REGION`)と同じリージョンで作成する（本書は `ap-northeast-1`）。 |
| api/batch 起動時に AWS リージョン解決で失敗 | Spring Cloud AWS の SQS クライアントが起動時にリージョンを要求。`application.yml` に `spring.cloud.aws.region.static` を既定設定済み。 |
| `timeout: command not found`（スクリプト） | macOS 標準に `timeout` は無い。`coreutils`（`gtimeout`）を入れるか、バックグラウンド実行＋`pkill` で代替。 |

---

## 付録: 関連ファイル

- 起動・モードの詳細 … `README.md`（5-2 / 5-3 / 5-4）
- ログ設計 … `ログ設計.xlsx` / `ログ設計書.md` / `Springbootログ設計書.epub`
- 設計と実装の差分記録 … `設計-実装差分レビュー記録.md`
- 接続設定 … `application.yml`（既定）/ `application-local.yml`（ローカルSQS）/ `docker-compose.yml` / `elasticmq.conf`
