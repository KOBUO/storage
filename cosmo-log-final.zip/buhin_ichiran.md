# ログ部品一覧（確認ケースの参照マスタ）

各部品に安定ID（`P01`〜）を付与。`部品確認ケース.md` の各ケースはこのIDを参照する。
- **logger / 主要キー** … そのログを `grep` で特定するための logger 名（=`logger_name`）と確認フィールド。
- **起点クラス** … 動作の起点となる実装クラス。

| ID | 部品名 | 起点クラス | logger / 主要キー | 出力モード |
|---|---|---|---|---|
| **P01** | コンテナ情報付与 | `ContainerInfoJsonProvider` | 全ログ共通 `id` / `name`（**環境変数** `CONTAINER_ID` / `CONTAINER_NAME` 由来） | 全モード |
| **P02** | HTTPログ制御 | `HttpLoggingFilter` / `FunctionActionResolver` | `SPRINGBOOT_API_ACCESS_LOG`(url/status/latency)<br>`SPRINGBOOT_API_ACCESS_JNL_LOG`(要求/応答 headers/body) | API |
| **P03** | 実行単位スコープMDC | `ExecutionScopeMdc` / `BatchLogScope` / `MessageLogScope` | MDC: `function`/`action`/`user`/`trace_id`/`source_ip` | 全モード |
| **P04** | サービスジャーナル | `ServiceJournalAspect`（`@Service` AOP） | `SPRINGBOOT_SERVICE_JNL_LOG`(class_name/method_name/args/result/latency) | API/バッチ |
| **P05** | SQLジャーナル | `SqlJournalInterceptor`（MyBatis） | `SPRINGBOOT_SQL_JNL_LOG`(message=ステートメントID/latency) | ※未Bean登録(参照実装) |
| **P06** | 外部HTTPジャーナル | `HttpClientJournalInterceptor` / `RestClientConfig` | `SPRINGBOOT_HTTP_CLIENT_JNL_LOG`(url/status/headers/body/latency) | API |
| ~~P07~~ | ~~キャッシュジャーナル~~ | — | **廃止**（キャッシュはログ出力しない） | — |
| **P08** | 業務ログ | `ApplicationLogger` | `SPRINGBOOT_API_LOG`(info) / `SPRINGBOOT_ERROR_LOG`(error)<br>class_name/method_name/message | 全モード |
| **P09** | マスキング | `LogMaskingService` | 各ジャーナルの body/headers/args/result が `***` / `...(truncated)` | 全モード |
| **P10** | エラーハンドリング | `GlobalExceptionHandler`（`@RestControllerAdvice`） | `SPRINGBOOT_ERROR_LOG`(class_name=GlobalExceptionHandler/stack_trace) + HTTP 400 | API |
| ~~P11~~ | ~~非同期MDC伝播~~ | — | **廃止**（不要になった） | — |
| ~~P12~~ | ~~S3アクセス~~ | — | **部品廃止**。`SPRINGBOOT_STORAGE_JNL_LOG` の **logback定義のみ存置** | — |
| **P13** | KMSアクセス | `KmsAccessService` | `SPRINGBOOT_KMS_JNL_LOG`(subtype=AWSCALL/aws_request_id) | AWS |
| **P14** | DynamoDBアクセス | `DynamoDbAccessService` | `SPRINGBOOT_DYNAMODB_JNL_LOG`(subtype=AWSCALL/aws_request_id) | AWS |
| **P15** | SQSアクセス/受信証跡 | `SampleMessageListener` / `SqsAccessService` / `SqsTraceSupport` | `SPRINGBOOT_SQS_JNL_LOG`(aws_sqs_message_id) | 常駐 |

> **P05(SQLジャーナル)** はサンプルに実DBが無く Bean 登録していない参照実装。実機 curl では確認不可 → ユニットテスト or 実DB接続時に確認する。

## 廃止した部品（今回の改修）
- **P07 キャッシュジャーナル** … キャッシュをログ出力しない方針に変更。`CacheJournalAspect` / `PricingService` / `@EnableCaching` / `CACHE_JNL` を削除。
- **P11 非同期MDC伝播** … 不要となり `MdcTaskDecorator` / `AsyncConfig` を削除。
- **P12 S3アクセス** … 部品 `S3AccessService` と `/api/aws/s3` を削除。ただし `SPRINGBOOT_STORAGE_JNL_LOG` の **logback定義（appender + logger）は存置**。

## logback appender 構成（種類別）
旧 `appender-stdout.xml` / `appender-stderr.xml`（出力先で分割）を廃止し、**ログの種類ごとに `logback/appender-*.xml`** を定義する方式に変更。
- 各定義ファイル内で出力先（`System.out` / `System.err`）を決める。
- INFO と ERROR の両方を出す種類（**SERVICE_JNL / SQL_JNL / system(root)**）は、同一ファイルに out 用・err 用の `ConsoleAppender` を2つ定義し、logger から両方を参照する。
- `logback-spring.xml` の各 logger が、対応する種類別 appender を参照する。

| 種類別ファイル | appender 名 | 出力先 |
|---|---|---|
| `appender-access.xml` | ACCESS | out |
| `appender-access-jnl.xml` | ACCESS_JNL | out |
| `appender-service-jnl.xml` | SERVICE_JNL_OUT / SERVICE_JNL_ERR | out / err |
| `appender-sql-jnl.xml` | SQL_JNL_OUT / SQL_JNL_ERR | out / err |
| `appender-storage-jnl.xml` | STORAGE_JNL | out |
| `appender-http-client-jnl.xml` | HTTP_CLIENT_JNL | out |
| `appender-sqs-jnl.xml` | SQS_JNL | out |
| `appender-kms-jnl.xml` | KMS_JNL | out |
| `appender-dynamodb-jnl.xml` | DYNAMODB_JNL | out |
| `appender-app.xml` | APP | out |
| `appender-error.xml` | ERROR | err |
| `appender-system.xml` | SYSTEM_OUT / SYSTEM_ERR | out / err |
