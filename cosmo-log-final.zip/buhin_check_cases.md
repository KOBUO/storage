# ログ部品 動作確認ケース集（Windows / IntelliJ 2026.1.1）

**起動シナリオ3軸**（①API / ②単発バッチ / ③常駐バッチ）ごとに、何を実行すればどの部品が確認できるかを定義する。
部品IDは `部品一覧.md` を参照。各ケースに **【確認部品】** を明示し、末尾に **カバレッジ表** を置く。

- **起動**: IntelliJ の Run Configuration（下記「起動方法」）。
- **トリガ**: 別の **PowerShell** ウィンドウから `curl.exe`（Windows 10/11 同梱）/ `aws`（AWS CLI）。
- **ログ確認**: IntelliJ の実行(Run)ツールウィンドウのコンソールに JSON 1行/件で出る。`Ctrl+F` で `logger_name` 検索が最速。ファイル保存して PowerShell で絞る方法は後述。
- 各ケースに **出力ログ例**（実際に出るJSON, 値はサンプル）を併記。

> ⚠ PowerShell では `curl` は `Invoke-WebRequest` の別名。必ず **`curl.exe`** と打つこと。改行継続はバッククォート `` ` ``（bash の `\` ではない）。

> 🔧 **今回の改修で廃止**: キャッシュジャーナル(P07) / 非同期MDC伝播(P11) / S3アクセス部品(P12)。S3 は logback の `STORAGE_JNL` 定義のみ存置（実行ケース無し）。

---

## 起動方法（IntelliJ 2026.1.1）

メインクラス `com.example.cosmolog.CosmoLogApplication` に対して、3つの実行構成を作る。
`Run` → `Edit Configurations…` → `+` → **Spring Boot**（無ければ Application）で作成。

| 構成名 | Active profiles | Program arguments | Environment variables |
|---|---|---|---|
| **cosmo-API** | （空） | （空。`app.mode=api` が既定） | `CONTAINER_ID=local-1;CONTAINER_NAME=cosmo-log` |
| **cosmo-batch** | （空） | `--app.mode=batch --spring.main.web-application-type=none` | `CONTAINER_ID=local-1;CONTAINER_NAME=cosmo-log` |
| **cosmo-resident** | `local` | `--app.mode=resident --spring.main.web-application-type=none` | `CONTAINER_ID=local-1;CONTAINER_NAME=cosmo-log` |
| **cosmo-API-aws**（任意） | （空） | （空） | `AWS_ENDPOINT_URL=http://localhost:4566;CONTAINER_ID=local-1;CONTAINER_NAME=cosmo-log` |

- **`CONTAINER_ID` / `CONTAINER_NAME`** がログの `id` / `name`（P01）になる。**未設定だと** `id`=ホスト名 / `name`=`cosmo-log` にフォールバック。
- ⚠ シェル(PowerShell)で `set` した環境変数は **IntelliJ 起動には渡らない**。必ず Run Config の「Environment variables」欄に入れること。
- 入力欄が見えない場合は `Modify options` から `Program arguments` / `Environment variables` / `Active profiles` を追加。
- **資材保存**: Run Config の `Modify options` → `Save console output to file` を ON にし、出力先（例 `C:\tmp\app.log`）を指定すると、後述の PowerShell 絞り込みが使える。
- 軸③(常駐)は事前に Docker Desktop で `docker compose up -d` を実行（`sample-queue`/DLQ 作成, 管理UI http://localhost:9325）。

---

## ログ確認の方法（2通り）

**(A) IntelliJ コンソールで直接見る（推奨・手軽）**
実行ツールウィンドウで `Ctrl+F` → logger名（例 `SPRINGBOOT_SERVICE_JNL_LOG`）や `trace_id` の値（例 `trace-a1`）で検索。

**(B) ファイル保存 → PowerShell で整形（jq不要）**
Run Config で console をファイル保存している前提（例 `C:\tmp\app.log`）。
```powershell
Select-String C:\tmp\app.log -Pattern 'trace-a1' |
  ForEach-Object { $_.Line } |
  Where-Object { $_.StartsWith('{') } |
  ForEach-Object { $_ | ConvertFrom-Json | Select-Object logger_name, trace_id, user, function, action }
```
> 以降の各ケースの確認コマンドは、この (B) の形（`Select-String` + `ConvertFrom-Json`）で記載する。(A) なら `Ctrl+F` で同じ logger名/trace_id を探せばよい。

## ログ出力先（種類別 appender）

logback は **ログの種類ごとに appender を定義**（`logback/appender-*.xml`）。各定義内で出力先を決める：
- **ERROR は `System.err`、それ以外は `System.out`**（CloudWatch が収集）。
- 両方出る種類（SERVICE_JNL / SQL_JNL / system(root)）は out/err の2 appender で振り分け。
- `type` は ERROR=`monitor` / 他=`app`。

## 全ログ共通フィールド（主なもの）

| フィールド | 供給元 | 例 / 説明 |
|---|---|---|
| `timestamp` `level` `level_value` `logger_name` `thread` `message` | logback組込 | `"level":"INFO"`, `"logger_name":"SPRINGBOOT_API_LOG"` |
| `id` / `name` | P01 | `id`=`CONTAINER_ID`(未設定→ホスト名) / `name`=`CONTAINER_NAME`(未設定→cosmo-log) |
| `type` / `subtype` | TypeSubtypeProvider | `type`=app（ERRORは monitor）/ `subtype`=APL（AWS系=AWSCALL, SQL=DBCALL, 固定logger外=SYSTEM） |
| `function` `user` `action` `trace_id` `source_ip` | P03(MDC) | スコープ内の全ログに付与 |
| `url` `status` `headers` `body` `class_name` `method_name` `args` `result` `bucket_name` `path` `latency` `aws_*` | 各部品(Marker) | そのログ種別固有 |
| `stack_trace` | logback組込 | error時のみ |

---

# 軸① API モード

**起動**: IntelliJ で **cosmo-API** を Run（AWSケースA-5/A-6のみ **cosmo-API-aws**）。
> 全ケース共通で **P01(コンテナ情報)** と **P03(MDCスコープ)** が乗る。各ケースの【確認部品】では、そのエンドポイント固有の部品を太字で示す。
> 以下のトリガは別の PowerShell ウィンドウで実行する。

---

### A-1. `GET /api/orders/{id}` — 正常系
```powershell
curl.exe -s http://localhost:8080/api/orders/1 -H "traceparent: trace-a1" -H "X-User-Id: u001"
```
**期待ログ**
- `SPRINGBOOT_API_ACCESS_LOG` ×1（url/status=200/latency）
- `SPRINGBOOT_API_ACCESS_JNL_LOG` ×2（要求・応答）
- `SPRINGBOOT_SERVICE_JNL_LOG` ×2（開始・終了, class_name/method_name/latency）
- `SPRINGBOOT_API_LOG` ×1（「注文を取得しました id=1」, class_name=SampleService）
- 全件に `trace_id=trace-a1` / `user=u001` / `id` / `name`

**出力ログ例**
```json
{"timestamp":"2026-06-17 10:00:00.140","level":"INFO","logger_name":"SPRINGBOOT_SERVICE_JNL_LOG","thread":"http-nio-8080-exec-1","message":"service start","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"orders","action":"GET /api/orders/1","user":"u001","trace_id":"trace-a1","source_ip":"127.0.0.1","class_name":"com.example.cosmolog.demo.SampleService","method_name":"getOrder","args":["1"]}
{"timestamp":"2026-06-17 10:00:00.151","level":"INFO","logger_name":"SPRINGBOOT_API_LOG","thread":"http-nio-8080-exec-1","message":"注文を取得しました id=1","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"orders","action":"GET /api/orders/1","user":"u001","trace_id":"trace-a1","source_ip":"127.0.0.1","class_name":"com.example.cosmolog.demo.SampleService","method_name":"getOrder"}
{"timestamp":"2026-06-17 10:00:00.155","level":"INFO","logger_name":"SPRINGBOOT_SERVICE_JNL_LOG","thread":"http-nio-8080-exec-1","message":"service end","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"orders","action":"GET /api/orders/1","user":"u001","trace_id":"trace-a1","source_ip":"127.0.0.1","class_name":"com.example.cosmolog.demo.SampleService","method_name":"getOrder","result":"Order[id=1, name=山田太郎, amount=1200]","latency":15}
{"timestamp":"2026-06-17 10:00:00.160","level":"INFO","logger_name":"SPRINGBOOT_API_ACCESS_LOG","thread":"http-nio-8080-exec-1","message":"access","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"orders","action":"GET /api/orders/1","user":"u001","trace_id":"trace-a1","source_ip":"127.0.0.1","url":"/api/orders/1","status":200,"latency":21}
```
**【確認部品】** P01, **P02**, P03, **P04**, **P08**
```powershell
Select-String C:\tmp\app.log -Pattern 'trace-a1' | %{ $_.Line } | ?{ $_.StartsWith('{') } | %{ $_ | ConvertFrom-Json | Select logger_name, trace_id, user, function, action }
```

---

### A-2. `GET /api/orders/error` — 異常系（業務例外）
```powershell
curl.exe -s -i http://localhost:8080/api/orders/error -H "traceparent: trace-a2"
```
**期待**: HTTP **400** + `{"error":"order not found: error"}`
- `SPRINGBOOT_ERROR_LOG` ×1（class_name=`GlobalExceptionHandler` / method_name=`handleBadRequest` / stack_trace, **stderr** 出力 / type=monitor）
- `SPRINGBOOT_SERVICE_JNL_LOG` のエラー側（stack_trace 付き, **stderr**）

**出力ログ例**
```json
{"timestamp":"2026-06-17 10:01:00.210","level":"INFO","logger_name":"SPRINGBOOT_SERVICE_JNL_LOG","thread":"http-nio-8080-exec-2","message":"service error","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"orders","action":"GET /api/orders/error","trace_id":"trace-a2","source_ip":"127.0.0.1","class_name":"com.example.cosmolog.demo.SampleService","method_name":"getOrder","latency":3,"stack_trace":"java.lang.IllegalArgumentException: order not found: error\n\tat ..."}
{"timestamp":"2026-06-17 10:01:00.215","level":"ERROR","logger_name":"SPRINGBOOT_ERROR_LOG","thread":"http-nio-8080-exec-2","message":"業務エラーが発生しました: order not found: error","id":"local-1","name":"cosmo-log","type":"monitor","subtype":"APL","function":"orders","action":"GET /api/orders/error","trace_id":"trace-a2","source_ip":"127.0.0.1","class_name":"com.example.cosmolog.demo.GlobalExceptionHandler","method_name":"handleBadRequest","stack_trace":"java.lang.IllegalArgumentException: order not found: error\n\tat ..."}
```
**【確認部品】** P01, P03, **P04(エラー分岐)**, **P08**, **P10**
```powershell
Select-String C:\tmp\app.log -Pattern 'SPRINGBOOT_ERROR_LOG' | %{ $_.Line } | ?{ $_.StartsWith('{') } | %{ $_ | ConvertFrom-Json | Select logger_name, type, class_name, method_name, message }
```

---

### A-3. `POST /api/orders` — マスキング確認（PII投入）
```powershell
curl.exe -s -X POST http://localhost:8080/api/orders -H "Content-Type: application/json" -H "Authorization: Bearer SECRET" -H "traceparent: trace-a3" -d '{"id":"X1","name":"山田","password":"p@ss","token":"abc123"}'
```
> PowerShell では JSON を **シングルクォート**で囲めば中の `"` はそのまま `curl.exe` に渡る（エスケープ不要）。
**期待**: アクセスジャーナルの `body` で `password`/`token` が `***`、`headers.authorization` が `***`。長文は `...(truncated)`。

**出力ログ例**（`password`/`token`/`authorization` がマスク済み）
```json
{"timestamp":"2026-06-17 10:02:00.300","level":"INFO","logger_name":"SPRINGBOOT_API_ACCESS_JNL_LOG","thread":"http-nio-8080-exec-3","message":"access journal (request)","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"orders","action":"POST /api/orders","trace_id":"trace-a3","source_ip":"127.0.0.1","url":"/api/orders","headers":{"authorization":"***","content-type":"application/json"},"body":"{\"id\":\"X1\",\"name\":\"山田\",\"password\":\"***\",\"token\":\"***\"}"}
```
**【確認部品】** P01, P02, P03, **P09**
```powershell
Select-String C:\tmp\app.log -Pattern 'trace-a3' | %{ $_.Line } | ?{ $_ -match 'API_ACCESS_JNL' } | %{ ($_ | ConvertFrom-Json) | Select body, headers }
```

---

### A-4. `GET /api/external?url=` — 外部HTTP
```powershell
curl.exe -s "http://localhost:8080/api/external?url=https://example.com" -H "traceparent: trace-a4"
```
**期待**: `SPRINGBOOT_HTTP_CLIENT_JNL_LOG` ×2（要求・応答 status/latency）。
✅ 下流へ `traceparent` 伝播（`trace_id=trace-a4` が応答ログにも一致）。

**出力ログ例**
```json
{"timestamp":"2026-06-17 10:04:00.500","level":"INFO","logger_name":"SPRINGBOOT_HTTP_CLIENT_JNL_LOG","thread":"http-nio-8080-exec-5","message":"http client (request)","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"external","action":"GET /api/external","trace_id":"trace-a4","source_ip":"127.0.0.1","url":"https://example.com","headers":{"traceparent":"trace-a4"}}
{"timestamp":"2026-06-17 10:04:00.640","level":"INFO","logger_name":"SPRINGBOOT_HTTP_CLIENT_JNL_LOG","thread":"http-nio-8080-exec-5","message":"http client (response)","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"external","action":"GET /api/external","trace_id":"trace-a4","source_ip":"127.0.0.1","url":"https://example.com","status":200,"body":"<!doctype html>...","latency":140}
```
**【確認部品】** P01, P02, P03, **P06**
```powershell
Select-String C:\tmp\app.log -Pattern 'HTTP_CLIENT_JNL' | %{ $_.Line } | ?{ $_.StartsWith('{') } | %{ $_ | ConvertFrom-Json | Select logger_name, url, status, trace_id }
```

---

### A-5. `GET /api/aws/kms` — KMSアクセス（要 LocalStack）
> 起動は **cosmo-API-aws**（環境変数 `AWS_ENDPOINT_URL=http://localhost:4566`）で行う。
```powershell
curl.exe -s http://localhost:8080/api/aws/kms
```
**期待**: `SPRINGBOOT_KMS_JNL_LOG`（subtype=AWSCALL / aws_request_id）。
**【確認部品】** P01, P02, P03, **P13**

### A-6. `GET /api/aws/dynamo` — DynamoDBアクセス（要 LocalStack）
```powershell
curl.exe -s http://localhost:8080/api/aws/dynamo
```
**期待**: `SPRINGBOOT_DYNAMODB_JNL_LOG`（subtype=AWSCALL / aws_request_id）。
**【確認部品】** P01, P02, P03, **P14**

**出力ログ例**（AWS系は `subtype=AWSCALL`）
```json
{"timestamp":"2026-06-17 10:05:10.800","level":"INFO","logger_name":"SPRINGBOOT_KMS_JNL_LOG","thread":"http-nio-8080-exec-7","message":"kms encrypt","id":"local-1","name":"cosmo-log","type":"app","subtype":"AWSCALL","function":"aws-kms","action":"GET /api/aws/kms","trace_id":"trace-kms","aws_request_id":"EFGH5678","latency":22}
{"timestamp":"2026-06-17 10:05:20.900","level":"INFO","logger_name":"SPRINGBOOT_DYNAMODB_JNL_LOG","thread":"http-nio-8080-exec-8","message":"dynamodb putItem","id":"local-1","name":"cosmo-log","type":"app","subtype":"AWSCALL","function":"aws-dynamo","action":"GET /api/aws/dynamo","trace_id":"trace-ddb","aws_request_id":"IJKL9012","latency":18}
```
```powershell
Select-String C:\tmp\app.log -Pattern 'KMS_JNL|DYNAMODB_JNL' | %{ $_.Line } | ?{ $_.StartsWith('{') } | %{ $_ | ConvertFrom-Json | Select logger_name, subtype, aws_request_id }
```

---

# 軸② 単発バッチモード

**起動**: IntelliJ で **cosmo-batch** を Run（起動＝ジョブ1回実行して終了, exit 0）。

### B-1. バッチ起動 → ジョブ1回実行
**期待**
- MDC: `action=BATCH_EXEC`(固定) / `trace_id`=ジョブ実行ID / `source_ip` 無し
- `SPRINGBOOT_API_LOG`（業務ログ）/ `SPRINGBOOT_SERVICE_JNL_LOG` が同一 `trace_id`
- 異常時は `SPRINGBOOT_ERROR_LOG` + exit 1

**出力ログ例**（`action=BATCH_EXEC` 固定 / `source_ip` 無し / `thread=main`）
```json
{"timestamp":"2026-06-17 11:00:00.100","level":"INFO","logger_name":"SPRINGBOOT_API_LOG","thread":"main","message":"バッチ処理を開始しました","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"売上集計バッチ","action":"BATCH_EXEC","user":"7f3c...","trace_id":"7f3c...","class_name":"com.example.cosmolog.demo.SampleBatchJob","method_name":"run"}
{"timestamp":"2026-06-17 11:00:00.120","level":"INFO","logger_name":"SPRINGBOOT_SERVICE_JNL_LOG","thread":"main","message":"service end","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"売上集計バッチ","action":"BATCH_EXEC","trace_id":"7f3c...","class_name":"...","method_name":"...","latency":12}
```
**【確認部品】** P01, **P03(バッチ=BatchLogScope)**, P04, P08（異常時 P10）
> 確認は IntelliJ コンソールで `Ctrl+F` → `BATCH_EXEC`。ファイル保存していれば:
```powershell
Select-String C:\tmp\app.log -Pattern 'BATCH_EXEC' | %{ $_.Line } | ?{ $_.StartsWith('{') } | %{ $_ | ConvertFrom-Json | Select logger_name, action, trace_id, source_ip }
```

---

# 軸③ 常駐バッチモード

**起動**:
1. Docker Desktop で `docker compose up -d`（PowerShell。`sample-queue`/DLQ 作成, 管理UI http://localhost:9325）
2. IntelliJ で **cosmo-resident** を Run（`@SqsListener` がポーリング開始＝起動したまま常駐）
3. 別 PowerShell から下記でメッセージ送信（AWS CLI 必要）

### C-1. 正常メッセージ受信
```powershell
aws sqs send-message --endpoint-url http://localhost:9324 `
  --queue-url http://localhost:9324/000000000000/sample-queue `
  --message-body '{"hello":"world"}' `
  --message-attributes 'traceparent={DataType=String,StringValue=trace-c1}'
```
**期待**
- `SPRINGBOOT_SQS_JNL_LOG`（受信証跡, `aws_sqs_message_id`）
- 業務ログ 開始/終了, MDC `action=CONSUME`(固定) / `trace_id=trace-c1`（属性優先）
✅ traceparent 属性なしで送ると `trace_id`=SQS MessageId になる。

**出力ログ例**（`action=CONSUME` 固定 / `SQS_JNL` は DEBUG）
```json
{"timestamp":"2026-06-17 12:00:00.100","level":"DEBUG","logger_name":"SPRINGBOOT_SQS_JNL_LOG","thread":"sqs-listener-1","message":"sqs journal (receive)","id":"local-1","name":"cosmo-log","type":"app","subtype":"AWSCALL","function":"配信計画メッセージ処理","action":"CONSUME","trace_id":"trace-c1","aws_sqs_message_id":"d290f1ee-6c54-4b01-90e6-d701748f0851"}
{"timestamp":"2026-06-17 12:00:00.110","level":"INFO","logger_name":"SPRINGBOOT_API_LOG","thread":"sqs-listener-1","message":"メッセージ処理開始 body={\"hello\":\"world\"}","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"配信計画メッセージ処理","action":"CONSUME","trace_id":"trace-c1","class_name":"...SampleMessageListener","method_name":"onMessage"}
{"timestamp":"2026-06-17 12:00:00.130","level":"INFO","logger_name":"SPRINGBOOT_API_LOG","thread":"sqs-listener-1","message":"メッセージ処理終了","id":"local-1","name":"cosmo-log","type":"app","subtype":"APL","function":"配信計画メッセージ処理","action":"CONSUME","trace_id":"trace-c1","class_name":"...SampleMessageListener","method_name":"onMessage"}
```
**【確認部品】** P01, **P03(常駐=MessageLogScope)**, P08, **P15**
```powershell
Select-String C:\tmp\app.log -Pattern 'trace-c1|SQS_JNL' | %{ $_.Line } | ?{ $_.StartsWith('{') } | %{ $_ | ConvertFrom-Json | Select logger_name, action, trace_id, aws_sqs_message_id }
```

### C-2. 失敗メッセージ → 再試行 → DLQ
```powershell
aws sqs send-message --endpoint-url http://localhost:9324 `
  --queue-url http://localhost:9324/000000000000/sample-queue `
  --message-body '{"task":"fail-me"}'
```
**期待**: `SPRINGBOOT_ERROR_LOG` が2回（maxReceiveCount=2）→ 以降 `sample-queue-dlq` に滞留（管理UI http://localhost:9325 で確認）。

**出力ログ例**（同一メッセージで2回 → DLQ。ERROR は stderr）
```json
{"timestamp":"2026-06-17 12:05:00.200","level":"ERROR","logger_name":"SPRINGBOOT_ERROR_LOG","thread":"sqs-listener-1","message":"メッセージ処理失敗 messageId=a1b2c3d4-...","id":"local-1","name":"cosmo-log","type":"monitor","subtype":"APL","function":"配信計画メッセージ処理","action":"CONSUME","trace_id":"a1b2c3d4-...","class_name":"...SampleMessageListener","method_name":"onMessage","stack_trace":"java.lang.RuntimeException: 意図的な処理失敗(検証用): {\"task\":\"fail-me\"}\n\tat ..."}
```
（10秒の可視性タイムアウト後に再配信され、2回目の同内容ERRORのあと `sample-queue-dlq` へ）
**【確認部品】** P01, P03, **P08(error)**, **P10**, P15
```powershell
Select-String C:\tmp\app.log -Pattern 'SPRINGBOOT_ERROR_LOG' | %{ $_.Line } | ?{ $_.StartsWith('{') } | %{ $_ | ConvertFrom-Json | Select logger_name, type, message }
```

---

# カバレッジ表（部品 × ケース）

`●`=主目的で確認 / `○`=副次的に確認。

| 部品＼ケース | A-1 | A-2 | A-3 | A-4 | A-5 | A-6 | B-1 | C-1 | C-2 |
|---|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
| P01 コンテナ情報 | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ |
| P02 HTTPログ制御 | ● | ○ | ○ | ○ | ○ | ○ |   |   |   |
| P03 MDCスコープ | ○ | ○ | ○ | ○ | ○ | ○ | ● | ● | ○ |
| P04 サービスジャーナル | ● | ● |   |   |   |   | ● |   |   |
| P05 SQLジャーナル | — | — | — | — | — | — | — | — | — |
| P06 外部HTTPジャーナル |   |   |   | ● |   |   |   |   |   |
| P08 業務ログ | ● | ● |   |   |   |   | ● | ● | ● |
| P09 マスキング |   |   | ● |   |   |   |   |   |   |
| P10 エラーハンドリング |   | ● |   |   |   |   | △ |   | ● |
| P13 KMSアクセス |   |   |   |   | ● |   |   |   |   |
| P14 DynamoDBアクセス |   |   |   |   |   | ● |   |   |   |
| P15 SQSアクセス/受信 |   |   |   |   |   |   |   | ● | ○ |

- `—` P05 は参照実装のため実機ケース対象外（ユニットテスト/実DBで確認）。
- `△` B-1 のエラーハンドリングはジョブ失敗時のみ（fail を仕込んだ場合）。
- **廃止**: P07(キャッシュ) / P11(非同期MDC) / P12(S3部品)。STORAGE_JNL は logback 定義のみ存置で実行ケース無し。
- **全部品カバー確認**: 軸①(A-1〜A-6) + 軸②(B-1) + 軸③(C-1,C-2) を実施すれば P05 以外の現役部品（P01〜P04, P06, P08〜P10, P13〜P15）を確認できる。

---

## PowerShell 補足（よくある詰まり）

| 事象 | 対処 |
|---|---|
| `curl` が変な動作 | PowerShell の `curl` は `Invoke-WebRequest` の別名。**`curl.exe`** を使う |
| 改行で続けたい | 行末は **バッククォート `` ` ``**（bash の `\` は不可） |
| JSON本文の `"` が壊れる | JSON全体を**シングルクォート**で囲む（中の `"` はそのまま渡る） |
| `id`/`name` が反映されない | `CONTAINER_ID`/`CONTAINER_NAME` を **IntelliJ Run Config の Environment variables** に設定（シェルの環境変数は届かない） |
| `aws` が無い | AWS CLI v2 をインストール（軸③のみ必要） |
| `%{ }` `?{ }` の意味 | `%`=`ForEach-Object`, `?`=`Where-Object` の別名 |
| 日本語が文字化け | コンソールを UTF-8 に: `chcp 65001`、または IntelliJ の File Encoding を UTF-8 |
