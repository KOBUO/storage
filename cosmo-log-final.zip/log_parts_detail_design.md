# ログ部品詳細設計書（非AWS共通部品）

各部品の内部仕様。AWS系（S3/SQS/KMS/DynamoDB）は別途設計書を参照。

---

## 1. コンテナ情報付与部品

### 部品概要

**目的**
**環境変数**から取得したコンテナ ID / 名前を、全ログの `id` / `name` フィールドに付与する。

**概要**
- logback の `ContainerInfoJsonProvider` が、環境変数 `CONTAINER_ID` / `CONTAINER_NAME` を読み取り、全ログに `id` / `name` を追記する。
- 値はクラス初期化時（起動時）に1回だけ解決して static フィールドで保持する。
- 環境変数が未設定の場合は、`id` = ホスト名、`name` = `cosmo-log` にフォールバックする。

**特記事項**
- 旧版（ECS メタデータ API を HTTP 取得する `ContainerInfoProvider` / キャッシュ用 `ContainerInfo`）は**廃止**し、環境変数を直接読む方式に簡素化した。
- ECS 等の本番では、タスク定義で `CONTAINER_ID` / `CONTAINER_NAME` を環境変数として渡すこと（Spring の起動より前に解決される）。
- 環境変数はプロセスに渡す必要がある。IntelliJ から起動する場合は Run Configuration の「Environment variables」に設定する（シェルで `set` した値は IntelliJ 起動プロセスには渡らない）。

### 処理フロー

1. クラス初期化時に環境変数 `CONTAINER_ID` を読む。空なら `InetAddress.getLocalHost().getHostName()`（取得失敗時は `UNKNOWN`）。
2. クラス初期化時に環境変数 `CONTAINER_NAME` を読む。空なら `cosmo-log`。
3. 解決した値を static フィールドに保持する。
4. logback がログ1件ごとに `writeTo()` を呼び、`id` / `name` を JSON に書き込む。

### クラス一覧

| クラス名 | 役割 |
|---|---|
| `ContainerInfoJsonProvider` | logback の JsonProvider。環境変数由来の `id` / `name` を全ログに追記する |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `ContainerInfoJsonProvider` | `writeTo(generator, event)` | logback が呼び出す。`id` / `name` を JSON に書き込む |
| `ContainerInfoJsonProvider` | `resolveId()` / `resolveName()`（内部 static） | 環境変数 → フォールバックで値を解決する |

### 利用ガイド

**設定方法**

以下の環境変数を設定する（任意。未設定ならフォールバック）。

```
CONTAINER_ID=<コンテナID>
CONTAINER_NAME=<コンテナ名>
```

未設定時は `id` = ホスト名、`name` = `cosmo-log`。

---

## 2. HTTPログ制御部品

### 部品概要

**目的**
HTTPリクエスト単位でログスコープを開始し、アクセスログ・アクセスジャーナルログ（要求/応答）を出力する。

**概要**
- `OncePerRequestFilter` を継承し、`@Order(HIGHEST_PRECEDENCE)` で最外周に配置する。
- リクエスト・レスポンスを `ContentCachingRequestWrapper` / `ContentCachingResponseWrapper` でラップしてボディを再読可能にする。
- `ExecutionScopeMdc.open()` で MDC（function / action / user / trace_id / source_ip）を設定し、スコープ内の全ログに自動付与する。
- スコープ終了（`close()`）で MDC を必ずクリアする。

**特記事項**
- `traceparent` ヘッダが無い場合は UUID を生成して `trace_id` に使用する。
- `ContentCachingResponseWrapper` は最後に `copyBodyToResponse()` しないとレスポンスが返らない。
- `function` は `FunctionActionResolver` が URL パスから導出する（実運用ではルーティング定義と照合すること）。

### 処理フロー

1. リクエスト・レスポンスをラップする。
2. `traceparent` ヘッダから `trace_id` を取得する（無ければ UUID 生成）。
3. `FunctionActionResolver.resolve()` で `function` / `action` を決定する。
4. URL をマスクする（クエリパラメータの PII を伏せる）。
5. `ExecutionScopeMdc.open()` でスコープを開始する（MDC 設定）。
6. 後続フィルタ・コントローラを実行する（`chain.doFilter()`）。
7. レスポンス確定後、アクセスログ（1件）・アクセスジャーナル要求・アクセスジャーナル応答を出力する。
8. `copyBodyToResponse()` でレスポンスを返す。
9. スコープ終了（MDC クリア）。

### クラス一覧

| クラス名 | 役割 |
|---|---|
| `HttpLoggingFilter` | アクセスログ・ジャーナルログの出力とスコープ管理 |
| `FunctionActionResolver` | HTTPリクエストから `function` / `action` を導出する |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `HttpLoggingFilter` | `doFilterInternal(req, res, chain)` | フィルタ本体。ラップ・スコープ・ログ出力・レスポンスコピーを行う |
| `FunctionActionResolver` | `resolve(request)` | `FunctionAction(function, action)` を返す |

### 出力ログ

| ログ種別 | logger | タイミング | 出力項目 |
|---|---|---|---|
| アクセスログ | `SPRINGBOOT_API_ACCESS_LOG` | レスポンス返却直前（1リクエスト1件） | url / status / latency |
| アクセスジャーナル（要求） | `SPRINGBOOT_API_ACCESS_JNL_LOG` | レスポンス返却直前 | url / headers / body |
| アクセスジャーナル（応答） | `SPRINGBOOT_API_ACCESS_JNL_LOG` | レスポンス返却直前 | url / status / headers / body / latency |

---

## 3. 実行単位スコープ MDC 部品

### 部品概要

**目的**
オンライン/バッチ/常駐バッチの処理単位で MDC（function / user / action / trace_id / source_ip）を設定・クリアし、スコープ内の全ログに共通項目を自動付与する。

**概要**
- `ExecutionScopeMdc` は `AutoCloseable` を実装し、try-with-resources で確実にクリアする。
- `BatchLogScope` / `MessageLogScope` は `ExecutionScopeMdc` を呼び出す薄いファサード。設定値（action 固定値・source_ip の有無）のみ異なる。
- null/空白の値は MDC に設定しない。

**特記事項**
- バッチでは `trace_id` = ジョブ実行 ID、`user` = ジョブ実行 ID（TODO: 要確認）、`source_ip` = 未設定。
- 常駐バッチでは `trace_id` = SQS MessageId（メッセージ属性 `traceparent` があれば優先）、`user` / `source_ip` = 未設定。

### クラス一覧

| クラス名 | 実行区分 | 役割 |
|---|---|---|
| `ExecutionScopeMdc` | 共通 | MDC 設定・クリアの共通実装 |
| `BatchLogScope` | バッチ | `ExecutionScopeMdc.open()` のラッパー。`action=BATCH_EXEC` |
| `MessageLogScope` | 常駐バッチ | `ExecutionScopeMdc.open()` のラッパー。`action=CONSUME` |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `ExecutionScopeMdc` | `open(function, action, user, traceId, sourceIp)` | MDC を設定してインスタンスを返す（static ファクトリ） |
| `ExecutionScopeMdc` | `close()` | MDC の全スコープキーをクリアする |
| `BatchLogScope` | `open(jobName, jobExecutionId)` | バッチ向け。`action=BATCH_EXEC` で `ExecutionScopeMdc.open()` を呼ぶ |
| `MessageLogScope` | `open(handlerName, messageId)` | 常駐バッチ向け。`action=CONSUME` で `ExecutionScopeMdc.open()` を呼ぶ |

### MDC 設定値

| MDC キー | オンライン | バッチ | 常駐バッチ |
|---|---|---|---|
| `function` | `FunctionActionResolver` が導出した API 識別子 | JOB 名 | メッセージ処理機能名 |
| `action` | `メソッド + URI` | `BATCH_EXEC`（固定） | `CONSUME`（固定） |
| `user` | リクエストヘッダ `X-User-Id` | ジョブ実行 ID（TODO） | 未設定 |
| `trace_id` | ヘッダ `traceparent`（無ければ UUID 生成） | ジョブ実行 ID | SQS MessageId（属性 `traceparent` 優先） |
| `source_ip` | `X-Forwarded-For` 先頭 or `getRemoteAddr()` | 未設定 | 未設定 |

### 利用ガイド

**使い方（バッチ）**
```java
try (var scope = BatchLogScope.open("売上集計バッチ", jobExecutionId)) {
    // ジョブ本体
}
```

**使い方（常駐バッチ）**
```java
try (var scope = MessageLogScope.open("配信計画メッセージ処理", message.messageId())) {
    // 1メッセージの処理
}
```

---

## 4. サービスジャーナルログ出力部品

### 部品概要

**目的**
`@Service` のメソッド実行前後に自動でサービスジャーナルログ（開始/終了）を出力する。

**概要**
- `@Aspect` + `@Around` で `@Service` アノテーションが付いたすべてのクラスのメソッドに適用する。
- 開始時に class_name / method_name / args（マスク済み）を出力する。
- 終了時に result（マスク済み）/ latency を出力する。
- 例外発生時は result の代わりに stack_trace を出力し、例外を再スローする。

**特記事項**
- args / result は `LogMaskingService` でマスク・最大長制限を適用する。
- class_name は FQCN（完全修飾クラス名）で出力する。

### 処理フロー

1. `@Service` メソッド呼び出しをインターセプトする。
2. サービスジャーナルログ（開始）: class_name / method_name / args を出力する。
3. メソッドを実行する（`pjp.proceed()`）。
4. 正常終了 → サービスジャーナルログ（終了）: result / latency を出力する。
5. 例外 → サービスジャーナルログ（エラー）: latency / stack_trace を出力して例外を再スローする。

### クラス一覧

| クラス名 | 役割 |
|---|---|
| `ServiceJournalAspect` | `@Service` メソッドの前後でサービスジャーナルログを出力する AOP |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `ServiceJournalAspect` | `aroundService(pjp)` | `@Around` 本体。開始/終了/エラーのジャーナルログを出力する |

### 出力ログ

| ログ種別 | logger | タイミング | 出力項目 |
|---|---|---|---|
| サービスジャーナル（開始） | `SPRINGBOOT_SERVICE_JNL_LOG` | メソッド呼び出し直前 | class_name / method_name / args |
| サービスジャーナル（終了） | `SPRINGBOOT_SERVICE_JNL_LOG` | メソッド正常終了直後 | class_name / method_name / result / latency |
| サービスジャーナル（エラー） | `SPRINGBOOT_SERVICE_JNL_LOG` | 例外発生時 | class_name / method_name / latency / stack_trace |

---

## 5. SQLジャーナルログ出力部品

### 部品概要

**目的**
MyBatis の SQL 実行（update / query）前後に DBCALL ジャーナルログを出力する。

**概要**
- MyBatis の `Interceptor` インターフェースを実装する。
- `Executor.update()` / `Executor.query()` をインターセプトする。
- 本サンプルは実 DB を持たないため Spring Bean 登録しない（参照実装）。実プロジェクトでは MyBatis 設定に登録する。

**特記事項**
- マトリクス準拠：出力項目は `message`（ステートメント ID）+ `latency` のみ。class_name / method_name / args は出力しない。
- SQL 詳細を message に含める場合は 4KB 制約と PII に注意する。
- バッチ/常駐バッチでは IN/OUT 件数・進捗・エラー時のみ出力する運用とする（全 DB アクセスは出力しない）。

### 処理フロー

1. `Executor.update()` / `Executor.query()` 呼び出しをインターセプトする。
2. `MappedStatement.getId()`（ステートメント ID）を取得する。
3. SQL を実行する（`invocation.proceed()`）。
4. 正常終了 → latency と共に INFO でジャーナルログを出力する。
5. 例外 → latency と stack_trace と共に ERROR で出力して例外を再スローする。

### クラス一覧

| クラス名 | 役割 |
|---|---|
| `SqlJournalInterceptor` | MyBatis Interceptor。SQL 実行前後でジャーナルログを出力する |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `SqlJournalInterceptor` | `intercept(invocation)` | Interceptor 本体。latency を計測してログを出力する |

### 出力ログ

| ログ種別 | logger | タイミング | 出力項目 |
|---|---|---|---|
| SQL ジャーナル | `SPRINGBOOT_SQL_JNL_LOG` | SQL 応答時（正常/エラー） | message（ステートメント ID）/ latency |

### 利用ガイド

**設定方法（実プロジェクト）**
```java
@Bean
ConfigurationCustomizer mybatisCustomizer() {
    return config -> config.addInterceptor(new SqlJournalInterceptor());
}
```

---

## 6. 外部HTTPジャーナルログ出力部品

### 部品概要

**目的**
RestTemplate による外部 API 呼び出しの前後に外部アクセスジャーナルログ（要求/応答）を出力する。

**概要**
- `ClientHttpRequestInterceptor` を実装し `RestTemplate` のインターセプターとして登録する（`RestClientConfig` で設定）。
- MDC の `trace_id` を下流サービスへ `traceparent` ヘッダで伝播する（分散トレーシング）。
- レスポンスボディを読み捨てないよう `RestTemplate` は `BufferingClientHttpRequestFactory` で構成する。

**特記事項**
- `traceparent` ヘッダが既に設定されている場合は追加しない（伝播元の値を優先）。
- レスポンスボディは `StreamUtils.copyToString()` で読み取るため `BufferingClientHttpRequestFactory` が必須。

### 処理フロー

1. MDC から `trace_id` を取得し `traceparent` ヘッダに付与する（既存ヘッダがない場合のみ）。
2. 外部アクセスジャーナル（要求）: url / headers / body（マスク済み）を出力する。
3. 外部 HTTP リクエストを実行する（`execution.execute()`）。
4. レスポンスボディを文字列に変換する。
5. 外部アクセスジャーナル（応答）: url / status / headers / body（マスク済み）/ latency を出力する。

### クラス一覧

| クラス名 | 役割 |
|---|---|
| `HttpClientJournalInterceptor` | RestTemplate インターセプター。外部アクセスジャーナルログを出力する |
| `RestClientConfig` | `RestTemplate` Bean 定義。`BufferingClientHttpRequestFactory` と `HttpClientJournalInterceptor` を設定する |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `HttpClientJournalInterceptor` | `intercept(request, body, execution)` | インターセプター本体。traceparent 付与・ログ出力 |
| `RestClientConfig` | `restTemplate(journalInterceptor)` | `@Bean`。BufferingFactory + インターセプター設定 |

### 出力ログ

| ログ種別 | logger | タイミング | 出力項目 |
|---|---|---|---|
| 外部アクセスジャーナル（要求） | `SPRINGBOOT_HTTP_CLIENT_JNL_LOG` | リクエスト送信直前 | url / headers / body |
| 外部アクセスジャーナル（応答） | `SPRINGBOOT_HTTP_CLIENT_JNL_LOG` | レスポンス受信直後 | url / status / headers / body / latency |

---

## 7. キャッシュジャーナルログ出力部品（廃止）

> **廃止**: キャッシュをログ出力しない方針に変更したため、本部品は削除した。
> 削除対象: `CacheJournalAspect` / デモ用 `PricingService`（`@Cacheable`） / `CosmoLogApplication` の `@EnableCaching` / `LoggerNames.CACHE_JNL`（`SPRINGBOOT_CACHE_JNL_LOG`）。

---

## 8. 業務ログ出力部品

### 部品概要

**目的**
業務コードが明示的に呼び出すログ出力部品。業務イベントログ（INFO）と業務エラーログ（ERROR）を固定 logger 名で出力する。

**概要**
- `info()` は `SPRINGBOOT_API_LOG`、`error()` は `SPRINGBOOT_ERROR_LOG` へ出力する。
- 固定 logger 名のため発生元クラスが分からなくなる問題を `StackWalker` で解決する。呼び出し元の class_name / method_name を自動取得して付与する。
- 業務コードは `info(message)` / `error(message, t)` を呼ぶだけでよい。

**特記事項**
- `StackWalker` の skip 数: frame0=`base()`、frame1=`info()/error()`、frame2=業務コード（呼び出し元）。
- システムログ（root ロガーの出力）は本部品ではなく、明示出力しないフレームワーク等のログ。
- `message` は `LogMaskingService.maskMessage()` でマスク・最大長制限する。

### 処理フロー

1. `StackWalker` で呼び出し元（frame2）の class_name / method_name を取得する。
2. `StructuredLog` に class_name / method_name を設定する。
3. `maskMessage()` で message をマスクする。
4. `info()` → `SPRINGBOOT_API_LOG` に INFO で出力する。
5. `error()` → `SPRINGBOOT_ERROR_LOG` に ERROR で出力する（stack_trace は logback が Throwable から出力）。

### クラス一覧

| クラス名 | 役割 |
|---|---|
| `ApplicationLogger` | 業務ログ・業務エラーログを固定 logger 名で出力する Spring Bean |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `ApplicationLogger` | `info(message)` | 業務ログ（`SPRINGBOOT_API_LOG`）を INFO で出力する |
| `ApplicationLogger` | `error(message, t)` | 業務エラーログ（`SPRINGBOOT_ERROR_LOG`）を ERROR で出力する |
| `ApplicationLogger` | `base()` | `StackWalker` で呼び出し元の class_name / method_name を取得する（内部用） |

### 出力ログ

| ログ種別 | logger | タイミング | 出力項目 |
|---|---|---|---|
| 業務ログ | `SPRINGBOOT_API_LOG` | `info()` 呼び出し時 | class_name / method_name / message |
| 業務エラーログ | `SPRINGBOOT_ERROR_LOG` | `error()` 呼び出し時 | class_name / method_name / message / stack_trace |

### 利用ガイド

**使い方**
```java
@Autowired
ApplicationLogger appLogger;

// 業務ログ
appLogger.info("注文が確定しました: orderId=" + orderId);

// 業務エラーログ
appLogger.error("注文処理に失敗しました", e);
```

---

## 9. マスキング部品

### 部品概要

**目的**
ログ出力前に個人情報・機密情報をマスク（`***` で置換）し、最大長で切り詰める。

**概要**
- 各ジャーナルログ出力部品から呼び出され、headers / body / args / result / message を処理する。
- マスク対象は `LoggingProperties` で設定する。
- JSON の `"key":"value"` 形式と `key=value` 形式の両方に対応する。

**特記事項**
- ヘッダーは名前の大文字小文字を無視して比較する（小文字に統一して照合）。
- URL のクエリパラメータ（`?key=value`）もマスク対象。
- 切り詰め時は末尾に `...(truncated)` を付与する。

### 処理フロー（maskBody の例）

1. 対象キー一覧（`maskBodyKeys`）の各キーについて、`"key":"value"` および `key=value` パターンを正規表現で `***` に置換する。
2. 最大長（`bodyMaxLength`）を超えていれば先頭 N 文字に切り詰め `...(truncated)` を付与する。

### クラス一覧

| クラス名 | 役割 |
|---|---|
| `LogMaskingService` | ログ項目のマスク・切り詰め処理を行う Spring Bean |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `LogMaskingService` | `maskHeaders(headers)` | マスク対象ヘッダーを `***` に置換する |
| `LogMaskingService` | `maskBody(body)` | JSON ボディのマスク対象キーを置換し最大長で切り詰める |
| `LogMaskingService` | `maskUrl(url)` | URL クエリパラメータのマスク対象キーを置換する |
| `LogMaskingService` | `maskArgs(args)` | メソッド引数配列の各要素をマスクする |
| `LogMaskingService` | `maskResult(result)` | 戻り値をマスク・切り詰める |
| `LogMaskingService` | `maskMessage(message)` | メッセージを最大長で切り詰める（マスクは適用しない） |
| `LogMaskingService` | `truncate(s, max)` | 最大長超過時に切り詰めて `...(truncated)` を付与する |

### 定義（application.yml 設定項目）

| キー | デフォルト値 | 概要 |
|---|---|---|
| `logging.custom.body-max-length` | `2048` | body / args / result の最大出力長（文字数） |
| `logging.custom.message-max-length` | `4096` | message の最大出力長（文字数） |
| `logging.custom.mask-header-names` | `[authorization, cookie]` | マスク対象ヘッダー名（小文字）のリスト |
| `logging.custom.mask-body-keys` | `[password, secret, token]` | マスク対象ボディ/引数キー名のリスト |

### 利用ガイド

**設定例（application.yml）**
```yaml
logging:
  custom:
    body-max-length: 2048
    message-max-length: 4096
    mask-header-names:
      - authorization
      - cookie
    mask-body-keys:
      - password
      - secret
      - token
      - credit-card-number
```

---

## 10. エラーハンドリング部品

### 部品概要

**目的**
Controller で捕捉されなかった例外を一元的にハンドリングし、業務エラーログを出力してクライアントにエラーレスポンスを返す。

**概要**
- `@RestControllerAdvice` で全 Controller に横断適用する。
- `ApplicationLogger.error()` を呼び出して `SPRINGBOOT_ERROR_LOG` に出力する（stack_trace は logback が自動付与）。
- 現状は `IllegalArgumentException`（業務エラー）のみ明示処理。それ以外の未捕捉例外は root ロガーが ERROR で出力する（type=monitor / subtype=SYSTEM）。

**特記事項**
- 例外種別ごとのメッセージ定義・レベル分けを行う場合は、例外クラス群と `@ExceptionHandler` を追加して拡張する。
- `ApplicationLogger.error()` は `StackWalker` で呼び出し元クラスを取得するため、class_name / method_name には `GlobalExceptionHandler` / `handleBadRequest` が記録される。

### 処理フロー

1. Controller から `IllegalArgumentException` がスローされる。
2. `handleBadRequest()` がインターセプトする。
3. `appLogger.error("業務エラーが発生しました: " + message, e)` で業務エラーログを出力する。
4. HTTP 400 Bad Request でエラーレスポンス `{"error": "<message>"}` を返す。

### クラス一覧

| クラス名 | 役割 |
|---|---|
| `GlobalExceptionHandler` | `@RestControllerAdvice`。例外を業務エラーログへ出力しエラーレスポンスを返す |

### メソッド一覧

| クラス名 | メソッド名 | 概要 |
|---|---|---|
| `GlobalExceptionHandler` | `handleBadRequest(e)` | `IllegalArgumentException` をハンドリングし ERROR ログ出力 + 400 レスポンスを返す |

### 出力ログ

| ログ種別 | logger | タイミング | 出力項目 |
|---|---|---|---|
| 業務エラーログ | `SPRINGBOOT_ERROR_LOG` | 例外ハンドリング時 | class_name / method_name / message / stack_trace |

---

## 11. 非同期 MDC 伝播部品（廃止）

> **廃止**: 不要となったため本部品は削除した。
> 削除対象: `MdcTaskDecorator` / `AsyncConfig`（`@EnableAsync` / `ThreadPoolTaskExecutor`）。
> ※ 将来 `@Async` やスレッドプールを使う場合は、子スレッドへ MDC（trace_id 等）が引き継がれない点に注意し、必要に応じて `TaskDecorator` を再導入すること。

---

## 付録. logback appender 構成（ログ種類別）

### 概要

出力先は stdout / stderr（CloudWatch Logs が収集）。**ERROR は `System.err`、それ以外は `System.out`**。
appender は **ログの種類ごとに `src/main/resources/logback/appender-*.xml`** に定義し、`logback-spring.xml` が include して各 logger に割り当てる。

- 旧構成（`appender-stdout.xml` / `appender-stderr.xml` の2本で出力先により分割）は**廃止**。
- 各定義ファイル内で出力先（`System.out` / `System.err`）を決める。
- INFO と ERROR の**両方を出す種類**（サービスジャーナル / SQLジャーナル / システムログ(root)）は、同一ファイル内に out 用・err 用の `ConsoleAppender` を2つ定義し（`*_OUT` / `*_ERR`）、`LevelFilter` で振り分ける。logger 側はその2つを参照する。

### 定義ファイルと appender

| 種類別ファイル | appender 名 | 出力先 | 対応 logger |
|---|---|---|---|
| `appender-access.xml` | `ACCESS` | out | `SPRINGBOOT_API_ACCESS_LOG` |
| `appender-access-jnl.xml` | `ACCESS_JNL` | out | `SPRINGBOOT_API_ACCESS_JNL_LOG` |
| `appender-service-jnl.xml` | `SERVICE_JNL_OUT` / `SERVICE_JNL_ERR` | out / err | `SPRINGBOOT_SERVICE_JNL_LOG` |
| `appender-sql-jnl.xml` | `SQL_JNL_OUT` / `SQL_JNL_ERR` | out / err | `SPRINGBOOT_SQL_JNL_LOG` |
| `appender-storage-jnl.xml` | `STORAGE_JNL` | out | `SPRINGBOOT_STORAGE_JNL_LOG`（部品は廃止。定義のみ存置） |
| `appender-http-client-jnl.xml` | `HTTP_CLIENT_JNL` | out | `SPRINGBOOT_HTTP_CLIENT_JNL_LOG` |
| `appender-sqs-jnl.xml` | `SQS_JNL` | out | `SPRINGBOOT_SQS_JNL_LOG` |
| `appender-kms-jnl.xml` | `KMS_JNL` | out | `SPRINGBOOT_KMS_JNL_LOG` |
| `appender-dynamodb-jnl.xml` | `DYNAMODB_JNL` | out | `SPRINGBOOT_DYNAMODB_JNL_LOG` |
| `appender-app.xml` | `APP` | out | `SPRINGBOOT_API_LOG` |
| `appender-error.xml` | `ERROR` | err | `SPRINGBOOT_ERROR_LOG` |
| `appender-system.xml` | `SYSTEM_OUT` / `SYSTEM_ERR` | out / err | root（システムログ） |

### 種類を追加するときの手順

1. `logback/appender-<種類>.xml` を新規作成し、`ConsoleAppender`（必要なら out/err 2本）と encoder を定義する。
2. `logback-spring.xml` で `<include>` し、対象 logger に `<appender-ref>` を割り当てる。
3. 業務／ジャーナル側はその固定 logger 名で出力する。
