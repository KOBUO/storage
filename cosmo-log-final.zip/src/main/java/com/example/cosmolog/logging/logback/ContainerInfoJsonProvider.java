package com.example.cosmolog.logging.logback;

import java.io.IOException;
import java.net.InetAddress;

import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * 全ログに id / name（アプリケーションスコープ）を付与する logback provider。
 * 値は環境変数から取得する（ECSタスク定義等で設定する想定）。
 *   id   = 環境変数 CONTAINER_ID  （未設定ならホスト名）
 *   name = 環境変数 CONTAINER_NAME（未設定なら "cosmo-log"）
 * 起動時に1回だけ解決して保持する。logback-spring.xml の {@code <providers>} に登録する。
 */
public class ContainerInfoJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    private static final String ID = resolveId();
    private static final String NAME = resolveName();

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        generator.writeStringField("id", ID);
        generator.writeStringField("name", NAME);
    }

    private static String resolveId() {
        String v = System.getenv("CONTAINER_ID");
        if (v != null && !v.isBlank()) {
            return v;
        }
        try {
            return InetAddress.getLocalHost().getHostName();
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }

    private static String resolveName() {
        String v = System.getenv("CONTAINER_NAME");
        return (v != null && !v.isBlank()) ? v : "cosmo-log";
    }
}
