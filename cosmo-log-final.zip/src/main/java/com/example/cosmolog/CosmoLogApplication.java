package com.example.cosmolog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CosmoLogApplication {

    public static void main(String[] args) {
        SpringApplication.run(CosmoLogApplication.class, args);
    }
}
