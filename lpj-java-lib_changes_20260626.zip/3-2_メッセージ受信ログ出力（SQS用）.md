## メッセージ受信ログ出力（SQS用）

### 部品概要

#### 目的

`@SqsListener` がメッセージを受信する前後に処理を挟み、受信ジャーナルログの出力と MDC スコープの設定・クリアを自動で行う。

#### 前提

  - `io.awspring.cloud:spring-cloud-aws-starter-sqs` の `@SqsListener`（`io.awspring.cloud.sqs.annotation.SqsListener`）を使用する常駐アプリで動作する。
  - デフォルト無効。  
    `cosmo-app.logging.sqs.enabled=true` を明示したときのみ有効。（`matchIfMissing=false`）
  - 1メッセージを1スレッドで処理する前提。（受信 `intercept` →リスナー→完了 `afterProcessing` が同じスレッド）  
    MDC はスレッドごとの領域なので、途中でスレッドが変わると値が引き継がれない。

#### 特記事項

  - 受信時の AWS メタ情報（`aws_request_id` など）は、SDK の受信処理を Spring が内部で保持しているため取得できず `"null"` になる。  
    受信時に取得できるのは `aws_sqs_message_id`（＝SQS が採番した MessageId。  
    `org.springframework.messaging.MessageHeaders.getId()`）のみ。
  - 出力先は固定ロガー名 `"SPRINGBOOT_SQS_JNL_LOG"`、`type=app`・`subtype=AWSCALL`。（appender で固定付与）  
    値は全て文字列、値なしは `"null"`。
  - marker は `StructuredLog`（`jp.co.lawson.common.app.lib.logging.StructuredLog`）で組み立てる。  
    値なしを `"null"` で出力する項目（`latency`／`aws_request_id`／`aws_request_timestamp`／`aws_response_time`）は `putNullable` を使用する。
  - `function` には、DI した `SqsJobArgumentProvider`（`jp.co.lawson.common.app.lib.logging.sqs.SqsJobArgumentProvider`）の `getJobExecutionId()`（ジョブ実行ID）を設定する。

### 処理フロー

本部品は以下のような処理フローで動作する。

#### SqsMessageListenerContainerFactory の Bean 化

`@SqsListener` は、Spring Cloud AWS が自動構成する `defaultSqsListenerContainerFactory`（`io.awspring.cloud.sqs.config.SqsMessageListenerContainerFactory`）でリスナーコンテナを生成する。  
受信前後のフックは、このファクトリに `messageInterceptor` を設定すれば配下の全リスナーへ一括適用できるが、自動構成のデフォルトファクトリには interceptor が設定されていない。  
各 `@SqsListener` に個別の実装を追加せずに `SqsReceiveJournalInterceptor`（`jp.co.lawson.common.app.lib.logging.sqs.SqsReceiveJournalInterceptor`）を横断適用するため、interceptor を追加したファクトリを**同名の Bean（`defaultSqsListenerContainerFactory`）で定義し、デフォルトを置き換える**必要がある。

1. `SqsAsyncClient`（`software.amazon.awssdk.services.sqs.SqsAsyncClient`、Spring Cloud AWS の自動構成）と `SqsReceiveJournalInterceptor`（`@Component`）を DI で取得する。
2. `SqsMessageListenerContainerFactory.builder()` に以下を設定する。
    1. `sqsAsyncClient(SqsAsyncClient)` で SQS クライアントを設定する。
    2. `messageInterceptor(SqsReceiveJournalInterceptor)` で受信ジャーナルの interceptor を設定する。
3. `SqsMessageListenerContainerFactory.build()` で `SqsMessageListenerContainerFactory` を生成し、Bean に登録する。

> 注：Bean 名 `defaultSqsListenerContainerFactory`（`@SqsListener` がデフォルトで使用するファクトリ名）で登録してデフォルトファクトリを置き換えることで、各リスナーの受信前後で `SqsReceiveJournalInterceptor` がフックされる。  
> 注：`@ConditionalOnMissingBean` を付与しているため、利用者が独自に `SqsMessageListenerContainerFactory` を定義している場合は本 Bean は生成されない。

#### メッセージ受信前後のフック（SqsReceiveJournalInterceptor）

1. SQSメッセージ受信時（`intercept(message)`）に、以下の処理を実施する。
    1. 引数（`org.springframework.messaging.Message`）のヘッダからメッセージID（`MessageHeaders.getId()`）を取得し、DI した `SqsJobArgumentProvider` から `getJobExecutionId()` を取得する。
    2. 以下の表の内容を `MDC`（`org.slf4j.MDC`）に追加する。（null／空白は設定しない）

        | キー         | 設定値                                       |
        | ------------ | -------------------------------------------- |
        | `"function"` | `SqsJobArgumentProvider.getJobExecutionId()` |
        | `"action"`   | `"null"`                                     |
        | `"trace"`    | メッセージID                                 |
        | `"user"`     | `"null"`                                     |

    3. 以下の表の内容で、 `LogstashMarker`（`net.logstash.logback.marker.LogstashMarker`）を生成する。

        | キー                      | 設定値       |
        | ------------------------- | ------------ |
        | `"latency"`               | `"null"`     |
        | `"aws_request_id"`        | `"null"`     |
        | `"aws_sqs_message_id"`    | メッセージID |
        | `"aws_request_timestamp"` | `"null"`     |
        | `"aws_response_time"`     | `"null"`     |

    4. メッセージジャーナル用（`"SPRINGBOOT_SQS_JNL_LOG"`）の `Logger`（`org.slf4j.Logger`）から、以下の内容でログを出力する。

        | 引数     | 設定値                       |
        | -------- | ---------------------------- |
        | `marker` | 生成した `LogstashMarker`    |
        | `msg`    | `"メッセージ受信ジャーナル"` |

    5. メッセージをそのまま返却する。
2. 業務リスナーが実行される。
3. 処理完了時（`afterProcessing(message, throwable)`）に、`MDC.clear()` でスレッドの MDC をクリアする。

### クラス一覧／メソッド一覧

| クラス                         | メソッド                                                                                     | 概要                                                                  |
| ------------------------------ | -------------------------------------------------------------------------------------------- | --------------------------------------------------------------------- |
| `SqsReceiveJournalInterceptor` | `intercept(org.springframework.messaging.Message)`                                           | MDC put ＋ 受信ジャーナル出力                                         |
| 〃                             | `afterProcessing(Message, Throwable)`                                                        | `MDC.clear()` のみ（失敗時のエラーログは出力しない・例外は伝播）      |
| `ResidentSqsConfig`            | `defaultSqsListenerContainerFactory(SqsAsyncClient, SqsReceiveJournalInterceptor)` *(@Bean)* | interceptor を適用したファクトリを生成（`@ConditionalOnMissingBean`） |
| `SqsJobArgumentProvider`       | `getJobExecutionId()`                                                                        | 起動引数から解決した JobExecutionId を提供（`function` に設定）       |

### 利用ガイド

本機能は `spring-cloud-aws-starter-sqs` に依存するため、**利用者が依存に追加する**。（`@SqsListener` を使用する常駐アプリは通常すでに保持。依存が無い場合は `@ConditionalOnClass(MessageInterceptor)` により無効）  
コンポーネントスキャン対象に含めたうえで、`application.yml` で有効化する。（`@SqsListener` を使用する常駐アプリ前提）

```yaml
cosmo-app:
  logging:
    sqs:
      enabled: true   # 既定 false。常駐バッチ環境でのみ true にする
```

有効化したうえで、アプリのリスナーコンテナファクトリの定義状況によって対応が分かれる。

#### ケース1：アプリが独自のファクトリを定義しない（標準・推奨）

追加実装は不要。  
本部品が `defaultSqsListenerContainerFactory` を提供し、全 `@SqsListener` の受信前後に `SqsReceiveJournalInterceptor` が自動で適用される。  
`@SqsListener` は通常どおり書く。

```java
@SqsListener("orders-queue")
public void handle(String body) {
    // 業務処理だけ書けばよい。
    // 受信ジャーナル出力・MDC の設定／クリアは自動
}
```

#### ケース2：アプリが独自に `SqsMessageListenerContainerFactory` を定義している

本部品の Bean は `@ConditionalOnMissingBean` で生成されない。（自作ファクトリに譲る）  
そのままでは interceptor が挿さらないため、**自作ファクトリへ `SqsReceiveJournalInterceptor`（Bean）を `messageInterceptor(...)` で手動追加する**。

```java
@Configuration
public class MySqsConfig {

    @Bean
    SqsMessageListenerContainerFactory<Object> defaultSqsListenerContainerFactory(
            SqsAsyncClient sqsAsyncClient,
            SqsReceiveJournalInterceptor journalInterceptor) { // ← 本部品の Bean を DI で受け取る
        return SqsMessageListenerContainerFactory.<Object>builder()
                .sqsAsyncClient(sqsAsyncClient)
                .messageInterceptor(journalInterceptor)         // ← 受信ジャーナル interceptor を適用する
                // … アプリ独自の設定 …
                .build();
    }
}
```

> 注：interceptor を複数適用する場合は `messageInterceptor(...)` を必要な数だけ呼び出す。（登録順に適用される）

#### ケース3：無効化（既定）

`enabled` を未設定または `false` にすると、`ResidentSqsConfig`・`SqsReceiveJournalInterceptor` とも `@ConditionalOnProperty` により生成されず、受信ジャーナル出力・MDC の設定は一切行われない。  
SQS を使用しない環境・受信ログが不要な環境はこのままでよい。

---
