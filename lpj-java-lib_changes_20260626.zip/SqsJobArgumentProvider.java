package jp.co.lawson.common.app.lib.logging.sqs;

import java.util.List;
import java.util.UUID;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * 起動引数（非オプション引数）から JobIdentifier／JobExecutionId を取り出して保持するコンポーネントクラス。
 */
@Component
@ConditionalOnProperty(prefix = "cosmo-app.logging.sqs", name = "enabled", havingValue = "true", matchIfMissing = false)
public class SqsJobArgumentProvider {

    /** ジョブ識別子（起動引数の第1引数）。 */
    private final String jobIdentifier;
    /** ジョブ実行ID（第2引数。無ければ JobIdentifier に UUID を付与して採番）。 */
    private final String jobExecutionId;

    /**
     * 起動引数から JobIdentifier と JobExecutionId を解決する。
     * 第1引数を JobIdentifier、第2引数を JobExecutionId とし、第2引数が無い場合は JobIdentifier に UUID を付与して採番する。
     *
     * @param args アプリケーション起動引数
     * @throws IllegalArgumentException 第1引数（JobIdentifier）が未設定または空白の場合
     */
    public SqsJobArgumentProvider(ApplicationArguments args) {

        List<String> nonOptionArgs = args.getNonOptionArgs();

        if (nonOptionArgs.size() <= 0 || nonOptionArgs.get(0).isBlank()) {
            throw new IllegalArgumentException("引数にJobIdentifierが設定されていません。");
        }

        this.jobIdentifier = nonOptionArgs.get(0);

        if (nonOptionArgs.size() <= 1 || nonOptionArgs.get(1).isBlank()) {
            this.jobExecutionId = this.jobIdentifier + "-" + UUID.randomUUID();
        } else {
            this.jobExecutionId = nonOptionArgs.get(1);
        }
    }

    /**
     * @return ジョブ識別子（JobIdentifier）
     */
    public String getJobIdentifier() {
        return jobIdentifier;
    }

    /**
     * @return ジョブ実行ID（JobExecutionId）
     */
    public String getJobExecutionId() {
        return jobExecutionId;
    }
}
