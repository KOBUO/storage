## LPJ のshell共通部品・サンプル

| No. | ファイル名 | 概要 | 設計書 |
| --- | --- | --- | --- |
| 1 | `jp1/receive.sh` | 受信ファイルの後続処理として、受信ファイルを `s3_put_object.sh` 経由で S3 に登録したうえで、あらかじめ定めたジョブネットを `jp1_register_exec.sh` 経由で実行するサンプル。 | [`jp1/docs/受信ファイル後続処理サンプル.md`](jp1/docs/受信ファイル後続処理サンプル.md) |
| 2 | `jp1/jp1_register_exec.sh` | 指定したユニット完全名のジョブネットを、JP1 の即時実行登録API にリクエストすることで実行する。 | [`jp1/docs/JP1即時実行登録.md`](jp1/docs/JP1即時実行登録.md) |
| 3 | `jp1/s3_put_object.sh` | 指定したファイルを、指定したキーで S3 に登録する。 | [`jp1/docs/S3ファイル登録.md`](jp1/docs/S3ファイル登録.md) |
