#!/usr/bin/env bash
#
# Links 受信定義設定ファイルの後続処理の実行ファイルのサンプル
#
# 指定したファイルIDに一致するジョブネットを、
# JP1 の即時実行登録API にリクエストすることで実行する。
#
# 参照: JP1 Version 11 JP1/AJS3 コマンドリファレンス 7.1.6 即時実行登録API
#       https://itpfdoc.hitachi.co.jp/manuals/3021/30213b1920/AJSO0284.HTM
#
# ---------------------------------------------------------------------------
# 引数
#
#   $1  unitName（ユニット完全名。ジョブネット、ファイルID）
#         ・1〜930バイト
#         ・空白、制御文字は使用できない
#         ・/ で終わる、/ が連続する形式は指定できない
#         ・先頭の / は省略可（省略時は補完する）
#
#   実行例)
#     ./jp1_register_exec.sh /JobGroup/Jobnet
#
#       ユニット完全名     /JobGroup/Jobnet
#       URLエンコード後    %2FJobGroup%2FJobnet
#
# ---------------------------------------------------------------------------
# 環境変数
#
#   実行には以下の環境変数が必要になる。
#
#   AJS_WEBCONSOLE   Web Console サーバの host:port     例) HOSTW:22252
#   AJS_SCHEME       http または https                  例) http
#   AJS_APPLICATION  リクエスト行の application         例) ajs
#   AJS_COMPONENT    リクエスト行の component           例) api
#   AJS_API_VERSION  リクエスト行の apiVersion          例) v1
#   AJS_MANAGER      メッセージボディの manager         例) HOSTM
#   AJS_SERVICE      メッセージボディの serviceName     例) AJSROOT1
#   AJS_USER         JP1ユーザー名                      例) jp1admin
#   AJS_PASSWORD     JP1ユーザーのパスワード
#
# ---------------------------------------------------------------------------
# 終了コード
#
#   0  即時実行登録に成功した（HTTP 200）
#   1  引数が不正、または必須環境変数が未設定
#   2  通信エラー
#   3  HTTP ステータスが 200 以外
#   4  HTTP 200 だが応答内容が不正（execID が取得できない）
#
# ---------------------------------------------------------------------------

PROG=$(basename "$0")

die() {
  printf '%s: %s\n' "$PROG" "$*" >&2
  exit 1
}

# ==== 引数チェック =========================================================
# unitName（ユニット完全名）のみを引数に取る。
[ $# -eq 1 ] \
  || die "使い方: $PROG <unitName>   例) $PROG /JobGroup/Jobnet"

unitName=$1

# 空でないこと
[ -n "$unitName" ] || die "unitName が空です"

# ユニット完全名はルートからの位置を表すため必ず / で始まる。
# 先頭の / が無い場合は補完する。
case "$unitName" in
  /*) : ;;
  *)  unitName="/${unitName}" ;;
esac

# パスパラメーターとして不正な値を弾く
case "$unitName" in
  */)   die "unitName の末尾に / は指定できません: $unitName" ;;
  *//*) die "unitName に / が連続しています: $unitName" ;;
esac

case "$unitName" in
  *[[:cntrl:]]*) die "unitName に制御文字が含まれています" ;;
  *" "*)         die "unitName に空白が含まれています: $unitName" ;;
esac

# 1〜930バイトであること（マニュアル記載の制限）
LEN=$(LC_ALL=C printf '%s' "$unitName" | wc -c | tr -d ' ')
if [ "$LEN" -gt 930 ]; then
  die "unitName は1〜930バイトで指定してください（現在 ${LEN} バイト）"
fi

# ==== 必須環境変数チェック =================================================
# いずれか一つでも未設定（空文字を含む）の場合は実行せずに終了する。
MISSING=""
for name in \
  AJS_WEBCONSOLE \
  AJS_SCHEME \
  AJS_APPLICATION \
  AJS_COMPONENT \
  AJS_API_VERSION \
  AJS_MANAGER \
  AJS_SERVICE \
  AJS_USER \
  AJS_PASSWORD
do
  eval "value=\${$name:-}"
  [ -n "$value" ] || MISSING="${MISSING} ${name}"
done

if [ -n "$MISSING" ]; then
  die "必須環境変数が設定されていません:${MISSING}"
fi

# AJS_SCHEME は http または https のみ
case "$AJS_SCHEME" in
  http|https) : ;;
  *) die "AJS_SCHEME は http または https を指定してください: $AJS_SCHEME" ;;
esac

# ==== ユニット完全名の URL エンコード =====================================
# unreserved (A-Z a-z 0-9 - . _ ~) 以外を UTF-8 バイト単位で %XX にする。
# '/' も %2F になる（マニュアルのリクエスト例と同じ形式）。
urlencode() {
  local hex i b d out=""

  hex=$(LC_ALL=C printf '%s' "$1" | od -An -tx1 -v | tr -d ' \n')

  for (( i=0; i<${#hex}; i+=2 )); do
    b=${hex:i:2}
    d=$((16#$b))

    if { [ "$d" -ge 65 ] && [ "$d" -le 90 ]; } ||
       { [ "$d" -ge 97 ] && [ "$d" -le 122 ]; } ||
       { [ "$d" -ge 48 ] && [ "$d" -le 57 ]; } ||
       [ "$d" -eq 45 ] || [ "$d" -eq 46 ] ||
       [ "$d" -eq 95 ] || [ "$d" -eq 126 ]; then
      out="$out$(printf "\\x$b")"
    else
      out="$out%$(printf '%s' "$b" | tr 'a-f' 'A-F')"
    fi
  done

  printf '%s' "$out"
}

encodedUnitName=$(urlencode "$unitName")

# ==== 認証 =================================================================
# マニュアル 7.1.6 では、リクエストヘッダー X-AJS-Authorization に
# 「JP1ユーザー名:パスワード」を Base64 エンコードした値を指定して認証する。
#   例) X-AJS-Authorization: dXNlcjpwYXNzd29yZA==
#       （デコードすると user:password）
#
# 実行権限として、ログインしたJP1ユーザーが対象ユニットに対し
# 次のいずれかのJP1権限を持っている必要がある。
#   JP1_AJS_Admin / JP1_AJS_Manager / JP1_AJS_Operator
#
# 認証情報が不正な場合は 401 Unauthorized、
# 権限が不足している場合は 403 Forbidden が返却される。
#
# 注意: 下記では curl の --header で渡しているため、
#       実行中は ps コマンドで他ユーザーからこの値が見える。
#       共用サーバで運用する場合は、curl の --config
#       （パーミッションを絞ったファイル）経由に変更すること。
AUTHORIZATION=$(
  LC_ALL=C printf '%s' "${AJS_USER}:${AJS_PASSWORD}" \
    | base64 \
    | tr -d '\r\n'
)

# ==== リクエスト ===========================================================
URL="${AJS_SCHEME}://${AJS_WEBCONSOLE}"
URL="${URL}/${AJS_APPLICATION}/${AJS_COMPONENT}/${AJS_API_VERSION}"
URL="${URL}/objects/definitions/${encodedUnitName}"
URL="${URL}/actions/registerImmediateExec/invoke"

# 必須パラメーターは manager と serviceName のみ。
# 任意の startCondition / holding / macro はこのサンプルでは指定しない。
BODY=$(cat <<JSON
{
  "parameters": {
    "manager": "${AJS_MANAGER}",
    "serviceName": "${AJS_SERVICE}"
  }
}
JSON
)

# --http1.1 はマニュアルのリクエスト行の httpVersion に合わせて明示する。
RESPONSE=$(curl --silent --show-error \
  --http1.1 \
  --request POST \
  --header "Accept-Language: ja" \
  --header "Content-type: application/json" \
  --header "X-AJS-Authorization: ${AUTHORIZATION}" \
  --data-binary "$BODY" \
  --connect-timeout 10 \
  --max-time 60 \
  --write-out '\n%{http_code}' \
  "$URL")
CURL_RC=$?

if [ "$CURL_RC" -ne 0 ]; then
  printf '%s: 通信に失敗しました（curl rc=%d）\n' "$PROG" "$CURL_RC" >&2
  printf '%s\n' "$URL" >&2
  exit 2
fi

HTTP_CODE=${RESPONSE##*$'\n'}
BODY_TEXT=${RESPONSE%$'\n'*}

# ==== 応答の判定 ===========================================================
# ステータスコードはマニュアル 7.1.6 の記載に対応する。
case "$HTTP_CODE" in
  200)
    MSG="即時実行登録が成功しました。"
    ;;
  400)
    MSG="Bad Request: 引数が不正です。"
    ;;
  401)
    MSG="Unauthorized: 認証が必要です。"
    ;;
  403)
    MSG="Forbidden: 実行権限がありません。"
    ;;
  404)
    MSG="Not found: リソースにアクセスする権限がありません。"
    MSG="${MSG}または、リソースがありません。"
    ;;
  409)
    MSG="Conflict: リクエストは現在のリソースの状態と矛盾しているため、"
    MSG="${MSG}処理を続行できません。"
    ;;
  412)
    MSG="Precondition failed: Web Consoleサーバが利用できません。"
    ;;
  500)
    MSG="Server-side error: Web Consoleサーバ処理エラーが発生しました。"
    ;;
  *)
    MSG="予期しないステータスコードです。"
    ;;
esac

if [ "$HTTP_CODE" != "200" ]; then
  printf '%s: HTTP %s - %s\n' "$PROG" "$HTTP_CODE" "$MSG" >&2
  [ -n "$BODY_TEXT" ] && printf '%s\n' "$BODY_TEXT" >&2
  exit 3
fi

# 実行IDを取り出す（形式: @[mmmm]{A〜Z}nnnn  例: @A2895）
EXEC_ID=$(
  printf '%s' "$BODY_TEXT" \
    | sed -n 's/.*"execID"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' \
    | head -n 1
)

# HTTP 200 でも応答に execID が含まれない場合は異常終了とする。
if [ -z "$EXEC_ID" ]; then
  printf '%s: 応答から execID を取得できませんでした\n' "$PROG" >&2
  [ -n "$BODY_TEXT" ] && printf '%s\n' "$BODY_TEXT" >&2
  exit 4
fi

printf '%s\n' "$MSG"
printf 'unit   : %s\n' "$unitName"
printf 'manager: %s\n' "$AJS_MANAGER"
printf 'service: %s\n' "$AJS_SERVICE"
printf 'execID : %s\n' "$EXEC_ID"

exit 0
