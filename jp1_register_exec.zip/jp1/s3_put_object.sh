#!/usr/bin/env bash
#
# Links 受信定義設定ファイルの後続処理の実行ファイル
#
# 指定したファイルを、AWS CLI の aws s3 cp で S3 に登録する。
#
# ---------------------------------------------------------------------------
# 引数
#
#   $1  登録するファイルのパス
#
#   $2  登録先のバケット名（/ は使用できない）
#
#   $3  S3 のキー（登録先のオブジェクト名）
#         ・1〜1024バイト
#         ・制御文字は使用できない
#         ・/ で始まる形式は指定できない
#
#   実行例)
#     ./s3_put_object.sh /data/recv/FILE001.dat lpj-recv-bucket recv/FILE001.dat
#
#       登録先    s3://lpj-recv-bucket/recv/FILE001.dat
#
# ---------------------------------------------------------------------------
# 環境変数
#
#   AWS の認証情報・リージョンは AWS CLI の設定に従う。
#
# ---------------------------------------------------------------------------
# 終了コード
#
#   0  S3 への登録に成功した
#   1  引数が不正
#   2  登録するファイルが存在しない、または読み込めない
#   3  aws コマンドが見つからない
#   4  aws s3 cp が異常終了した
#
# ---------------------------------------------------------------------------

PROG=$(basename "$0")

die() {
  code=$1
  shift
  printf '%s: %s\n' "$PROG" "$*" >&2
  exit "$code"
}

# 文字列のバイト数を返す
bytelen() {
  LC_ALL=C printf '%s' "$1" | wc -c | tr -d ' '
}

# ==== 引数チェック =========================================================
[ $# -eq 3 ] \
  || die 1 "使い方: $PROG <ファイルのパス> <バケット名> <S3のキー>   例) $PROG /data/recv/FILE001.dat lpj-recv-bucket recv/FILE001.dat"

filePath=$1
bucket=$2
s3Key=$3

[ -n "$filePath" ] || die 1 "ファイルのパスが空です"

[ -n "$bucket" ] || die 1 "バケット名が空です"

# バケット名のみを指定する（s3:// やプレフィックスは付けない）
case "$bucket" in
  */*) die 1 "バケット名に / は使用できません: $bucket" ;;
esac

[ -n "$s3Key" ] || die 1 "S3 のキーが空です"

case "$s3Key" in
  /*)            die 1 "S3 のキーの先頭に / は指定できません: $s3Key" ;;
  *[[:cntrl:]]*) die 1 "S3 のキーに制御文字が含まれています" ;;
esac

# 1〜1024バイトであること（S3 のオブジェクトキーの制限）
LEN=$(bytelen "$s3Key")
if [ "$LEN" -gt 1024 ]; then
  die 1 "S3 のキーは1〜1024バイトで指定してください（現在 ${LEN} バイト）"
fi

# ==== ファイルチェック =====================================================
[ -f "$filePath" ] || die 2 "ファイルが存在しません: $filePath"
[ -r "$filePath" ] || die 2 "ファイルを読み込めません: $filePath"

# ==== S3 への登録 ==========================================================
command -v aws >/dev/null 2>&1 \
  || die 3 "aws コマンドが見つかりません"

S3_URI="s3://${bucket}/${s3Key}"

# 先頭が - のパスは aws にオプション（- 単体の場合は標準入力）として解釈されるため、
# ./ を付けて渡す。
case "$filePath" in
  -*) srcPath="./${filePath}" ;;
  *)  srcPath=$filePath ;;
esac

aws s3 cp "$srcPath" "$S3_URI" --only-show-errors
AWS_RC=$?

if [ "$AWS_RC" -ne 0 ]; then
  die 4 "S3 への登録に失敗しました（aws rc=${AWS_RC}）: $S3_URI"
fi

printf '%s\n' "S3 への登録が成功しました。"
printf 'file: %s\n' "$filePath"
printf 's3  : %s\n' "$S3_URI"

exit 0
