#!/usr/bin/env bash
#
# Links 受信定義設定ファイルの後続処理の実行ファイルのサンプル
#
# 引数で受け取ったファイルから店舗IDの一覧を読み込み、
# あらかじめ定めたジョブネットを jp1_register_exec.sh 経由で実行する。
# 読み込んだ店舗IDはカンマで連結し、マクロ変数 AJS2STORES として JP1 へ引き継ぐ。
#
# ---------------------------------------------------------------------------
# 引数
#
#   $1  店舗IDリストファイルのパス
#         ・1行に店舗IDを1件記載したテキストファイル
#         ・半角英数字1〜6文字
#         ・空行は読み飛ばす。行頭・行末の空白は除去する
#         ・改行コードは LF / CRLF のどちらでもよい
#         ・先頭に BOM が付いていても読み込める（除去する）
#
#   実行例)
#     ./receive.sh /data/recv/store_20260831.txt
#
#       ファイルの内容        呼び出す引数
#         000001               ./jp1_register_exec.sh /JobGroup/Jobnet \
#         000002                   STORES=000001,000002,000003
#         000003
#
# ---------------------------------------------------------------------------
# 環境変数
#
#   jp1_register_exec.sh が必要とする環境変数（AJS_ で始まる9個）を
#   そのまま引き継ぐため、本シェルの実行前に設定しておく必要がある。
#   詳細は jp1_register_exec.sh のヘッダーを参照。
#
# ---------------------------------------------------------------------------
# 終了コード
#
#   0  即時実行登録に成功した
#   1  引数が不正
#   2  ファイルパスが無効（存在しない、読み取れない、通常ファイルでない）
#   3  店舗IDが0件
#   4  店舗IDの形式が不正
#   5  jp1_register_exec.sh が異常終了した
#   6  jp1_register_exec.sh を実行できない（配置されていない、実行権限が無い）
#
# ---------------------------------------------------------------------------

PROG=$(basename "$0")

# 実行対象のジョブネット（ユニット完全名）。本シェルでは固定値とする。
UNIT_NAME="/JobGroup/Jobnet"

# 即時実行登録を行うシェル。本シェルと同じディレクトリに配置する。
REGISTER_SCRIPT="$(cd "$(dirname "$0")" && pwd)/jp1_register_exec.sh"

# 店舗IDの最大文字数（ルーティング情報の店舗コードに合わせる）
STORE_ID_MAX_LENGTH=6

# 店舗IDを引き継ぐマクロ変数の名前。
# JP1側のジョブ定義に ?AJS2STORES? の受け口が用意されていることが前提となる。
# 接頭辞 AJS2 は jp1_register_exec.sh が付与するため、ここでは指定しない。
MACRO_KEY="STORES"

die() {
  code=$1
  shift
  printf '%s: %s\n' "$PROG" "$*" >&2
  exit "$code"
}

# ==== 引数チェック =========================================================
[ $# -eq 1 ] \
  || die 1 "使い方: $PROG <店舗IDリストファイルのパス>   例) $PROG /data/recv/store.txt"

STORE_FILE=$1

[ -n "$STORE_FILE" ] || die 1 "ファイルパスが空です"

# ==== ファイルチェック =====================================================
[ -e "$STORE_FILE" ] || die 2 "ファイルが存在しません: $STORE_FILE"
[ -f "$STORE_FILE" ] || die 2 "通常ファイルではありません: $STORE_FILE"
[ -r "$STORE_FILE" ] || die 2 "ファイルを読み取れません: $STORE_FILE"

# ==== 店舗IDの読み込み =====================================================
# 1行1件で読み込み、空行は読み飛ばす。
# 最終行に改行が無い場合も読み落とさないよう、読み込み後の残りを判定する。
STORE_IDS=()
LINE_NO=0

while IFS= read -r line || [ -n "$line" ]; do
  LINE_NO=$((LINE_NO + 1))

  # Windows で作成されたファイルに備えて、1行目の先頭の BOM を除去する
  if [ "$LINE_NO" -eq 1 ]; then
    line=${line#$'\xEF\xBB\xBF'}
  fi

  # CRLF の改行コードに備えて行末の CR を除去する
  line=${line%$'\r'}

  # 行頭・行末の空白を除去する
  line="${line#"${line%%[![:space:]]*}"}"
  line="${line%"${line##*[![:space:]]}"}"

  # 空行は読み飛ばす
  [ -n "$line" ] || continue

  case "$line" in
    *[!0-9A-Za-z]*)
      die 4 "店舗IDは半角英数字で指定してください（${LINE_NO}行目: ${line}）"
      ;;
  esac

  if [ "${#line}" -gt "$STORE_ID_MAX_LENGTH" ]; then
    die 4 "店舗IDは1〜${STORE_ID_MAX_LENGTH}文字で指定してください（${LINE_NO}行目: ${line}）"
  fi

  STORE_IDS+=("$line")
done < "$STORE_FILE"

# 店舗IDが1件も無い場合は実行せずに終了する。
if [ "${#STORE_IDS[@]}" -eq 0 ]; then
  die 3 "店舗IDが1件もありません: $STORE_FILE"
fi

# ==== 即時実行登録 =========================================================
[ -x "$REGISTER_SCRIPT" ] \
  || die 6 "実行できません: $REGISTER_SCRIPT"

printf '%s: 店舗ID %d 件を読み込みました（%s）\n' "$PROG" "${#STORE_IDS[@]}" "$STORE_FILE"

# 読み込んだ店舗IDをカンマで連結し、マクロ変数の値として渡す。
STORE_LIST=$(IFS=,; printf '%s' "${STORE_IDS[*]}")

# ユニット完全名は固定値とし、店舗IDはマクロ変数として渡す。
"$REGISTER_SCRIPT" "$UNIT_NAME" "${MACRO_KEY}=${STORE_LIST}"
REGISTER_RC=$?

if [ "$REGISTER_RC" -ne 0 ]; then
  die 5 "即時実行登録に失敗しました（jp1_register_exec.sh の終了コード: ${REGISTER_RC}）"
fi

exit 0
