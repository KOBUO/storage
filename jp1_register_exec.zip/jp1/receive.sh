#!/usr/bin/env bash
#
# Links 受信定義設定ファイルの後続処理の実行ファイルのサンプル
#
# 受信ファイルを s3_put_object.sh 経由で S3 に登録したうえで、
# JP1 のジョブネットを、jp1_register_exec.sh 経由で実行する。
#
# ---------------------------------------------------------------------------
# 引数
#
#   $1  受信ファイルのパス
#
#   実行例)
#     ./receive.sh /data/recv/FILE001.dat
#
# ---------------------------------------------------------------------------
# 環境変数
#
#   s3_put_object.sh が必要とする環境変数（S3_BUCKET）と、
#   jp1_register_exec.sh が必要とする環境変数（AJS_ で始まる9個）を
#   そのまま引き継ぐため、本シェルの実行前に設定しておく必要がある。
#   詳細は各シェルのヘッダーを参照。
#
# ---------------------------------------------------------------------------
# 終了コード
#
#   0  S3 への登録と即時実行登録に成功した
#   1  引数が指定されていない
#   2  s3_put_object.sh または jp1_register_exec.sh を実行できない
#      （配置されていない、実行権限が無い）
#   3  s3_put_object.sh が異常終了した
#   4  jp1_register_exec.sh が異常終了した
#
# ---------------------------------------------------------------------------

PROG=$(basename "$0")

# 本シェルと同じディレクトリに配置する。
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
S3_PUT_SCRIPT="${SCRIPT_DIR}/s3_put_object.sh"
REGISTER_SCRIPT="${SCRIPT_DIR}/jp1_register_exec.sh"

die() {
  code=$1
  shift
  printf '%s: %s\n' "$PROG" "$*" >&2
  exit "$code"
}

# ==== 引数チェック =========================================================
[ -n "$1" ] \
  || die 1 "使い方: $PROG <受信ファイルのパス>   例) $PROG /data/recv/FILE001.dat"

# ==== 呼び出すシェルのチェック =============================================
# S3 への登録後に jp1_register_exec.sh を実行できないと判明することが無いよう、
# 先に両方を確認する。
[ -x "$S3_PUT_SCRIPT" ] \
  || die 2 "実行できません: $S3_PUT_SCRIPT"
[ -x "$REGISTER_SCRIPT" ] \
  || die 2 "実行できません: $REGISTER_SCRIPT"

# ==== S3 への登録 ==========================================================
"$S3_PUT_SCRIPT" "$1" "recv/FILE001.dat"
S3_PUT_RC=$?

if [ "$S3_PUT_RC" -ne 0 ]; then
  die 3 "S3 への登録に失敗しました（s3_put_object.sh の終了コード: ${S3_PUT_RC}）"
fi

# ==== 即時実行登録 =========================================================
"$REGISTER_SCRIPT" "/JobGroup/FILE001"
REGISTER_RC=$?

if [ "$REGISTER_RC" -ne 0 ]; then
  die 4 "即時実行登録に失敗しました（jp1_register_exec.sh の終了コード: ${REGISTER_RC}）"
fi

exit 0
