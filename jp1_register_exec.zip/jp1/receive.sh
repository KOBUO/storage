#!/usr/bin/env bash
#
# Links 受信定義設定ファイルの後続処理の実行ファイルのサンプル
#
# 引数で受け取ったファイルIDに対応する JP1 のジョブネットを、
# jp1_register_exec.sh 経由で実行する。
#
# ---------------------------------------------------------------------------
# 引数
#
#   $1  ファイルID
#         ・空白、制御文字は使用できない
#         ・後述のマッピングに定義されている値であること
#
#   実行例)
#     ./receive.sh FILE001
#
#       ファイルID     FILE001
#       ジョブネット   /JobGroup/JobnetA
#
# ---------------------------------------------------------------------------
# 環境変数
#
#   jp1_register_exec.sh が必要とする環境変数（AJS_ で始まる9個）を
#   そのまま引き継ぐため、本シェルの実行前に設定しておく必要がある。
#   詳細は jp1_register_exec.sh のヘッダーを参照。
#
# ---------------------------------------------------------------------------
# 終了コード
#
#   0  即時実行登録に成功した
#   1  引数が不正
#   2  ファイルIDに対応するジョブネットが定義されていない
#   3  jp1_register_exec.sh を実行できない（配置されていない、実行権限が無い）
#   4  jp1_register_exec.sh が異常終了した
#
# ---------------------------------------------------------------------------

PROG=$(basename "$0")

# 即時実行登録を行うシェル。本シェルと同じディレクトリに配置する。
REGISTER_SCRIPT="$(cd "$(dirname "$0")" && pwd)/jp1_register_exec.sh"

die() {
  code=$1
  shift
  printf '%s: %s\n' "$PROG" "$*" >&2
  exit "$code"
}

# ==== 引数チェック =========================================================
[ $# -eq 1 ] \
  || die 1 "使い方: $PROG <ファイルID>   例) $PROG FILE001"

FILE_ID=$1

[ -n "$FILE_ID" ] || die 1 "ファイルIDが空です"

case "$FILE_ID" in
  *[[:cntrl:]]*) die 1 "ファイルIDに制御文字が含まれています" ;;
  *" "*)         die 1 "ファイルIDに空白が含まれています: $FILE_ID" ;;
esac

# ==== ファイルIDとジョブネットのマッピング =================================
# ファイルIDに対応するジョブネット（ユニット完全名）を決める。
# 導入時は、この対応表を実際のファイルIDとジョブネット構成に合わせて書き換える。
case "$FILE_ID" in
  FILE001) UNIT_NAME="/JobGroup/JobnetA" ;;
  FILE002) UNIT_NAME="/JobGroup/JobnetB" ;;
  FILE003) UNIT_NAME="/JobGroup/JobnetC" ;;
  *)
    die 2 "ファイルIDに対応するジョブネットが定義されていません: $FILE_ID"
    ;;
esac

# ==== 即時実行登録 =========================================================
[ -x "$REGISTER_SCRIPT" ] \
  || die 3 "実行できません: $REGISTER_SCRIPT"

printf '%s: ファイルID %s のジョブネット %s を実行します\n' "$PROG" "$FILE_ID" "$UNIT_NAME"

"$REGISTER_SCRIPT" "$UNIT_NAME"
REGISTER_RC=$?

if [ "$REGISTER_RC" -ne 0 ]; then
  die 4 "即時実行登録に失敗しました（jp1_register_exec.sh の終了コード: ${REGISTER_RC}）"
fi

exit 0
