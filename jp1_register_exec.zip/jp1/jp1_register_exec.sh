#!/usr/bin/env bash
#
# Links 受信定義設定ファイルの後続処理の実行ファイルのサンプル
#
# 指定したファイルIDに一致するジョブネットを、
# JP1 の即時実行登録API にリクエストすることで実行する。
# マクロ変数が指定された場合は、その値を JP1 のジョブへ引き継ぐ。
#
# 参照: JP1 Version 11 JP1/AJS3 コマンドリファレンス 7.1.6 即時実行登録API
#       https://itpfdoc.hitachi.co.jp/manuals/3021/30213b1920/AJSO0284.HTM
#
# ---------------------------------------------------------------------------
# 引数
#
#   $1  unitName（ユニット完全名。ジョブネット、ファイルID）
#         ・1〜930バイト
#         ・空白、制御文字は使用できない
#         ・/ で終わる、/ が連続する形式は指定できない
#         ・先頭の / は省略可（省略時は補完する）
#
#   $2以降  マクロ変数（任意。複数指定可。最大32個）
#         ・「名前=引き継ぐ値」の形式で指定する
#         ・最初の = を区切りとするため、値には = を含められる
#         ・名前に使用できるのは A〜Z（大文字）、0〜9、. のみ
#         ・JP1 の規約である接頭辞 AJS2 は、付いていなければ本シェルが付与する
#           （規約: ジョブ定義では ?AJS2xxxxx? の形式。?を含めて64バイト以下）
#         ・値に " と \ は使用できない
#         ・指定しない場合、マクロ変数は送信しない
#
#   実行例)
#     ./jp1_register_exec.sh /JobGroup/Jobnet
#     ./jp1_register_exec.sh /JobGroup/Jobnet STORES=000001,000002 AJS2DATE=20260831
#
#       ユニット完全名     /JobGroup/Jobnet
#       URLエンコード後    %2FJobGroup%2FJobnet
#       マクロ変数         AJS2STORES = 000001,000002   （AJS2 を付与した）
#                          AJS2DATE   = 20260831        （すでに付いているのでそのまま）
#
#   JP1側のジョブ定義に受け口（例: ?AJS2STORES?）が記述されていない場合、
#   値を送っても何も起こらない。
#
# ---------------------------------------------------------------------------
# 環境変数
#
#   実行には以下の環境変数が必要になる。
#
#   AJS_WEBCONSOLE   Web Console サーバの host:port     例) HOSTW:22252
#   AJS_SCHEME       http または https                  例) http
#   AJS_APPLICATION  リクエスト行の application         例) ajs
#   AJS_COMPONENT    リクエスト行の component           例) api
#   AJS_API_VERSION  リクエスト行の apiVersion          例) v1
#   AJS_MANAGER      メッセージボディの manager         例) HOSTM
#   AJS_SERVICE      メッセージボディの serviceName     例) AJSROOT1
#   AJS_USER         JP1ユーザー名                      例) jp1admin
#   AJS_PASSWORD     JP1ユーザーのパスワード
#
# ---------------------------------------------------------------------------
# 終了コード
#
#   0  即時実行登録に成功した（HTTP 200）
#   1  引数が不正、または必須環境変数が未設定
#   2  通信エラー
#   3  HTTP ステータスが 200 以外
#   4  HTTP 200 だが応答内容が不正（execID が取得できない）
#
# ---------------------------------------------------------------------------

PROG=$(basename "$0")

die() {
  printf '%s: %s\n' "$PROG" "$*" >&2
  exit 1
}

# 文字列のバイト数を返す
bytelen() {
  LC_ALL=C printf '%s' "$1" | wc -c | tr -d ' '
}

# ==== 引数チェック =========================================================
# 第1引数に unitName（ユニット完全名）、第2引数以降にマクロ変数を取る。
# マクロ変数は任意とし、指定されない場合はメッセージボディに含めない。
[ $# -ge 1 ] \
  || die "使い方: $PROG <unitName> [名前=値 ...]   例) $PROG /JobGroup/Jobnet STORES=000001,000002"

unitName=$1
shift

# 空でないこと
[ -n "$unitName" ] || die "unitName が空です"

# ユニット完全名はルートからの位置を表すため必ず / で始まる。
# 先頭の / が無い場合は補完する。
case "$unitName" in
  /*) : ;;
  *)  unitName="/${unitName}" ;;
esac

# パスパラメーターとして不正な値を弾く
case "$unitName" in
  */)   die "unitName の末尾に / は指定できません: $unitName" ;;
  *//*) die "unitName に / が連続しています: $unitName" ;;
esac

case "$unitName" in
  *[[:cntrl:]]*) die "unitName に制御文字が含まれています" ;;
  *" "*)         die "unitName に空白が含まれています: $unitName" ;;
esac

# 1〜930バイトであること（マニュアル記載の制限）
LEN=$(LC_ALL=C printf '%s' "$unitName" | wc -c | tr -d ' ')
if [ "$LEN" -gt 930 ]; then
  die "unitName は1〜930バイトで指定してください（現在 ${LEN} バイト）"
fi

# ==== マクロ変数のチェック =================================================
# 「名前=引き継ぐ値」の形式で受け取り、名前と値に分割して検証する。
# JP1 の規約である接頭辞 AJS2 は、付いていなければここで付与する。
MACRO_PREFIX="AJS2"
MACRO_NAMES=()
MACRO_VALUES=()

for macro in "$@"; do
  # 最初の = を区切りとする。値に = が含まれていてもよい。
  case "$macro" in
    *=*) : ;;
    *)   die "マクロ変数は「名前=値」の形式で指定してください: $macro" ;;
  esac

  macroKey=${macro%%=*}
  macroValue=${macro#*=}

  # --- 名前 ---
  # JP1 の規約により、ジョブ定義では ?AJS2xxxxx? の形式で ? を含めて64バイト以下、
  # xxxxx に使用できる文字は A〜Z（大文字）、0〜9、. に限られる。
  # API のメッセージボディには、前後の ? を付けずに指定する。
  [ -n "$macroKey" ] || die "マクロ変数の名前が空です: $macro"

  # case のパターン [A-Z] はロケールの照合順序によって小文字にも一致するため、
  # 使用できる文字を列挙して判定する。
  case "$macroKey" in
    *[!ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.]*)
      die "マクロ変数の名前に使用できるのは A〜Z（大文字）、0〜9、. です: $macroKey"
      ;;
  esac

  # 接頭辞 AJS2 は規約で定まっているため、付いていなければ付与する。
  # すでに付いている場合はそのまま扱う（AJS2AJS2xxxxx とならないようにする）。
  case "$macroKey" in
    ${MACRO_PREFIX}*) macroName="$macroKey" ;;
    *)                macroName="${MACRO_PREFIX}${macroKey}" ;;
  esac

  # AJS2 に続く xxxxx が1文字以上であること
  [ -n "${macroName#${MACRO_PREFIX}}" ] \
    || die "マクロ変数の名前は ${MACRO_PREFIX} に続けて1文字以上を指定してください: $macroKey"

  # ジョブ定義での表記 ?AJS2xxxxx? が64バイト以下であること
  if [ "$(( $(bytelen "$macroName") + 2 ))" -gt 64 ]; then
    die "マクロ変数名 ?${macroName}? が64バイトを超えています"
  fi

  # 同一の変数名を複数指定した場合、JP1 は最初の値を採用する。
  # 意図しない値が使われることを避けるため、重複はエラーとする。
  for registered in ${MACRO_NAMES[@]+"${MACRO_NAMES[@]}"}; do
    [ "$registered" != "$macroName" ] \
      || die "マクロ変数名が重複しています: $macroName"
  done

  # --- 引き継ぐ値 ---
  [ -n "$macroValue" ] || die "マクロ変数の値が空です: $macro"

  case "$macroValue" in
    *[[:cntrl:]]*) die "マクロ変数の値に制御文字は使用できません: $macroName" ;;
    *'"'*)         die "マクロ変数の値に \" は使用できません: $macroName" ;;
    *'\'*)         die "マクロ変数の値に \\ は使用できません: $macroName" ;;
  esac

  # サイズ制限（マニュアル 7.1.6）:
  #   「マクロ変数名のバイト数 ＋ 引き継ぎ情報のバイト数 ＋ 4」が 4,085 以内。
  MACRO_LEN=$(( $(bytelen "$macroName") + $(bytelen "$macroValue") + 4 ))
  if [ "$MACRO_LEN" -gt 4085 ]; then
    die "マクロ変数のサイズが上限を超えています（${macroName}: ${MACRO_LEN} バイト > 4085 バイト）"
  fi

  MACRO_NAMES+=("$macroName")
  MACRO_VALUES+=("$macroValue")
done

# 指定できるマクロ変数は32個まで（マニュアル 7.1.6）。
if [ "${#MACRO_NAMES[@]}" -gt 32 ]; then
  die "マクロ変数は32個まで指定できます（現在 ${#MACRO_NAMES[@]} 個）"
fi

# ==== 必須環境変数チェック =================================================
# いずれか一つでも未設定（空文字を含む）の場合は実行せずに終了する。
MISSING=""
for name in \
  AJS_WEBCONSOLE \
  AJS_SCHEME \
  AJS_APPLICATION \
  AJS_COMPONENT \
  AJS_API_VERSION \
  AJS_MANAGER \
  AJS_SERVICE \
  AJS_USER \
  AJS_PASSWORD
do
  eval "value=\${$name:-}"
  [ -n "$value" ] || MISSING="${MISSING} ${name}"
done

if [ -n "$MISSING" ]; then
  die "必須環境変数が設定されていません:${MISSING}"
fi

# AJS_SCHEME は http または https のみ
case "$AJS_SCHEME" in
  http|https) : ;;
  *) die "AJS_SCHEME は http または https を指定してください: $AJS_SCHEME" ;;
esac

# AJS_MANAGER と AJS_SERVICE はメッセージボディへそのまま埋め込むため、
# JSON を壊す文字が含まれていないことを確認する（マクロ変数の値と同じ基準）。
for name in AJS_MANAGER AJS_SERVICE; do
  eval "value=\${$name}"
  case "$value" in
    *[[:cntrl:]]*) die "${name} に制御文字は使用できません" ;;
    *'"'*)         die "${name} に \" は使用できません: ${value}" ;;
    *'\'*)         die "${name} に \\ は使用できません: ${value}" ;;
  esac
done

# ==== ユニット完全名の URL エンコード =====================================
# unreserved (A-Z a-z 0-9 - . _ ~) 以外を UTF-8 バイト単位で %XX にする。
# '/' も %2F になる（マニュアルのリクエスト例と同じ形式）。
urlencode() {
  local hex i b d out=""

  hex=$(LC_ALL=C printf '%s' "$1" | od -An -tx1 -v | tr -d ' \n')

  for (( i=0; i<${#hex}; i+=2 )); do
    b=${hex:i:2}
    d=$((16#$b))

    if { [ "$d" -ge 65 ] && [ "$d" -le 90 ]; } ||
       { [ "$d" -ge 97 ] && [ "$d" -le 122 ]; } ||
       { [ "$d" -ge 48 ] && [ "$d" -le 57 ]; } ||
       [ "$d" -eq 45 ] || [ "$d" -eq 46 ] ||
       [ "$d" -eq 95 ] || [ "$d" -eq 126 ]; then
      out="$out$(printf "\\x$b")"
    else
      out="$out%$(printf '%s' "$b" | tr 'a-f' 'A-F')"
    fi
  done

  printf '%s' "$out"
}

encodedUnitName=$(urlencode "$unitName")

# ==== 認証 =================================================================
# マニュアル 7.1.6 では、リクエストヘッダー X-AJS-Authorization に
# 「JP1ユーザー名:パスワード」を Base64 エンコードした値を指定して認証する。
#   例) X-AJS-Authorization: dXNlcjpwYXNzd29yZA==
#       （デコードすると user:password）
#
# 実行権限として、ログインしたJP1ユーザーが対象ユニットに対し
# 次のいずれかのJP1権限を持っている必要がある。
#   JP1_AJS_Admin / JP1_AJS_Manager / JP1_AJS_Operator
#
# 認証情報が不正な場合は 401 Unauthorized、
# 権限が不足している場合は 403 Forbidden が返却される。
#
# 注意: 下記では curl の --header で渡しているため、
#       実行中は ps コマンドで他ユーザーからこの値が見える。
#       共用サーバで運用する場合は、curl の --config
#       （パーミッションを絞ったファイル）経由に変更すること。
AUTHORIZATION=$(
  LC_ALL=C printf '%s' "${AJS_USER}:${AJS_PASSWORD}" \
    | base64 \
    | tr -d '\r\n'
)

# ==== リクエスト ===========================================================
URL="${AJS_SCHEME}://${AJS_WEBCONSOLE}"
URL="${URL}/${AJS_APPLICATION}/${AJS_COMPONENT}/${AJS_API_VERSION}"
URL="${URL}/objects/definitions/${encodedUnitName}"
URL="${URL}/actions/registerImmediateExec/invoke"

# API の必須パラメーターは manager と serviceName の2つ。
# 任意パラメーターのうち macro は、マクロ変数が指定された場合のみ付加する。
# 同じく任意の startCondition / holding はこのサンプルでは指定しない。
MACRO_PARAM=""
if [ "${#MACRO_NAMES[@]}" -gt 0 ]; then
  MACRO_ITEMS=""
  for (( i=0; i<${#MACRO_NAMES[@]}; i++ )); do
    [ "$i" -eq 0 ] || MACRO_ITEMS="${MACRO_ITEMS},"
    MACRO_ITEMS="${MACRO_ITEMS}
      {
        \"name\": \"${MACRO_NAMES[i]}\",
        \"value\": \"${MACRO_VALUES[i]}\"
      }"
  done

  MACRO_PARAM=$(cat <<JSON
,
    "macro": [${MACRO_ITEMS}
    ]
JSON
)
fi

BODY=$(cat <<JSON
{
  "parameters": {
    "manager": "${AJS_MANAGER}",
    "serviceName": "${AJS_SERVICE}"${MACRO_PARAM}
  }
}
JSON
)

# --http1.1 はマニュアルのリクエスト行の httpVersion に合わせて明示する。
RESPONSE=$(curl --silent --show-error \
  --http1.1 \
  --request POST \
  --header "Accept-Language: ja" \
  --header "Content-type: application/json" \
  --header "X-AJS-Authorization: ${AUTHORIZATION}" \
  --data-binary "$BODY" \
  --connect-timeout 10 \
  --max-time 60 \
  --write-out '\n%{http_code}' \
  "$URL")
CURL_RC=$?

if [ "$CURL_RC" -ne 0 ]; then
  printf '%s: 通信に失敗しました（curl rc=%d）\n' "$PROG" "$CURL_RC" >&2
  printf '%s\n' "$URL" >&2
  exit 2
fi

HTTP_CODE=${RESPONSE##*$'\n'}
BODY_TEXT=${RESPONSE%$'\n'*}

# ==== 応答の判定 ===========================================================
# ステータスコードはマニュアル 7.1.6 の記載に対応する。
case "$HTTP_CODE" in
  200)
    MSG="即時実行登録が成功しました。"
    ;;
  400)
    MSG="Bad Request: 引数が不正です。"
    ;;
  401)
    MSG="Unauthorized: 認証が必要です。"
    ;;
  403)
    MSG="Forbidden: 実行権限がありません。"
    ;;
  404)
    MSG="Not found: リソースにアクセスする権限がありません。"
    MSG="${MSG}または、リソースがありません。"
    ;;
  409)
    MSG="Conflict: リクエストは現在のリソースの状態と矛盾しているため、"
    MSG="${MSG}処理を続行できません。"
    ;;
  412)
    MSG="Precondition failed: Web Consoleサーバが利用できません。"
    ;;
  500)
    MSG="Server-side error: Web Consoleサーバ処理エラーが発生しました。"
    ;;
  *)
    MSG="予期しないステータスコードです。"
    ;;
esac

if [ "$HTTP_CODE" != "200" ]; then
  printf '%s: HTTP %s - %s\n' "$PROG" "$HTTP_CODE" "$MSG" >&2
  [ -n "$BODY_TEXT" ] && printf '%s\n' "$BODY_TEXT" >&2
  exit 3
fi

# 実行IDを取り出す（形式: @[mmmm]{A〜Z}nnnn  例: @A2895）
EXEC_ID=$(
  printf '%s' "$BODY_TEXT" \
    | sed -n 's/.*"execID"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' \
    | head -n 1
)

# HTTP 200 でも応答に execID が含まれない場合は異常終了とする。
if [ -z "$EXEC_ID" ]; then
  printf '%s: 応答から execID を取得できませんでした\n' "$PROG" >&2
  [ -n "$BODY_TEXT" ] && printf '%s\n' "$BODY_TEXT" >&2
  exit 4
fi

printf '%s\n' "$MSG"
printf 'unit   : %s\n' "$unitName"
printf 'manager: %s\n' "$AJS_MANAGER"
printf 'service: %s\n' "$AJS_SERVICE"
for (( i=0; i<${#MACRO_NAMES[@]}; i++ )); do
  printf 'macro  : %s=%s\n' "${MACRO_NAMES[i]}" "${MACRO_VALUES[i]}"
done
printf 'execID : %s\n' "$EXEC_ID"

exit 0
