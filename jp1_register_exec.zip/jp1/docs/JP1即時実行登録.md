# JP1即時実行登録（`jp1_register_exec.sh`）

## 1. 処理概要

### 目的

- 引数で指定されたユニット完全名のジョブネットを、
  **JP1 の即時実行登録API にリクエストすることで実行する**。

参照: JP1 Version 11 JP1/AJS3 コマンドリファレンス 7.1.6 即時実行登録API
　　　https://itpfdoc.hitachi.co.jp/manuals/3021/30213b1920/AJSO0284.HTM

### 前提

- リクエスト先は JP1/AJS3 Web Console サーバとする。接続情報はすべて環境変数で与える。
- 認証は、リクエストヘッダー `X-AJS-Authorization` に「JP1ユーザー名:パスワード」を
  Base64 エンコードした値を設定して行う。
- 実行には、ログインした JP1 ユーザーが対象ユニットに対し
  `JP1_AJS_Admin` / `JP1_AJS_Manager` / `JP1_AJS_Operator` のいずれかの JP1 権限を持っている必要がある。

### 特記事項

- ユニット完全名は、unreserved（`A-Z` `a-z` `0-9` `-` `.` `_` `~`）以外を UTF-8 のバイト単位で
  `%XX` にエンコードする。`/` も `%2F` になる（マニュアルのリクエスト例と同じ形式）。
- 必須パラメーターは `manager` と `serviceName` の2つのみを指定する。
  任意パラメーターの `startCondition` / `holding` / `macro` は、本Shellでは指定しない。
- `AJS_MANAGER` および `AJS_SERVICE` はメッセージボディへそのまま埋め込むため、
  JSON を壊す文字（制御文字・`"`・`\`）を含む場合は異常終了する。
- HTTP 200 であっても応答に `execID` が含まれない場合は、異常終了とする。
- 認証情報を curl の `--header` で渡しているため、実行中は `ps` コマンドで他ユーザーから値が見える。
  共用サーバで運用する場合は、curl の `--config`（パーミッションを絞ったファイル）経由に変更すること。

## 2. 処理フロー

1. 引数が1個であることを検証し、ユニット完全名を取得する。
2. ユニット完全名を検証する。先頭の `/` が無い場合は補完し、
   末尾の `/`、`/` の連続、制御文字、空白、930バイト超を不正とする。
3. 必須とする環境変数がすべて設定されていることを検証する。
   あわせて `AJS_SCHEME` が `http` または `https` であること、および
   `AJS_MANAGER` と `AJS_SERVICE` が制御文字・`"`・`\` を含まないことを検証する。
4. ユニット完全名を URL エンコードし、リクエストURLを組み立てる。
5. `AJS_USER` と `AJS_PASSWORD` を `ユーザー名:パスワード` の形式で連結し、Base64 エンコードする。
6. メッセージボディを組み立てる。
7. 組み立てたURLへ HTTP/1.1 で POST し、応答とHTTPステータスコードを取得する。
8. HTTPステータスコードが 200 であることを確認する。
9. 応答から `execID` を取り出し、実行結果を標準出力へ出力して正常終了する。

### リクエストURL

```
{AJS_SCHEME}://{AJS_WEBCONSOLE}/{AJS_APPLICATION}/{AJS_COMPONENT}/{AJS_API_VERSION}
  /objects/definitions/{URLエンコードしたユニット完全名}
  /actions/registerImmediateExec/invoke
```

例) `http://HOSTW:22252/ajs/api/v1/objects/definitions/%2FJobGroup%2FJobnet/actions/registerImmediateExec/invoke`

### リクエストヘッダー

| # | ヘッダー | 値 |
|---|---------|----|
| 1 | `Accept-Language` | `ja` |
| 2 | `Content-type` | `application/json` |
| 3 | `X-AJS-Authorization` | `{AJS_USER}:{AJS_PASSWORD}` を Base64 エンコードした値 |

### メッセージボディ

```json
{
  "parameters": {
    "manager": "HOSTM",
    "serviceName": "AJSROOT1"
  }
}
```

### 実行例

```
$ ./jp1_register_exec.sh /JobGroup/Jobnet
即時実行登録が成功しました。
unit   : /JobGroup/Jobnet
manager: HOSTM
service: AJSROOT1
execID : @A2895
```

### 発生するエラー

#### 引数・環境変数の検証（終了コード 1）

- 以下を参考にエラーメッセージを標準エラー出力へ出力し、異常終了とする。

| # | エラーケース | エラーメッセージ |
|---|------|---------------|
| 1 | 引数の個数が1個でない場合 | 使い方: jp1_register_exec.sh <unitName>　例) jp1_register_exec.sh /JobGroup/Jobnet |
| 2 | ユニット完全名が空文字の場合 | unitName が空です |
| 3 | ユニット完全名が `/` で終わる場合 | unitName の末尾に / は指定できません: {unitName} |
| 4 | ユニット完全名に `/` が連続する場合 | unitName に / が連続しています: {unitName} |
| 5 | ユニット完全名に制御文字が含まれる場合 | unitName に制御文字が含まれています |
| 6 | ユニット完全名に空白が含まれる場合 | unitName に空白が含まれています: {unitName} |
| 7 | ユニット完全名が930バイトを超える場合 | unitName は1〜930バイトで指定してください（現在 {バイト数} バイト） |
| 8 | 必須とする環境変数が未設定の場合 | 必須環境変数が設定されていません: {環境変数名 ...} |
| 9 | `AJS_SCHEME` が `http` / `https` 以外の場合 | AJS_SCHEME は http または https を指定してください: {設定値} |
| 10 | `AJS_MANAGER` / `AJS_SERVICE` に制御文字が含まれる場合 | {環境変数名} に制御文字は使用できません |
| 11 | `AJS_MANAGER` / `AJS_SERVICE` に `"` が含まれる場合 | {環境変数名} に " は使用できません: {設定値} |
| 12 | `AJS_MANAGER` / `AJS_SERVICE` に `\` が含まれる場合 | {環境変数名} に \ は使用できません: {設定値} |

※ 8 は、未設定の環境変数が複数ある場合、すべてを列挙して1件のメッセージで出力する。

#### 通信・応答の判定（終了コード 2〜4）

| # | エラーケース | 終了コード | 出力するメッセージ |
|---|------|:---:|---------------|
| 1 | 通信に失敗した場合 | 2 | 通信に失敗しました（curl rc={curlの終了コード}）／リクエストURL |
| 2 | HTTPステータスが 200 以外の場合 | 3 | HTTP {ステータス} - {下表のメッセージ}／応答本文 |
| 3 | HTTP 200 だが `execID` を取得できない場合 | 4 | 応答から execID を取得できませんでした／応答本文 |

- HTTPステータスコードに対応するメッセージは以下とする（マニュアル 7.1.6 の記載に対応）。

| # | ステータス | メッセージ |
|---|:---:|---------------|
| 1 | 200 | 即時実行登録が成功しました。 |
| 2 | 400 | Bad Request: 引数が不正です。 |
| 3 | 401 | Unauthorized: 認証が必要です。 |
| 4 | 403 | Forbidden: 実行権限がありません。 |
| 5 | 404 | Not found: リソースにアクセスする権限がありません。または、リソースがありません。 |
| 6 | 409 | Conflict: リクエストは現在のリソースの状態と矛盾しているため、処理を続行できません。 |
| 7 | 412 | Precondition failed: Web Consoleサーバが利用できません。 |
| 8 | 500 | Server-side error: Web Consoleサーバ処理エラーが発生しました。 |
| 9 | 上記以外 | 予期しないステータスコードです。 |

### 終了コード

| # | 終了コード | 内容 |
|---|:---:|------|
| 1 | 0 | 即時実行登録に成功した（HTTP 200） |
| 2 | 1 | 引数が不正、または必須環境変数が未設定 |
| 3 | 2 | 通信エラー |
| 4 | 3 | HTTPステータスが 200 以外 |
| 5 | 4 | HTTP 200 だが応答内容が不正（`execID` が取得できない） |

## 3. 引数

| # | 引数 | 用途 | 値（例） |
|---|------|------|---------|
| 1 | `$1` | ユニット完全名（ジョブネット）。1〜930バイト。先頭の `/` は省略可 | `/JobGroup/Jobnet` |

## 4. 環境変数

| # | 環境変数 | 用途 | 値（例） |
|---|---------|------|---------|
| 1 | `AJS_WEBCONSOLE` | Web Console サーバの `host:port` | `HOSTW:22252` |
| 2 | `AJS_SCHEME` | `http` または `https` | `http` |
| 3 | `AJS_APPLICATION` | リクエスト行の application | `ajs` |
| 4 | `AJS_COMPONENT` | リクエスト行の component | `api` |
| 5 | `AJS_API_VERSION` | リクエスト行の apiVersion | `v1` |
| 6 | `AJS_MANAGER` | メッセージボディの `manager`（1〜255バイト） | `HOSTM` |
| 7 | `AJS_SERVICE` | メッセージボディの `serviceName`（1〜30バイト） | `AJSROOT1` |
| 8 | `AJS_USER` | JP1ユーザー名 | `jp1admin` |
| 9 | `AJS_PASSWORD` | JP1ユーザーのパスワード | — |

※ 9個すべてが必須。未設定（空文字を含む）の場合はリクエストせずに異常終了する。
※ `AJS_MANAGER` と `AJS_SERVICE` はメッセージボディへそのまま埋め込むため、
　 制御文字・`"`・`\` を含む場合は異常終了する。
※ `AJS_PASSWORD` は秘匿情報のため、シェルの履歴やプロセス一覧に残らない方法で与えること。

## 5. 即時実行登録API のメッセージボディ仕様

マニュアル 7.1.6 で `parameters` に指定できるパラメーターは以下のとおり。

| # | パラメーター | 必須 | 内容 | 本シェルでの扱い |
|---|-------------|:---:|------|---------------|
| 1 | `manager` | ○ | マネージャーホスト名/IPアドレス（1〜255バイト） | `AJS_MANAGER` を設定する |
| 2 | `serviceName` | ○ | スケジューラーサービス名（1〜30バイト） | `AJS_SERVICE` を設定する |
| 3 | `startCondition` | — | 起動条件オブジェクト | 指定しない |
| 4 | `holding` | — | 実行保留するか（既定 `false`） | 指定しない |
| 5 | `macro` | — | マクロ変数オブジェクトの配列 | 指定しない |
