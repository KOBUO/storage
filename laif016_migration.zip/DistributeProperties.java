package jp.co.lawson.laif.bt.daemon.jobs.common;

import jakarta.validation.Valid;
import jakarta.validation.constraints.PositiveOrZero;
import org.springframework.boot.context.properties.ConfigurationProperties;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

/**
 * 配信制御に使用する設定値を保持するクラス。
 */
@ConfigurationProperties(prefix = "distribute.control.settings")
@Data
public class DistributeProperties {

    /**
     * 帯域上限設定。
     */
    @Valid
    private final Bandwidth bandwidth = new Bandwidth();

    /**
     * 転送帯域
     */
    @Valid
    private final TransferBand transferBand = new TransferBand();

    /**
     * 同時配信機器数
     */
    @Valid
    private final SimulEquipment simulEquipment = new SimulEquipment();

    /**
     * 登録済み配信制御情報
     */
    @Valid
    private final DistributeCtrlInfo distributeCtrlInfo = new DistributeCtrlInfo();

    /**
     * 帯域上限
     * <p>
     * 各設定値は整数を指定する。 TODO 負数が設定される場合、想定外の挙動になりそうなので、、設計書にも反映して対応する？
     * </p>
     */
    @Data
    public static class Bandwidth {

        /**
         * 全体の帯域上限（単位: Mbps）
         */
        @NotNull
        @PositiveOrZero
        private Integer overall;

        /**
         * チャネルBの帯域上限（単位: Mbps）
         */
        @NotNull
        @PositiveOrZero
        private Integer channelB;

        /**
         * チャネルCの帯域上限（単位: Mbps）
         */
        @NotNull
        @PositiveOrZero
        private Integer channelC;
    }

    /**
     * 転送帯域
     * <p>
     * 各設定値は整数を指定する。 TODO 負数が設定される場合、想定外の挙動になりそうなので、、設計書にも反映して対応する？
     * </p>
     */
    @Data
    public static class TransferBand {

        /**
         * チャネルAの転送帯域（単位: Mbps）
         */
        @NotNull
        @PositiveOrZero
        private Integer channelA;

        /**
         * チャネルBの転送帯域（単位: Mbps）
         */
        @NotNull
        @PositiveOrZero
        private Integer channelB;

        /**
         * チャネルCの転送帯域（単位: Mbps）
         */
        @NotNull
        @PositiveOrZero
        private Integer channelC;
    }

    /**
     * 同時配信機器数
     * <p>
     * 各設定値は整数を指定する。 TODO 負数が設定される場合、想定外の挙動になりそうなので、、設計書にも反映して対応する？
     * </p>
     */
    @Data
    public static class SimulEquipment {

        /**
         * チャネルAの通常店同時配信機器数
         */
        @NotNull
        @PositiveOrZero
        private Integer channelA;

        /**
         * チャネルBの通常店同時配信機器数
         */
        @NotNull
        @PositiveOrZero
        private Integer channelB;

        /**
         * チャネルCの通常店同時配信機器数
         */
        @NotNull
        @PositiveOrZero
        private Integer channelC;

        /**
         * 低速回線店の同時配信機器数
         */
        @NotNull
        @PositiveOrZero
        private Integer lowSpeed;
    }

    /**
     * 登録済み配信制御情報
     * <p>
     * 各設定値は整数を指定する。 TODO 負数が設定される場合、想定外の挙動になりそうなので、、設計書にも反映して対応する？
     * </p>
     */
    @Data
    public static class DistributeCtrlInfo {

        /**
         * 保存期間（単位：h）
         */
        @NotNull
        @PositiveOrZero
        private Integer retentionPeriod;
    }
}
