DROP TABLE IF EXISTS laif_down_equipment;
CREATE TABLE laif_down_equipment
(
    store_cd                   character varying(6)  not null,
    equipment_category         character varying(2)  not null,
    equipment_no               character varying(2)  not null,
    down_equipment_entry_dt_tm timestamp             not null,
    entry_dt_tm                timestamp             not null,
    creator_id                 character varying(60) not null,
    upd_dt_tm                  timestamp,
    updater_id                 character varying(60),
    constraint pk_laif_down_equipment primary key (store_cd, equipment_category, equipment_no)
);
