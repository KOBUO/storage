DROP TABLE IF EXISTS laif_distribute_completed;
CREATE TABLE laif_distribute_completed
(
    distribute_id              bigint                 not null,
    distribute_status_kbn      character varying(2)   not null,
    distribute_completed_dt_tm timestamp,
    distribute_stop_dt_tm      timestamp,
    entry_dt_tm                timestamp              not null,
    creator_id                 character varying(60)  not null,
    upd_dt_tm                  timestamp,
    updater_id                 character varying(60),
    constraint pk_laif_distribute_completed primary key (distribute_id)
);
