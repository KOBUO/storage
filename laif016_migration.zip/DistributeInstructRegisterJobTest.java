package jp.co.lawson.laif.bt.daemon.jobs.job.dlaif0100001;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.UncheckedIOException;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Modifier;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.AfterAllCallback;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.mockito.internal.util.MockUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.AnnotatedElementUtils;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.SystemEnvironmentPropertySource;
import javax.sql.DataSource;
import org.springframework.boot.env.YamlPropertySourceLoader;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.dao.QueryTimeoutException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;

import jp.co.lawson.laif.bt.daemon.BatchApplication;
import jp.co.lawson.laif.bt.daemon.BatchConfiguration;
import jp.co.lawson.laif.bt.daemon.jobs.mapper.DownEquipmentMapper;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.scheduling.annotation.ScheduledAnnotationBeanPostProcessor;
import jp.co.lawson.laif.bt.daemon.jobs.mapper.DistributeStatusMapper;
import jp.co.nri.xpalette.batch.core.exception.DuplicateJobParameterException;
import jp.co.nri.xpalette.batch.core.exception.JobExecFailedException;
import jp.co.nri.xpalette.batch.core.exception.NoJobParameterException;
import jp.co.nri.xpalette.batch.core.result.JobExecutionResult;
import jp.co.nri.xpalette.batch.core.exception.JobStartFailedException;
import jp.co.nri.xpalette.batch.core.runner.JobContext;

import tools.jackson.core.JacksonException;
import tools.jackson.databind.JsonNode;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.SerializationFeature;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.node.ObjectNode;

/**
 * 配信指示登録ジョブのテスト.
 */
class DistributeInstructRegisterJobTest {

    static final String JOB_ID = "DLAIF0100001";
    static final String AREA_LOW_SPEED = "--distribute_area_category=05";
    static final String AREA_01 = "--distribute_area_category=01";
    static final String SIMULATED = "simulated";
    static final String FIND_ALL = "findAll";
    static final String FIND_STATUS = "findByDistributeAreaCategory";
    static final String ENV_INVALID = "環境変数(プロパティ)の設定値が不正です。";
    static final String UNEXPECTED_ILLEGAL_STATE = "予期せぬ以下の例外が発生しました。Exception=IllegalStateException";
    static final String BIND_FAILED = "Failed to bind properties under 'distribute.control.settings.";
    static final String TO_INTEGER = "' to java.lang.Integer";
    static final String SIMULATED_TIMEOUT = "simulated timeout";
    static final String OVERALL = "bandwidth.overall";

    @Nested
    @DisplayName("case_01: 配信不可の配信状況を、店舗の同時配信上限まで配信可能にする (正常系)")
    @BatchCase("case_01")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    class Case01 extends BatchTestSupport {

        @Autowired
        ApplicationContext applicationContext;

        @Test
        void test() {
            assertThat(applicationContext.getBean(BatchConfiguration.class)).isNotNull();
            assertThat(applicationContext.getBeanNamesForType(ScheduledAnnotationBeanPostProcessor.class)).isNotEmpty();
            assertThat(aspect.lastFailure()).as("例外は発生しない").isNull();
            assertThat(jobFailure).isNull();
            assertThat(jobResult).isInstanceOf(JobExecutionResult.class);
            assertThat(((JobExecutionResult) jobResult).getExitCode()).isZero();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_02: DB エラーが 2 回でも、リトライで成功する (正常系)")
    @BatchCase("case_02")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DownEquipmentMapper.class, method = FIND_ALL, times = "2",
            exception = QueryTimeoutException.class, message = SIMULATED_TIMEOUT)
    class Case02 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).as("2 回失敗させている").isEqualTo(2);
            assertThat(aspect.calls()).as("3 回目で成功している").contains("findAll");
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_03: DB エラーが 4 回でリトライを使い切り、中断する (異常系)")
    @BatchCase("case_03")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DownEquipmentMapper.class, method = FIND_ALL, times = "4",
            exception = QueryTimeoutException.class, message = SIMULATED_TIMEOUT)
    class Case03 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).as("初回 + リトライ 3 回").isEqualTo(4);
            assertThat(aspect.lastFailure())
                    .isInstanceOf(QueryTimeoutException.class)
                    .hasMessage(SIMULATED_TIMEOUT);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_04: 起動引数が不正なら例外になる (バリデーション)")
    @BatchCase("case_04")
    @SpringBootTest(args = {JOB_ID, "--distribute_area_category=99"})
    class Case04 extends BatchTestSupport {

        @Test
        void test() {
            JobContext jobContext = new JobContext(applicationArguments);
            assertThatThrownBy(() -> job.runJob(jobContext))
                    .isInstanceOf(JobStartFailedException.class)
                    .hasMessage("起動引数が不正です。--distribute_area_category=99");
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_05: 環境変数が不正なら例外になる (バリデーション)")
    @BatchCase("case_05")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    class Case05 extends BatchTestSupport {

        @Test
        void test() {
            JobContext jobContext = new JobContext(applicationArguments);
            assertThatThrownBy(() -> job.runJob(jobContext))
                    .isInstanceOf(JobStartFailedException.class)
                    .hasMessageStartingWith(ENV_INVALID)
                    .hasMessageContaining("bandwidth.overall=-1");
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_06: 環境変数が数値でなければ起動時のバインドでエラーになる (バリデーション)")
    @BatchCase("case_06")
    class Case06 extends StartupFailureTestSupport {

        @Test
        void test() {
            assertThatThrownBy(() -> startApplication(JOB_ID, AREA_LOW_SPEED))
                    .hasStackTraceContaining(BIND_FAILED + OVERALL + TO_INTEGER)
                    .hasRootCauseInstanceOf(NumberFormatException.class)
                    .hasRootCauseMessage("For input string: \"abc\"");
            testCase().assertDatabase(testDb());
        }
    }

    @Nested
    @DisplayName("case_07: 環境変数が int の範囲外なら起動時のバインドでエラーになる (バリデーション)")
    @BatchCase("case_07")
    class Case07 extends StartupFailureTestSupport {

        @Test
        void test() {
            assertThatThrownBy(() -> startApplication(JOB_ID, AREA_LOW_SPEED))
                    .hasStackTraceContaining(BIND_FAILED + OVERALL + TO_INTEGER)
                    .hasRootCauseInstanceOf(NumberFormatException.class)
                    .hasRootCauseMessage("For input string: \"2147483648\"");
            testCase().assertDatabase(testDb());
        }
    }

    @Nested
    @DisplayName("case_08: 通常店: チャネル B → C → A の順に処理し、全体の帯域上限に達したらそのチャネルを打ち切る")
    @BatchCase("case_08")
    @SpringBootTest(args = {JOB_ID, AREA_01})
    class Case08 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_09: 通常店: チャネル B・C は各チャネルの帯域上限で打ち切り、チャネル A はチャネル別の上限を見ない")
    @BatchCase("case_09")
    @SpringBootTest(args = {JOB_ID, "--distribute_area_category=02"})
    class Case09 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_10: 通常店: 店舗の同時配信上限は機器単位で数え、同じ機器は使用中帯域に重ねて加算しない")
    @BatchCase("case_10")
    @SpringBootTest(args = {JOB_ID, "--distribute_area_category=03"})
    class Case10 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_11: 通常店: チャネル A・C の同時配信機器数で判定する (0 なら許可しない)")
    @BatchCase("case_11")
    @SpringBootTest(args = {JOB_ID, "--distribute_area_category=04"})
    class Case11 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_12: ダウン機器: 配信許可中から除外し、処理対象は上限判定せずに許可する (一部の項目だけ一致は対象外)")
    @BatchCase("case_12")
    @SpringBootTest(args = {JOB_ID, AREA_01})
    class Case12 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_13: 低速回線店: 同時配信機器数はレコード単位で数え、帯域上限は判定しない")
    @BatchCase("case_13")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    class Case13 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_14: 配信許可の対象が無ければ更新しない")
    @BatchCase("case_14")
    @SpringBootTest(args = {JOB_ID, AREA_01})
    class Case14 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            assertThat(logs.lines()).noneMatch(line -> line.contains("更新しました"));
        }
    }

    @Nested
    @DisplayName("case_15: 配信完了済みと他エリアの配信状況は処理対象にしない")
    @BatchCase("case_15")
    @SpringBootTest(args = {JOB_ID, AREA_01})
    class Case15 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            assertThat(logs.lines()).noneMatch(line -> line.contains("更新しました"));
        }
    }

    @Nested
    @DisplayName("case_16: 配信優先区分の降順、配信順の昇順で処理する")
    @BatchCase("case_16")
    @SpringBootTest(args = {JOB_ID, AREA_01})
    class Case16 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_17: 処理対象配信状況リストの取得が 4 回失敗するとリトライを使い切って中断する")
    @BatchCase("case_17")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DistributeStatusMapper.class, method = FIND_STATUS, times = "4",
            exception = QueryTimeoutException.class, message = SIMULATED)
    class Case17 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).isEqualTo(4);
            assertThat(jobFailure)
                    .isInstanceOf(JobExecFailedException.class)
                    .hasMessage("DB処理でエラーが発生しました。DB処理: 処理対象配信状況リストの取得")
                    .hasCauseInstanceOf(QueryTimeoutException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_18: 処理対象配信状況リストの取得が 2 回失敗しても、リトライで成功する")
    @BatchCase("case_18")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DistributeStatusMapper.class, method = FIND_STATUS, times = "2",
            exception = QueryTimeoutException.class, message = SIMULATED)
    class Case18 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).isEqualTo(2);
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_19: ダウン機器リストの取得で DB エラー以外が起きたらリトライせずに中断する")
    @BatchCase("case_19")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DownEquipmentMapper.class, method = FIND_ALL, times = "*",
            exception = IllegalStateException.class, message = SIMULATED)
    class Case19 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).isEqualTo(1);
            assertThat(jobFailure)
                    .isInstanceOf(JobExecFailedException.class)
                    .hasMessage(UNEXPECTED_ILLEGAL_STATE)
                    .hasCauseInstanceOf(IllegalStateException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_20: 処理対象配信状況リストの取得で DB エラー以外が起きたらリトライせずに中断する")
    @BatchCase("case_20")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DistributeStatusMapper.class, method = FIND_STATUS, times = "*",
            exception = IllegalStateException.class, message = SIMULATED)
    class Case20 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).isEqualTo(1);
            assertThat(jobFailure)
                    .isInstanceOf(JobExecFailedException.class)
                    .hasMessage(UNEXPECTED_ILLEGAL_STATE)
                    .hasCauseInstanceOf(IllegalStateException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_21: ダウン機器リストの取得で一時的でない DB エラーが起きたらリトライせずに中断する")
    @BatchCase("case_21")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DownEquipmentMapper.class, method = FIND_ALL, times = "*",
            exception = DataIntegrityViolationException.class, message = SIMULATED)
    class Case21 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).isEqualTo(1);
            assertThat(jobFailure)
                    .isInstanceOf(JobExecFailedException.class)
                    .hasMessage("DB処理でエラーが発生しました。DB処理: ダウン機器リストの取得")
                    .hasCauseInstanceOf(DataIntegrityViolationException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_22: 配信状況の更新で DB エラーが起きたらロールバックして中断する (リトライしない)")
    @BatchCase("case_22")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DistributeStatusMapper.class, method = "updateDistributeAvailabilityToPossible", times = "*",
            exception = QueryTimeoutException.class, message = SIMULATED, afterCall = true)
    class Case22 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).isEqualTo(1);
            assertThat(jobFailure)
                    .isInstanceOf(JobExecFailedException.class)
                    .hasMessage("DB処理でエラーが発生しました。DB処理: 配信許可設定")
                    .hasCauseInstanceOf(QueryTimeoutException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_23: 配信状況の更新で DB エラー以外が起きたらロールバックして中断する")
    @BatchCase("case_23")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DistributeStatusMapper.class, method = "updateDistributeAvailabilityToPossible", times = "*",
            exception = IllegalStateException.class, message = SIMULATED, afterCall = true)
    class Case23 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).isEqualTo(1);
            assertThat(jobFailure)
                    .isInstanceOf(JobExecFailedException.class)
                    .hasMessage(UNEXPECTED_ILLEGAL_STATE)
                    .hasCauseInstanceOf(IllegalStateException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_25: 通常店で転送帯域が 0 のチャネルは帯域上限を判定しない")
    @BatchCase("case_25")
    @SpringBootTest(args = {JOB_ID, AREA_01})
    class Case25 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            testCase.assertDatabase(testDb);
            testCase.assertLogContains(logs.lines());
        }
    }

    @Nested
    @DisplayName("case_26: 環境変数が未設定なら例外になる (バリデーション)")
    @BatchCase("case_26")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    class Case26 extends BatchTestSupport {

        @Test
        void test() {
            JobContext jobContext = new JobContext(applicationArguments);
            assertThatThrownBy(() -> job.runJob(jobContext))
                    .isInstanceOf(JobStartFailedException.class)
                    .hasMessageStartingWith(ENV_INVALID)
                    .hasMessageContainingAll(PROPERTY_PATHS.stream().map(path -> "(" + path + "=null)").toArray(String[]::new));
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_27: 環境変数が負数なら例外になる (バリデーション)")
    @BatchCase("case_27")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    class Case27 extends BatchTestSupport {

        @Test
        void test() {
            JobContext jobContext = new JobContext(applicationArguments);
            assertThatThrownBy(() -> job.runJob(jobContext))
                    .isInstanceOf(JobStartFailedException.class)
                    .hasMessageStartingWith(ENV_INVALID)
                    .hasMessageContainingAll(PROPERTY_PATHS.stream().map(path -> "(" + path + "=-1)").toArray(String[]::new));
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_28: 環境変数がすべて 0 でも起動できる")
    @BatchCase("case_28")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    class Case28 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(jobFailure).isNull();
            assertThat(jobResult).isInstanceOf(JobExecutionResult.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_29: 環境変数が Integer に変換できなければ起動時のバインドでエラーになる (バリデーション)")
    @BatchCase("case_29")
    class Case29 extends StartupFailureTestSupport {

        static Stream<Arguments> invalidValues() {
            return BINDING_NAMES.entrySet().stream()
                    .flatMap(entry -> Stream.of("abc", "2147483648", "-2147483649")
                            .map(value -> Arguments.of(entry.getKey(), entry.getValue(), value)));
        }

        @ParameterizedTest(name = "{0}={2}")
        @MethodSource("invalidValues")
        void test(String variable, String property, String value) {
            Map<String, Object> overrides = Map.of(variable, value);
            assertThatThrownBy(() -> startApplication(overrides, JOB_ID, AREA_LOW_SPEED))
                    .hasStackTraceContaining(BIND_FAILED + property + TO_INTEGER)
                    .hasRootCauseInstanceOf(NumberFormatException.class)
                    .hasRootCauseMessage("For input string: \"" + value + "\"");
            testCase().assertDatabase(testDb());
        }
    }

    @Nested
    @DisplayName("case_30: 起動引数の配信エリア種別が無ければ例外になる (バリデーション)")
    @BatchCase("case_30")
    @SpringBootTest(args = {JOB_ID})
    class Case30 extends BatchTestSupport {

        @Test
        void test() {
            JobContext jobContext = new JobContext(applicationArguments);
            assertThatThrownBy(() -> job.runJob(jobContext))
                    .isInstanceOf(NoJobParameterException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_31: 起動引数の配信エリア種別が重複していれば例外になる (バリデーション)")
    @BatchCase("case_31")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED, AREA_01})
    class Case31 extends BatchTestSupport {

        @Test
        void test() {
            JobContext jobContext = new JobContext(applicationArguments);
            assertThatThrownBy(() -> job.runJob(jobContext))
                    .isInstanceOf(DuplicateJobParameterException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_32: 起動引数の配信エリア種別が空なら例外になる (バリデーション)")
    @BatchCase("case_32")
    @SpringBootTest(args = {JOB_ID, "--distribute_area_category="})
    class Case32 extends BatchTestSupport {

        @Test
        void test() {
            JobContext jobContext = new JobContext(applicationArguments);
            assertThatThrownBy(() -> job.runJob(jobContext))
                    .isInstanceOf(JobStartFailedException.class)
                    .hasMessage("起動引数が不正です。--distribute_area_category=");
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_33: 処理対象配信状況リストの取得で一時的でない DB エラーが起きたらリトライせずに中断する")
    @BatchCase("case_33")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    @InjectFault(target = DistributeStatusMapper.class, method = FIND_STATUS, times = "*",
            exception = DataIntegrityViolationException.class, message = SIMULATED)
    class Case33 extends BatchTestSupport {

        @Test
        void test() {
            assertThat(aspect.injectedCount()).isEqualTo(1);
            assertThat(jobFailure)
                    .isInstanceOf(JobExecFailedException.class)
                    .hasMessage("DB処理でエラーが発生しました。DB処理: 処理対象配信状況リストの取得")
                    .hasCauseInstanceOf(DataIntegrityViolationException.class);
            testCase.assertDatabase(testDb);
        }
    }

    @Nested
    @DisplayName("case_34: 環境変数が空文字なら例外になる (バリデーション)")
    @BatchCase("case_34")
    @SpringBootTest(args = {JOB_ID, AREA_LOW_SPEED})
    class Case34 extends BatchTestSupport {

        @Test
        void test() {
            JobContext jobContext = new JobContext(applicationArguments);
            assertThatThrownBy(() -> job.runJob(jobContext))
                    .isInstanceOf(JobStartFailedException.class)
                    .hasMessageStartingWith(ENV_INVALID)
                    .hasMessageContainingAll(PROPERTY_PATHS.stream().map(path -> "(" + path + "=null)").toArray(String[]::new));
            testCase.assertDatabase(testDb);
        }
    }

    static final List<String> PROPERTY_PATHS = List.of(OVERALL, "bandwidth.channelB", "bandwidth.channelC",
            "transferBand.channelA", "transferBand.channelB", "transferBand.channelC",
            "simulEquipment.channelA", "simulEquipment.channelB", "simulEquipment.channelC", "simulEquipment.lowSpeed",
            "distributeCtrlInfo.retentionPeriod");

    static final Map<String, String> BINDING_NAMES = new LinkedHashMap<>();

    static {
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_BANDWIDTH_OVERALL", OVERALL);
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_B", "bandwidth.channel-b");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_BANDWIDTH_CHANNEL_C", "bandwidth.channel-c");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_A", "transfer-band.channel-a");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_B", "transfer-band.channel-b");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_TRANSFERBAND_CHANNEL_C", "transfer-band.channel-c");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_A", "simul-equipment.channel-a");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_B", "simul-equipment.channel-b");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_CHANNEL_C", "simul-equipment.channel-c");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CONTROL_SIMUL_EQUIPMENT_LOWSPEED", "simul-equipment.low-speed");
        BINDING_NAMES.put("ENV_DISTRIBUTE_CTRL_INFO_RETENTION_PERIOD", "distribute-ctrl-info.retention-period");
    }

    /**
     * DB アクセスに例外を注入する.
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.TYPE)
    public @interface InjectFault {

        /**
         * 例外を投げる対象の Mapper.
         */
        Class<?> target();

        /**
         * 例外を投げる対象のメソッド名.
         */
        String method();

        /**
         * 引数での絞り込み. 引数の文字列表現にすべて含まれる呼び出しだけ失敗させる.
         */
        String[] args() default {};

        /**
         * 最初の何回を失敗させるか. "*" は毎回.
         */
        String times() default "*";

        /**
         * 投げる例外.
         */
        Class<? extends RuntimeException> exception();

        /**
         * 例外メッセージ.
         */
        String message() default "injected by test";

        /**
         * 呼び出しの後で例外を投げるか.
         */
        boolean afterCall() default false;
    }

    /**
     * このテストクラスが検証するケース.
     */
    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.TYPE)
    public @interface BatchCase {

        /**
         * ケース名.
         */
        String value();
    }

    /**
     * ケースの .env を環境変数として積み、テスト用の仕掛けを登録する.
     */
    public static class CaseContextInitializer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext context) {
            TestCaseResources testCase = BatchTestSupport.testCase;
            Map<String, Object> variables = testCase.environment();
            variables.putAll(BatchTestSupport.environmentOverrides);
            context.getEnvironment()
                    .getPropertySources()
                    .addFirst(new SystemEnvironmentPropertySource("case-systemEnvironment", variables));

            BeanDefinitionRegistry registry = (BeanDefinitionRegistry) context.getBeanFactory();
            registry.registerBeanDefinition("jobAspect", BeanDefinitionBuilder
                    .genericBeanDefinition(JobAspect.class)
                    .addConstructorArgValue(BatchTestSupport.fault)
                    .getBeanDefinition());
            registry.registerBeanDefinition("oneCycleJobPostProcessor", BeanDefinitionBuilder
                    .genericBeanDefinition(OneCycleJobPostProcessor.class)
                    .getBeanDefinition());
        }
    }

    /**
     * 注入ルール.
     */
    public record Fault(Class<?> target, String method, List<String> args, String times,
            Class<? extends RuntimeException> exception, String message, boolean afterCall) {

        static Fault of(InjectFault annotation) {
            if (Modifier.isAbstract(annotation.exception().getModifiers())) {
                throw new IllegalArgumentException("@InjectFault の exception に抽象クラスは指定できない"
                        + " (QueryTimeoutException などの具象クラスを指定する): " + annotation.exception().getName());
            }
            return new Fault(annotation.target(), annotation.method(), List.of(annotation.args()),
                    annotation.times(), annotation.exception(), annotation.message(), annotation.afterCall());
        }

        boolean matches(Object actualTarget, String method, Object[] actualArgs) {
            if (!target.isInstance(actualTarget) || !this.method.equals(method)) {
                return false;
            }
            String values = Stream.of(actualArgs).map(String::valueOf).collect(Collectors.joining(", "));
            return args.stream().allMatch(values::contains);
        }

        boolean remains(int injected) {
            return "*".equals(times) || injected < Integer.parseInt(times);
        }

        RuntimeException newException() {
            try {
                return exception.getConstructor(String.class).newInstance(message);
            } catch (ReflectiveOperationException e) {
                throw new IllegalArgumentException("例外が生成できない: " + exception, e);
            }
        }
    }

    /**
     * ケースのデータ投入とログ取り込みを行う.
     */
    public static class CaseSetupExtension implements BeforeAllCallback, AfterAllCallback {

        /**
         * application-test.yml の接続先で DataSource を作る.
         */
        private static DataSource testDataSource() {
            try {
                PropertySource<?> properties = new YamlPropertySourceLoader()
                        .load("application-test", new ClassPathResource("application-test.yml"))
                        .getFirst();
                return new SingleConnectionDataSource(
                        String.valueOf(properties.getProperty("spring.datasource.url")),
                        String.valueOf(properties.getProperty("spring.datasource.username")),
                        String.valueOf(properties.getProperty("spring.datasource.password")),
                        true);
            } catch (IOException e) {
                throw new UncheckedIOException("application-test.yml が読めない", e);
            }
        }

        @Override
        public void beforeAll(ExtensionContext context) {
            Class<?> testClass = context.getRequiredTestClass();
            BatchCase batchCase = AnnotatedElementUtils.findMergedAnnotation(testClass, BatchCase.class);
            if (batchCase == null) {
                throw new IllegalStateException("テストクラスに @BatchCase を付けること: " + testClass.getSimpleName());
            }
            InjectFault injectFault = AnnotatedElementUtils.findMergedAnnotation(testClass, InjectFault.class);

            BatchTestSupport.prepare(injectFault == null ? null : Fault.of(injectFault),
                    new TestDatabase(new JdbcTemplate(testDataSource())),
                    new TestCaseResources(testClass.getPackageName(), batchCase.value()));
        }

        @Override
        public void afterAll(ExtensionContext context) {
            BatchTestSupport.finish();
        }
    }

    /**
     * ジョブを spy に差し替え、1 サイクルで停止させる.
     */
    public static class OneCycleJobPostProcessor implements BeanPostProcessor {

        @Override
        public Object postProcessAfterInitialization(Object bean, String beanName) {
            if (!(bean instanceof DistributeInstructRegisterJob job)) {
                return bean;
            }
            DistributeInstructRegisterJob spy = MockUtil.isMock(job) ? job : Mockito.spy(job);
            Mockito.doAnswer(invocation -> {
                try {
                    Object result = invocation.callRealMethod();
                    BatchTestSupport.recordResult(result);
                    return result;
                } catch (RuntimeException e) {
                    BatchTestSupport.recordFailure(e);
                    throw e;
                } finally {
                    spy.requestStop();
                }
            }).when(spy).execute(ArgumentMatchers.any(JobContext.class));
            return spy;
        }
    }

    /**
     * @InjectFault に従って例外を注入し、呼び出しを記録するアスペクト.
     */
    @Aspect
    @Order(Ordered.LOWEST_PRECEDENCE)
    public static class JobAspect {

        private final Fault fault;
        private final List<String> calls = new CopyOnWriteArrayList<>();
        private final AtomicInteger injected = new AtomicInteger();

        private Throwable lastFailure;

        public JobAspect(Fault fault) {
            this.fault = fault;
        }

        /**
         * Mapper の呼び出しを横取りする.
         */
        @Around("execution(* jp.co.lawson.laif.bt.daemon.jobs.mapper..*.*(..))")
        public Object intercept(ProceedingJoinPoint joinPoint) throws Throwable {
            String method = joinPoint.getSignature().getName();
            try {
                failIfConfigured(false, joinPoint.getTarget(), method, joinPoint.getArgs());
                Object result = joinPoint.proceed();
                failIfConfigured(true, joinPoint.getTarget(), method, joinPoint.getArgs());
                calls.add(method);
                return result;
            } catch (RuntimeException e) {
                calls.add(method + ":" + e.getClass().getSimpleName());
                lastFailure = e;
                throw e;
            }
        }

        /**
         * @InjectFault に一致する呼び出しで例外を投げる.
         */
        private void failIfConfigured(boolean afterCall, Object target, String method, Object[] args) {
            if (fault == null || fault.afterCall() != afterCall || !fault.matches(target, method, args)
                    || !fault.remains(injected.get())) {
                return;
            }
            injected.incrementAndGet();
            throw fault.newException();
        }

        /**
         * 記録された呼び出し.
         */
        public List<String> calls() {
            return List.copyOf(calls);
        }

        /**
         * 注入した例外の回数.
         */
        public int injectedCount() {
            return injected.get();
        }

        /**
         * 最後に発生した例外.
         */
        public Throwable lastFailure() {
            return lastFailure;
        }
    }

    /**
     * 各ケースの共通処理.
     */
    @ActiveProfiles("test")
    @ExtendWith(CaseSetupExtension.class)
    @ContextConfiguration(initializers = CaseContextInitializer.class)
    @DirtiesContext(classMode = ClassMode.AFTER_CLASS)
    abstract static class BatchTestSupport {

        /**
         * このケースの例外注入ルール.
         */
        static Fault fault;

        /**
         * .env に上書きする環境変数.
         */
        static Map<String, Object> environmentOverrides = Map.of();

        /**
         * ジョブの 1 サイクルの戻り値.
         */
        static volatile Object jobResult;

        /**
         * ジョブの 1 サイクルで発生した例外.
         */
        static volatile Throwable jobFailure;

        protected static TestDatabase testDb;

        /**
         * 検証対象のジョブ.
         */
        @MockitoSpyBean
        protected DistributeInstructRegisterJob job;

        /**
         * 起動引数.
         */
        @Autowired
        protected ApplicationArguments applicationArguments;

        /**
         * このケースのテスト資材.
         */
        protected static TestCaseResources testCase;

        protected static JsonLogCapture logs;

        /**
         * テスト用アスペクト.
         */
        @Autowired(required = false)
        protected JobAspect aspect;

        /**
         * ケースの準備をする.
         */
        static void prepare(Fault caseFault, TestDatabase db, TestCaseResources resources) {
            fault = caseFault;
            environmentOverrides = Map.of();
            jobResult = null;
            jobFailure = null;
            testDb = db;
            testCase = resources;
            testCase.setUpDatabase(testDb);
            logs = JsonLogCapture.start();
        }

        /**
         * ケースの後片付けをする.
         */
        static void finish() {
            if (logs != null) {
                logs.detach();
            }
        }

        /**
         * ジョブの 1 サイクルの戻り値を記録する.
         */
        static void recordResult(Object result) {
            jobResult = result;
        }

        /**
         * ジョブの 1 サイクルで発生した例外を記録する.
         */
        static void recordFailure(Throwable failure) {
            jobFailure = failure;
        }
    }

    /**
     * 起動に失敗するケースの共通処理.
     */
    @ExtendWith(CaseSetupExtension.class)
    abstract static class StartupFailureTestSupport {

        /**
         * ケースの環境変数でアプリを起動する.
         */
        protected static void startApplication(String... args) {
            startApplication(Map.of(), args);
        }

        /**
         * ケースの環境変数を一部上書きしてアプリを起動する.
         */
        protected static void startApplication(Map<String, Object> overrides, String... args) {
            BatchTestSupport.environmentOverrides = overrides;
            new SpringApplicationBuilder(BatchApplication.class)
                    .profiles("test")
                    .initializers(new CaseContextInitializer())
                    .run(args)
                    .close();
        }

        /**
         * このケースのテスト資材.
         */
        protected static TestCaseResources testCase() {
            return BatchTestSupport.testCase;
        }

        /**
         * テスト用の DB.
         */
        protected static TestDatabase testDb() {
            return BatchTestSupport.testDb;
        }
    }

    /**
     * テスト用の DB 操作.
     */
    static final class TestDatabase {

        private final JdbcTemplate jdbc;

        TestDatabase(JdbcTemplate jdbc) {
            this.jdbc = jdbc;
        }

        /**
         * .sql ファイルを実行する.
         */
        void runScript(Resource script) {
            ResourceDatabasePopulator populator = new ResourceDatabasePopulator(script);
            populator.setSeparator(";");
            populator.execute(jdbc.getDataSource());
        }

        /**
         * CSV の全行を投入する.
         */
        void insert(String table, List<Map<String, String>> rows) {
            if (rows.isEmpty()) {
                return;
            }
            List<String> columns = List.copyOf(rows.getFirst().keySet());
            Map<String, Integer> types = columnTypes(table);
            String sql = "INSERT INTO %s (%s) VALUES (%s)".formatted(table, String.join(", ", columns),
                    columns.stream().map(column -> "?").collect(Collectors.joining(", ")));
            List<Object[]> values = rows.stream()
                    .map(row -> columns.stream()
                            .map(column -> toColumnValue(row.get(column), types.get(column)))
                            .toArray())
                    .toList();
            jdbc.batchUpdate(sql, values);
        }

        /**
         * テーブルのカラム型.
         */
        private Map<String, Integer> columnTypes(String table) {
            return jdbc.execute((Connection connection) -> {
                Map<String, Integer> types = new LinkedHashMap<>();
                for (String name : List.of(table.toUpperCase(), table.toLowerCase())) {
                    try (ResultSet columns = connection.getMetaData().getColumns(null, null, name, null)) {
                        while (columns.next()) {
                            types.put(columns.getString("COLUMN_NAME").toLowerCase(), columns.getInt("DATA_TYPE"));
                        }
                    }
                    if (!types.isEmpty()) {
                        return types;
                    }
                }
                throw new IllegalStateException("テーブルが見つからない: " + table);
            });
        }

        /**
         * CSV の文字列をカラム型の値にする.
         */
        private static Object toColumnValue(String value, Integer sqlType) {
            if (value == null || value.isEmpty()) {
                return null;
            }
            if (sqlType == null) {
                return value;
            }
            return switch (sqlType) {
                case Types.TINYINT, Types.SMALLINT, Types.INTEGER, Types.BIGINT -> Long.valueOf(value);
                case Types.DECIMAL, Types.NUMERIC, Types.REAL, Types.FLOAT, Types.DOUBLE -> new BigDecimal(value);
                case Types.BOOLEAN, Types.BIT -> Boolean.valueOf(value);
                case Types.DATE -> LocalDate.parse(value);
                case Types.TIME -> LocalTime.parse(value);
                case Types.TIMESTAMP, Types.TIMESTAMP_WITH_TIMEZONE ->
                        LocalDateTime.parse(value.replace(' ', 'T'));
                default -> value;
            };
        }

        /**
         * ヘッダー付き CSV を読む.
         */
        static List<Map<String, String>> readCsv(Resource csv) {
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(csv.getInputStream(), StandardCharsets.UTF_8))) {
                List<String> lines = reader.lines().filter(line -> !line.isBlank()).toList();
                List<String> columns = Stream.of(lines.getFirst().split(",", -1)).map(String::strip).toList();
                return lines.stream().skip(1).map(line -> {
                    String[] values = line.split(",", -1);
                    Map<String, String> row = new LinkedHashMap<>();
                    for (int i = 0; i < columns.size(); i++) {
                        row.put(columns.get(i), i < values.length ? values[i].strip() : "");
                    }
                    return row;
                }).toList();
            } catch (IOException e) {
                throw new UncheckedIOException("CSV が読めない: " + csv.getDescription(), e);
            }
        }

        /**
         * テーブルの全行を取得する.
         */
        List<Map<String, Object>> selectAll(String table) {
            return jdbc.queryForList("SELECT * FROM " + table);
        }
    }

    /**
     * 標準出力・標準エラーの JSON ログを取り込む.
     */
    static final class JsonLogCapture {

        private final PrintStream originalOut;
        private final PrintStream originalErr;
        private final ByteArrayOutputStream captured = new ByteArrayOutputStream();

        private JsonLogCapture(PrintStream originalOut, PrintStream originalErr) {
            this.originalOut = originalOut;
            this.originalErr = originalErr;
        }

        /**
         * 取り込みを開始する.
         */
        static JsonLogCapture start() {
            JsonLogCapture capture = new JsonLogCapture(System.out, System.err);
            System.setOut(tee(System.out, capture.captured));
            System.setErr(tee(System.err, capture.captured));
            return capture;
        }

        private static PrintStream tee(OutputStream original, OutputStream capture) {
            return new PrintStream(new TeeOutputStream(original, capture), true, StandardCharsets.UTF_8);
        }

        /**
         * 取り込みを終了して出力先を元に戻す.
         */
        void detach() {
            System.out.flush();
            System.err.flush();
            System.setOut(originalOut);
            System.setErr(originalErr);
        }

        /**
         * 取り込んだ JSON ログ.
         */
        List<String> lines() {
            return captured.toString(StandardCharsets.UTF_8).lines()
                    .map(String::strip)
                    .filter(line -> line.startsWith("{"))
                    .filter(JsonLogCapture::isJsonObject)
                    .toList();
        }

        private static boolean isJsonObject(String line) {
            try {
                return TestCaseResources.MAPPER.readTree(line).isObject();
            } catch (JacksonException e) {
                return false;
            }
        }

        /**
         * 書き込みを 2 つの出力先へ流す.
         */
        private static final class TeeOutputStream extends OutputStream {

            private final OutputStream first;
            private final OutputStream second;

            private TeeOutputStream(OutputStream first, OutputStream second) {
                this.first = first;
                this.second = second;
            }

            @Override
            public synchronized void write(int b) throws IOException {
                first.write(b);
                second.write(b);
            }

            @Override
            public synchronized void write(byte[] b, int off, int len) throws IOException {
                first.write(b, off, len);
                second.write(b, off, len);
            }

            @Override
            public void flush() throws IOException {
                first.flush();
                second.flush();
            }
        }
    }

    /**
     * テストクラスと同じパッケージ配下のテスト資材を扱う.
     *
     * <pre>
     * {パッケージ}/ddl/{テーブル名}.sql
     * {パッケージ}/testcases/{ケース名}/
     *   input/{テーブル名}.csv
     *   expected/{テーブル名}.csv
     *   expected/log.json
     *   .env
     * </pre>
     */
    static final class TestCaseResources {

        /**
         * 期待値ログのワイルドカード.
         */
        static final String MASK = "***";

        /**
         * 実行のたびに変わるカラム.
         */
        static final Set<String> IGNORED_DB_COLUMNS = Set.of("upd_dt_tm");

        static final ObjectMapper MAPPER = JsonMapper.builder()
                .enable(SerializationFeature.INDENT_OUTPUT)
                .build();
        private static final PathMatchingResourcePatternResolver RESOLVER = new PathMatchingResourcePatternResolver();

        private final String basePath;
        private final String caseName;

        TestCaseResources(String packageName, String caseName) {
            this.basePath = packageName.replace('.', '/');
            this.caseName = caseName;
        }

        /**
         * テーブルを作り直して input/*.csv を投入する.
         */
        void setUpDatabase(TestDatabase db) {
            ddlResources().values().forEach(db::runScript);
            for (Resource resource : resources("input/*.csv")) {
                db.insert(tableName(resource), db.readCsv(resource));
            }
        }

        /**
         * .env を読む.
         */
        Map<String, Object> environment() {
            Map<String, Object> variables = new LinkedHashMap<>();
            for (String line : read(resource(".env")).lines().map(String::strip).toList()) {
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                String[] keyValue = line.split("=", 2);
                variables.put(keyValue[0].strip(), keyValue.length > 1 ? keyValue[1].strip() : "");
            }
            return variables;
        }

        /**
         * expected/{テーブル名}.csv と DB の内容を突合する.
         */
        void assertDatabase(TestDatabase db) {
            List<Resource> expectedTables = resources("expected/*.csv");
            if (expectedTables.isEmpty()) {
                throw new IllegalStateException("no expected table files for case: " + caseName);
            }
            for (Resource resource : expectedTables) {
                String table = tableName(resource);
                List<Map<String, String>> expected = db.readCsv(resource).stream()
                        .map(TestCaseResources::canonicalRow)
                        .toList();
                Set<String> expectedColumns = expected.isEmpty() ? Set.of() : expected.getFirst().keySet();
                List<Map<String, String>> actual = db.selectAll(table).stream()
                        .map(row -> normalizeRow(row, expectedColumns))
                        .toList();
                assertThat(actual)
                        .as("[%s] table [%s] mismatch.%nexpected:%n%s%nactual:%n%s",
                                caseName, table, toCsv(expected), toCsv(actual))
                        .containsExactlyInAnyOrderElementsOf(expected);
            }
        }

        /**
         * expected/log.json のログが順番どおり含まれていることを確認する.
         */
        void assertLogContains(List<String> jsonLines) {
            List<ObjectNode> actual = parseLogs(jsonLines);
            int from = 0;
            for (JsonNode expected : MAPPER.readTree(read(resource("expected/log.json")))) {
                int found = indexOfMatch(actual, (ObjectNode) expected, from);
                if (found < 0) {
                    throw new AssertionError("[" + caseName + "] expected log not found"
                            + (from > 0 ? " (after the previous one)" : "") + ":\n" + toJson(expected)
                            + "\nactual:\n" + toJson(actual) + "\n");
                }
                from = found + 1;
            }
        }

        /**
         * 出力されたログが expected/log.json と一致することを確認する.
         */
        void assertLogExactly(List<String> jsonLines) {
            List<ObjectNode> actual = parseLogs(jsonLines);
            JsonNode expected = MAPPER.readTree(read(resource("expected/log.json")));
            boolean sameSize = expected.size() == actual.size();
            for (int i = 0; sameSize && i < actual.size(); i++) {
                ObjectNode log = actual.get(i);
                ObjectNode want = (ObjectNode) expected.get(i);
                if (!want.propertyNames().equals(log.propertyNames()) || !matches(want, log)) {
                    sameSize = false;
                }
            }
            if (!sameSize) {
                throw new AssertionError("[" + caseName + "] log mismatch.\nexpected:\n" + toJson(expected)
                        + "\nactual:\n" + toJson(actual) + "\n");
            }
        }

        /**
         * JSON ログを読み、実行のたびに変わる項目を MASK に置き換える.
         */
        private static List<ObjectNode> parseLogs(List<String> jsonLines) {
            List<ObjectNode> logs = new ArrayList<>();
            for (String line : jsonLines) {
                try {
                    logs.add((ObjectNode) MAPPER.readTree(line));
                } catch (JacksonException e) {
                    throw new IllegalStateException("not a JSON log line: " + line, e);
                }
            }
            return logs;
        }

        /**
         * 期待値の項目をすべて満たす最初のログの位置.
         */
        private static int indexOfMatch(List<ObjectNode> actual, ObjectNode expected, int from) {
            for (int i = from; i < actual.size(); i++) {
                if (matches(expected, actual.get(i))) {
                    return i;
                }
            }
            return -1;
        }

        /**
         * 期待値に書かれた項目がすべて一致するか.
         */
        private static boolean matches(ObjectNode expected, ObjectNode log) {
            return expected.properties().stream()
                    .allMatch(field -> valueMatches(field.getValue(), log.get(field.getKey())));
        }

        /**
         * 値が期待値と一致するか.
         */
        private static boolean valueMatches(JsonNode expected, JsonNode actual) {
            if (actual == null) {
                return false;
            }
            if (!expected.isString() || !expected.stringValue().contains(MASK)) {
                return expected.equals(actual);
            }
            String text = actual.isString() ? actual.stringValue() : actual.toString();
            int from = 0;
            for (String part : expected.stringValue().split("\\*\\*\\*", -1)) {
                if (part.isEmpty()) {
                    continue;
                }
                int found = text.indexOf(part, from);
                if (found < 0) {
                    return false;
                }
                from = found + part.length();
            }
            return true;
        }

        /**
         * 日時の表記を揃える.
         */
        private static final Pattern DATE_TIME =
                Pattern.compile("(\\d{4}-\\d{2}-\\d{2})[T ](\\d{2}:\\d{2}:\\d{2})(\\.\\d+)?");

        /**
         * 比較のために値を正規化する.
         */
        private static String canonical(String value) {
            Matcher matcher = DATE_TIME.matcher(value);
            if (!matcher.matches()) {
                return value;
            }
            String fraction = matcher.group(3) == null ? "" : matcher.group(3).replaceAll("0+$", "");
            return matcher.group(1) + " " + matcher.group(2) + (".".equals(fraction) ? "" : fraction);
        }

        /**
         * DB の 1 行を CSV と比較できる形にする.
         */
        private static Map<String, String> normalizeRow(Map<String, Object> row, Set<String> expectedColumns) {
            Map<String, String> normalized = new LinkedHashMap<>();
            row.forEach((column, value) -> {
                String key = column.toLowerCase();
                if (IGNORED_DB_COLUMNS.contains(key) && !expectedColumns.contains(key)) {
                    return;
                }
                normalized.put(key, switch (value) {
                    case null -> "";
                    case Date d -> d.toLocalDate().toString();
                    case Timestamp t -> canonical(t.toLocalDateTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
                    case BigDecimal b -> b.toPlainString();
                    default -> canonical(value.toString());
                });
            });
            return normalized;
        }

        /**
         * ファイル名 → DDL.
         */
        private Map<String, Resource> ddlResources() {
            Map<String, Resource> ddls = new TreeMap<>();
            try {
                for (Resource resource : RESOLVER.getResources("classpath*:" + basePath + "/ddl/*.sql")) {
                    ddls.put(resource.getFilename(), resource);
                }
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
            resources("ddl/*.sql").forEach(resource -> ddls.put(resource.getFilename(), resource));
            if (ddls.isEmpty()) {
                throw new IllegalStateException("no DDL files found under classpath:ddl/");
            }
            return ddls;
        }

        /**
         * 期待値 CSV の 1 行を実際の値と同じ表記に揃える.
         */
        private static Map<String, String> canonicalRow(Map<String, String> row) {
            Map<String, String> canonical = new LinkedHashMap<>();
            row.forEach((column, value) -> canonical.put(column, canonical(value)));
            return canonical;
        }

        /**
         * ケースフォルダ配下のリソースをファイル名順で取得する.
         */
        private List<Resource> resources(String pattern) {
            try {
                List<Resource> list = new ArrayList<>(List.of(
                        RESOLVER.getResources("classpath*:" + basePath + "/testcases/" + caseName + "/" + pattern)));
                list.sort(Comparator.comparing(r -> String.valueOf(r.getFilename())));
                return list;
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }

        /**
         * ケースフォルダ配下の 1 ファイルを取得する.
         */
        private Resource resource(String path) {
            Resource resource = RESOLVER.getResource("classpath:" + basePath + "/testcases/" + caseName + "/" + path);
            if (!resource.exists()) {
                throw new IllegalStateException("resource not found: " + resource.getDescription());
            }
            return resource;
        }

        /**
         * CSV のファイル名からテーブル名を得る.
         */
        private static String tableName(Resource resource) {
            return resource.getFilename().replaceFirst("\\.csv$", "");
        }

        /**
         * CSV 形式の文字列にする.
         */
        private static String toCsv(List<Map<String, String>> rows) {
            if (rows.isEmpty()) {
                return "(no rows)";
            }
            StringBuilder csv = new StringBuilder(String.join(",", rows.getFirst().keySet())).append("\n");
            rows.forEach(row -> csv.append(String.join(",", row.values())).append("\n"));
            return csv.toString();
        }

        /**
         * ファイルを文字列として読む.
         */
        private static String read(Resource resource) {
            try (InputStream in = resource.getInputStream()) {
                return new String(in.readAllBytes(), StandardCharsets.UTF_8);
            } catch (IOException e) {
                throw new UncheckedIOException(e);
            }
        }

        /**
         * JSON 文字列へ変換する.
         */
        private static String toJson(Object value) {
            return MAPPER.writeValueAsString(value);
        }
    }
}
