﻿LAIF016 移行用ファイル (すべてトップに配置)

1. 本番コード
   main_changes.diff を見て、移植先の src/main 配下 8 ファイルに手で反映する
   (DistributeProperties / DistributeInstructRegisterJob / DatabaseUpdater / PermissionSetter / Preprocessor /
    DistributeStatusMapper / DownEquipmentMapper / application.yml)

2. テスト (restore.ps1 で配置)
   PowerShell で次を実行すると、manifest.csv の restore=yes のファイルを元の場所にコピーする (上書き)
     powershell -ExecutionPolicy Bypass -File restore.ps1 -ProjectDir C:\path\to\laif-daemon-bt
   対象: DistributeInstructRegisterJobTest.java、testcases の case_01〜34 (case_24 なし)、testcases の README.md、lombok.config
   env.txt は .env にリネームして配置される

3. 手で確認して反映するもの (restore=no)
   application-test.yml、ddl__*.sql: 移植先にあるものと見比べる
   テストクラスの new JobContext(...) と NoJobParameterException / DuplicateJobParameterException の import は本物に合わせる
   build.gradle.kts に jacoco を追加 (id("jacoco") と jacocoTestReport の設定)

4. 資料 (配置不要)
   UNT-030_LAIF016_kanten.tsv       試験項目書に貼る観点の行
   UNT-030_LAIF016_pre_db.tsv       事前DBデータ
   UNT-030_LAIF016_expected_db.tsv  想定DBデータ
   pre_expected_db.md               上の2つを読みやすくしたもの
   test_README.md                   観点とテストの対応、カバレッジ、設計書との違い
