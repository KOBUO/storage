package jp.co.lawson.laif.bt.daemon.jobs.jobstep.dlaif0100001;

import jp.co.lawson.laif.bt.daemon.jobs.dto.DistributeInstructRegisterJobPreprocessorResult;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DistributeStatus;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DownEquipment;
import jp.co.lawson.laif.bt.daemon.jobs.mapper.DistributeStatusMapper;
import jp.co.lawson.laif.bt.daemon.jobs.mapper.DownEquipmentMapper;
import jp.co.nri.cortixa.batch.core.runner.JobStep;
import jp.co.nri.xpalette.batch.core.exception.JobExecFailedException;
import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeConst.Channel;
import lombok.RequiredArgsConstructor;
import org.jspecify.annotations.NonNull;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * 配信指示登録ジョブの事前処理を行うクラス
 */
@Component
@RequiredArgsConstructor
public class DistributeInstructRegisterJobPreprocessor {

    private final DownEquipmentMapper downEquipmentMapper;
    private final DistributeStatusMapper distributeStatusMapper;

    /**
     * 事前処理を行う。
     *
     * @param distributeAreaCategory 配信エリア種別
     * @return ジョブ事前処理結果
     */
    @JobStep
    public DistributeInstructRegisterJobPreprocessorResult preprocess(
            String distributeAreaCategory) {

        // ダウン機器リストの取得
        List<DownEquipment> downEquipmentList = this.executeDbOperation(
                this.downEquipmentMapper::findAll,
                "ダウン機器リストの取得");

        // 処理対象配信状況リストの取得
        List<DistributeStatus> distributeStatusList = this.executeDbOperation(
                () -> this.distributeStatusMapper.findByDistributeAreaCategory(distributeAreaCategory),
                "処理対象配信状況リストの取得");

        // 配信チャネル・店舗別配信許可中配信状況マップの作成
        Map<Channel, Map<String, List<DistributeStatus>>> permittedDistributeStatusMap = this
                .createPermittedDistributeStatusMap(distributeStatusList, downEquipmentList);

        // 配信チャネル別配信許可設定処理対象マップの作成
        Map<Channel, List<DistributeStatus>> distributePermissionSettingTargetMap = this
                .createDistributePermissionSettingTargetMap(distributeStatusList);

        return new DistributeInstructRegisterJobPreprocessorResult(
                downEquipmentList,
                permittedDistributeStatusMap,
                distributePermissionSettingTargetMap);
    }

    /**
     * DB検索処理を実行する。
     *
     * @param supplier    DB検索処理
     * @param processName 処理名
     * @param <T>         DB検索結果の型
     * @return DB検索結果
     */
    private <T> T executeDbOperation(Supplier<T> supplier, String processName) {
        try {
            return supplier.get();
        } catch (DataAccessException e) {
            String msg = "DB処理でエラーが発生しました。DB処理: " + processName;
            throw new JobExecFailedException(msg, e);
        } catch (Exception e) {
            String msg = "予期せぬ以下の例外が発生しました。Exception=" + e.getClass().getSimpleName();
            throw new JobExecFailedException(msg, e);
        }
    }

    /**
     * 配信チャネル・店舗別配信許可中配信状況マップを作成する。
     * <p>
     * 配信可能な配信状況からダウン機器を除外し、
     * 配信チャネル・店舗コード単位にグルーピングする。
     * </p>
     *
     * @param distributeStatusList 処理対象配信状況リスト
     * @param downEquipmentList    ダウン機器リスト
     * @return 配信チャネル・店舗別配信許可中配信状況マップ
     */
    private Map<Channel, Map<String, List<DistributeStatus>>> createPermittedDistributeStatusMap(
            @NonNull List<DistributeStatus> distributeStatusList,
            List<DownEquipment> downEquipmentList) {
        return distributeStatusList.stream()
                // 配信可否FG が 「1:配信可」 の配信状況を抽出する。
                .filter(status -> "1".equals(status.getDistributeAvailabilityFg()))
                .filter(status -> downEquipmentList.stream()
                        // 店舗コード、機器種別、機器番号がすべて一致するダウン機器が存在する配信状況を除外する。
                        .noneMatch(down -> Objects.equals(status.getStoreCd(),
                                down.getStoreCd())
                                && Objects.equals(status.getEquipmentCategory(),
                                down.getEquipmentCategory())
                                && Objects.equals(status.getEquipmentNo(),
                                down.getEquipmentNo())))
                .collect(Collectors.groupingBy(
                        status -> Channel.codeOf(status.getDistributeChannel()),
                        Collectors.groupingBy(DistributeStatus::getStoreCd)));
    }

    /**
     * 配信チャネル別配信許可設定処理対象マップを作成する。
     * <p>
     * 配信不可の配信状況を抽出し、配信チャネル単位にグルーピングする。
     * </p>
     *
     * @param distributeStatusList 処理対象配信状況リスト
     * @return 配信チャネル別配信許可設定処理対象マップ
     */
    private Map<Channel, List<DistributeStatus>> createDistributePermissionSettingTargetMap(
            @NonNull List<DistributeStatus> distributeStatusList) {
        return distributeStatusList.stream()
                // 配信可否FG が 「0:配信不可」 の配信状況を抽出する。
                .filter(status -> "0".equals(status.getDistributeAvailabilityFg()))
                .collect(Collectors.groupingBy(
                        status -> Channel.codeOf(status.getDistributeChannel())));
    }
}
