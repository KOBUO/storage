﻿param(
    [Parameter(Mandatory = $true)][string]$ProjectDir
)
$ErrorActionPreference = "Stop"
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$rows = Import-Csv -Path (Join-Path $here "manifest.csv") -Encoding UTF8
foreach ($row in $rows) {
    if ($row.restore -ne "yes") { continue }
    $dest = Join-Path $ProjectDir $row.target_path
    $dir = Split-Path -Parent $dest
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Copy-Item -Path (Join-Path $here $row.flat_name) -Destination $dest -Force
    Write-Host "copied: $($row.target_path)"
}
