package jp.co.lawson.laif.bt.daemon.jobs.jobstep.dlaif0100001;

import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeConst.AreaCategory;
import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeConst.Channel;
import jp.co.lawson.laif.bt.daemon.jobs.common.DistributeProperties;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DistributeStatus;
import jp.co.lawson.laif.bt.daemon.jobs.entity.DownEquipment;
import jp.co.nri.cortixa.batch.core.runner.JobStep;
import lombok.RequiredArgsConstructor;
import org.jspecify.annotations.NonNull;
import org.springframework.stereotype.Component;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 配信指示登録ジョブの配信許可設定処理を行うクラス
 */
@Component
@RequiredArgsConstructor
public class DistributeInstructRegisterJobPermissionSetter {

    // 配信チャネルの処理順
    private static final List<Channel> CHANNEL_ORDER = List.of(
            Channel.B,
            Channel.C,
            Channel.A);

    private final DistributeProperties distributeProperties;

    /**
     * 配信許可設定処理の結果。
     */
    private enum PermissionResult {
        PERMITTED, // 配信許可
        SKIPPED, // 処理対象をスキップ
        STOP_CHANNEL // 処理対象チャネルの処理を終了
    }

    /**
     * 処理対象チャネルの配信許可設定に使用する情報を保持する。
     *
     * @param channel                  処理対象の配信チャネル
     * @param transferBandwidth        処理対象チャネルの転送帯域
     * @param bandwidthLimit           処理対象チャネルの帯域上限（チャネルAの場合は未設定）
     * @param permittedByStoreMap      店舗別配信許可中配信状況マップ
     * @param channelBandwidthInUseMap チャネル別使用中帯域マップ
     * @param isLowSpeedStore          低速回線店判定結果
     */
    private record ChannelContext(
            Channel channel,
            int transferBandwidth,
            Optional<Integer> bandwidthLimit,
            Map<String, List<DistributeStatus>> permittedByStoreMap,
            Map<Channel, Integer> channelBandwidthInUseMap,
            boolean isLowSpeedStore) {
    }

    /**
     * 配信許可設定処理を行う。
     * <p>
     * 配信チャネルごとに店舗側同時配信上限およびセンター側配信帯域上限を判定し、
     * 配信許可対象を決定する。
     * </p>
     *
     * @param distributeAreaCategory               配信エリア種別
     * @param downEquipmentList                    ダウン機器リスト
     * @param permittedDistributeStatusMap         配信チャネル・店舗別配信許可中配信状況マップ
     * @param distributePermissionSettingTargetMap 配信チャネル別配信許可設定処理対象マップ
     * @return 配信許可設定済み配信IDリスト
     */
    @JobStep
    public List<Long> getPermittedDistributeIds(
            String distributeAreaCategory,
            List<DownEquipment> downEquipmentList,
            Map<Channel, Map<String, List<DistributeStatus>>> permittedDistributeStatusMap,
            Map<Channel, List<DistributeStatus>> distributePermissionSettingTargetMap) {
        List<Long> permittedDistributeIdList = new ArrayList<>();
        boolean isLowSpeedStore = AreaCategory.LOW_SPEED.matchOf(distributeAreaCategory);
        // チャネル別使用中帯域マップの作成
        Map<Channel, Integer> channelBandwidthInUseMap = this.createChannelBandwidthInUseMap(
                permittedDistributeStatusMap,
                isLowSpeedStore);
        // 配信チャネルをB→C→Aの順に処理
        for (Channel channel : CHANNEL_ORDER) {
            // 処理対象チャネルの転送帯域を取得
            int transferBandwidth = this.getTransferBandwidth(channel);
            // 処理対象チャネルの帯域上限を取得
            Optional<Integer> bandwidthLimit = switch (channel) {
                case A -> Optional.empty(); // チャネルAは帯域上限なし
                case B -> Optional.of(distributeProperties.getBandwidth().getChannelB());
                case C -> Optional.of(distributeProperties.getBandwidth().getChannelC());
            };
            // 店舗別配信許可中配信状況マップを取得
            Map<String, List<DistributeStatus>> permittedByStoreMap = permittedDistributeStatusMap
                    .computeIfAbsent(
                            channel, _ -> new HashMap<>());
            ChannelContext context = new ChannelContext(
                    channel,
                    transferBandwidth,
                    bandwidthLimit,
                    permittedByStoreMap,
                    channelBandwidthInUseMap,
                    isLowSpeedStore);
            // 処理対象チャネルの配信許可設定対象を順に処理
            for (DistributeStatus target : distributePermissionSettingTargetMap.getOrDefault(
                    channel, List.of())) {
                PermissionResult result = this.processPermissionTarget(
                        context, target,
                        downEquipmentList);
                // センター側帯域上限到達時は、処理対象チャネルの処理を終了
                if (result == PermissionResult.STOP_CHANNEL) {
                    break;
                }
                // 配信許可対象の場合、配信IDを追加
                if (result == PermissionResult.PERMITTED) {
                    permittedDistributeIdList.add(target.getDistributeId());
                }
            }
        }
        return permittedDistributeIdList;
    }

    /**
     * 配信許可設定対象1件の配信許可判定および関連情報の更新を行う。
     * <p>
     * ダウン機器、店舗側同時配信上限、センター側配信帯域上限を判定し、
     * 配信許可、スキップ、または処理対象チャネル終了を決定する。
     * 配信許可の場合は、配信許可中機器情報および使用中帯域を更新する。
     * </p>
     *
     * @param context           処理対象チャネルの配信許可設定情報
     * @param target            配信許可設定対象の配信状況
     * @param downEquipmentList ダウン機器リスト
     * @return 配信許可設定処理結果
     */
    private PermissionResult processPermissionTarget(
            ChannelContext context,
            DistributeStatus target,
            List<DownEquipment> downEquipmentList) {
        // ダウン機器は各種上限判定を行わず配信許可
        if (this.isDownEquipment(target, downEquipmentList)) {
            return PermissionResult.PERMITTED;
        }
        // 店舗別配信許可中の配信状況リストを取得
        List<DistributeStatus> permittedByStoreList = context.permittedByStoreMap.computeIfAbsent(
                target.getStoreCd(),
                _ -> new ArrayList<>());
        // 店舗側同時配信上限に到達している場合は処理対象をスキップ
        if (this.isStoreLimitReached(
                context.channel,
                permittedByStoreList,
                context.isLowSpeedStore)) {
            return PermissionResult.SKIPPED;
        }
        // センター側配信帯域上限に到達している場合は処理対象チャネルを終了
        if (!context.isLowSpeedStore
                && this.isBandwidthLimitReached(
                context.channel,
                context.transferBandwidth,
                context.bandwidthLimit,
                context.channelBandwidthInUseMap)) {
            return PermissionResult.STOP_CHANNEL;
        }
        // 配信許可に伴う使用中帯域を更新
        this.updateBandwidthInUse(
                context.channel,
                target,
                context.transferBandwidth,
                permittedByStoreList,
                context.channelBandwidthInUseMap,
                context.isLowSpeedStore);
        // 配信許可中機器情報を更新
        permittedByStoreList.add(target);
        return PermissionResult.PERMITTED;
    }

    /**
     * 処理対象がダウン機器に該当するか判定する。
     * <p>
     * 店舗コード、機器種別、機器番号がすべて一致するダウン機器が存在する場合、
     * ダウン機器と判定する。
     * </p>
     *
     * @param target            配信許可設定対象の配信状況
     * @param downEquipmentList ダウン機器リスト
     * @return ダウン機器に該当する場合true
     */
    private boolean isDownEquipment(
            DistributeStatus target,
            List<DownEquipment> downEquipmentList) {
        return downEquipmentList.stream()
                .anyMatch(down -> Objects.equals(target.getStoreCd(), down.getStoreCd())
                        && Objects.equals(target.getEquipmentCategory(),
                        down.getEquipmentCategory())
                        && Objects.equals(target.getEquipmentNo(), down.getEquipmentNo()));
    }

    /**
     * 配信許可に伴い、チャネル別使用中帯域を更新する。
     * <p>
     * 同一機器がすでに配信許可中の場合は帯域を重複加算しない。
     * 低速回線店はセンター側配信帯域制御の対象外のため更新しない。
     * </p>
     *
     * @param channel                  処理対象の配信チャネル
     * @param target                   配信許可設定対象の配信状況
     * @param transferBandwidth        処理対象チャネルの転送帯域
     * @param permittedByStoreList     店舗別配信許可中配信状況リスト
     * @param channelBandwidthInUseMap チャネル別使用中帯域マップ
     * @param isLowSpeedStore          低速回線店判定結果
     */
    private void updateBandwidthInUse(
            Channel channel,
            DistributeStatus target,
            int transferBandwidth,
            List<DistributeStatus> permittedByStoreList,
            Map<Channel, Integer> channelBandwidthInUseMap,
            boolean isLowSpeedStore) {
        // 低速回線店はセンター側配信帯域制御の対象外
        if (isLowSpeedStore) {
            return;
        }
        // 同一機器（機器種別・機器番号）が配信許可中か判定
        boolean alreadyPermitted = permittedByStoreList.stream()
                .anyMatch(status -> Objects.equals(
                        status.getEquipmentCategory(),
                        target.getEquipmentCategory())
                        && Objects.equals(
                        status.getEquipmentNo(),
                        target.getEquipmentNo()));
        // 同一機器は既に帯域をカウント済みのため重複加算しない
        if (!alreadyPermitted) {
            channelBandwidthInUseMap.merge(
                    channel,
                    transferBandwidth,
                    Integer::sum);
        }
    }

    /**
     * チャネル別使用中帯域マップを作成する。
     * <p>
     * 低速回線店の場合、空のマップを返却する。
     * 低速回線店以外の場合、配信チャネルごとに配信許可中機器数をカウントし、
     * 配信許可中機器数と対象チャネルの転送帯域から使用中帯域を算出する。
     * </p>
     *
     * @param permittedDistributeStatusMap 配信チャネル・店舗別配信許可中配信状況マップ
     * @param isLowSpeedStore              低速回線店判定結果
     * @return チャネル別使用中帯域マップ
     */
    private Map<Channel, Integer> createChannelBandwidthInUseMap(
            Map<Channel, Map<String, List<DistributeStatus>>> permittedDistributeStatusMap,
            boolean isLowSpeedStore) {
        if (isLowSpeedStore) {
            // 低速回線店はセンター側配信帯域上限判定の対象外
            return new EnumMap<>(Channel.class);
        }
        // 配信チャネル別の配信許可中機器数をカウント
        Map<Channel, Integer> permittedEquipmentCountMap = permittedDistributeStatusMap.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey,
                        e -> e.getValue().values().stream()
                                .mapToInt(list -> this.countPermittedEquipment(list,
                                        false))
                                .sum()));
        // 配信許可中機器数と対象チャネルの転送帯域から使用中帯域を算出
        return permittedEquipmentCountMap.entrySet().stream()
                .collect(Collectors.toMap(Map.Entry::getKey,
                        // 使用中帯域 = 配信許可中機器数 × 対象の配信チャネルに対応する転送帯域
                        e -> e.getValue()
                                * this.getTransferBandwidth(e.getKey())));
    }

    /**
     * 配信チャネルに対応する転送帯域を取得する。
     *
     * @param channel 配信チャネル（null不可）
     * @return 転送帯域
     */
    private int getTransferBandwidth(@NonNull Channel channel) {
        return switch (channel) {
            case A -> this.distributeProperties.getTransferBand().getChannelA();
            case B -> this.distributeProperties.getTransferBand().getChannelB();
            case C -> this.distributeProperties.getTransferBand().getChannelC();
        };
    }

    /**
     * 店舗側の同時配信機器数が上限に到達しているか判定する。
     *
     * @param channel              配信チャネル
     * @param permittedByStoreList 店舗別配信許可中配信状況リスト
     * @param isLowSpeedStore      低速回線店判定結果
     * @return 上限到達の場合 true
     */
    private boolean isStoreLimitReached(
            Channel channel,
            List<DistributeStatus> permittedByStoreList,
            boolean isLowSpeedStore) {
        // 店舗の配信許可中機器数を取得
        int permittedEquipmentCount = this.countPermittedEquipment(permittedByStoreList, isLowSpeedStore);
        // 店舗の同時配信機器数上限を取得
        int simultaneousEquipmentLimit;
        if (isLowSpeedStore) {
            simultaneousEquipmentLimit = distributeProperties.getSimulEquipment().getLowSpeed();
        } else {
            simultaneousEquipmentLimit = switch (channel) {
                case A -> distributeProperties.getSimulEquipment().getChannelA();
                case B -> distributeProperties.getSimulEquipment().getChannelB();
                case C -> distributeProperties.getSimulEquipment().getChannelC();
            };
        }
        // 店舗の同時配信機器数が上限に到達しているか判定
        return permittedEquipmentCount >= simultaneousEquipmentLimit;
    }

    /**
     * センター側の配信帯域が上限に到達しているか判定する。
     *
     * @param channel                  配信チャネル
     * @param transferBandwidth        チャネル別転送帯域
     * @param bandwidthLimit           チャネル別帯域上限（チャネルAの場合、Optinal.empty()）
     * @param channelBandwidthInUseMap チャネル別使用中帯域マップ（null不可）
     * @return 上限到達の場合 true
     */
    @SuppressWarnings("OptionalUsedAsFieldOrParameterType")
    private boolean isBandwidthLimitReached(
            Channel channel,
            int transferBandwidth,
            Optional<Integer> bandwidthLimit,
            @NonNull Map<Channel, Integer> channelBandwidthInUseMap) {
        // 転送帯域が0の場合、帯域を使用しないため帯域上限未到達
        if (transferBandwidth == 0) {
            return false;
        }
        // 全チャネルの使用中帯域を合算
        int bandwidthInUse = channelBandwidthInUseMap.values().stream()
                .mapToInt(Integer::intValue)
                .sum();
        // 全体の帯域上限から残配可能数を算出
        int availableBandwidth = distributeProperties.getBandwidth().getOverall() - bandwidthInUse;
        int remainingCount = availableBandwidth / transferBandwidth;
        // 全体の帯域上限に到達しているか判定
        if (remainingCount <= 0) {
            return true;
        }
        // チャネル別帯域上限が設定されている場合
        if (bandwidthLimit.isPresent()) {
            // 処理対象のチャネルの使用中帯域を取得
            int channelBandwidthInUse = channelBandwidthInUseMap.getOrDefault(channel, 0);
            // 処理対象のチャネルの帯域上限から残配可能数を算出
            int channelAvailableBandwidth = bandwidthLimit.get() - channelBandwidthInUse;
            int channelRemainingCount = channelAvailableBandwidth / transferBandwidth;
            // 処理対象のチャネルの帯域上限に到達しているか判定
            return channelRemainingCount <= 0;
        }
        // 全体・チャネル別ともに帯域上限未到達
        return false;
    }

    /**
     * 配信許可中の機器数を取得する。
     * <p>
     * 低速回線店の場合: 配信状況1レコードを1機器としてカウントする。
     * 低速回線店以外の場合: 店舗コード、機器種別、機器番号が同一のレコードを1機器としてカウントする。
     * </p>
     *
     * @param distributeStatusList 配信状況リスト
     * @param isLowSpeedStore      低速回線店判定結果
     * @return 配信許可中機器数
     */
    private int countPermittedEquipment(
            List<DistributeStatus> distributeStatusList,
            boolean isLowSpeedStore) {
        if (isLowSpeedStore) {
            return distributeStatusList.size();
        }
        return (int) distributeStatusList.stream()
                // 店舗コードは店舗別マップでグルーピング済みのため、
                // 機器種別・機器番号の組み合わせで重複排除
                .map(status -> new AbstractMap.SimpleImmutableEntry<>(
                        status.getEquipmentCategory(),
                        status.getEquipmentNo()))
                .distinct()
                .count();
    }
}
