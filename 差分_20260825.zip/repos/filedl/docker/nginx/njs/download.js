var BANDWIDTH_HEADER = 'X-BandWidth-Limit';
var POS_VERSION_PARAMETER = 'posVersion';
var CONTEXT_PATH = '/download/';
var OFFLINE_PATH = '/download/offline/';

// 1Mbps = 125,000 バイト毎秒。上限は換算後も指数表記にならない範囲に収める。
var BYTES_PER_SECOND_PER_MBPS = 125000;
var MAX_BANDWIDTH_MBPS = 100000;

// POSバージョンはオブジェクトキーの一部になるため、URL安全な文字のみ許容する。
var POS_VERSION_PATTERN = /^[0-9A-Za-z._-]+$/;

// message はログ出力用。generatedByNginx は error_page 経由で差し替える対象を示す。
var ERRORS = {
    bandwidth_missing:   { status: 400, message: '帯域制限値が設定されていません。' },
    bandwidth_invalid:   { status: 400, message: '帯域制限値が不正です。' },
    pos_version_missing: { status: 400, message: 'POSバージョンが設定されていません。' },
    pos_version_invalid: { status: 400, message: 'POSバージョンが不正です。' },
    method_not_allowed:  { status: 405, message: '許可されていないメソッドです。' },
    path_not_supported:  { status: 404, message: '対象外のパスです。', generatedByNginx: true },
    request_invalid:     { status: 400, message: 'リクエストが不正です。', generatedByNginx: true },
    uri_too_long:        { status: 414, message: 'リクエストURIが上限を超えました。', generatedByNginx: true },
    version_unsupported: { status: 505, message: '対応していない通信プロトコルです。', generatedByNginx: true },
    encoding_unsupported:{ status: 501, message: '対応していない転送符号化です。', generatedByNginx: true },
    limit_exceeded:      { status: 503, message: '同時ダウンロード数が上限を超えました。', generatedByNginx: true },
    s3_unreachable:      { status: 502, message: 'S3 へ接続できません。', generatedByNginx: true },
    s3_timeout:          { status: 504, message: 'S3 からの応答がタイムアウトしました。', generatedByNginx: true },
    internal_error:      { status: 500, message: 'サーバ内部でエラーが発生しました。', generatedByNginx: true },
};

var REASON_PHRASES = {
    400: 'Bad Request',
    404: 'Not Found',
    405: 'Method Not Allowed',
    412: 'Precondition Failed',
    414: 'URI Too Long',
    416: 'Range Not Satisfiable',
    500: 'Internal Server Error',
    501: 'Not Implemented',
    502: 'Bad Gateway',
    503: 'Service Unavailable',
    504: 'Gateway Timeout',
    505: 'HTTP Version Not Supported',
};

function nginxErrorCodeOf(status) {
    for (var code in ERRORS) {
        if (ERRORS[code].generatedByNginx && ERRORS[code].status === status) {
            return code;
        }
    }
    return null;
}

function respondError(r, code) {
    var error = ERRORS[code];
    var status = String(error.status);
    r.variables.error_code = code;
    r.headersOut['Content-Type'] = 'application/json';
    r.return(error.status, JSON.stringify({
        apiStatus: status,
        errors: [{ validationErrCd: status, validationMessage: REASON_PHRASES[error.status] }],
    }));
}

// エンコードを保持したまま扱うため、生のリクエストURI（$request_uri）をパスとクエリに分割する。
function splitRequestUri(r) {
    var raw = r.variables.request_uri;
    var separator = raw.indexOf('?');
    return {
        path: separator < 0 ? raw : raw.substring(0, separator),
        query: separator < 0 ? '' : raw.substring(separator + 1),
    };
}

// posVersion の値を読むためにクエリを解釈する（$args 由来のため値は生・未デコード）。
function queryValue(r, name) {
    var found = null;
    (r.variables.args || '').split('&').forEach(function (pair) {
        var separator = pair.indexOf('=');
        var key = separator < 0 ? pair : pair.substring(0, separator);
        if (key === name) {
            found = separator < 0 ? '' : pair.substring(separator + 1);
        }
    });
    return found;
}

// 指定パラメータを生のクエリ文字列から除去する。
function removeRawParam(rawQuery, name) {
    var kept = rawQuery.split('&').filter(function (pair) {
        if (!pair) {
            return false;
        }
        var separator = pair.indexOf('=');
        var key = separator < 0 ? pair : pair.substring(0, separator);
        return key !== name;
    });
    return kept.length ? '?' + kept.join('&') : '';
}

function handle(r) {
    if (r.method !== 'GET' && r.method !== 'HEAD') {
        respondError(r, 'method_not_allowed');
        return;
    }

    var bandwidth = r.headersIn[BANDWIDTH_HEADER];
    if (!bandwidth) {
        respondError(r, 'bandwidth_missing');
        return;
    }
    if (!/^[0-9]+$/.test(bandwidth) || Number(bandwidth) > MAX_BANDWIDTH_MBPS) {
        respondError(r, 'bandwidth_invalid');
        return;
    }

    if (!r.uri.startsWith(CONTEXT_PATH)) {
        respondError(r, 'path_not_supported');
        return;
    }

    var raw = splitRequestUri(r);
    var key;
    if (r.uri.startsWith(OFFLINE_PATH)) {
        var posVersion = queryValue(r, POS_VERSION_PARAMETER);
        if (!posVersion) {
            respondError(r, 'pos_version_missing');
            return;
        }
        if (!POS_VERSION_PATTERN.test(posVersion)) {
            respondError(r, 'pos_version_invalid');
            return;
        }
        var fileName = raw.path.substring(OFFLINE_PATH.length);
        key = '/' + r.variables.offline_bucket + '/' + posVersion + '/' + fileName;
        r.variables.s3_args = removeRawParam(raw.query, POS_VERSION_PARAMETER);
    } else {
        key = raw.path.substring(CONTEXT_PATH.length - 1);
        r.variables.s3_args = raw.query ? '?' + raw.query : '';
    }

    // 0 は無制限（limit_rate 0 の仕様）。それ以外は Mbps をバイト毎秒へ換算する。
    r.variables.limit_rate = String(Number(bandwidth) * BYTES_PER_SECOND_PER_MBPS);
    r.variables.s3_key = key;
    r.internalRedirect('@s3');
}

// error_page からの呼び出し時点では r.status が未確定のため、$status から元の応答コードを取る。
function errorResponse(r) {
    var code = nginxErrorCodeOf(Number(r.variables.status));
    respondError(r, code || 'internal_error');
}

// 上流の応答を受けた後に生成されるエラーは error_page を経由せず、上流が返したエラーと区別できない。
// 上流が返しうる範囲を超えるものだけをエラーとして扱う。
var UNJUDGEABLE_STATUSES = [412, 416];

function isUnjudgeable(r) {
    return UNJUDGEABLE_STATUSES.indexOf(Number(r.variables.status)) !== -1;
}

function logLevel(r) {
    return (r.variables.error_code || isUnjudgeable(r)) ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    var code = r.variables.error_code;
    if (code) {
        return ERRORS[code].message;
    }
    return isUnjudgeable(r) ? '想定外のエラーが発生しました。' : '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { handle, errorResponse, logLevel, logMessage, logLatency, logTimestamp };
