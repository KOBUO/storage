# 試験ケース（AWS） — ファイルダウンロード

- 設計根拠: ファイルダウンロード.md
- 対象実装: 本リポジトリの `docker/`
- 実施環境: AWS（ECS Fargate）。ログは CloudWatch Logs で確認する。
- 前提: ダウンロードURLは API が発行する path-style の素のURL（署名なし）。ホスト名を nginx に置換して実行する。アクセス認可はバケットポリシー（VPCエンドポイント経由）で行う。
- 証跡取得時は接続先を直書きせず、事前に `接続先=http://<実際の接続先>` を実行（この行は証跡に含めない）し、`curl -i "$接続先/…"` の形で実行する。

検証データ（`test/s3/` と同じ配置）:
- オンライン: 対象バケットに `hello.txt`
- オフライン: `OFFLINE_BUCKET` に `2.0.0/fixed.txt`（`posVersion=2.0.0`・固定ファイル名 `fixed.txt`）
- 存在しない: `nonexistent.bin` は配置しない

---

## ケース1 ファイルが S3 から中継されること

- **手順**（`<バケット>` は対象の S3 バケット名）:
  ```sh
  curl -i "$接続先/health"
  curl -i -H 'X-BandWidth-Limit: 800' "$接続先/download/<バケット>/hello.txt"
  curl -i -H 'X-BandWidth-Limit: 800' "$接続先/download/offline/fixed.txt?posVersion=2.0.0"
  curl -i -H 'X-BandWidth-Limit: 8'   "$接続先/download/<バケット>/nonexistent.bin"
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 1-1 | 起動成功・コンテナ情報の取得 | タスク起動成功。ログの `id`=コンテナID / `name`=コンテナ名（タスクメタデータ由来） | |
| 1-2 | ヘルスチェック | `/health` が 200 `ok`（アクセスログに出力されない） | |
| 1-3 | オンラインファイルの中継 | `hello.txt` が 200・取得ファイルが元と一致（Host置換・VPCエンドポイント経由・バケットポリシー認可で S3 へ中継） | |
| 1-4 | オフラインファイルの中継 | `posVersion=2.0.0` により S3キー=`/<OFFLINE_BUCKET>/2.0.0/fixed.txt` で 200。転送時のクエリから `posVersion` は除去 | |
| 1-5 | S3エラーの透過 | `nonexistent.bin` は S3 が 403 を返す。ステータス・本文（XML）とも加工せず返却 | |
| 1-6 | 正常アクセスのログ項目 | level=INFO / type=app / url（クエリ込み）/ status / latency / timestamp=JST | |
