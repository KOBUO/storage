# 試験ケース（ローカル） — ファイルダウンロード

- 設計根拠: ファイルダウンロード.md
- 対象実装: 本リポジトリの `docker/`
- 実施環境: ローカル Docker（上流は S3 代替のスタブ）。実施日時のシステム日付・JST で採取。
- 証跡: `local/証跡/` に、ケースごとに実行ログ（コンソール）とコンテナログ（nginx の標準出力・標準エラー）を格納。
- エラー電文 = `{"apiStatus":"<code>","errors":[{"validationErrCd":"<code>","validationMessage":"<reason>"}]}`

---

## ケース1 リクエストが不正な場合、エラー電文が返ること

- **手順**:
  ```sh
  curl -i "$接続先/download/<バケット>/file.bin"                          # 帯域制限値ヘッダ欠落
  curl -i -H 'X-BandWidth-Limit: abc' "$接続先/download/<バケット>/file.bin"     # 数値でない
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/other/x"                     # 対象外パス
  curl -i -H 'X-BandWidth-Limit: 100001' "$接続先/download/<バケット>/file.bin"  # 上限超過
  curl -i -X POST -H 'X-BandWidth-Limit: 8' "$接続先/download/<バケット>/file.bin"  # GET/HEAD 以外
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/<固定ファイル名>"                    # posVersion欠落
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/<固定ファイル名>?posVersion=..%2Fx" # posVersion不正
  ```

| # | 観点 | 返却ステータス | ログ（level=ERROR）の message | 結果 |
|---|------|:---:|------|------|
| 1-1 | 帯域制限値ヘッダ欠落 | **400** | 帯域制限値が設定されていません。 | 代替済 |
| 1-2 | 帯域制限値が数値でない | **400** | 帯域制限値が不正です。 | 代替済 |
| 1-3 | 対象外パス | **404** | 対象外のパスです。 | 代替済 |
| 1-4 | 帯域制限値が上限（`100000`）超過 | **400** | 帯域制限値が不正です。 | 代替済 |
| 1-5 | GET/HEAD 以外のメソッド | **405** | 許可されていないメソッドです。 | 代替済 |
| 1-6 | posVersion 欠落（オフライン） | **400** | POSバージョンが設定されていません。 | 代替済 |
| 1-7 | posVersion 不正（オフライン） | **400** | POSバージョンが不正です。 | 代替済 |

## ケース2 帯域制御が効き、取得内容が一致すること

- **条件**: 上流に 3MB の検証用ファイル（`large.bin`）を配置する。
- **手順**:
  ```sh
  curl -s -o /dev/null -w '8Mbps: %{time_total}s\n'   -H 'X-BandWidth-Limit: 8'   "$接続先/download/<バケット>/large.bin"
  curl -s -o /dev/null -w '800Mbps: %{time_total}s\n' -H 'X-BandWidth-Limit: 800' "$接続先/download/<バケット>/large.bin"
  curl -s -H 'X-BandWidth-Limit: 800' -o out.bin "$接続先/download/<バケット>/large.bin"
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 2-1 | 帯域制御（Mbps→バイト/秒 換算） | `8` 指定は 3MB で約3秒、`800` 指定はほぼ即時 | 代替済 |
| 2-2 | 取得内容の一致 | 取得ファイルが元と一致する | 代替済 |

## ケース3 低速クライアントでも転送ファイルがディスクへ退避しないこと

- **条件**: 上流に 3MB の検証用ファイルを配置する。
- **手順**: 低速（`X-BandWidth-Limit: 1`）でダウンロードし、転送中に一時ファイル領域を確認する。
  ```sh
  curl -s -H 'X-BandWidth-Limit: 1' -o /dev/null "$接続先/download/<バケット>/large.bin" &
  docker exec <コンテナ> du -sb /var/cache/nginx/proxy_temp
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 3-1 | ディスクへ退避しないこと | 転送中も `proxy_temp` にファイルが作られない（`proxy_max_temp_file_size 0` の効果） | 代替済 |
