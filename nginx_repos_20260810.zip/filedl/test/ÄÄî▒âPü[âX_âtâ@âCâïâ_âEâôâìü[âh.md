# 試験ケース — ファイルダウンロード

- 設計根拠: ファイルダウンロード.md
- 対象実装: 本リポジトリの `docker/`
- 前提: ダウンロードURLは API が発行する path-style の素のURL（署名なし）。ホスト名を nginx に置換して実行する。アクセス認可はバケットポリシー（VPCエンドポイント経由）で行う。
- エラー電文 = `{"apiStatus":"<code>","errors":[{"validationErrCd":"<code>","validationMessage":"<reason>"}]}`
- 証跡取得時は接続先を直書きせず、事前に `接続先=http://<実際の接続先>` を実行（この行は証跡に含めない）し、
  `curl -i "$接続先/…"` の形で実行する。

---

## ケース1 ファイルが帯域制限つきでダウンロードできること

- **条件**: 通常のタスク定義でデプロイ。S3 に 3MB 程度の検証用ファイル（`head -c 3000000 /dev/zero > large.bin`）を配置する。
  `URL=http://<接続先>/download/<バケット>/large.bin`（ホストは nginx）を事前に設定して使う。
- **手順**:
  ```sh
  curl -s -H 'X-BandWidth-Limit: 8' -o out.bin "$URL"   # 取得後 large.bin と一致を確認
  curl -s -o /dev/null -w '8Mbps: %{time_total}s\n'   -H 'X-BandWidth-Limit: 8'   "$URL"
  curl -s -o /dev/null -w '800Mbps: %{time_total}s\n' -H 'X-BandWidth-Limit: 800' "$URL"
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 1-1 | 起動成功・コンテナ情報の取得 | タスク起動成功。ログの `id`/`name` にタスクメタデータ由来の値 | 起動は代替済（id/name は Fargate でのみ確認可） |
| 1-2 | **実S3でのダウンロード（Host置換でS3へ中継）** | 200・取得ファイルが元と一致 | 代替済（MinIO。実S3は AWS で） |
| 1-3 | 帯域制御（Mbps→バイト/秒 換算） | `8` 指定 ≒ サイズ(MB)÷1 秒（3MBなら約3秒）。`800` 指定は即時 | 代替済（3.2s/0.016s） |
| 1-4 | 正常ログ項目 | level=INFO / type=app / **url はクエリ込みで出力（秘匿情報を含まない）**/ status=200 / latency(ms) / timestamp=JSTミリ秒 | 代替済 |

## ケース2 帯域制限値ヘッダやパスが不正な場合、エラー電文が返ること

- **手順**（各行が下表の番号に対応）:
  ```sh
  curl -i "$URL"                                              # 2-1 帯域制限値ヘッダ無し
  curl -i -H 'X-BandWidth-Limit: abc' "$URL"                  # 2-2 数値でない
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/other/x"         # 2-3 対象外パス
  curl -i -H 'X-BandWidth-Limit: 100001' "$URL"              # 2-4 上限(100000)超過
  curl -i -X POST -H 'X-BandWidth-Limit: 8' "$URL"           # 2-5 GET/HEAD 以外
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/fixed.txt?posVersion=..%2Fx"  # 2-6 posVersion 不正
  ```

  ※ 応答電文の `validationMessage` は英語のリーズンフレーズ、ログの `message` は日本語。両者は別物。

| # | 観点 | 返却ステータス | 応答電文 `validationMessage` | ログ（level=ERROR）の message | 結果 |
|---|------|:---:|------|------|------|
| 2-1 | 帯域制限値ヘッダ欠落 | **400** | `Bad Request` | 帯域制限値が設定されていません。 | 代替済 |
| 2-2 | 帯域制限値が数値でない（`abc`） | **400** | `Bad Request` | 帯域制限値が不正です。 | 代替済 |
| 2-3 | 対象外パス（`/other/x`） | **404** | `Not Found` | 対象外のパスです。 | 代替済 |
| 2-4 | 帯域制限値が上限（`100000`）超過 | **400** | `Bad Request` | 帯域制限値が不正です。 | 代替済 |
| 2-5 | GET/HEAD 以外（POST） | **405** | `Method Not Allowed` | 許可されていないメソッドです。 | 代替済 |
| 2-6 | posVersion が不正（`../` 等） | **400** | `Bad Request` | POSバージョンが不正です。 | 代替済 |

## ケース3 S3が返したエラーが加工されずに返却されること

- **手順**: 存在しない、またはバケットポリシーで許可されていないオブジェクトを要求して実行。
  ```sh
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/<バケット>/nonexistent.bin"
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 3-1 | S3エラーの透過 | S3 の **403（`AccessDenied`）/404（`NoSuchKey`）** をステータス・本文（XML）とも加工せず返却。Content-Type も S3 のまま | 代替済 |
| 3-2 | S3起因エラーのログ | level=**INFO**（nginxとしては正常処理。message=`-`） | 代替済 |

## ケース4（任意）オフラインファイルがダウンロードできること

- **条件**: オフライン用バケット（`OFFLINE_BUCKET`）に s3/offline/2.0.0/fixed.txt を
  キー `2.0.0/fixed.txt` で配置する。
- **手順**:
  ```sh
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/<固定ファイル名>?posVersion=2.0.0"
  curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/<固定ファイル名>"   # posVersion無し
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 4-1 | オブジェクトキーの組み立て | 200。S3キー=`/<OFFLINE_BUCKET>/2.0.0/<固定名>`、転送時のクエリから `posVersion` は除去 | 代替済 |
| 4-2 | posVersion 欠落 | 400 + エラー電文。ログ ERROR「POSバージョンが設定されていません。」 | 代替済 |

## ケース5 低速クライアントでも転送ファイルが Nginx 内に溜まり続けないこと

- **背景**: `proxy_buffering on`（`limit_rate` に必須）では、クライアントの受信が遅いと Nginx が上流から
  先読みした分を保持する。既定ではバッファ超過分をディスクの一時ファイルに退避するが、本実装は
  `proxy_max_temp_file_size 0`（固定）で退避しない。メモリ保持は `proxy_buffers` 分に限定される。
- **確認方法**: これは Nginx の設定挙動で、AWS・代替環境とも同一。ECS Exec が使えないため、`docker exec` で
  内部を確認できる代替環境で検証する（AWS 本番では `proxy_max_temp_file_size 0` の固定で担保）。
- **手順**（代替環境）: 3MB のファイルを低速（`limit_rate` で 1Mbps 相当）で取得し、転送中に一時ファイル領域を観察する。
  3MB は `proxy_buffers`（既定 約64KB）を十分超えるため、退避が既定なら本来ディスクに書かれる状況になる。
  ```sh
  docker exec <filedlコンテナ> du -sh /var/cache/nginx/proxy_temp   # 転送中に繰り返し確認
  ```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 5-1 | ディスクへ退避しないこと | 転送中も `proxy_temp` にファイルが作られない（0 のまま）。`proxy_max_temp_file_size 0` の効果 | 代替済（同一ディレクティブで確認。既定設定では一時ファイルが出現することも対比確認） |
| 5-2 | ファイルの完全性 | 低速でも最終的に全量を取得でき、内容が一致する | 代替済 |

---

> 追加検証済（代替）: 同時ダウンロード数上限(`LIMIT_CONNECTION`)超過で503 / 日本語・空白キーのエンコード保持でキー破損なし / S3への余計なヘッダ(Cookie/Authorization/X-BandWidth-Limit)除去 / 上流DNSの都度再解決(resolve)。
>
> 対象外: S3接続不可502／応答タイムアウト504（実S3では再現困難。njsとerror_pageの機構は電文受付と同一で代替環境確認済み）／
> 起動異常系（必須env検証は電文受付・本部画面と同一実装。ローカル確認で足りる）／帯域 `0`=無制限（`limit_rate 0` の nginx 仕様）。
