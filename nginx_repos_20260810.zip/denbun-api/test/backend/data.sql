-- 試験ケース_電文受付 ケース1（適用期間・適用開始日時の閾値）の検証データ。
-- 000002: 適用期間内 / 000003: 適用終了が過去（期間外）/ 000004: 適用開始が未来（期間前）
INSERT INTO laif_routing_info
    (store_cd, request_context_path, request_ver, routing_dest_ver,
     appl_start_dt_tm, appl_end_dt_tm, entry_dt_tm, creator_id)
VALUES
    ('000002', 'order', 'v1', 'v2', TIMESTAMP '2026-01-01 00:00:00', NULL,                              CURRENT_TIMESTAMP, 'test'),
    ('000003', 'order', 'v1', 'v2', TIMESTAMP '2026-01-01 00:00:00', TIMESTAMP '2026-06-30 23:59:59',   CURRENT_TIMESTAMP, 'test'),
    ('000004', 'order', 'v1', 'v2', TIMESTAMP '2099-01-01 00:00:00', NULL,                              CURRENT_TIMESTAMP, 'test');

-- デフォルト: 現行世代 v1 + 将来世代 v2（2099年。到来までは使われないことの確認用）
INSERT INTO laif_default_routing
    (request_context_path, request_ver, routing_dest_ver, appl_start_dt_tm, entry_dt_tm, creator_id)
VALUES
    ('order', 'v1', 'v1', TIMESTAMP '2026-01-01 00:00:00', CURRENT_TIMESTAMP, 'test'),
    ('order', 'v1', 'v2', TIMESTAMP '2099-01-01 00:00:00', CURRENT_TIMESTAMP, 'test');
