plugins {
    java
    // ライブラリなので Spring Boot プラグイン（bootJar/実行可能 jar）は適用しない。
    `java-library`
    // バージョンを Spring Boot / Spring Cloud AWS の BOM で揃えるため dependency-management を使う。
    id("io.spring.dependency-management") version "1.1.7"
}

group = "jp.co.xxx.common.app"
version = "0.0.1-SNAPSHOT"

java {
    toolchain {
        // ルート/ tranning と同じ Amazon Corretto 25。
        languageVersion = JavaLanguageVersion.of(25)
    }
}

// メソッド引数名を保持（AspectJ CodeSignature.getParameterNames 用）。
tasks.withType<JavaCompile>().configureEach {
    options.compilerArgs.add("-parameters")
}

val springBootVersion = "4.0.6"
val springCloudAwsVersion = "4.0.2"

repositories {
    mavenCentral()
}

dependencyManagement {
    imports {
        mavenBom("org.springframework.boot:spring-boot-dependencies:$springBootVersion")
        mavenBom("io.awspring.cloud:spring-cloud-aws-dependencies:$springCloudAwsVersion")
    }
}

dependencies {
    // ドロップイン方針：このライブラリを依存追加するだけでログ部品が効くよう、必要な実装依存を api で公開する。
    api("org.springframework.boot:spring-boot-starter-web")        // Filter / HandlerMethod / RestClient
    api("org.springframework.boot:spring-boot-starter-aspectj")    // @Aspect（サービスジャーナル）
    api("net.logstash.logback:logstash-logback-encoder:8.1")       // JSON ログ provider
    api("io.awspring.cloud:spring-cloud-aws-starter-sqs")          // @SqsListener / MessageInterceptor（SQS常駐ログ）
    api("software.amazon.awssdk:sqs")                              // ResidentSqsConfig(SqsAsyncClient型) / SqsTraceSupport
    // 接続部品（KMS/DynamoDB/SQS送受信）は検証アプリ(tranning)へ移設。lib はログ部品のみ。

    annotationProcessor("org.springframework.boot:spring-boot-configuration-processor")

    testImplementation("org.springframework.boot:spring-boot-starter-test")
    // Boot プラグイン未適用のため JUnit Platform launcher を明示（Gradle 9 のテスト実行に必要）。
    testRuntimeOnly("org.junit.platform:junit-platform-launcher")
}

tasks.named<Test>("test") {
    useJUnitPlatform()
}
