package jp.co.xxx.common.app.lib.log.logback;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import net.logstash.logback.composite.loggingevent.LoggingEventPatternJsonProvider;
import net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.CoreConstants;

/**
 * appender が依存する配線（{@code <conversionRule truncMsg>} → pattern provider
 * {@code {"message":"%truncMsg{N}"}}）が実際に効くことを encoder 経由で検証する。
 * UTF-8 バイト切詰・suffix は {@link jp.co.xxx.common.app.lib.log.mask.LogMaskingService} 側で検証済み。
 * ここでは「pattern 経由で converter が呼ばれる」「JSON エスケープが効く」を担保する。
 */
class TruncatingMessageConverterTest {

    /** logback-spring.xml の <conversionRule> と同等の登録をしたコンテキストで encode する。 */
    private String encode(String message, int maxBytes) {
        LoggerContext context = new LoggerContext();

        // <conversionRule conversionWord="truncMsg" converterClass="...TruncatingMessageConverter"/> 相当
        @SuppressWarnings("unchecked")
        Map<String, String> rules = (Map<String, String>) context.getObject(CoreConstants.PATTERN_RULE_REGISTRY);
        if (rules == null) {
            rules = new HashMap<>();
            context.putObject(CoreConstants.PATTERN_RULE_REGISTRY, rules);
        }
        rules.put("truncMsg", TruncatingMessageConverter.class.getName());

        LoggingEventPatternJsonProvider provider = new LoggingEventPatternJsonProvider();
        provider.setContext(context);
        provider.setPattern("{\"message\":\"%truncMsg{" + maxBytes + "}\"}");

        LoggingEventCompositeJsonEncoder encoder = new LoggingEventCompositeJsonEncoder();
        encoder.setContext(context);
        encoder.getProviders().addProvider(provider);
        encoder.start();

        Logger logger = context.getLogger("test");
        LoggingEvent event = new LoggingEvent("fqcn", logger, Level.INFO, message, null, null);
        return new String(encoder.encode(event), StandardCharsets.UTF_8);
    }

    @Test
    void shortMessagePassesThroughUntouched() {
        assertThat(encode("hello", 4096)).contains("\"message\":\"hello\"");
    }

    @Test
    void longMessageIsTruncatedByBytesWithSuffix() {
        // maxBytes=20, suffix "...(truncated)"=14byte → 先頭6byte + suffix
        String out = encode("abcdefghijklmnopqrstuvwxyz", 20);
        assertThat(out).contains("\"message\":\"abcdef...(truncated)\"");
    }

    @Test
    void messageIsJsonEscaped() {
        assertThat(encode("he said \"hi\"", 4096)).contains("\"message\":\"he said \\\"hi\\\"\"");
    }
}
