package jp.co.xxx.common.app.lib.log.mask;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.junit.jupiter.api.Test;

import jp.co.xxx.common.app.lib.log.LoggingProperties;

/**
 * マスキング/切詰めロジック（静的・純粋メソッド）を、キー/パターン/最大長を与えて検証する。
 * 本番のマスク対象・最大長は {@link LogMaskingService} のハードコード定数（合流時に確定）。
 */
class LogMaskingServiceTest {

    @Test
    void masksConfiguredHeadersCaseInsensitively() {
        Map<String, String> out = LogMaskingService.maskHeaders(
                Map.of("Authorization", "Bearer x", "Accept", "*/*"), Set.of("authorization", "cookie"));
        assertThat(out.get("Authorization")).isEqualTo("***");
        assertThat(out.get("Accept")).isEqualTo("*/*");
    }

    @Test
    void masksJsonBodyKeys() {
        String out = LogMaskingService.maskKeys(
                "{\"id\":\"1\",\"password\":\"p@ss\",\"token\":\"abc\"}", List.of("password", "token"), List.of());
        assertThat(out).contains("\"password\":\"***\"").contains("\"token\":\"***\"").contains("\"id\":\"1\"");
    }

    @Test
    void masksNonStringJsonValues() {
        // 数値/真偽 の値もマスクされる（従来は文字列値しか伏せられず漏れていた）。
        String out = LogMaskingService.maskKeys(
                "{\"id\":1,\"password\":12345,\"token\":true,\"note\":\"x\"}", List.of("password", "token"), List.of());
        assertThat(out)
                .contains("\"password\":***")
                .contains("\"token\":***")
                .contains("\"id\":1")        // マスク対象外キーはそのまま
                .contains("\"note\":\"x\"");
    }

    @Test
    void appliesValuePatterns() {
        // 値パターン（opt-in）。メールアドレスを正規表現で伏せる。
        String out = LogMaskingService.maskKeys("{\"memo\":\"連絡先 taro@example.com まで\"}",
                List.of("password"), List.of(Pattern.compile("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}")));
        assertThat(out).contains("連絡先 *** まで").doesNotContain("taro@example.com");
    }

    @Test
    void valuePatternsDisabledWhenEmpty() {
        // パターン未指定なら本文の値はそのまま＝誤爆しない。
        assertThat(LogMaskingService.maskKeys("{\"memo\":\"taro@example.com\"}", List.of("password"), List.of()))
                .contains("taro@example.com");
    }

    @Test
    void masksUrlQueryValues() {
        assertThat(LogMaskingService.maskUrlKeys("GET /login?token=secret&id=1", List.of("token")))
                .isEqualTo("GET /login?token=***&id=1");
    }

    @Test
    void truncatesOverMaxBytes() {
        String out = LogMaskingService.truncate("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", 40);
        assertThat(out).endsWith("(truncated)").startsWith("0123456789");
        assertThat(out.getBytes(StandardCharsets.UTF_8).length).isLessThanOrEqualTo(40);
    }

    @Test
    void truncatesByByteNotCharForMultibyte() {
        // 日本語(UTF-8 3byte)。文字数でなくバイトで切れること（境界で割れない）。
        String out = LogMaskingService.truncate("あ".repeat(30), 40); // 90byte > 40
        assertThat(out).endsWith("(truncated)");
        assertThat(out.getBytes(StandardCharsets.UTF_8).length).isLessThanOrEqualTo(40);
    }

    @Test
    void masksPiiKeyValueText() {
        assertThat(LogMaskingService.maskKeys("login password=secret done", List.of("password"), List.of()))
                .contains("password=***").doesNotContain("secret");
    }

    @Test
    void nullSafe() {
        assertThat(LogMaskingService.maskHeaders(null, Set.of())).isNull();
        assertThat(LogMaskingService.maskKeys(null, List.of(), List.of())).isNull();
        assertThat(LogMaskingService.maskUrlKeys(null, List.of())).isNull();
        assertThat(LogMaskingService.truncate(null, 10)).isNull();
    }

    @Test
    void afterPropertiesSetPublishesYmlRulesToHolder() {
        // yml(LoggingProperties)→LogMaskRules の橋渡し（appender 層 masker が実行時に読む）。
        LoggingProperties props = new LoggingProperties();
        props.setMaskHeaderNames(List.of("Authorization"));
        props.setMaskBodyKeys(List.of("password"));
        LogMaskingService m = new LogMaskingService(props);
        m.afterPropertiesSet();
        assertThat(LogMaskRules.headerLower()).contains("authorization"); // 小文字化して公開
        assertThat(LogMaskRules.bodyKeys()).contains("password");
    }
}
