package jp.co.xxx.common.app.lib.log.mask;

import static org.assertj.core.api.Assertions.assertThat;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import net.logstash.logback.composite.loggingevent.LogstashMarkersJsonProvider;
import net.logstash.logback.composite.loggingevent.MessageJsonProvider;
import net.logstash.logback.encoder.LoggingEventCompositeJsonEncoder;
import net.logstash.logback.marker.LogstashMarker;
import net.logstash.logback.marker.Markers;
import net.logstash.logback.mask.MaskingJsonGeneratorDecorator;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.LoggingEvent;

/**
 * 案1（yml-bridge）の検証：appender の {@code <jsonGeneratorDecorator>} に差した
 * {@link ConfiguredValueMasker}/{@link ConfiguredHeaderFieldMasker} が、{@link LogMaskRules} の規則で
 * encoder 書き出し時にマスクすることを実機相当で確認する。呼び出し側マスクは介さない。
 */
class MaskingDecoratorTest {

    @BeforeEach
    void installRules() {
        // yml 相当：ヘッダ authorization / body キー password / 値パターン=メール
        LogMaskRules.install(
                Set.of("authorization"),
                List.of("password"),
                List.of(Pattern.compile("[\\w.+-]+@[\\w.-]+\\.[A-Za-z]{2,}")));
    }

    private String encode(LogstashMarker marker) {
        LoggerContext context = new LoggerContext();

        MaskingJsonGeneratorDecorator decorator = new MaskingJsonGeneratorDecorator();
        decorator.addValueMasker(new ConfiguredValueMasker());
        decorator.addFieldMasker(new ConfiguredHeaderFieldMasker());
        decorator.start();

        LoggingEventCompositeJsonEncoder encoder = new LoggingEventCompositeJsonEncoder();
        encoder.setContext(context);
        encoder.getProviders().addProvider(new MessageJsonProvider());
        encoder.getProviders().addProvider(new LogstashMarkersJsonProvider());
        encoder.setJsonGeneratorDecorator(decorator);
        encoder.start();

        Logger logger = context.getLogger("test");
        LoggingEvent event = new LoggingEvent("fqcn", logger, Level.INFO, "msg", null, null);
        event.addMarker(marker);
        return new String(encoder.encode(event), StandardCharsets.UTF_8);
    }

    @Test
    void masksHeaderValueUnderHeadersObject() {
        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("Authorization", "Bearer secret");
        headers.put("Accept", "*/*");
        String out = encode(Markers.appendEntries(new LinkedHashMap<>(Map.of("headers", headers))));
        assertThat(out).contains("\"Authorization\":\"***\"");   // 対象ヘッダは値ごと
        assertThat(out).contains("\"Accept\":\"*/*\"");          // 対象外は素通し
        assertThat(out).doesNotContain("Bearer secret");
    }

    @Test
    void doesNotMaskSameNameFieldOutsideHeaders() {
        // headers 直下でない同名フィールドは誤爆しない（親が headers の時のみ）
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("authorization", "top-level-not-a-header");
        String out = encode(Markers.appendEntries(fields));
        assertThat(out).contains("\"authorization\":\"top-level-not-a-header\"");
    }

    @Test
    void masksBodyStringKeysAndValuePatterns() {
        Map<String, Object> fields = new LinkedHashMap<>();
        fields.put("body", "{\"password\":\"p@ss\",\"id\":\"1\"}");
        fields.put("memo", "連絡先 taro@example.com まで");
        String out = encode(Markers.appendEntries(fields));
        assertThat(out).doesNotContain("p@ss");              // body 内キー password の値
        assertThat(out).doesNotContain("taro@example.com");  // 値パターン（メール）
        assertThat(out).contains("***").contains("\\\"id\\\":\\\"1\\\""); // 対象外はそのまま
    }
}
