package jp.co.xxx.common.app.lib.log.logback;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.StringWriter;
import java.util.LinkedHashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;

/**
 * appender 定義で列挙した順・項目名で MDC を出力し、値が無いキーは文字列 "null" で出ること、
 * および「取得キー→出力名」の変換（{@code <entry>}）が効くことを検証する。
 */
class MdcOrderedJsonProviderTest {

    /** appender の {@code <includeMdcKeyName>} 列挙を模した provider。 */
    private MdcOrderedJsonProvider configured(String... keys) {
        MdcOrderedJsonProvider p = new MdcOrderedJsonProvider();
        for (String k : keys) {
            p.addIncludeMdcKeyName(k);
        }
        return p;
    }

    private String render(MdcOrderedJsonProvider provider, Map<String, String> mdc) throws Exception {
        StringWriter writer = new StringWriter();
        try (JsonGenerator g = new JsonFactory().createGenerator(writer)) {
            g.writeStartObject();
            ILoggingEvent event = mock(ILoggingEvent.class);
            when(event.getMDCPropertyMap()).thenReturn(mdc);
            provider.writeTo(g, event);
            g.writeEndObject();
        }
        return writer.toString();
    }

    @Test
    void writesListedOrderWithValues() throws Exception {
        // MDC の投入順に関係なく、列挙順(function/user/action/trace)で出る
        Map<String, String> mdc = new LinkedHashMap<>();
        mdc.put("trace", "t1");
        mdc.put("action", "POST");
        mdc.put("user", "u1");
        mdc.put("function", "/api/x");
        assertThat(render(configured("function", "user", "action", "trace"), mdc))
                .contains("\"function\":\"/api/x\",\"user\":\"u1\",\"action\":\"POST\",\"trace\":\"t1\"");
    }

    @Test
    void writesNullStringForAbsentKeys() throws Exception {
        // 統一方針：値なしは JSON null ではなく文字列 "null"
        String json = render(configured("function", "user", "action", "trace"), Map.of());
        assertThat(json)
                .contains("\"function\":\"null\"")
                .contains("\"user\":\"null\"")
                .contains("\"action\":\"null\"")
                .contains("\"trace\":\"null\"");
    }

    @Test
    void onlyListedKeysAreOutput() throws Exception {
        // 列挙していない MDC キーは出力しない（ホワイトリスト）
        MdcOrderedJsonProvider p = configured("function");
        String json = render(p, Map.of("function", "f", "secretKey", "leak"));
        assertThat(json).contains("\"function\":\"f\"").doesNotContain("secretKey").doesNotContain("leak");
    }

    @Test
    void mapsMdcKeyToDifferentOutputName() throws Exception {
        // <entry>取得キー:出力名> による変換（既存が別キー名で登録しているケース）
        MdcOrderedJsonProvider p = new MdcOrderedJsonProvider();
        p.addEntry("traceId:trace");
        String json = render(p, Map.of("traceId", "abc"));
        assertThat(json).contains("\"trace\":\"abc\"").doesNotContain("traceId");
    }
}
