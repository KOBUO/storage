package jp.co.xxx.common.app.lib.log;

/** ログ種類詳細(subtype)。 */
public final class LogSubtype {

    public static final String SHELL = "SHELL";
    public static final String SYSTEM = "SYSTEM";
    public static final String NGINX = "NGINX";
    public static final String AWSCALL = "AWSCALL";
    public static final String DBCALL = "DBCALL";
    public static final String APL = "APL";

    private LogSubtype() {
    }
}
