package jp.co.xxx.common.app.lib.log;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * マスク対象の設定保持部品。application.yml の {@code cosmo-app.logging.custom.*} をバインドする。
 * 「指定したものだけマスク」＝<b>既定は空</b>（合流先/アプリが yml で指定する）。
 *
 * <p>最大長は yml ではなくコード定数（message は {@code TruncatingMessageConverter.DEFAULT_MAX_BYTES}=4096、
 * body/result は上限なし）。本クラスはマスク対象リストのみを保持する。
 */
@Component
@ConfigurationProperties(prefix = "cosmo-app.logging.custom")
public class LoggingProperties {

    /** マスク対象ヘッダー名（小文字比較）。 */
    private List<String> maskHeaderNames = new ArrayList<>();
    /** マスク対象ボディ/引数キー（値を {@code ***} に）。 */
    private List<String> maskBodyKeys = new ArrayList<>();
    /** 値パターンマスク（正規表現）。キーに紐づかない PII を本文から伏せる opt-in。既定は空。 */
    private List<String> maskBodyPatterns = new ArrayList<>();

    public List<String> getMaskHeaderNames() {
        return maskHeaderNames;
    }

    public void setMaskHeaderNames(List<String> maskHeaderNames) {
        this.maskHeaderNames = maskHeaderNames;
    }

    public List<String> getMaskBodyKeys() {
        return maskBodyKeys;
    }

    public void setMaskBodyKeys(List<String> maskBodyKeys) {
        this.maskBodyKeys = maskBodyKeys;
    }

    public List<String> getMaskBodyPatterns() {
        return maskBodyPatterns;
    }

    public void setMaskBodyPatterns(List<String> maskBodyPatterns) {
        this.maskBodyPatterns = maskBodyPatterns;
    }
}
