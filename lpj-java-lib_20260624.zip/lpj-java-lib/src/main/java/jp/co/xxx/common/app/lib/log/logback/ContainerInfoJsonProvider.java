package jp.co.xxx.common.app.lib.log.logback;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * 全ログに id / name（アプリケーションスコープ）を付与する logback provider。
 * 値は環境変数から取得する（ECSタスク定義等で設定する想定）。統一方針に従い未設定時は文字列 {@code "null"}。
 *   id   = 環境変数 CONTAINER_ID  （未設定なら {@code "null"}）
 *   name = 環境変数 CONTAINER_NAME（未設定なら {@code "null"}）
 * 起動時に1回だけ解決して保持する。logback-spring.xml の {@code <providers>} に登録する。
 */
public class ContainerInfoJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    /** 値なしの統一プレースホルダ（JSON null ではなく文字列）。 */
    private static final String NULL = "null";

    private static final String ID = resolve("CONTAINER_ID");
    private static final String NAME = resolve("CONTAINER_NAME");

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        generator.writeStringField("id", ID);
        generator.writeStringField("name", NAME);
    }

    private static String resolve(String envName) {
        String v = System.getenv(envName);
        return (v != null && !v.isBlank()) ? v : NULL;
    }
}
