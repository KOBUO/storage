package jp.co.xxx.common.app.lib.log.mask;

import java.util.Locale;

import com.fasterxml.jackson.core.JsonStreamContext;

import net.logstash.logback.mask.FieldMasker;

import jp.co.xxx.common.app.lib.log.LogFields;

/**
 * {@code headers} オブジェクト直下の、yml 指定ヘッダー名のフィールド値を伏せる {@link FieldMasker}。
 * appender 層（{@code MaskingJsonGeneratorDecorator}）に差し、呼び出し側を介さずヘッダーをマスクする。
 *
 * <p><b>headers 直下に限定</b>するのが要点：フィールド名だけで判定すると、yml のヘッダー名が
 * MDC 等の構造化フィールド名（例 {@code user}）と衝突した際に誤爆する。親が {@code headers} の時のみ対象。
 * 規則は {@link LogMaskRules}（yml→{@link LogMaskingService} 経由）から実行時に読む。
 */
public class ConfiguredHeaderFieldMasker implements FieldMasker {

    @Override
    public Object mask(JsonStreamContext context) {
        String name = context.getCurrentName();
        if (name == null) {
            return null;
        }
        JsonStreamContext parent = context.getParent();
        if (parent == null || !LogFields.HEADERS.equals(parent.getCurrentName())) {
            return null; // headers オブジェクト直下以外は対象外
        }
        if (LogMaskRules.headerLower().contains(name.toLowerCase(Locale.ROOT))) {
            return LogMaskingService.MASK;
        }
        return null;
    }
}
