package jp.co.xxx.common.app.lib.log.logback;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

/**
 * 実行単位スコープ(MDC)項目を <b>appender 定義で列挙した順・項目名</b>で出力する provider。
 *
 * <p>標準の {@code <mdc/>} は MDC マップ（順序非保証）をそのまま出すため JSON キー順が非決定になる。
 * これを避け、かつ「どの appender がどの MDC を出すか」を appender 定義で可視化するため、
 * 出力する項目を appender 側で明示列挙する。
 *
 * <p>取得キー（MDC のキー名）と出力項目名を<b>分離</b>できる：
 * <ul>
 *   <li>{@code <includeMdcKeyName>function</includeMdcKeyName>} … 取得キー=出力名（同名）</li>
 *   <li>{@code <entry>取得キー:出力名</entry>} … 取得キーと出力名が異なる場合（既存部品が別キー名で
 *       MDC へ辞書登録しているケース等）。例 {@code <entry>traceId:trace</entry>}</li>
 * </ul>
 *
 * <p>値が無い場合も、統一方針「キーは出力し値は文字列 {@code "null"}」に従い {@code "null"} を出力する。
 * 列挙したキー以外は出力しない（ホワイトリスト）。
 */
public class MdcOrderedJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    /**
     * 出力エントリ：[0]=MDC取得キー / [1]=出力項目名。appender 定義の列挙順を保持。
     * 設定スレッドが add（copy-on-write）、出力スレッドが read するため <b>volatile + 不変リスト</b>で公開する
     * （{@code LogMaskRules} と同方針。可視性を担保）。
     */
    private volatile List<String[]> entries = List.of();

    /** {@code <includeMdcKeyName>name</includeMdcKeyName>}：取得キー=出力名（同名）。 */
    public void addIncludeMdcKeyName(String name) {
        if (name != null && !name.isBlank()) {
            String n = name.trim();
            append(new String[] {n, n});
        }
    }

    /** {@code <entry>取得キー:出力名</entry>}：取得キーと出力名を分離。{@code :} 無しは同名扱い。 */
    public void addEntry(String spec) {
        if (spec == null || spec.isBlank()) {
            return;
        }
        int i = spec.indexOf(':');
        if (i < 0) {
            addIncludeMdcKeyName(spec);
        } else {
            append(new String[] {spec.substring(0, i).trim(), spec.substring(i + 1).trim()});
        }
    }

    /** 設定時の追加。不変スナップショットを volatile 公開して出力スレッドへ可視化する。 */
    private void append(String[] entry) {
        List<String[]> next = new ArrayList<>(entries);
        next.add(entry);
        entries = List.copyOf(next);
    }

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        Map<String, String> mdc = event.getMDCPropertyMap();
        for (String[] e : entries) {
            String value = mdc.get(e[0]);
            // 統一方針：値なしは JSON null ではなく文字列 "null"。
            generator.writeStringField(e[1], value != null ? value : "null");
        }
    }
}
