package jp.co.xxx.common.app.lib.log.mask;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

import jp.co.xxx.common.app.lib.log.LoggingProperties;

/**
 * マスキングの<b>規則エンジン＋yml橋渡し</b>部品。マスク/切詰めのロジックは静的・純粋メソッド
 * （{@link #maskKeys}/{@link #maskHeaders}/{@link #maskUrlKeys}/{@link #truncate}。キー・パターン・最大長を引数で受ける）。
 *
 * <p>実際のマスク/切詰めは <b>appender 層</b>で全ロガー一律に適用される：
 * <ul>
 *   <li>マスク … {@code MaskingJsonGeneratorDecorator} ＋ {@link ConfiguredValueMasker}/{@link ConfiguredHeaderFieldMasker}
 *       が、この静的ロジックを実行時に呼ぶ。</li>
 *   <li>message 切詰 … {@link jp.co.xxx.common.app.lib.log.logback.TruncatingMessageConverter}（{@code %truncMsg}）が
 *       {@link #truncate} を呼ぶ。</li>
 * </ul>
 *
 * <p>マスク<b>対象</b>（header名/body-key/値パターン）は application.yml（{@code cosmo-app.logging.custom.*}）から
 * {@link LoggingProperties} 経由で受け取り（「指定したものだけマスク」＝既定空）、{@link #afterPropertiesSet} で
 * {@link LogMaskRules} へ公開する（logback の masker は Bean を DI できないため静的ホルダー経由で橋渡し）。
 */
@Component
public class LogMaskingService implements InitializingBean {

    /** マスク後の値。decorator の masker からも参照する。 */
    public static final String MASK = "***";
    private static final String TRUNCATED_SUFFIX = "...(truncated)";

    /** マスク対象（yml 由来）。ヘッダーは小文字化、値パターンは事前コンパイル。 */
    private final Set<String> maskHeaderLower;
    private final List<String> maskBodyKeys;
    private final List<Pattern> bodyPatterns;

    public LogMaskingService(LoggingProperties props) {
        this.maskHeaderLower = props.getMaskHeaderNames().stream()
                .map(s -> s.toLowerCase(Locale.ROOT)).collect(Collectors.toSet());
        this.maskBodyKeys = List.copyOf(props.getMaskBodyKeys());
        this.bodyPatterns = props.getMaskBodyPatterns().stream().map(Pattern::compile).toList();
    }

    /**
     * 起動時に yml 由来の規則を {@link LogMaskRules} へ公開する。
     * appender 層の masker（{@link ConfiguredValueMasker}/{@link ConfiguredHeaderFieldMasker}）が
     * これを実行時に読む。Spring がライフサイクルで呼ぶ（テストの素の new では発火しない）。
     */
    @Override
    public void afterPropertiesSet() {
        LogMaskRules.install(maskHeaderLower, maskBodyKeys, bodyPatterns);
    }

    // ---- ロジック（純粋・静的。masker/converter と テストが直接利用する） ----

    /** マスク対象ヘッダー（小文字集合）を値ごと伏せる。 */
    static Map<String, String> maskHeaders(Map<String, String> headers, Set<String> maskLower) {
        if (headers == null) {
            return null;
        }
        Map<String, String> out = new LinkedHashMap<>();
        headers.forEach((k, v) -> out.put(k, maskLower.contains(k.toLowerCase(Locale.ROOT)) ? MASK : v));
        return out;
    }

    /** テキストへ (1)キー名ベース (2)値パターンベース のマスクを適用する。 */
    static String maskKeys(String text, List<String> keys, List<Pattern> patterns) {
        if (text == null) {
            return null;
        }
        String masked = text;
        // (1) キー名ベース（キー名は大小文字を無視＝(?i)）
        for (String key : keys) {
            String q = Pattern.quote(key);
            // "key":"value"（文字列値。エスケープ \" を含む値も末尾まで）
            masked = masked.replaceAll("(?i)(\"" + q + "\"\\s*:\\s*\")(?:\\\\.|[^\"\\\\])*(\")", "$1" + MASK + "$2");
            // "key":123 / true / false / null（非文字列の**スカラ**値のみ。オブジェクト/配列値は対象外＝JSON を壊さない）
            masked = masked.replaceAll("(?i)(\"" + q + "\"\\s*:\\s*)(?:-?\\d[\\d.eE+-]*|true|false|null)", "$1" + MASK);
            // key=value（クエリ/フォーム/フリーテキスト形式）
            masked = masked.replaceAll("(?i)(" + q + "\\s*=\\s*)[^,&;\\s)}]+", "$1" + MASK);
        }
        // (2) 値パターンベース
        for (Pattern p : patterns) {
            masked = p.matcher(masked).replaceAll(Matcher.quoteReplacement(MASK));
        }
        return masked;
    }

    /** URL クエリ（?key=value / &key=value）のマスク対象キーの値を伏せる。 */
    static String maskUrlKeys(String url, List<String> keys) {
        if (url == null) {
            return null;
        }
        String masked = url;
        for (String key : keys) {
            masked = masked.replaceAll("([?&]" + Pattern.quote(key) + "=)[^&\\s]*", "$1" + MASK);
        }
        return masked;
    }

    /**
     * 最大<b>バイト数</b>(UTF-8)で切り詰める。超過時は切り詰め後に {@code ...(truncated)} を付け、
     * サフィックス込みで max バイト以内に収める（マルチバイト文字はコードポイント境界で切る）。
     */
    public static String truncate(String s, int maxBytes) {
        if (s == null) {
            return null;
        }
        if (s.getBytes(StandardCharsets.UTF_8).length <= maxBytes) {
            return s;
        }
        int suffixBytes = TRUNCATED_SUFFIX.getBytes(StandardCharsets.UTF_8).length;
        // max がサフィックス長以下なら、サフィックスを付けず本文を max バイトまで素切り（出力が max を超えないように）。
        boolean withSuffix = maxBytes > suffixBytes;
        int budget = withSuffix ? maxBytes - suffixBytes : maxBytes;
        StringBuilder sb = new StringBuilder();
        int used = 0;
        for (int i = 0; i < s.length(); ) {
            int cp = s.codePointAt(i);
            int bw = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8).length;
            if (used + bw > budget) {
                break;
            }
            sb.appendCodePoint(cp);
            used += bw;
            i += Character.charCount(cp);
        }
        return withSuffix ? sb + TRUNCATED_SUFFIX : sb.toString();
    }
}
