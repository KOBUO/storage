package jp.co.xxx.common.app.lib.log;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

/**
 * {@code @Service} メソッドの処理時間を測り、MDC の {@code latency} に載せる「最内」アスペクト。
 * サービスジャーナルログの出力は既存部品が担うため、本部品は<b>処理時間（latency）だけ</b>を MDC で渡す。
 *
 * <ul>
 *   <li>{@code @Order(LOWEST_PRECEDENCE)} で最内＝外側の既存アスペクトがログを出す<b>前</b>に latency を put する。</li>
 *   <li><b>remove はしない</b>（put 層とログ層が別のため）。残留は実行単位スコープの境界クリア
 *       （{@code ApiAccessLogFilter}（API）/ {@code SqsReceiveJournalInterceptor}（SQS常駐）の {@code MDC.clear()}）に委ねる。
 *       単発バッチはプロセス終了で消えるため問題なし。</li>
 * </ul>
 *
 * <p>TODO【合流時】pointcut に {@code && !@within(...ExcludeServiceLog)} を追加し、既存アスペクトと同一対象へ揃える。
 */
@Aspect
@Component
@Order(Ordered.LOWEST_PRECEDENCE)
public class ServiceLatencyMdcAspect {

    @Around("@within(org.springframework.stereotype.Service)")
    public Object around(ProceedingJoinPoint pjp) throws Throwable {
        long startNanos = System.nanoTime();
        try {
            return pjp.proceed();
        } finally {
            MDC.put(MdcKeys.LATENCY, String.valueOf((System.nanoTime() - startNanos) / 1_000_000));
        }
    }
}
