package jp.co.xxx.common.app.lib.log;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import org.jspecify.annotations.NonNull;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * アクセスログ／アクセスジャーナルログ（要求/応答）を出力する Servlet フィルタ。
 * リクエスト前後で実行単位スコープ(MDC)を張る。詳細は設計書「アクセスログ出力（API用）」。
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class ApiAccessLogFilter extends OncePerRequestFilter {

    /** アクセスログ：1リクエスト1件のサマリ。 */
    private static final Logger accessLog = LoggerFactory.getLogger(LoggerNames.API_ACCESS);
    /** アクセスジャーナルログ：要求/応答の詳細。 */
    private static final Logger journalLog = LoggerFactory.getLogger(LoggerNames.API_ACCESS_JNL);

    // 取得元ヘッダ名（既存仕様で確定）。
    private static final String HEADER_TRACE = "X-Trace-ID";
    private static final String HEADER_USER = "X-User-ID";
    private static final String HEADER_FORWARDED_FOR = "X-Forwarded-For";

    /** アクセスログ／アクセスジャーナルログ（要求/応答）を出力するフィルタ本体。 */
    @Override
    protected void doFilterInternal(
        @NonNull HttpServletRequest request, 
        @NonNull HttpServletResponse response,
        @NonNull FilterChain chain) throws ServletException, IOException {

        ContentCachingRequestWrapper req = new ContentCachingRequestWrapper(request, Integer.MAX_VALUE);
        ContentCachingResponseWrapper res = new ContentCachingResponseWrapper(response);

        String traceId = req.getHeader(HEADER_TRACE);
        if (traceId == null || traceId.isBlank()) {
            traceId = UUID.randomUUID().toString(); // X-Trace-ID が無ければ自動採番
        }
        String action = req.getMethod() + " " + req.getRequestURI(); // function は当面 action と同値
        String function = action;
        String url = buildUrl(req); // マスクは appender 層
        long startNanos = System.nanoTime();

        // 実行単位スコープ(MDC)：put → finally で MDC.clear()（境界で一掃）。
        putMdc(MdcKeys.FUNCTION, function);
        putMdc(MdcKeys.ACTION, action);
        putMdc(MdcKeys.USER, req.getHeader(HEADER_USER));
        putMdc(MdcKeys.TRACE_ID, traceId);
        putMdc(MdcKeys.SOURCE_IP, clientIp(req));
        try {
            // ジャーナルは MDC 有効中(remove前)に出力。前後ペア統一で要求側の status/latency は null。
            try {
                chain.doFilter(req, res);
            } finally {
                // ログ出力が例外を投げても実レスポンスは必ず書き戻す（copyBodyToResponse を独立 finally に）。
                try {
                    long latencyMs = (System.nanoTime() - startNanos) / 1_000_000;

                    accessLog.info(StructuredLog.create()
                            .put(LogFields.URL, url)
                            .put(LogFields.STATUS, res.getStatus())
                            .put(LogFields.LATENCY, latencyMs)
                            .marker(), "アクセスログ");

                    journalLog.info(StructuredLog.create()
                            .put(LogFields.URL, url)
                            .putNullable(LogFields.STATUS, null)
                            .put(LogFields.HEADERS, requestHeaders(req))
                            .put(LogFields.BODY, content(req.getContentAsByteArray()))
                            .putNullable(LogFields.LATENCY, null)
                            .marker(), "アクセスジャーナル（要求）");

                    journalLog.info(StructuredLog.create()
                            .put(LogFields.URL, url)
                            .put(LogFields.STATUS, res.getStatus())
                            .put(LogFields.HEADERS, responseHeaders(res))
                            .put(LogFields.BODY, content(res.getContentAsByteArray()))
                            .put(LogFields.LATENCY, latencyMs)
                            .marker(), "アクセスジャーナル（応答）");
                } finally {
                    res.copyBodyToResponse(); // copy しないと実レスポンスが返らない
                }
            }
        } finally {
            MDC.clear();
        }
    }

    /** 値があれば MDC へ設定（null/空は設定しない＝provider が "null" 出力）。 */
    private static void putMdc(String key, String value) {
        if (value != null && !value.isBlank()) {
            MDC.put(key, value);
        }
    }

    /** クライアントIP（X-Forwarded-For 先頭、無ければ remoteAddr）。 */
    private String clientIp(HttpServletRequest request) {
        String forwarded = request.getHeader(HEADER_FORWARDED_FOR);
        if (forwarded != null && !forwarded.isBlank()) {
            return forwarded.split(",")[0].trim();
        }
        return request.getRemoteAddr();
    }

    /** URL = メソッド + URI（+ クエリ文字列）。 */
    private String buildUrl(HttpServletRequest request) {
        String query = request.getQueryString();
        return request.getMethod() + " " + request.getRequestURI() + (query != null ? "?" + query : "");
    }

    /** リクエストヘッダーを Map 化。 */
    private Map<String, String> requestHeaders(HttpServletRequest request) {
        Map<String, String> headers = new LinkedHashMap<>();
        Enumeration<String> names = request.getHeaderNames();
        while (names.hasMoreElements()) {
            String name = names.nextElement();
            headers.put(name, request.getHeader(name));
        }
        return headers;
    }

    /** レスポンスヘッダーを Map 化。 */
    private Map<String, String> responseHeaders(HttpServletResponse response) {
        Map<String, String> headers = new LinkedHashMap<>();
        for (String name : response.getHeaderNames()) {
            headers.put(name, response.getHeader(name));
        }
        return headers;
    }

    /** バイト列を UTF-8 文字列化（空は null）。 */
    private String content(byte[] bytes) {
        if (bytes == null || bytes.length == 0) {
            return null;
        }
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
