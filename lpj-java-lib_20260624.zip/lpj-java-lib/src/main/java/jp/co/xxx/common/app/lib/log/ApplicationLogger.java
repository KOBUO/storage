package jp.co.xxx.common.app.lib.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 業務ログ出力部品（明示的に出力する業務イベント）。
 * 業務ログは SPRINGBOOT_API_LOG、業務エラーログは SPRINGBOOT_ERROR_LOG へ固定ロガー名で出力する。
 * type / subtype は TypeSubtypeJsonProvider が付与する（type=レベル判定 / subtype=APL）。
 * class_name / method_name は appender の CallerDataJsonProvider が付与する（実装者は info/error を呼ぶだけ）。
 * ※システムログは「明示出力していない FW 等の root ログ」であり本部品ではない。
 *
 * <p><b>取得方法</b>：{@link ApplicationLoggerFactory#getLogger()}（slf4j 風）。状態を持たない薄いラッパ
 * （マスク・最大長は appender 層へ移行済み）なので <b>Bean ではなくシングルトン</b>。
 * DI 不要＝コンポーネントでも非コンポーネント（ユーティリティ/静的文脈）でも同じく呼べる。
 */
public final class ApplicationLogger {

    private static final Logger business = LoggerFactory.getLogger(LoggerNames.API_LOG);
    private static final Logger error = LoggerFactory.getLogger(LoggerNames.ERROR_LOG);

    /** 生成は {@link ApplicationLoggerFactory} 経由（同パッケージ）。直接 new させない。 */
    ApplicationLogger() {
    }

    /** 業務ログ: trace(MDC) / message / class_name / method_name。
     *  マスク・最大長は appender 層（decorator / %truncMsg）で全ロガー一律に適用される。 */
    public void info(String message) {
        business.info(message);
    }

    /** 業務エラーログ: trace(MDC) / message / stack_trace / class_name / method_name。 */
    public void error(String message, Throwable t) {
        error.error(message, t);
    }

    /** 業務エラーログ（例外なし）: trace(MDC) / message / class_name / method_name（stack_trace なし）。 */
    public void error(String message) {
        error.error(message);
    }
}
