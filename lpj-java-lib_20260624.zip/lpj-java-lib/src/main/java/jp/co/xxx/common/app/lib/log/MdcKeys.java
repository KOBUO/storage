package jp.co.xxx.common.app.lib.log;

/**
 * MDCに載せる実行単位スコープの項目キー。
 * 物理名とMDCキーを一致させ、logback の {@code <mdc/>} provider でそのまま出力する。
 */
public final class MdcKeys {

    // 出力項目名は確定。現状は「取得キー＝出力名」（同名）。
    // 合流時、既存部品が MDC を別キー名で読み書きする場合は取得キーをそれに合わせる（出力名は不変。
    // 取得≠出力なら appender 側 MdcOrderedJsonProvider の <entry>取得:出力> で吸収）。
    public static final String FUNCTION = "function";
    public static final String USER = "user";
    public static final String ACTION = "action";
    /** 出力項目名・MDCキーとも "trace"。 */
    public static final String TRACE_ID = "trace";
    public static final String SOURCE_IP = "source_ip";
    /** 処理時間。スコープ項目ではなく @Service メソッド毎に ServiceLatencyMdcAspect が put。境界の MDC.clear() で消える。 */
    public static final String LATENCY = "latency";

    private MdcKeys() {
    }
}
