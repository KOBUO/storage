package jp.co.xxx.common.app.lib.log.logback;

import ch.qos.logback.classic.pattern.ClassicConverter;
import ch.qos.logback.classic.spi.ILoggingEvent;

import jp.co.xxx.common.app.lib.log.mask.LogMaskingService;

/**
 * message を UTF-8 バイト数で切り詰める {@link ClassicConverter}。
 * appender 層（pattern provider 内 {@code %truncMsg{N}}）で全ロガーに適用するための部品。
 *
 * <ul>
 *   <li>呼び出し側（ApplicationLogger 等）を介さず、encoder が message を書く瞬間に切り詰める。
 *       ＝素の slf4j / root(システムログ) も含めて effective。</li>
 *   <li>上限値はオプションで受け取る（{@code %truncMsg{4096}}）。未指定時は {@link #DEFAULT_MAX_BYTES}。</li>
 *   <li>切り詰めロジックは {@link LogMaskingService#truncate}（UTF-8 バイト・コードポイント境界・
 *       {@code ...(truncated)} 付与）に委譲し、規則を一本化する。</li>
 * </ul>
 *
 * <p>登録: {@code <conversionRule conversionWord="truncMsg"
 * converterClass="jp.co.xxx.common.app.lib.log.logback.TruncatingMessageConverter"/>}<br>
 * 使用: pattern provider で {@code {"message":"%truncMsg{4096}"}}。
 */
public class TruncatingMessageConverter extends ClassicConverter {

    /** オプション未指定時の上限。4KB は Rv 指摘で確定（{@link LogMaskingService} と同値）。 */
    private static final int DEFAULT_MAX_BYTES = 4096;

    private int maxBytes = DEFAULT_MAX_BYTES;

    @Override
    public void start() {
        String opt = getFirstOption();
        if (opt != null && !opt.isBlank()) {
            maxBytes = Integer.parseInt(opt.trim());
        }
        super.start();
    }

    @Override
    public String convert(ILoggingEvent event) {
        return LogMaskingService.truncate(event.getFormattedMessage(), maxBytes);
    }
}
