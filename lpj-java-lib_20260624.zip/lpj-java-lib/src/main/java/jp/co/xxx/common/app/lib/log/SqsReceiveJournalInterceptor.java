package jp.co.xxx.common.app.lib.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.stereotype.Component;

import io.awspring.cloud.sqs.listener.SqsHeaders;
import io.awspring.cloud.sqs.listener.interceptor.MessageInterceptor;

/**
 * 【常駐バッチ（@SqsListener）共通】のログ出力部品。
 * Spring Cloud AWS の {@link MessageInterceptor} として全 {@code @SqsListener} の受信前後にフックし、
 * 業務リスナーがログを意識しなくて済むようにする（オンラインの ApiAccessLogFilter と同じ思想）。
 *
 * <ul>
 *   <li>{@code intercept}（受信時）: MDC スコープ(function/action/trace_id)を張り、メッセージジャーナルを出力</li>
 *   <li>{@code afterProcessing}（終了時）: MDC をクリアするのみ。失敗時のエラーログは業務側（{@code ApplicationLogger.error}）が出し、例外はそのまま伝播（リトライ/DLQ）</li>
 * </ul>
 *
 * <p>MDC はスレッドローカル。SINGLE_MESSAGE 処理では intercept→リスナー→afterProcessing が
 * 同一スレッドで動くため、業務リスナーのログにも function/trace_id 等が自動付与される。
 *
 * <p>trace はメッセージ属性（キー名は {@code ATTR_TRACE}）から取得し、統一方針で無ければ {@code null}
 * （SQS MessageId 等にフォールバックしない）。受信の AWS メタ(aws_request_id 等)は Spring 側が
 * SDK 受信を握るため取得できず {@code null}。
 */
@Component
@ConditionalOnProperty(prefix = "cosmo-app.lpj.logging.sqs", name = "enabled", havingValue = "true", matchIfMissing = false)
public class SqsReceiveJournalInterceptor implements MessageInterceptor<Object> {

    /** メッセージジャーナルログ。 */
    private static final Logger journalLog = LoggerFactory.getLogger(LoggerNames.SQS_JNL);

    /** 常駐受信の action は固定。 */
    private static final String ACTION_CONSUME = "CONSUME";
    // TODO SQS メッセージ属性名は仮。
    private static final String ATTR_TRACE = "trace";
    private static final String ATTR_USER = "user";

    @Override
    public Message<Object> intercept(Message<Object> message) {
        MessageHeaders headers = message.getHeaders();
        String messageId = messageId(headers);

        // MDC スコープ開始（afterProcessing でクリア）。null/空は設定しない（→ provider が null 出力）。
        put(MdcKeys.FUNCTION, function(headers));
        put(MdcKeys.ACTION, ACTION_CONSUME);
        put(MdcKeys.TRACE_ID, traceId(headers));
        put(MdcKeys.USER, attr(headers, ATTR_USER));  // user はメッセージ属性(ATTR_USER)から。無ければ未設定→"null"
        // source_ip は常駐では概念上なし／SQS appender でも出力しないため設定しない

        // メッセージジャーナル: 受信証跡。発生元・受信メタは取得不可のため null（キーは出力）。
        journalLog.info(StructuredLog.create()
                .putNullable(LogFields.LATENCY, null)
                .putNullable(LogFields.AWS_REQUEST_ID, null)
                .put(LogFields.AWS_SQS_MESSAGE_ID, messageId)
                .putNullable(LogFields.AWS_REQUEST_TIMESTAMP, null)
                .putNullable(LogFields.AWS_RESPONSE_TIME, null)
                .marker(), "メッセージ受信ジャーナル");
        return message;
    }

    @Override
    public void afterProcessing(Message<Object> message, Throwable t) {
        // 失敗時のエラーログは業務側（ApplicationLogger.error）が出す。例外はそのまま伝播（リトライ/DLQ）。
        MDC.clear(); // メッセージ境界でスレッドの MDC を一掃
    }

    private static void put(String key, String value) {
        if (value != null && !value.isBlank()) {
            MDC.put(key, value);
        }
    }

    // Spring Cloud AWS は Spring メッセージIDに SQS 採番の MessageId を設定するため、
    // headers.getId() が aws_sqs_message_id（SQS MessageId）になる（送信側 response.messageId() と一致・実機確認済み）。
    private static String messageId(MessageHeaders headers) {
        var id = headers.getId();
        return id != null ? id.toString() : null;
    }

    /** trace: メッセージ属性(ATTR_TRACE)から取得、無ければ null（フォールバックしない）。 */
    private static String traceId(MessageHeaders headers) {
        return attr(headers, ATTR_TRACE);
    }

    /** メッセージ属性(ヘッダ)から文字列取得、無ければ null。 */
    private static String attr(MessageHeaders headers, String name) {
        Object v = headers.get(name);
        return (v != null && !v.toString().isBlank()) ? v.toString() : null;
    }

    /** function: 受信キュー名を機能IDとして使う。 */
    private static String function(MessageHeaders headers) {
        Object queue = headers.get(SqsHeaders.SQS_QUEUE_NAME_HEADER);
        return queue != null ? queue.toString() : "sqs";
    }
}
