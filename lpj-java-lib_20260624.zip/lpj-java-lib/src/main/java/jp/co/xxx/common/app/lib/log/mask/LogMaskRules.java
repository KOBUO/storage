package jp.co.xxx.common.app.lib.log.mask;

import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * マスク規則（yml 由来）を logback の masker へ渡すための静的ホルダー。
 *
 * <p>decorator / masker は logback が config 時（Spring Bean より早い）に生成するため、
 * {@link LoggingProperties} を直接 DI できない。そこで Spring 管理の {@link LogMaskingService} が
 * 起動時に規則をここへ {@link #install} し、masker は<b>マスク実行時（=ログ1件ごと・runtime）</b>に
 * {@link #bodyKeys()} 等を読む。実マスクは context 起動後なので規則は充填済み。
 * 起動最初期（Bean生成前）のフレームワークログのみ規則未充填で素通り（許容）。
 *
 * <p>既定は空集合＝「指定したものだけマスク」を維持（install 前は何もマスクしない）。
 */
public final class LogMaskRules {

    private static volatile Set<String> headerLower = Set.of();
    private static volatile List<String> bodyKeys = List.of();
    private static volatile List<Pattern> bodyPatterns = List.of();

    private LogMaskRules() {
    }

    /** Spring 管理の {@link LogMaskingService} から起動時に1回充填する。 */
    static void install(Set<String> headerLowerNames, List<String> keys, List<Pattern> patterns) {
        headerLower = Set.copyOf(headerLowerNames);
        bodyKeys = List.copyOf(keys);
        bodyPatterns = List.copyOf(patterns);
    }

    /** マスク対象ヘッダー名（小文字）。 */
    public static Set<String> headerLower() {
        return headerLower;
    }

    /** マスク対象ボディ/引数キー。 */
    public static List<String> bodyKeys() {
        return bodyKeys;
    }

    /** 値パターン（事前コンパイル済み）。 */
    public static List<Pattern> bodyPatterns() {
        return bodyPatterns;
    }
}
