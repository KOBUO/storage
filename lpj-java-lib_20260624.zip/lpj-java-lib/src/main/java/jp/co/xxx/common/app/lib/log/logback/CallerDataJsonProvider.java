package jp.co.xxx.common.app.lib.log.logback;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonGenerator;

import ch.qos.logback.classic.spi.ILoggingEvent;
import net.logstash.logback.composite.AbstractJsonProvider;

import jp.co.xxx.common.app.lib.log.LogFields;

/**
 * ログを出力した場所（logger を呼び出したクラス・メソッド）を class_name / method_name で出力する provider。
 * logback の caller data（呼び出し元スタック）を読み、最初の「素通しfacade でないフレーム」を出力元とする。
 * 取得できなければ {@code "null"}（キーは出力）。
 *
 * <p>固定ロガー名のため通常のクラスロガー名が失われるのを補う。どのロガーのイベントにも appender で効くため、
 * 業務コードが直接ロガーを呼ぶ既存部品のログにも付与される（部品側の明示取得は不要）。
 *
 * <p>飛ばすのは「素通しfacade」（業務→facade→logger の中間クラス）だけ：既定で {@code ApplicationLogger}、
 * 追加は定数 {@code EXTRA_FACADE_PREFIXES}（合流時に編集）。アスペクト/フィルタ等は
 * 「出力した本人」なので飛ばさない（例: サービスジャーナル＝アスペクト、アクセスログ＝フィルタ）。
 */
public class CallerDataJsonProvider extends AbstractJsonProvider<ILoggingEvent> {

    /** 既定で飛ばす素通しfacade（業務→facade→logger の中間クラス）。 */
    private static final String LIB_FACADE = "jp.co.xxx.common.app.lib.log.ApplicationLogger";

    // TODO【仮値】追加で飛ばす素通しfacade の FQCN 接頭辞。合流先に独自ログ facade（業務→既存facade→logger）が
    // あれば、そのパッケージ接頭辞を登録する。既定は空（ApplicationLogger のみ除外）。
    private static final List<String> EXTRA_FACADE_PREFIXES = List.of();

    @Override
    public void writeTo(JsonGenerator generator, ILoggingEvent event) throws IOException {
        StackTraceElement origin = origin(event.getCallerData());
        generator.writeStringField(LogFields.CLASS_NAME, origin != null ? origin.getClassName() : "null");
        generator.writeStringField(LogFields.METHOD_NAME, origin != null ? origin.getMethodName() : "null");
    }

    /** caller data の先頭から、素通しfacade でない最初のフレーム＝出力元。 */
    private static StackTraceElement origin(StackTraceElement[] caller) {
        if (caller == null) {
            return null;
        }
        for (StackTraceElement e : caller) {
            if (!isFacade(e.getClassName())) {
                return e;
            }
        }
        return null;
    }

    private static boolean isFacade(String className) {
        if (className.startsWith(LIB_FACADE)) {
            return true;
        }
        for (String prefix : EXTRA_FACADE_PREFIXES) {
            if (className.startsWith(prefix)) {
                return true;
            }
        }
        return false;
    }
}
