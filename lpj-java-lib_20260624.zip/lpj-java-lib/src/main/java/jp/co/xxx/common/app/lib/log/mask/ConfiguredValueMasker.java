package jp.co.xxx.common.app.lib.log.mask;

import com.fasterxml.jackson.core.JsonStreamContext;

import net.logstash.logback.mask.ValueMasker;

/**
 * 全フィールドの文字列値に、yml 由来のキー名/値パターンマスクを適用する {@link ValueMasker}。
 * appender 層（{@code MaskingJsonGeneratorDecorator}）に差し、body/result/args/message/url 等の
 * 文字列を、呼び出し側を介さず JSON 書き出し時にマスクする（全ロガー対象）。
 *
 * <p>規則は {@link LogMaskRules}（yml→{@link LogMaskingService} 経由）から実行時に読む。
 * ロジックは {@link LogMaskingService#maskKeys} に委譲（規則エンジンを一本化）。
 */
public class ConfiguredValueMasker implements ValueMasker {

    @Override
    public Object mask(JsonStreamContext context, Object value) {
        if (value instanceof CharSequence cs) {
            String original = cs.toString();
            String masked = LogMaskingService.maskKeys(original, LogMaskRules.bodyKeys(), LogMaskRules.bodyPatterns());
            if (!original.equals(masked)) {
                return masked; // 変化した時だけ置換（無変化は null で素通し）
            }
        }
        return null;
    }
}
