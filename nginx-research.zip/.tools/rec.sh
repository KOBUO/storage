# 証跡取得の共通処理。表示するコマンド文字列と実行するコマンドを同一にする。
rec_begin() { REC_DIR="$1"; mkdir -p "$REC_DIR"; : > "$REC_DIR/実行ログ.txt"; REC_T=$(date '+%Y-%m-%dT%H:%M:%S'); }
run() {  # run "<コマンド全文>"
    printf '$ %s\n' "$1" >> "$REC_DIR/実行ログ.txt"
    eval "$1" >> "$REC_DIR/実行ログ.txt" 2>&1
    printf '\n' >> "$REC_DIR/実行ログ.txt"
}
rec_logs() { docker compose logs "$1" --since "$REC_T" --no-log-prefix > "$REC_DIR/コンテナログ.txt" 2>&1; }
