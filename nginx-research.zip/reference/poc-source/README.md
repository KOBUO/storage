# PoC 実ソース（撮影画像からの復元）

出典: 第2弾画像 IMG_5366〜5384（`canary_deployment` プロジェクトを IDE で開いた画面）。
**撮影画像から書き起こした復元版**であり、細部（空白・一部行）は原本と差異があり得る。
正本は Box の `canary_deployment.zip`（JIKIPH0-220 参照）。

## ディレクトリ構成（実物）

```
canary_deployment/
├─ init/                 # DB 初期化（検証用データ投入）
│   ├─ Dockerfile
│   ├─ entrypoint.sh
│   ├─ init.sql
│   └─ poc-canary-deployment-init-revision2.json
├─ loader/               # DB→JSON ローダー（サイドカー, ワンショット）
│   ├─ Dockerfile
│   └─ loader.py
├─ nginx/
│   ├─ Dockerfile
│   ├─ entrypoint.sh
│   ├─ nginx.conf
│   ├─ njs/route.js
│   └─ poc-canary-deployment-nginx-revision11.json
├─ routing_backend/      # 検証用 backend（固定レスポンス）
│   ├─ app.py
│   ├─ Dockerfile
│   └─ poc-canary-deployment-routing-backend-revision1.json
├─ shared/               # 共有ボリューム受け渡し（routing.json）
└─ README.md
```

## 復元ファイル

- [nginx/nginx.conf](nginx/nginx.conf)
- [nginx/entrypoint.sh](nginx/entrypoint.sh)
- [nginx/route.js](nginx/route.js)
- [nginx/Dockerfile](nginx/Dockerfile)
- [loader/loader.py](loader/loader.py)
- [loader/Dockerfile](loader/Dockerfile)
- [task-def/nginx-task.md](task-def/nginx-task.md) — ECS タスク定義（nginx + loader サイドカー）抜粋

> init/ と routing_backend/ の中身は今回の画像では未撮影（第1弾で存在は確認済）。TODO。
