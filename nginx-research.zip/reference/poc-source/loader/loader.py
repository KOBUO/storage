# PoC loader/loader.py（撮影画像 IMG_5382, 5383 からの復元）
# 役割: Aurora(PostgreSQL) の routing / default_routing を読み、routing.json を共有ボリュームへ出力。
#       ワンショット実行（常駐しない）。ECS タスクで essential=false + dependsOn(SUCCESS) で nginx より先に完了。
import json
import os
import psycopg2

ROUTING_JSON_PATH = os.environ["ROUTING_JSON_PATH"]
DB_HOST = os.environ["DB_HOST"]
DB_PORT = int(os.environ["DB_PORT"])
DB_NAME = os.environ["DB_NAME"]
DB_USER = os.environ["DB_USER"]
DB_PASSWORD = os.environ["DB_PASSWORD"]

conn = psycopg2.connect(
    host=DB_HOST,
    port=DB_PORT,
    dbname=DB_NAME,
    user=DB_USER,
    password=DB_PASSWORD,
    connect_timeout=5,
)

result = {
    "defaults": {},
    "stores": {},
}

sql_default = """
SELECT request_context_path, request_version, routing_version, start_at
FROM default_routing
ORDER BY request_context_path, request_version, start_at
"""

sql_routing = """
SELECT store_code, request_context_path, request_version, routing_version, start_at, end_at
FROM routing
ORDER BY store_code, request_context_path, request_version, start_at
"""

with conn:
    with conn.cursor() as cur:
        # default_routing → result["defaults"]  キー: "|{context_path}|{version}"
        cur.execute(sql_default)
        for request_context_path, request_version, routing_version, start_at in cur.fetchall():
            key = f"|{request_context_path}|{request_version}"
            result["defaults"].setdefault(key, []).append({
                "routing_version": routing_version,
                "start_at": start_at.isoformat() if start_at else None,
                "end_at": None,
            })

        # routing → result["stores"]  キー: "{store_code}|{context_path}|{version}"
        cur.execute(sql_routing)
        for store_code, request_context_path, request_version, routing_version, start_at, end_at in cur.fetchall():
            key = f"{store_code}|{request_context_path}|{request_version}"
            result["stores"].setdefault(key, []).append({
                "routing_version": routing_version,
                "start_at": start_at.isoformat() if start_at else None,
                "end_at": end_at.isoformat() if end_at else None,
            })

# routing.json を出力（この後 nginx/entrypoint.sh が routes.js にラップする）
# 出典: IMG_5436（L58-63）。撮影で確認済み。※with conn ブロックの外（トップレベル）。
with open(ROUTING_JSON_PATH, "w", encoding="utf-8") as f:
    json.dump(result, f, ensure_ascii=False)

print("===== routing.json =====")
print(json.dumps(result, ensure_ascii=False, indent=2))
print(f"routing json created: {ROUTING_JSON_PATH}")
