// PoC nginx/njs/route.js（撮影画像 IMG_5371〜5375 からの復元）
// njs のカナリアルーティング本体。routes.js(config) を import し、pick_upstream を js_set で公開。
// ※撮影からの復元のため細部（デバッグ log 等）に差異あり得る。

import config from '/etc/nginx/njs/routes.js';

var HEADER_STORE = 'X-Shop-Id';   // 店舗コードを載せるヘッダー名

// ヘッダーを大文字小文字を無視して取得
function getHeaderCaseInsensitive(headers, name) {
    var key;
    for (key in headers) {
        if (key.toLowerCase() === name.toLowerCase()) {
            return headers[key];
        }
    }
    return '';
}

// ヘッダー値の正規化（配列なら先頭要素）
function normalizeHeaderValue(value) {
    if (!value) return '';
    if (Array.isArray(value)) return value[0];
    return value;
}

// 元の URI を取得（request_uri 優先、なければ r.uri）
function getOriginalUri(r) {
    var requestUri = r.variables.request_uri || r.uri || '';
    var qpos = requestUri.indexOf('?');
    if (qpos >= 0) {
        return requestUri.substring(0, qpos);
    }
    return requestUri;
}

// URI を context_path / version に分解（例: /order/v2/... → order, v2）
function splitUri(uri) {
    var parts = uri.split('/').filter(Boolean);
    if (parts.length < 2) {
        return null;
    }
    return {
        request_context_path: parts[0],
        request_version: parts[1]
    };
}

// ルートが現在時刻で有効か（start_at / end_at の期間判定）
function isActive(nowMs, route) {
    var startMs = Date.parse(route.start_at);
    if (isNaN(startMs) || nowMs < startMs) return false;
    if (route.end_at) {
        var endMs = Date.parse(route.end_at);
        if (!isNaN(endMs) && nowMs >= endMs) return false;
    }
    return true;
}

// 有効なルートのうち、最も新しい start_at のものを選ぶ
function findActiveRoute(routeList, nowMs) {
    var i;
    var candidate = null;
    if (!routeList || routeList.length === 0) return null;
    for (i = 0; i < routeList.length; i++) {
        var route = routeList[i];
        if (!isActive(nowMs, route)) continue;
        if (candidate == null) {
            candidate = route;
            continue;
        }
        var c = Date.parse(candidate.start_at);
        var n = Date.parse(route.start_at);
        if (!isNaN(n) && !isNaN(c) && n > c) {
            candidate = route;
        }
    }
    return candidate;
}

// routing_version（例 "SHOP0002_V2" / "DEFAULT"）→ upstream URL
function routingVersionToUpstream(version) {
    if (!version) return null;
    return config.upstreamMap[version] || null;
}

function safeJson(value) {
    try {
        return JSON.stringify(value);
    } catch (e) {
        return '[json stringify error]';
    }
}

// ==== メイン: js_set $upstream route.pick_upstream ====
function pick_upstream(r) {
    var rawStoreCode = getHeaderCaseInsensitive(r.headersIn, HEADER_STORE);
    var storeCode = normalizeHeaderValue(rawStoreCode);
    var originalUri = getOriginalUri(r);
    var parsed = splitUri(originalUri);

    // デバッグログ
    r.error('===== route decision start =====');
    r.error('r.uri=' + r.uri);
    r.error('request_uri=' + (r.variables.request_uri || ''));
    r.error('originalUri=' + originalUri);
    r.error('headersIn=' + safeJson(r.headersIn));
    r.error('rawStoreCode=' + safeJson(rawStoreCode));
    r.error('storeCode=' + storeCode);

    if (!parsed) {
        r.error('fallback reason=parsed uri is invalid');
        r.error('===== route decision end =====');
        return config.upstreamMap['DEFAULT'];
    }

    var nowMs = Date.now();
    var storeKey   = storeCode + '|' + parsed.request_context_path + '|' + parsed.request_version;
    var defaultKey =             '|' + parsed.request_context_path + '|' + parsed.request_version;

    r.error('storeKey=' + storeKey);
    r.error('defaultKey=' + defaultKey);

    // 1) 店舗固有ルート
    var storeRouteList = config.routingTable.stores && config.routingTable.stores[storeKey];
    r.error('storeRouteList=' + safeJson(storeRouteList));
    var activeStoreRoute = findActiveRoute(storeRouteList, nowMs);
    r.error('activeStoreRoute=' + safeJson(activeStoreRoute));
    var storeUpstream = activeStoreRoute && routingVersionToUpstream(activeStoreRoute.routing_version);
    r.error('storeUpstream=' + storeUpstream);
    if (storeUpstream) {
        r.error('selected route=store specific');
        r.error('return upstream=' + storeUpstream);
        r.error('===== route decision end =====');
        return storeUpstream;
    }

    // 2) デフォルトルート（店舗コードなしのキー）
    var defaultRouteList = config.routingTable.defaults && config.routingTable.defaults[defaultKey];
    r.error('defaultRouteList=' + safeJson(defaultRouteList));
    var activeDefaultRoute = findActiveRoute(defaultRouteList, nowMs);
    r.error('activeDefaultRoute=' + safeJson(activeDefaultRoute));
    var defaultUpstream = activeDefaultRoute && routingVersionToUpstream(activeDefaultRoute.routing_version);
    r.error('defaultUpstream=' + defaultUpstream);
    if (defaultUpstream) {
        r.error('selected route=default');
        r.error('return upstream=' + defaultUpstream);
        r.error('===== route decision end =====');
        return defaultUpstream;
    }

    // 3) 最終フォールバック
    r.error('fallback reason=default route not found');
    r.error('return upstream=' + config.upstreamMap['DEFAULT']);
    r.error('===== route decision end =====');
    return config.upstreamMap['DEFAULT'];
}

export default { pick_upstream };
