#!/bin/sh
# PoC nginx/entrypoint.sh（撮影画像 IMG_5369 からの復元）
# 役割: loader が出力した routing.json をラップして njs 用 routes.js を生成 → nginx 起動。
set -eu

OUT_JS="/etc/nginx/njs/routes.js"

echo "Generating $OUT_JS from $ROUTING_FILE ..."

cat > "$OUT_JS" <<EOF
export default {
    routingTable:
EOF

cat "$ROUTING_FILE" >> "$OUT_JS"

cat >> "$OUT_JS" <<EOF
,
    upstreamMap: {
        "DEFAULT": "${DEFAULT_UPSTREAM}",
        "SHOP0002_V2": "${SHOP0002_V2_UPSTREAM}"
    }
};
EOF

echo "===== routes.js ====="
cat "$OUT_JS"

echo "Start nginx"
exec nginx -g 'daemon off;'

# --- 生成される routes.js のイメージ ---
# export default {
#     routingTable: { "defaults": {...}, "stores": {...} },   ← routing.json の中身
#     upstreamMap: { "DEFAULT": "http://...", "SHOP0002_V2": "http://..." }
# };
#
# ★商用課題: upstreamMap を環境変数でハードコード列挙している。
#   routing_version（=upstream名）が増えるたびに env と本行を増やす必要 → スケール設計が TODO。
