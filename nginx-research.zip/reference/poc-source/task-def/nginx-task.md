# ECS タスク定義（nginx + loader サイドカー）

出典: 撮影画像 IMG_5377〜5381（`poc-canary-deployment-nginx-revision11.json`）。
値は撮影からの読み取り。**DB 認証情報が平文**である点など、PoC 固有の簡略化に注意。

## コンテナ構成

```
Task: poc-canary-deployment-nginx (Fargate / awsvpc / X86_64・LINUX / cpu 256 / memory 512)
├─ container: nginx   (essential=true 想定)
│   image: .../poc-canary-deployment-nginx:11
│   portMappings: 80/tcp (http)
│   environment:
│     ROUTING_FILE        = /shared/routing.json
│     DEFAULT_UPSTREAM    = http://192.168.1.227:80
│     SHOP0002_V2_UPSTREAM= http://192.168.0.65:80
│   mountPoints: shared-volume → /shared (readOnly=true)
│   dependsOn:   loader (condition=SUCCESS)    ★loader 正常終了後に起動
│   logConfiguration: awslogs
│
└─ container: loader  (essential=false, ワンショット)
    image: .../poc-canary-deployment-loader:3
    environment:
      DB_NAME           = poc_db
      ROUTING_JSON_PATH = /shared/routing.json
      DB_HOST           = lsc-poc-aurora-db-instance-1.xxxxx.ap-northeast-1.rds.amazonaws.com
      DB_PORT           = 5432
      DB_USER           = poc_a
      DB_PASSWORD       = poc_a          ★平文（PoC）。商用は Secrets Manager 必須
    mountPoints: shared-volume → /shared (readOnly=false)
    logConfiguration: awslogs

volumes: shared-volume (host: {})           ← タスク内の空ボリューム（コンテナ間共有）
family: poc-canary-deployment-nginx
executionRoleArn: .../role/LSC-POC-IAMR-TASKEXECUTION
networkMode: awsvpc
requiresCompatibilities: [FARGATE]
```

## 設計上の重要ポイント（商用へ）

1. **起動順序**: `loader(essential=false) → SUCCESS → nginx 起動`。loader は routing.json を書いて exit。
   - loader が失敗すると nginx は起動しない（=不正なルーティングで起動しない安全側）。この挙動を商用でも踏襲するか要確認。
2. **DB 認証情報**: PoC は平文環境変数。**商用は Secrets Manager / SSM Parameter Store + `secrets` 指定**へ。→ TODO
3. **upstream の env 注入**: `DEFAULT_UPSTREAM` / `SHOP0002_V2_UPSTREAM` のように **routing_version ごとに環境変数**。
   バージョン追加ごとに task-def と entrypoint.sh の両方を修正する必要 → **拡張性の設計課題**。→ TODO
4. **共有ボリューム**は `host: {}`（Fargate のタスクローカル）。nginx は readOnly。
5. cpu/memory は PoC 値（256/512）。商用はサイジング要検討。
