# ローカル試験環境 — 本部画面

`試験ケース_本部画面_ローカル.md` の実施手順で使用する。

## 構成

| サービス | 役割 |
|---------|------|
| `app` | 本部画面の Nginx（`docker/nginx` をビルド）。`http://localhost:8080` で受け付ける |
| `s3stub` | S3 代替のスタブ。HTTPS で待ち受ける（実装が `proxy_ssl_verify on` のため TLS が必須） |

`s3stub/tls/` の証明書は検証用の自己署名。`ca.crt` を `app` の `/etc/ssl/certs/ca-certificates.crt` へマウントして検証を通す。

## 起動

```sh
docker compose up -d
```

環境変数は実行時に上書きする。

```sh
LIMIT_CONNECTION=1 docker compose up -d app       # 手順1
PROXY_READ_TIMEOUT=1s docker compose up -d app    # 手順10
MAX_BODY_SIZE=1k docker compose up -d app         # 手順11
```

## 資材の差し替えが必要な手順

手順2（`error.html` を除く）・手順4（静的コンテンツを除く）・手順6（500を返す定義を加える）は、
`docker/nginx` を複製して該当ファイルを変更したうえでビルドする。

## スタブが返す内容

- `/b/hello.txt`・`/b/large.bin`・`/b/日本 語.txt` … 200
- 存在しないキー … 404（S3 を模した XML）
- `/b/slow.bin` … 10秒後に応答（応答受信のタイムアウト用）
- `/b/sample/delivery.zip` … 200（詳細画面の「ダウンロード」ボタンの取得先）
- PUT … 200（格納はしない）
