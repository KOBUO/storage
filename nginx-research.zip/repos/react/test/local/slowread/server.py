"""受信を遅らせるスタブ。TLS ハンドシェイクのあと本文を読まない。"""
import socket
import ssl
import time

context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
context.load_cert_chain("/tls/server.crt", "/tls/server.key")

server = socket.socket()
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(("0.0.0.0", 443))
server.listen(16)

while True:
    connection, _ = server.accept()
    try:
        connection = context.wrap_socket(connection, server_side=True)
    except ssl.SSLError:
        connection.close()
        continue
    time.sleep(120)
    connection.close()
