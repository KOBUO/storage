# 試験ケース（AWS） — 本部画面

- 設計根拠: 本部画面.md
- 対象実装: 本リポジトリの `docker/`
- 実施環境: AWS（ECS Fargate）。ログは CloudWatch Logs で確認する。
- 証跡取得時は接続先を直書きせず、事前に `接続先=http://<実際の接続先>` を実行（この行は証跡に含めない）し、`curl -i "$接続先/…"` の形で実行する。
- デプロイイメージは全ケースで同一とし、タスク定義の環境変数のみを変更する。
- **ケースはデプロイ1回を単位とする。** 環境変数が異なれば別ケースとし、同一デプロイで確認できるものは観点で分ける。
- **AWS で実施するのは、環境変数の変更と curl の単発実行だけで確認できるものに限る。** 接続先に特定の状態を求めるもの（接続できない・応答が遅い・任意の応答を返させる）、スタブの用意、負荷、大きいBODYの送信、資材やマウントの操作を伴うものは、すべてローカルで実施する。試験データの事前配置（S3 のオブジェクト）は、事前準備として AWS でも行う。
- ケース番号・観点番号は `試験ケース_本部画面_ローカル.md` と通しで採番する（AWS: ケース1〜4 / ローカル: ケース5〜28）。

## 環境変数の既定値

各ケースは、この値を基準とする。ケースに記載のない環境変数はこの値のままとする。

| 環境変数 | 既定値 |
|---------|-------|
| `WORKER_CONNECTIONS` | `512` |
| `LIMIT_CONNECTION` | `10` |
| `LIMIT_ZONE_SIZE` | `10m` |
| `S3_ENDPOINT` | `s3.ap-northeast-1.amazonaws.com` |
| `S3_PORT` | `443` |
| `S3_BUCKET` | `<対象バケット>` |
| `MAX_BODY_SIZE` | `100m` |
| `PROXY_CONNECT_TIMEOUT` | `5s` |
| `PROXY_READ_TIMEOUT` | `60s` |
| `PROXY_SEND_TIMEOUT` | `60s` |

`DNS_RESOLVER` / `CONTAINER_ID` / `CONTAINER_NAME` は起動時に生成するため、タスク定義には設定しない。

## 事前準備

`S3_BUCKET` のバケットに `hello.txt` を配置する。`nonexistent.bin` は配置しない。

---

## ケース1 静的コンテンツが配信され、S3 へ中継されること

```
WORKER_CONNECTIONS=512
LIMIT_CONNECTION=10
LIMIT_ZONE_SIZE=10m
S3_ENDPOINT=s3.ap-northeast-1.amazonaws.com
S3_PORT=443
S3_BUCKET=<対象バケット>
MAX_BODY_SIZE=100m
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
```

```sh
curl -i "$接続先/health"                              # 1-2
curl -i "$接続先/"                                    # 1-3
curl -i "$接続先/orders/123"                          # 1-4・1-6・1-12
curl -i "$接続先/assets/nope.js"                      # 1-6
curl -i "$接続先/orders/"                             # 1-6・1-7
curl -i "$接続先/s3/hello.txt"                        # 1-5・1-8
curl -i -X PUT --data 'test' "$接続先/s3/upload.bin"  # 1-9
curl -i -X POST "$接続先/s3/hello.txt"                # 1-10
curl -i "$接続先/s3/nonexistent.bin"                  # 1-11
```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 1-1 | 起動成功・コンテナ情報の取得 | タスク起動成功。ログの `id`=コンテナID / `name`=コンテナ名（タスクメタデータ由来） | |
| 1-2 | ヘルスチェック | `/health` が 200 `ok`（アクセスログに出力されない） | |
| 1-3 | 定義済みパスの配信 | `/` が 200 で index.html | |
| 1-4 | 未定義パスの応答 | `/orders/123` が 200 で index.html | |
| 1-5 | 正常アクセスのログ項目 | level=INFO / level_value=20000 / type=app / thread＝ワーカープロセスID・接続の通し番号・リクエスト番号を連結した値 / url＝メソッド・URI・通信プロトコル（クエリ込み）/ status / latency / timestamp=JST `yyyy-MM-dd HH:mm:ss.SSS` / subtype=NGINX / function・user・action・trace=`-`。`latency` は S3 への中継など処理に時間を要するリクエストで所要時間（ミリ秒）が出る（静的コンテンツは1ミリ秒未満で完了するため `0`） | |
| 1-6 | 404 は index.html を返却すること | 未定義URL・欠落した資材・末尾スラッシュとも 200 で本文=index.html | |
| 1-7 | キャッシュ制御 | `error_page 404` 経由でも `Cache-Control: no-cache` が付与される | |
| 1-8 | S3 ダウンロードの中継 | 200。取得したファイルが元と一致する（`S3_BUCKET` の前置・VPCエンドポイント経由・バケットポリシーで認可） | |
| 1-9 | S3 アップロードの中継 | PUT が 200。S3 にオブジェクトが格納される | |
| 1-10 | 対象外のメソッド | POST は **405** で本文=error.html。ログ ERROR「許可されていないメソッドです。」 | |
| 1-11 | S3エラーの透過 | S3 が返す 403・404 をステータス・本文（XML）とも加工せず返却する。ログ level=INFO | |
| 1-12 | 静的コンテンツとの分離 | `/s3` 以外のURLは従来どおり静的コンテンツ・index.html が返る | |

1-1 は、タスクの起動状況と起動時ログで確認する。

## ケース2 共有メモリを確保できない大きさを設定した場合、起動に失敗すること

```
WORKER_CONNECTIONS=512
LIMIT_CONNECTION=10
LIMIT_ZONE_SIZE=4k            ← 変更
S3_ENDPOINT=s3.ap-northeast-1.amazonaws.com
S3_PORT=443
S3_BUCKET=<対象バケット>
MAX_BODY_SIZE=100m
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
```

起動しないため、確認はログで行う。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 2-1 | `LIMIT_ZONE_SIZE` の反映 | 起動失敗。ログ ERROR「Nginx 設定ファイルの妥当性検証に失敗しました。（{検証結果}）」 | |

## ケース3 必須の環境変数が設定されていない場合、起動に失敗すること

```
WORKER_CONNECTIONS            ← 削除
LIMIT_CONNECTION=10
LIMIT_ZONE_SIZE=10m
S3_ENDPOINT=s3.ap-northeast-1.amazonaws.com
S3_PORT=443
S3_BUCKET=<対象バケット>
MAX_BODY_SIZE=100m
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
```

起動しないため、確認はログで行う。

代表として `WORKER_CONNECTIONS` を未設定にする。他の環境変数および複数未設定はローカルで確認する。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 3-1 | 必須環境変数の検証 | 起動失敗。ログ ERROR「必須環境変数が設定されていません。（環境変数名: WORKER_CONNECTIONS）」 | |
| 3-2 | 起動時ログの出力項目 | `timestamp`＝`yyyy-MM-dd HH:mm:ss.SSS` / `id`＝コンテナID / `name`＝コンテナ名 / `level`=ERROR / `level_value`=40000 / `type`=monitor / `thread`・`function`・`user`・`action`・`trace`=`-` / `subtype`=NGINX | |

3-1・3-2 は、起動時に出力されるログで確認する。

## ケース4 数値として扱えない値を設定した場合、設定ファイルの検証に失敗すること

```
WORKER_CONNECTIONS=abc        ← 変更
LIMIT_CONNECTION=10
LIMIT_ZONE_SIZE=10m
S3_ENDPOINT=s3.ap-northeast-1.amazonaws.com
S3_PORT=443
S3_BUCKET=<対象バケット>
MAX_BODY_SIZE=100m
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
```

起動しないため、確認はログで行う。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 4-1 | 設定ファイルの妥当性検証 | 起動失敗。ログ ERROR「Nginx 設定ファイルの妥当性検証に失敗しました。（{検証結果}）」 | |

---

確認後は既定値へ戻す。

ケース5〜28 はローカルで実施する（`試験ケース_本部画面_ローカル.md`）。

| ケース | 内容 |
|:---:|------|
| 5 | S3 への中継が正常に行えること |
| 6 | 同時接続数が上限を超えた場合、503で error.html が返ること |
| 7 | ワーカープロセスあたりの接続数が不足した場合、エラーログが出力されること |
| 8 | リクエストのサイズが上限を超えた場合、413で error.html が返ること |
| 9 | 中継先の応答が設定時間を超えた場合、504で error.html が返ること |
| 10 | 中継先の名前を解決できない場合、502で error.html が返ること |
| 11 | 中継先が接続を拒否した場合、502で error.html が返ること |
| 12 | 中継先が接続に応答しない場合、504で error.html が返ること |
| 13 | エラー画面が配置されていない場合、起動に失敗すること |
| 14 | 静的コンテンツが配置されていない場合、起動に失敗すること |
| 15 | 設定ファイルを生成できない場合、起動に失敗すること |
| 16 | サーバ内部でエラーが発生した場合、500で error.html が返ること |
| 17 | `LIMIT_CONNECTION` が設定されていない場合、起動に失敗すること |
| 18 | `LIMIT_ZONE_SIZE` が設定されていない場合、起動に失敗すること |
| 19 | `S3_ENDPOINT` が設定されていない場合、起動に失敗すること |
| 20 | `S3_PORT` が設定されていない場合、起動に失敗すること |
| 21 | `S3_BUCKET` が設定されていない場合、起動に失敗すること |
| 22 | `MAX_BODY_SIZE` が設定されていない場合、起動に失敗すること |
| 23 | `PROXY_CONNECT_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 24 | `PROXY_READ_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 25 | `PROXY_SEND_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 26 | 必須の環境変数が複数設定されていない場合、最初の1件がログに出力されること |
| 27 | 既定値の場合、接続数不足のエラーログが出力されないこと |
| 28 | 中継先がリクエストを受信しない場合、504で error.html が返ること |
