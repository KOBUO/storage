import fs from 'fs';

var ERROR_PAGE = '/usr/share/nginx/html/error.html';
var errorPageBody = null;

// 静的ファイルの返却は PUT に応答できない（405 になる）ため、エラー画面は njs で返却する。
function errorPage(r) {
    if (errorPageBody === null) {
        errorPageBody = fs.readFileSync(ERROR_PAGE);
    }
    r.headersOut['Content-Type'] = 'text/html';
    r.headersOut['Cache-Control'] = 'no-cache';
    r.return(Number(r.variables.status), errorPageBody);
}

var ERROR_MESSAGES = {
    405: '許可されていないメソッドです。',
    413: 'リクエストのサイズが上限を超えました。',
    500: 'サーバ内部でエラーが発生しました。',
    502: 'S3 へ接続できません。',
    503: '同時接続数が上限を超えました。',
    504: 'S3 からの応答がタイムアウトしました。',
};

// $nginx_error は error_page の転送先（@error_page）でのみ設定される。
// S3 が返した応答はここを経由しないため、5xx でも Nginx 起因とは扱わない。
function isNginxError(r) {
    return r.variables.nginx_error === '1';
}

function logLevel(r) {
    return isNginxError(r) ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    return isNginxError(r) ? (ERROR_MESSAGES[Number(r.variables.status)] || '-') : '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { errorPage, logLevel, logMessage, logLatency, logTimestamp };
