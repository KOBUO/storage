// 応答受信のタイムアウトを再現するため、応答を遅延させる。
function slow(r) {
    setTimeout(function () {
        r.return(200, 'slow response');
    }, 10000);
}

export default { slow };
