# ローカル試験環境 — 電文受付

`試験ケース_電文受付_ローカル.md` の実施手順で使用する。

## 構成

| サービス | 役割 |
|---------|------|
| `db` | Postgres。タイムゾーンは JST（適用開始日時が JST として解釈されるため揃える） |
| `backend` | 転送先のスタブ。起動時に `ddl.sql`・`data.sql` を投入し、受信したURIを返す |
| `loader` | サイドカー。ルーティング情報を取得して `/shared/routing.json` を出力する |
| `app` | 電文受付の Nginx。`http://localhost:8082` で受け付ける |
| `slowread` | 受信を遅らせるスタブ。送信のタイムアウト（手順15）で使用する |

起動順は `db`（正常性確認）→ `backend`（投入完了）→ `loader`（正常終了）→ `app` の順に依存させている。

## 起動

```sh
docker compose up -d
LIMIT_CONNECTION=1 docker compose up -d app                                   # 503
BACKEND_URL=http://slowread:8080 PROXY_SEND_TIMEOUT=1s docker compose up -d app  # 手順15
```

## データの操作

```sh
docker compose exec db psql -U nginx_loader -d cosmo -c "<SQL>"
```

投入データを変更したら、`docker compose rm -sf app loader` のうえ `docker compose up -d` で
サイドカーを再実行する（ルーティング情報は起動時に一括取得するため）。
