"""受信を遅らせるスタブ。接続を受け付けたまま本文を読まない。"""
import socket
import time

server = socket.socket()
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(("0.0.0.0", 8080))
server.listen(16)

while True:
    connection, _ = server.accept()
    time.sleep(120)
    connection.close()
