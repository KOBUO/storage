# 試験ケース（AWS） — 電文受付

- 設計根拠: 電文受付.md
- 対象実装: 本リポジトリの `docker/`（nginx + サイドカー loader）
- 実施環境: AWS（ECS Fargate）。ログは CloudWatch Logs で確認する。
- 証跡取得時は接続先を直書きせず、事前に `接続先=http://<実際の接続先>` を実行（この行は証跡に含めない）し、`curl -i "$接続先/…"` の形で実行する。
- デプロイイメージは全ケースで同一とし、タスク定義の環境変数のみを変更する。
- **ケースはデプロイ1回を単位とする。** 環境変数が異なれば別ケースとし、同一デプロイで確認できるものは観点で分ける。
- **AWS で実施するのは、環境変数の変更と curl の単発実行だけで確認できるものに限る。** 接続先（バックエンド・データベース）に特定の状態を求めるもの、スタブの用意、負荷、大きいBODYの送信、資材の操作を伴うものは、すべてローカルで実施する。ルーティング情報の事前投入は、事前準備として AWS でも行う。
- ケース番号・観点番号は `試験ケース_電文受付_ローカル.md` と通しで採番する（AWS: ケース1〜6 / ローカル: ケース7〜43）。

## 環境変数の既定値

各ケースは、この値を基準とする。ケースに記載のない環境変数はこの値のままとする。

＜Nginx コンテナ＞

| 環境変数 | 既定値 |
|---------|-------|
| `WORKER_CONNECTIONS` | `512` |
| `MAX_CONNECTIONS` | `10` |
| `BACKEND_URL` | `http://<バックエンドAPI前段のALBのDNS名>` |
| `LIMIT_CONNECTION` | `10` |
| `PROXY_CONNECT_TIMEOUT` | `5s` |
| `PROXY_READ_TIMEOUT` | `60s` |
| `PROXY_SEND_TIMEOUT` | `60s` |
| `MAX_BODY_SIZE` | `10m` |
| `LIMIT_ZONE_SIZE` | `10m` |

＜サイドカーコンテナ＞

| 環境変数 | 既定値 |
|---------|-------|
| `DATABASE_HOST` | `<Aurora のエンドポイント>` |
| `DATABASE_PORT` | `5432` |
| `DATABASE_NAME` | `cosmo` |
| `DATABASE_USER` | `nginx_loader` |
| `DATABASE_PASSWORD` | `<Secrets Manager から注入>` |
| `DATABASE_CONNECT_TIMEOUT` | `5` |
| `DATABASE_SSLMODE` | `require` |

`BACKEND_ADDRESS` / `DNS_RESOLVER` / `CONTAINER_ID` / `CONTAINER_NAME` は起動時に生成するため、タスク定義には設定しない。

## 事前準備

Aurora に検証データ（`test/backend/data.sql` と同じ内容）を投入する。転送先URIは、バックエンドAPI側の受信ログで確認する。

- ルーティング情報: `000002`=範囲内（`order/v1`→`v2`）/ `000003`=範囲外・後（適用終了が過去）/ `000004`=範囲外・前（適用開始が未来、2099年）
- デフォルトルーティング情報: `order/v1`→`v1`=範囲内 / `order/v1`→`v2`=範囲外・前（2099年）

---

## ケース1 適用期間と適用開始日時に従って振分けされること

```
＜Nginx＞
WORKER_CONNECTIONS=512
MAX_CONNECTIONS=10
BACKEND_URL=http://<ALBのDNS名>
LIMIT_CONNECTION=10
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
MAX_BODY_SIZE=10m
LIMIT_ZONE_SIZE=10m

＜サイドカー＞
DATABASE_HOST=<Auroraのエンドポイント>
DATABASE_PORT=5432
DATABASE_NAME=cosmo
DATABASE_USER=nginx_loader
DATABASE_PASSWORD=<Secrets Manager から注入>
DATABASE_CONNECT_TIMEOUT=5
DATABASE_SSLMODE=require
```

```sh
curl -i "$接続先/health"                                      # 1-2
curl -s -H 'X-Store-Cd: 000002' "$接続先/order/v1/serviceA"   # 1-3 範囲内
curl -s -H 'X-Store-Cd: 000003' "$接続先/order/v1/serviceA"   # 1-4 範囲外(後)
curl -s -H 'X-Store-Cd: 000004' "$接続先/order/v1/serviceA"   # 1-5 範囲外(前)
curl -s -H 'X-Store-Cd: 999999' "$接続先/order/v1/serviceA"   # 1-6・1-7 一般店舗
curl -s -H 'X-Store-Cd: 000002' -H 'X-Trace-ID: trace-abc-123' "$接続先/order/v1/serviceA"  # 1-8
curl -i "$接続先/order/v1/serviceA"                           # 1-10 店舗コードヘッダ欠落
curl -i -H 'X-Store-Cd: 000002' "$接続先/unknown/v9/x"        # 1-11 ルーティング先なし
```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 1-1 | 起動成功・コンテナ情報の取得 | タスク起動成功。ログの `id`=コンテナID / `name`=コンテナ名（タスクメタデータ由来） | |
| 1-2 | ヘルスチェック | `/health` が 200 `ok`（アクセスログに出力されない） | |
| 1-3 | ルーティング情報が範囲内 | `000002` は **`/order/v2/serviceA`** として届く（`v1`→`v2` に置換） | |
| 1-4 | ルーティング情報が範囲外（後） | `000003` は **`/order/v1/serviceA`**（デフォルトに従う） | |
| 1-5 | ルーティング情報が範囲外（前） | `000004` は **`/order/v1/serviceA`**（デフォルトに従う） | |
| 1-6 | デフォルトが範囲内 | `999999` は適用開始日時が到来済みのもの **`/order/v1/serviceA`** | |
| 1-7 | デフォルトが範囲外（前） | 適用開始日時が未来のもの（2099年の `v2`）は使われない | |
| 1-8 | 正常アクセスのログ項目 | level=INFO / level_value=20000 / type=app / thread＝ワーカープロセスID・接続の通し番号・リクエスト番号を連結した値 / message=`-` / function=serviceA（取得できない場合は `-`）/ user・action=`-` / trace=`X-Trace-ID` の値（無ければ `-`）/ url＝メソッド・URI・通信プロトコル（クエリ込み）/ status / latency / timestamp=JST `yyyy-MM-dd HH:mm:ss.SSS` / subtype=NGINX | |
| 1-9 | `DATABASE_SSLMODE` の既定値 | `require` のまま正常起動する（Aurora と暗号化接続が成立する） | |
| 1-10 | 店舗コードヘッダ欠落 | **400** + エラー電文（`Bad Request`）。ログ ERROR「店舗コードが設定されていません。」 | |
| 1-11 | ルーティング先が特定できない | **404** + エラー電文（`Not Found`）。ログ ERROR「ルーティング先が特定できません。」 | |

1-1 と 1-9 は、タスクの起動状況、起動時ログ、および 1-3〜1-7 の応答で確認する。

## ケース2 共有メモリを確保できない大きさを設定した場合、起動に失敗すること

```
＜Nginx＞
WORKER_CONNECTIONS=512
MAX_CONNECTIONS=10
BACKEND_URL=http://<ALBのDNS名>
LIMIT_CONNECTION=10
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
MAX_BODY_SIZE=10m
LIMIT_ZONE_SIZE=4k            ← 変更

＜サイドカー＞ 既定値のまま
```

起動しないため、確認はログで行う。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 2-1 | `LIMIT_ZONE_SIZE` の反映 | 起動失敗。ログ ERROR「Nginx 設定ファイルの妥当性検証に失敗しました。（{検証結果}）」 | |

## ケース3 暗号化しない接続を指定した場合、データベースへ接続できないこと

```
＜Nginx＞ 既定値のまま

＜サイドカー＞
DATABASE_HOST=<Auroraのエンドポイント>
DATABASE_PORT=5432
DATABASE_NAME=cosmo
DATABASE_USER=nginx_loader
DATABASE_PASSWORD=<Secrets Manager から注入>
DATABASE_CONNECT_TIMEOUT=5
DATABASE_SSLMODE=disable      ← 変更
```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 3-1 | `DATABASE_SSLMODE` の反映 | Aurora のパラメータ `rds.force_ssl` が有効の場合、平文接続が拒否され、サイドカーが ERROR「データベースへの接続に失敗しました。（接続先: {ホスト名}:{ポート番号}）」で異常終了する | |

`rds.force_ssl` が無効の場合は `disable` でも接続できるため、証跡はローカルのケース23で取得する。

## ケース4 サイドカーの必須の環境変数が設定されていない場合、Nginx が起動しないこと

```
＜Nginx＞ 既定値のまま

＜サイドカー＞
DATABASE_HOST                 ← 削除
DATABASE_PORT=5432
DATABASE_NAME=cosmo
DATABASE_USER=nginx_loader
DATABASE_PASSWORD=<Secrets Manager から注入>
DATABASE_CONNECT_TIMEOUT=5
DATABASE_SSLMODE=require
```

起動しないため、確認はログで行う。

代表として `DATABASE_HOST` を未設定にする。他の環境変数および複数未設定はローカルで確認する。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 4-1 | サイドカーの必須環境変数検証 | loader が ERROR「必須環境変数が設定されていません。（環境変数名: DATABASE_HOST）」で異常終了 | |
| 4-2 | Nginx が起動しないこと | dependsOn: SUCCESS により Nginx は起動せず、タスクは停止する | |

4-1・4-2 は、サイドカーの起動時ログとタスクの起動状況で確認する。

## ケース5 Nginx の必須の環境変数が設定されていない場合、起動に失敗すること

```
＜Nginx＞
WORKER_CONNECTIONS            ← 削除
MAX_CONNECTIONS=10
BACKEND_URL=http://<ALBのDNS名>
LIMIT_CONNECTION=10
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
MAX_BODY_SIZE=10m
LIMIT_ZONE_SIZE=10m

＜サイドカー＞ 既定値のまま
```

起動しないため、確認はログで行う。

代表として `WORKER_CONNECTIONS` を未設定にする。他の環境変数および複数未設定はローカルで確認する。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 5-1 | Nginx の必須環境変数検証 | 起動失敗。ログ ERROR「必須環境変数が設定されていません。（環境変数名: WORKER_CONNECTIONS）」 | |
| 5-2 | 起動時ログの出力項目 | `timestamp`＝`yyyy-MM-dd HH:mm:ss.SSS` / `id`＝コンテナID / `name`＝コンテナ名 / `level`=ERROR / `level_value`=40000 / `type`=monitor / `thread`・`function`・`user`・`action`・`trace`=`-` / `subtype`=NGINX | |

5-1・5-2 は、起動時に出力されるログで確認する。

## ケース6 数値として扱えない値を設定した場合、設定ファイルの検証に失敗すること

```
＜Nginx＞
WORKER_CONNECTIONS=abc        ← 変更
MAX_CONNECTIONS=10
BACKEND_URL=http://<ALBのDNS名>
LIMIT_CONNECTION=10
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
MAX_BODY_SIZE=10m
LIMIT_ZONE_SIZE=10m

＜サイドカー＞ 既定値のまま
```

起動しないため、確認はログで行う。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 6-1 | 設定ファイルの妥当性検証 | 起動失敗。ログ ERROR「Nginx 設定ファイルの妥当性検証に失敗しました。（{検証結果}）」 | |

---

確認後は既定値へ戻す。

ケース7〜43 はローカルで実施する（`試験ケース_電文受付_ローカル.md`）。

| ケース | 内容 |
|:---:|------|
| 7 | メソッド・クエリ・エンコードを保持して振分けされること |
| 8 | 適用開始日時の到来で転送先が切り替わること |
| 9 | 同時接続数が上限を超えた場合、503でエラー電文が返ること |
| 10 | バックエンド1台あたりの同時接続数が上限を超えた場合、502でエラー電文が返ること |
| 11 | ワーカープロセスあたりの接続数が不足した場合、エラーログが出力されること |
| 12 | バックエンドの応答が設定時間を超えた場合、504でエラー電文が返ること |
| 13 | バックエンドへの送信が設定時間を超えた場合、504でエラー電文が返ること |
| 14 | バックエンドが接続に応答しない場合、504でエラー電文が返ること |
| 15 | バックエンドの名前を解決できない場合、502でエラー電文が返ること |
| 16 | データベースが接続に応答しない場合、サイドカーが異常終了すること |
| 17 | サイドカーの `DATABASE_PORT` が誤っている場合、異常終了すること |
| 18 | サイドカーの `DATABASE_NAME` が誤っている場合、異常終了すること |
| 19 | サイドカーの `DATABASE_USER` が誤っている場合、異常終了すること |
| 20 | サイドカーの `DATABASE_PASSWORD` が誤っている場合、異常終了すること |
| 21 | ルーティング情報を取得できない場合、サイドカーが異常終了すること |
| 22 | デフォルトルーティング情報を取得できない場合、サイドカーが異常終了すること |
| 23 | デフォルトルーティング情報が0件の場合、サイドカーが異常終了すること |
| 24 | 取得した情報を整形できない場合、サイドカーが異常終了すること |
| 25 | ルーティング情報ファイルを出力できない場合、サイドカーが異常終了すること |
| 26 | 振分け定義を生成できない場合、Nginx の起動に失敗すること |
| 27 | 設定ファイルを生成できない場合、起動に失敗すること |
| 28 | サーバ内部でエラーが発生した場合、500でエラー電文が返ること |
| 29 | サイドカーの `DATABASE_SSLMODE` が既定の場合、暗号化できない接続では異常終了すること |
| 30 | Nginx の `MAX_CONNECTIONS` が設定されていない場合、起動に失敗すること |
| 31 | Nginx の `BACKEND_URL` が設定されていない場合、起動に失敗すること |
| 32 | Nginx の `LIMIT_CONNECTION` が設定されていない場合、起動に失敗すること |
| 33 | Nginx の `PROXY_CONNECT_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 34 | Nginx の `PROXY_READ_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 35 | Nginx の `PROXY_SEND_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 36 | Nginx の `MAX_BODY_SIZE` が設定されていない場合、起動に失敗すること |
| 37 | Nginx の `LIMIT_ZONE_SIZE` が設定されていない場合、起動に失敗すること |
| 38 | サイドカーの `DATABASE_PORT` が設定されていない場合、異常終了すること |
| 39 | サイドカーの `DATABASE_NAME` が設定されていない場合、異常終了すること |
| 40 | サイドカーの `DATABASE_USER` が設定されていない場合、異常終了すること |
| 41 | サイドカーの `DATABASE_PASSWORD` が設定されていない場合、異常終了すること |
| 42 | Nginx の必須の環境変数が複数設定されていない場合、最初の1件がログに出力されること |
| 43 | サイドカーの必須の環境変数が複数設定されていない場合、最初の1件がログに出力されること |
