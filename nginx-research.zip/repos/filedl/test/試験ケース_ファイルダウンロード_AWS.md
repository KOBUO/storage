# 試験ケース（AWS） — ファイルダウンロード

- 設計根拠: ファイルダウンロード.md
- 対象実装: 本リポジトリの `docker/`
- 実施環境: AWS（ECS Fargate）。ログは CloudWatch Logs で確認する。
- 前提: ダウンロードURLは API が発行する path-style の素のURL（署名なし）。ホスト名を nginx に置換して実行する。アクセス認可はバケットポリシー（VPCエンドポイント経由）で行う。
- 証跡取得時は接続先を直書きせず、事前に `接続先=http://<実際の接続先>` を実行（この行は証跡に含めない）し、`curl -i "$接続先/…"` の形で実行する。
- デプロイイメージは全ケースで同一とし、タスク定義の環境変数のみを変更する。
- **ケースはデプロイ1回を単位とする。** 環境変数が異なれば別ケースとし、同一デプロイで確認できるものは観点で分ける。
- **AWS で実施するのは、環境変数の変更と curl の単発実行だけで確認できるものに限る。** 接続先に特定の状態を求めるもの（接続できない・応答が遅い・任意の応答を返させる）、スタブの用意、負荷、大きいBODYの送信、資材やマウントの操作を伴うものは、すべてローカルで実施する。試験データの事前配置（S3 のオブジェクト）は、事前準備として AWS でも行う。
- ケース番号・観点番号は `試験ケース_ファイルダウンロード_ローカル.md` と通しで採番する（AWS: ケース1〜4 / ローカル: ケース5〜22）。

## 環境変数の既定値

各ケースは、この値を基準とする。ケースに記載のない環境変数はこの値のままとする。

| 環境変数 | 既定値 |
|---------|-------|
| `WORKER_CONNECTIONS` | `512` |
| `S3_ENDPOINT` | `s3.ap-northeast-1.amazonaws.com` |
| `S3_PORT` | `443` |
| `OFFLINE_BUCKET` | `<オフライン用バケット>` |
| `PROXY_CONNECT_TIMEOUT` | `5s` |
| `PROXY_READ_TIMEOUT` | `60s` |
| `PROXY_SEND_TIMEOUT` | `60s` |
| `LIMIT_CONNECTION` | `10` |
| `LIMIT_ZONE_SIZE` | `10m` |

`DNS_RESOLVER` / `CONTAINER_ID` / `CONTAINER_NAME` は起動時に生成するため、タスク定義には設定しない。

## 事前準備

検証データ（`test/s3/` と同じ配置）:

- オンライン: 対象バケットに `hello.txt`
- オフライン: `OFFLINE_BUCKET` に `2.0.0/fixed.txt`（`posVersion=2.0.0`・固定ファイル名 `fixed.txt`）
- 存在しない: `nonexistent.bin` は配置しない

---

## ケース1 S3 から中継され、リクエストの検証が行われること

```
WORKER_CONNECTIONS=512
S3_ENDPOINT=s3.ap-northeast-1.amazonaws.com
S3_PORT=443
OFFLINE_BUCKET=<オフライン用バケット>
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
LIMIT_CONNECTION=10
LIMIT_ZONE_SIZE=10m
```

```sh
curl -i "$接続先/health"                                                                   # 1-2
curl -i -H 'X-BandWidth-Limit: 8' -H 'X-Trace-ID: trace-abc-123' "$接続先/download/<バケット>/hello.txt"   # 1-6
curl -i -H 'X-BandWidth-Limit: 800' "$接続先/download/<バケット>/hello.txt"                 # 1-3
curl -i -H 'X-BandWidth-Limit: 800' "$接続先/download/offline/fixed.txt?posVersion=2.0.0"   # 1-4
curl -i -H 'X-BandWidth-Limit: 8'   "$接続先/download/<バケット>/nonexistent.bin"           # 1-5
curl -i "$接続先/download/<バケット>/hello.txt"                                            # 1-7
curl -i -H 'X-BandWidth-Limit: abc' "$接続先/download/<バケット>/hello.txt"                 # 1-8
curl -i -H 'X-BandWidth-Limit: 8' "$接続先/other/x"                                        # 1-9
curl -i -H 'X-BandWidth-Limit: 100001' "$接続先/download/<バケット>/hello.txt"              # 1-10
curl -i -X POST -H 'X-BandWidth-Limit: 8' "$接続先/download/<バケット>/hello.txt"           # 1-11
curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/fixed.txt"                     # 1-12
curl -i -H 'X-BandWidth-Limit: 8' "$接続先/download/offline/fixed.txt?posVersion=..%2Fx"   # 1-13
```

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 1-1 | 起動成功・コンテナ情報の取得 | タスク起動成功。ログの `id`=コンテナID / `name`=コンテナ名（タスクメタデータ由来） | |
| 1-2 | ヘルスチェック | `/health` が 200 `ok`（アクセスログに出力されない） | |
| 1-3 | オンラインファイルの中継 | `hello.txt` が 200・取得ファイルが元と一致（Host置換・VPCエンドポイント経由・バケットポリシー認可で S3 へ中継） | |
| 1-4 | オフラインファイルの中継 | `posVersion=2.0.0` により S3キー=`/<OFFLINE_BUCKET>/2.0.0/fixed.txt` で 200。転送時のクエリから `posVersion` は除去 | |
| 1-5 | S3エラーの透過 | `nonexistent.bin` は S3 が 403 を返す。ステータス・本文（XML）とも加工せず返却。ログ level=INFO | |
| 1-6 | 正常アクセスのログ項目 | level=INFO / level_value=20000 / type=app / thread＝ワーカープロセスID・接続の通し番号・リクエスト番号を連結した値 / message=`-` / url（メソッド・URI・通信プロトコル。クエリ込み）/ status / latency / timestamp=JST `yyyy-MM-dd HH:mm:ss.SSS` / subtype=NGINX / function・user・action=`-` / trace=`X-Trace-ID` の値 | |
| 1-7 | 帯域制限値ヘッダ欠落 | **400** + エラー電文（`Bad Request`）。ログ ERROR「帯域制限値が設定されていません。」 | |
| 1-8 | 帯域制限値が数値でない | **400** + エラー電文。ログ ERROR「帯域制限値が不正です。」 | |
| 1-9 | 対象外のパス | **404** + エラー電文（`Not Found`）。ログ ERROR「対象外のパスです。」 | |
| 1-10 | 帯域制限値が上限（`100000`）超過 | **400** + エラー電文。ログ ERROR「帯域制限値が不正です。」 | |
| 1-11 | GET / HEAD 以外のメソッド | **405** + エラー電文（`Method Not Allowed`）。ログ ERROR「許可されていないメソッドです。」 | |
| 1-12 | `posVersion` 欠落 | **400** + エラー電文。ログ ERROR「POSバージョンが設定されていません。」 | |
| 1-13 | `posVersion` が不正 | **400** + エラー電文。ログ ERROR「POSバージョンが不正です。」 | |

1-1 は、タスクの起動状況と起動時ログで確認する。

## ケース2 共有メモリを確保できない大きさを設定した場合、起動に失敗すること

```
WORKER_CONNECTIONS=512
S3_ENDPOINT=s3.ap-northeast-1.amazonaws.com
S3_PORT=443
OFFLINE_BUCKET=<オフライン用バケット>
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
LIMIT_CONNECTION=10
LIMIT_ZONE_SIZE=4k            ← 変更
```

起動しないため、確認はログで行う。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 2-1 | `LIMIT_ZONE_SIZE` の反映 | 起動失敗。ログ ERROR「Nginx 設定ファイルの妥当性検証に失敗しました。（{検証結果}）」 | |

## ケース3 必須の環境変数が設定されていない場合、起動に失敗すること

```
WORKER_CONNECTIONS            ← 削除
S3_ENDPOINT=s3.ap-northeast-1.amazonaws.com
S3_PORT=443
OFFLINE_BUCKET=<オフライン用バケット>
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
LIMIT_CONNECTION=10
LIMIT_ZONE_SIZE=10m
```

起動しないため、確認はログで行う。

代表として `WORKER_CONNECTIONS` を未設定にする。他の環境変数および複数未設定はローカルで確認する。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 3-1 | 必須環境変数の検証 | 起動失敗。ログ ERROR「必須環境変数が設定されていません。（環境変数名: WORKER_CONNECTIONS）」 | |
| 3-2 | 起動時ログの出力項目 | `timestamp`＝`yyyy-MM-dd HH:mm:ss.SSS` / `id`＝コンテナID / `name`＝コンテナ名 / `level`=ERROR / `level_value`=40000 / `type`=monitor / `thread`・`function`・`user`・`action`・`trace`=`-` / `subtype`=NGINX | |

3-1・3-2 は、起動時に出力されるログで確認する。

## ケース4 数値として扱えない値を設定した場合、設定ファイルの検証に失敗すること

```
WORKER_CONNECTIONS=abc        ← 変更
S3_ENDPOINT=s3.ap-northeast-1.amazonaws.com
S3_PORT=443
OFFLINE_BUCKET=<オフライン用バケット>
PROXY_CONNECT_TIMEOUT=5s
PROXY_READ_TIMEOUT=60s
PROXY_SEND_TIMEOUT=60s
LIMIT_CONNECTION=10
LIMIT_ZONE_SIZE=10m
```

起動しないため、確認はログで行う。

| # | 観点 | 想定結果 | 結果 |
|---|------|---------|------|
| 4-1 | 設定ファイルの妥当性検証 | 起動失敗。ログ ERROR「Nginx 設定ファイルの妥当性検証に失敗しました。（{検証結果}）」 | |

---

確認後は既定値へ戻す。

`PROXY_SEND_TIMEOUT` は GET / HEAD のみ許可しており、上流へ送信する本文がないため発火しない。設定値の確認は対象外とする。

ケース5〜22 はローカルで実施する（`試験ケース_ファイルダウンロード_ローカル.md`）。

| ケース | 内容 |
|:---:|------|
| 5 | 帯域制限つきでダウンロードできること |
| 6 | 同時ダウンロード数が上限を超えた場合、503でエラー電文が返ること |
| 7 | ワーカープロセスあたりの接続数が不足した場合、エラーログが出力されること |
| 8 | 中継先の応答が設定時間を超えた場合、504でエラー電文が返ること |
| 9 | 中継先の名前を解決できない場合、502でエラー電文が返ること |
| 10 | 中継先が接続を拒否した場合、502でエラー電文が返ること |
| 11 | 中継先が接続に応答しない場合、504でエラー電文が返ること |
| 12 | 設定ファイルを生成できない場合、起動に失敗すること |
| 13 | サーバ内部でエラーが発生した場合、500でエラー電文が返ること |
| 14 | `S3_ENDPOINT` が設定されていない場合、起動に失敗すること |
| 15 | `S3_PORT` が設定されていない場合、起動に失敗すること |
| 16 | `OFFLINE_BUCKET` が設定されていない場合、起動に失敗すること |
| 17 | `LIMIT_CONNECTION` が設定されていない場合、起動に失敗すること |
| 18 | `LIMIT_ZONE_SIZE` が設定されていない場合、起動に失敗すること |
| 19 | `PROXY_CONNECT_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 20 | `PROXY_READ_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 21 | `PROXY_SEND_TIMEOUT` が設定されていない場合、起動に失敗すること |
| 22 | 必須の環境変数が複数設定されていない場合、最初の1件がログに出力されること |
