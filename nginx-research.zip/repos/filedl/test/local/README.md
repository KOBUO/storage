# ローカル試験環境 — ファイルダウンロード

`試験ケース_ファイルダウンロード_ローカル.md` の実施手順で使用する。

## 構成

| サービス | 役割 |
|---------|------|
| `app` | ファイルダウンロードの Nginx（`docker/nginx` をビルド）。`http://localhost:8081` で受け付ける |
| `s3stub` | S3 代替のスタブ。HTTPS で待ち受ける（実装が `proxy_ssl_verify on` のため TLS が必須） |

## 起動

```sh
docker compose up -d
PROXY_READ_TIMEOUT=1s docker compose up -d app    # 手順2
```

## スタブが返す内容

- `/bucket/hello.txt`・`/bucket/large.bin`（3MB） … 200
- `/offline/2.0.0/fixed.txt` … 200（オフラインダウンロード用）
- 存在しないキー … 404（S3 を模した XML）
- `/bucket/slow.bin` … 10秒後に応答（応答受信のタイムアウト用）
