-- テーブル定義書に基づくDDL。検証用データベースにテーブルが無い場合に使用する。
CREATE TABLE laif_routing_info (
    store_cd             character varying(6)   NOT NULL,
    request_context_path character varying(512) NOT NULL,
    request_ver          character varying(8)   NOT NULL,
    routing_dest_domain  character varying(255) NOT NULL,
    routing_dest_ver     character varying(8)   NOT NULL,
    appl_start_dt_tm     timestamp              NOT NULL,
    appl_end_dt_tm       timestamp,
    entry_dt_tm          timestamp              NOT NULL,
    creator_id           character varying(60)  NOT NULL,
    upd_dt_tm            timestamp,
    updater_id           character varying(60),
    PRIMARY KEY (store_cd, request_context_path, request_ver)
);

CREATE TABLE laif_default_routing (
    request_context_path character varying(512) NOT NULL,
    request_ver          character varying(8)   NOT NULL,
    appl_start_dt_tm     timestamp              NOT NULL,
    routing_dest_domain  character varying(255) NOT NULL,
    routing_dest_ver     character varying(8)   NOT NULL,
    entry_dt_tm          timestamp              NOT NULL,
    creator_id           character varying(60)  NOT NULL,
    upd_dt_tm            timestamp,
    updater_id           character varying(60),
    PRIMARY KEY (request_context_path, request_ver, appl_start_dt_tm)
);
