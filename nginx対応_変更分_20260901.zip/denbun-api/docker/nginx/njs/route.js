import routes from '/etc/nginx/njs/routes.js';

var STORE_CODE_HEADER = 'X-Store-Cd';

// message はログ出力用。generatedByNginx は error_page 経由で差し替える対象を示す。
var ERRORS = {
    store_code_missing: { status: 400, message: '店舗コードが設定されていません。' },
    route_not_found:    { status: 404, message: 'ルーティング先が特定できません。', generatedByNginx: true },
    request_invalid:    { status: 400, message: 'リクエストが不正です。', generatedByNginx: true },
    uri_too_long:       { status: 414, message: 'リクエストURIが上限を超えました。', generatedByNginx: true },
    version_unsupported:{ status: 505, message: '対応していない通信プロトコルです。', generatedByNginx: true },
    encoding_unsupported:{ status: 501, message: '対応していない転送符号化です。', generatedByNginx: true },
    body_too_large:     { status: 413, message: 'リクエストのサイズが上限を超えました。', generatedByNginx: true },
    limit_exceeded:     { status: 503, message: '同時接続数が上限を超えました。', generatedByNginx: true },
    backend_unreachable:{ status: 502, message: 'バックエンドサービスへ接続できません。', generatedByNginx: true },
    backend_timeout:    { status: 504, message: 'バックエンドサービスからの応答がタイムアウトしました。', generatedByNginx: true },
    internal_error:     { status: 500, message: 'サーバ内部でエラーが発生しました。', generatedByNginx: true },
};

var REASON_PHRASES = {
    400: 'Bad Request',
    404: 'Not Found',
    412: 'Precondition Failed',
    413: 'Payload Too Large',
    414: 'URI Too Long',
    500: 'Internal Server Error',
    501: 'Not Implemented',
    502: 'Bad Gateway',
    503: 'Service Unavailable',
    504: 'Gateway Timeout',
    505: 'HTTP Version Not Supported',
};

function nginxErrorCodeOf(status) {
    for (var code in ERRORS) {
        if (ERRORS[code].generatedByNginx && ERRORS[code].status === status) {
            return code;
        }
    }
    return null;
}

function respondError(r, code) {
    var error = ERRORS[code];
    var status = String(error.status);
    // ログ出力時に応答したエラーを参照できるよう保持する。
    r.variables.error_code = code;
    r.headersOut['Content-Type'] = 'application/json';
    r.return(error.status, JSON.stringify({
        apiStatus: status,
        errors: [{ validationErrCd: status, validationMessage: REASON_PHRASES[error.status] }],
    }));
}

// ルーティング先バージョンは URI にそのまま埋め込むため、URL安全な文字のみ許容する。
var DEST_VERSION_PATTERN = /^[0-9A-Za-z._-]+$/;

// 検索キーの構成要素はデコード済み URI から取り出す（DBのキーと突き合わせるため）。
function splitUri(uri) {
    var segments = uri.split('/').filter(function (segment) {
        return segment !== '';
    });
    if (segments.length < 2) {
        return null;
    }
    return { contextPath: segments[0], version: segments[1] };
}

// 転送先 URI はエンコードを保持するため、生の $request_uri を基に組み立てる。
// パスの2セグメント目（バージョン）だけをルーティング先バージョンへ置き換え、クエリは維持する。
function buildDestUri(rawRequestUri, version, destination) {
    var separator = rawRequestUri.indexOf('?');
    var rawPath = separator < 0 ? rawRequestUri : rawRequestUri.substring(0, separator);
    var rawQuery = separator < 0 ? '' : rawRequestUri.substring(separator);

    // 先頭・連続スラッシュを許容するため、非空セグメントの2番目（＝バージョン）を置き換える。
    var segments = rawPath.split('/');
    var seen = 0;
    for (var i = 0; i < segments.length; i++) {
        if (segments[i] === '') {
            continue;
        }
        seen++;
        if (seen === 2) {
            if (segments[i] !== version) {
                return null;
            }
            segments[i] = destination;
            return segments.join('/') + rawQuery;
        }
    }
    return null;
}

// 適用開始日時・適用終了日時はエポックミリ秒で保持される（終了日時ちょうどまで有効。null は無期限）。
function withinPeriod(entry, now) {
    if (entry.start !== null && now < entry.start) {
        return false;
    }
    if (entry.end !== null && now > entry.end) {
        return false;
    }
    return true;
}

// ルーティング先バージョンと転送先ドメインを返す。
function lookupDestination(storeCode, path) {
    var now = Date.now();

    var entry = routes.routing[storeCode + '|' + path.contextPath + '|' + path.version];
    if (entry && withinPeriod(entry, now)) {
        return entry;
    }

    // 適用開始日時の降順に並ぶ前提（loader が整列）。
    var entries = routes.default_routing[path.contextPath + '|' + path.version];
    if (entries) {
        for (var i = 0; i < entries.length; i++) {
            if (entries[i].start === null || entries[i].start <= now) {
                return entries[i];
            }
        }
    }
    return null;
}

function handle(r) {
    var storeCode = r.headersIn[STORE_CODE_HEADER];
    if (!storeCode) {
        respondError(r, 'store_code_missing');
        return;
    }

    var path = splitUri(r.uri);
    var destination = path ? lookupDestination(storeCode, path) : null;
    if (!destination || !DEST_VERSION_PATTERN.test(destination.dest) || !destination.domain) {
        respondError(r, 'route_not_found');
        return;
    }

    var destUri = buildDestUri(r.variables.request_uri, path.version, destination.dest);
    if (!destUri) {
        respondError(r, 'route_not_found');
        return;
    }
    r.variables.dest_uri = destUri;
    r.variables.dest_domain = destination.domain;
    r.internalRedirect('@backend');
}

// error_page からの呼び出し時点では r.status が未確定のため、$status から元の応答コードを取る。
function errorResponse(r) {
    var code = nginxErrorCodeOf(Number(r.variables.status));
    respondError(r, code || 'internal_error');
}

// error_page を経由できないステータス。ログの level は ERROR とし、次のメッセージを出力する。
// 408: クライアントからの受信がタイムアウトしたもの。Nginx が接続を閉じるため error_page を通らない。
// 上流の応答を受けた後に生成されるエラーも error_page を経由せず、上流が返したエラーと区別できない。
// 上流が返しうる範囲を超えるものだけをエラーとして扱う。
var UNINTERCEPTABLE_MESSAGES = {
    408: 'リクエストの受信がタイムアウトしました。',
    412: '想定外のエラーが発生しました。',
};

function uninterceptableMessage(r) {
    return UNINTERCEPTABLE_MESSAGES[Number(r.variables.status)] || null;
}

// クライアントへ 400 以上を返した場合は、発生元を問わず ERROR とする。
function isError(r) {
    return Number(r.variables.status) >= 400;
}

function logLevel(r) {
    return isError(r) ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    var code = r.variables.error_code;
    if (code) {
        return ERRORS[code].message;
    }
    var uninterceptable = uninterceptableMessage(r);
    if (uninterceptable) {
        return uninterceptable;
    }
    // 上流が返したエラー。加工せずそのまま返却するため、ログのみ出力する。
    return isError(r) ? 'バックエンドサービスがエラーを返却しました。' : '-';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { handle, errorResponse, logLevel, logMessage, logLatency, logTimestamp };
