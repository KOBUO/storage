import fs from 'fs';

var ERROR_PAGE = '/usr/share/nginx/html/error.html';
var errorPageBody = null;

// 静的ファイルの返却は PUT に応答できない（405 になる）ため、エラー画面は njs で返却する。
function errorPage(r) {
    if (errorPageBody === null) {
        errorPageBody = fs.readFileSync(ERROR_PAGE);
    }
    r.headersOut['Content-Type'] = 'text/html';
    r.headersOut['Cache-Control'] = 'no-cache';
    r.return(Number(r.variables.status), errorPageBody);
}

var ERROR_MESSAGES = {
    400: 'リクエストが不正です。',
    403: 'アクセスが拒否されました。',
    404: 'ファイルが見つかりません。',
    405: '許可されていないメソッドです。',
    408: 'リクエストの受信がタイムアウトしました。',
    412: '事前条件が成立しません。',
    413: 'リクエストのサイズが上限を超えました。',
    414: 'リクエストURIが上限を超えました。',
    416: '範囲指定が不正です。',
    500: 'サーバ内部でエラーが発生しました。',
    501: '対応していない転送符号化です。',
    502: 'S3 へ接続できません。',
    503: '同時接続数が上限を超えました。',
    504: 'S3 からの応答がタイムアウトしました。',
    505: '対応していない通信プロトコルです。',
};

// クライアントへ 400 以上を返した場合は、発生元を問わず ERROR とする。
// error_page を経由しないもの（S3 の応答、408 など）も対象に含める。
function isError(r) {
    return Number(r.variables.status) >= 400;
}

function logLevel(r) {
    return isError(r) ? 'ERROR' : 'INFO';
}

function logMessage(r) {
    if (!isError(r)) {
        return '-';
    }
    return ERROR_MESSAGES[Number(r.variables.status)] || '想定外のエラーが発生しました。';
}

// $request_time は秒（小数3桁）のため、ミリ秒へ変換する。
function logLatency(r) {
    return String(Math.round(Number(r.variables.request_time) * 1000));
}

// ログのタイムスタンプ書式 yyyy-MM-dd HH:mm:ss.SSS を組み立てる。
// $time_iso8601 はローカル時刻だがミリ秒を持たないため、$msec の小数部を補う。
function logTimestamp(r) {
    var localTime = r.variables.time_iso8601;
    var milliseconds = r.variables.msec.split('.')[1];
    return localTime.slice(0, 10) + ' ' + localTime.slice(11, 19) + '.' + milliseconds;
}

export default { errorPage, logLevel, logMessage, logLatency, logTimestamp };
